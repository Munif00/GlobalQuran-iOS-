/**
 * Global Quran — iOS project structural verification.
 *
 * Runs in Bun on any platform (this is the verification that CAN be
 * executed without macOS/Xcode). It validates:
 *
 *  1. project.pbxproj integrity — balanced braces, every referenced
 *     UUID resolves to a defined object, every target has its required
 *     build phases, the test target is wired (dependency, scheme,
 *     TEST_HOST), versions are 2.0.2/9 everywhere.
 *  2. Info.plist and PrivacyInfo.xcprivacy parse as valid plists and
 *     contain every required key/permission declaration.
 *  3. capacitor.config.json packageClassList contains the four custom
 *     plugins, and each plugin Swift file declares @objc(<name>) plus
 *     EVERY method the shared TypeScript contract requires (name-level
 *     cross-check: TS interface methods vs Swift @objc methods).
 *  4. The asset catalogs: AppIcon 1024x1024 present, splash images
 *     present, all files referenced by Contents.json exist.
 *  5. The web bundle (native/www) is present with its index.html.
 *  6. The shared web adapter gates that protect Android behavior are
 *     in place (no regression in the platform branches).
 *
 * It does NOT (and honestly does not claim to) compile Swift, run
 * XCTest, or verify device behavior — those require Xcode and are
 * documented in the test plan.
 */

import { readFileSync, existsSync, statSync } from 'node:fs'
import { resolve } from 'node:path'
import { execSync } from 'node:child_process'

const repoRoot = resolve(import.meta.dirname, '..')
const iosRoot = resolve(repoRoot, 'ios')
const pbxPath = resolve(iosRoot, 'App/App.xcodeproj/project.pbxproj')

let failures = 0
let checks = 0

function ok(condition: boolean, message: string, detail?: string): void {
  checks++
  if (condition) {
    console.log(`  PASS  ${message}${detail ? ` — ${detail}` : ''}`)
  } else {
    failures++
    console.error(`  FAIL  ${message}${detail ? ` — ${detail}` : ''}`)
  }
}

// ---------------------------------------------------------------------------
// 1. pbxproj structural validation
// ---------------------------------------------------------------------------
console.log('\n[i] project.pbxproj integrity')

const pbx = readFileSync(pbxPath, 'utf8')

{
  // Brace balance.
  let depth = 0
  let inString = false
  let escaped = false
  for (const char of pbx) {
    if (escaped) { escaped = false; continue }
    if (char === '\\') { escaped = true; continue }
    if (char === '"') { inString = !inString; continue }
    if (inString) continue
    if (char === '{') depth++
    if (char === '}') depth--
    if (depth < 0) break
  }
  ok(depth === 0 && !inString, 'pbxproj braces balanced')
}

{
  // Every 24-hex UUID mentioned inside comments/refs resolves to a
  // defined top-level object.
  const objectBodies = pbx.split(/\n\s{16}(?=[0-9A-F]{24} \/\*)/) // objects inside the objects map
  const defined = new Set(
    [...pbx.matchAll(/^\s*([0-9A-F]{24}) \/\*.*\*\/ = \{/gm)].map((m) => m[1]),
  )
  // Also accept objects in nested sections (TargetAttributes ids are
  // defined elsewhere; those are references only).
  const referenced = new Set(
    [...pbx.matchAll(/([0-9A-F]{24}) \/\*/g)].map((m) => m[1]),
  )
  const missing: string[] = []
  for (const id of referenced) {
    if (!defined.has(id)) missing.push(id)
  }
  ok(missing.length === 0, 'all referenced UUIDs resolve to defined objects', missing.length ? `missing: ${missing.join(', ')}` : `${referenced.size} unique ids`)
}

{
  // Required targets and wiring.
  ok(pbx.includes('productType = "com.apple.product-type.application"'), 'App target present')
  ok(pbx.includes('productType = "com.apple.product-type.bundle.unit-test"'), 'CapAppTests unit-test target present')
  ok(pbx.includes('TestTargetID = 504EC3031FED79650016851F'), 'test target hosted by App (TestTargetID)')
  ok(pbx.includes('TEST_HOST = "$(BUILT_PRODUCTS_DIR)/App.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/App"'), 'TEST_HOST points at the app')
  ok((pbx.match(/CURRENT_PROJECT_VERSION = 9;/g) ?? []).length === 4, 'CURRENT_PROJECT_VERSION = 9 in all 4 configurations', `${(pbx.match(/CURRENT_PROJECT_VERSION = 9;/g) ?? []).length}/4`)
  ok((pbx.match(/MARKETING_VERSION = 2\.0\.2;/g) ?? []).length === 4, 'MARKETING_VERSION = 2.0.2 in all 4 configurations', `${(pbx.match(/MARKETING_VERSION = 2\.0\.2;/g) ?? []).length}/4`)
  ok((pbx.match(/PRODUCT_BUNDLE_IDENTIFIER = com\.globalquran\.app;/g) ?? []).length === 2, 'App bundle id com.globalquran.app (both configs)')
  ok(pbx.includes('/* PrivacyInfo.xcprivacy in Resources */'), 'PrivacyInfo.xcprivacy in App Resources')
  ok(pbx.includes('IPHONEOS_DEPLOYMENT_TARGET = 15.0;'), 'iOS deployment target 15.0')
  for (const testFile of [
    'AdhanModelsTests.swift',
    'AdhanQuietHoursTests.swift',
    'AdhanSanitizerAndStoreTests.swift',
    'TtsBridgeMappingTests.swift',
    'DeviceBridgeMappingTests.swift',
  ]) {
    ok(pbx.includes(`/* ${testFile} in Sources */`), `${testFile} in test target Sources`)
    ok(existsSync(resolve(iosRoot, 'App/AppTests', testFile)), `${testFile} exists on disk`)
  }
}

// ---------------------------------------------------------------------------
// 2. Plists
// ---------------------------------------------------------------------------
console.log('\n[ii] Info.plist / PrivacyInfo.xcprivacy')

function parsePlist(path: string): Record<string, unknown> | null {
  try {
    const xml = readFileSync(path, 'utf8')
    const out = execSync(
      `python3 -c "import plistlib,sys,json; print(json.dumps(plistlib.loads(sys.stdin.read().encode())))"`,
      { input: xml, encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] },
    )
    return JSON.parse(out) as Record<string, unknown>
  } catch {
    return null
  }
}

const infoPlist = parsePlist(resolve(iosRoot, 'App/App/Info.plist'))
ok(infoPlist !== null, 'Info.plist parses as a valid plist')
if (infoPlist) {
  ok(infoPlist['CFBundleDisplayName'] === 'Global Quran', 'CFBundleDisplayName = Global Quran')
  ok(typeof infoPlist['NSLocationWhenInUseUsageDescription'] === 'string'
    && (infoPlist['NSLocationWhenInUseUsageDescription'] as string).length > 20,
  'NSLocationWhenInUseUsageDescription present (location permission)')
  ok(typeof infoPlist['NSMotionUsageDescription'] === 'string', 'NSMotionUsageDescription present (Qibla compass)')
  ok(JSON.stringify(infoPlist['UIBackgroundModes']) === JSON.stringify(['audio']), 'UIBackgroundModes = [audio] (background recitation)')
  ok(infoPlist['ITSAppUsesNonExemptEncryption'] === false, 'ITSAppUsesNonExemptEncryption = false (honest export compliance)')
  const orientations = infoPlist['UISupportedInterfaceOrientations'] as string[] | undefined
  ok(Array.isArray(orientations) && orientations.includes('UIInterfaceOrientationPortrait') && orientations.length >= 3,
    'iPhone orientations: portrait + landscape')
  const ipadOrientations = infoPlist['UISupportedInterfaceOrientations~ipad'] as string[] | undefined
  ok(Array.isArray(ipadOrientations) && ipadOrientations.length === 4, 'iPad supports all four orientations')
}

const privacy = parsePlist(resolve(iosRoot, 'App/App/PrivacyInfo.xcprivacy'))
ok(privacy !== null, 'PrivacyInfo.xcprivacy parses as a valid plist')
if (privacy) {
  ok(privacy['NSPrivacyTracking'] === false, 'NSPrivacyTracking = false (no tracking)')
  ok(JSON.stringify(privacy['NSPrivacyTrackingDomains']) === JSON.stringify([]), 'no tracking domains')
  const collected = privacy['NSPrivacyCollectedDataTypes'] as Array<Record<string, unknown>> | undefined
  ok(Array.isArray(collected) && collected.length === 1
    && collected[0]['NSPrivacyCollectedDataType'] === 'NSPrivacyCollectedDataTypePreciseLocation'
    && collected[0]['NSPrivacyCollectedDataTypeTracking'] === false,
  'collected data: precise location only, app-functionality, not tracking (honest declaration)')
  const apiTypes = privacy['NSPrivacyAccessedAPITypes'] as Array<Record<string, unknown>> | undefined
  ok(Array.isArray(apiTypes) && apiTypes.some((t) => t['NSPrivacyAccessedAPIType'] === 'NSPrivacyAccessedAPICategoryUserDefaults'),
    'required-reason API: UserDefaults declared')
}

// ---------------------------------------------------------------------------
// 3. Plugin registration + contract cross-check
// ---------------------------------------------------------------------------
console.log('\n[iii] native plugins vs the shared TypeScript contracts')

const capConfig = JSON.parse(readFileSync(resolve(iosRoot, 'App/App/capacitor.config.json'), 'utf8')) as {
  packageClassList?: string[]
}
const expectedPlugins = ['AdhanSchedulerPlugin', 'DeviceBridgePlugin', 'TtsBridgePlugin', 'AudioSessionBridgePlugin']
for (const plugin of expectedPlugins) {
  ok(capConfig.packageClassList?.includes(plugin) === true, `packageClassList includes ${plugin}`)
}

function swiftMethods(path: string): { classAnnotation: string | null; methods: string[] } {
  const body = readFileSync(path, 'utf8')
  const classAnnotation = body.match(/@objc\(([A-Za-z0-9_-]+)\)/)?.[1] ?? null
  const methods = [...body.matchAll(/func (\w+)\(_ call: CAPPluginCall\)/g)].map((m) => m[1])
  const pluginMethodNames = [...body.matchAll(/CAPPluginMethod\(name: "(\w+)"/g)].map((m) => m[1])
  return { classAnnotation, methods: [...new Set([...methods, ...pluginMethodNames])] }
}

const pluginsDir = resolve(iosRoot, 'App/CapApp-SPM/Sources/CapApp-SPM/plugins')

// The methods each shared TS contract requires (source of truth:
// src/services/native/*.ts). playMirrored/stopMirroredPlayback are the
// documented iOS extensions of the AdhanScheduler contract.
const contracts: Record<string, string[]> = {
  AdhanSchedulerPlugin: [
    'sync', 'status', 'requestNotificationPermission', 'beginFile', 'writeFileChunk',
    'finalizeFile', 'deleteFile', 'listFiles', 'debugFireNext', 'playMirrored', 'stopMirroredPlayback',
  ],
  DeviceBridgePlugin: ['isLocationServiceEnabled', 'isAvailable', 'openLocationSettings', 'getPermissionState'],
  TtsBridgePlugin: [
    'getStatus', 'getVoices', 'isLanguageAvailable', 'speak', 'stop',
    'pauseSupported', 'openTtsSettings',
  ],
  AudioSessionBridgePlugin: ['setPlaybackActive', 'isPlaybackActive'],
}

for (const [name, required] of Object.entries(contracts)) {
  const path = resolve(pluginsDir, `${name}.swift`)
  if (!existsSync(path)) {
    ok(false, `${name}.swift exists`)
    continue
  }
  const { classAnnotation, methods } = swiftMethods(path)
  ok(classAnnotation === name, `${name}.swift declares @objc(${name})`, classAnnotation ?? 'missing')
  const missing = required.filter((method) => !methods.includes(method))
  ok(missing.length === 0, `${name} implements every contract method`, missing.length ? `missing: ${missing.join(', ')}` : `${required.length} methods`)
}

// Plugin files must not touch the UNUserNotificationCenter delegate
// directly (Capacitor's NotificationRouter owns it).
{
  const adhanBody = readFileSync(resolve(pluginsDir, 'AdhanSchedulerPlugin.swift'), 'utf8')
  ok(!adhanBody.includes('UNUserNotificationCenter.current().delegate'),
    'AdhanSchedulerPlugin does not steal the UNUserNotificationCenter delegate (routes via NotificationRouter)')
  ok(adhanBody.includes('localNotificationHandler = self'),
    'AdhanSchedulerPlugin registers as the router\'s localNotificationHandler')
  ok(adhanBody.includes('eventForegroundFire = "foregroundFire"'), 'foregroundFire event name literal')
  ok(!adhanBody.includes('.withVolume('), 'notification sound avoids unsupported per-notification volume API')
  ok(adhanBody.includes('UNNotificationSound(named: UNNotificationSoundName'), 'short mirrored notification sound remains supported')
  ok(adhanBody.includes('let userInfo: [AnyHashable: Any] = note.userInfo ?? [:]'),
    'audio interruption userInfo is normalized to a non-optional dictionary before subscripting')
  ok(adhanBody.includes('AVAudioSession.InterruptionType(rawValue: rawType)'),
    'audio interruption raw value is validated before constructing the interruption type')
}

// ---------------------------------------------------------------------------
// 4. Asset catalogs
// ---------------------------------------------------------------------------
console.log('\n[iv] asset catalogs (original 2.0.x brand)')

const appIconDir = resolve(iosRoot, 'App/App/Assets.xcassets/AppIcon.appiconset')
const appIconJson = JSON.parse(readFileSync(resolve(appIconDir, 'Contents.json'), 'utf8')) as {
  images: Array<{ filename?: string; size: string; platform?: string }>
}
{
  const iconEntry = appIconJson.images.find((image) => image.size === '1024x1024')
  ok(iconEntry?.filename !== undefined, 'AppIcon has a 1024x1024 entry')
  if (iconEntry?.filename) {
    const iconPath = resolve(appIconDir, iconEntry.filename)
    ok(existsSync(iconPath), 'AppIcon 1024 file exists', iconEntry.filename)
    // Verify square 1024 via PNG header (IHDR) — no image libs needed.
    const png = readFileSync(iconPath)
    const width = png.readUInt32BE(16)
    const height = png.readUInt32BE(20)
    ok(width === 1024 && height === 1024, 'AppIcon is exactly 1024x1024', `${width}x${height}`)
    const sourceIcon = readFileSync(resolve(repoRoot, 'native-assets/icon.png'))
    const sourceW = sourceIcon.readUInt32BE(16)
    ok(sourceW === 1024, 'native-assets source icon is 1024 wide (brand source of truth)')
  }
}

{
  const splashDir = resolve(iosRoot, 'App/App/Assets.xcassets/Splash.imageset')
  const splashJson = JSON.parse(readFileSync(resolve(splashDir, 'Contents.json'), 'utf8')) as {
    images: Array<{ filename?: string }>
  }
  const files = splashJson.images.map((image) => image.filename).filter(Boolean) as string[]
  ok(files.length >= 2, 'Splash imageset has entries', `${files.length} files`)
  const missing = files.filter((file) => !existsSync(resolve(splashDir, file)))
  ok(missing.length === 0, 'all splash files referenced by Contents.json exist', missing.length ? `missing: ${missing.join(', ')}` : '')
}

// ---------------------------------------------------------------------------
// 5. Web bundle + shared adapter protections
// ---------------------------------------------------------------------------
console.log('\n[v] web bundle and Android-protection gates')

ok(existsSync(resolve(repoRoot, 'native/www/index.html')), 'native/www static export present (shared iOS/Android bundle)')
ok(existsSync(resolve(iosRoot, 'App/App/public/index.html')), 'web bundle copied into the iOS app (ios/App/App/public)')

{
  const backButton = readFileSync(resolve(repoRoot, 'src/services/navigation/back-button.ts'), 'utf8')
  ok(backButton.includes("Capacitor.getPlatform() === 'android'"), 'Android back-button controller still gated to android only (iOS untouched)')
  const nativeMode = readFileSync(resolve(repoRoot, 'src/services/platform/native-mode.ts'), 'utf8')
  ok(nativeMode.includes('isNativeAdapterActive'), 'native adapter detection unchanged')
}

// This iOS source archive may intentionally omit the Android project.
// If Android sources are present in a full repository, verify their release
// identity without modifying them. Otherwise report an explicit skip.
{
  const gradlePath = resolve(repoRoot, 'android/app/build.gradle')
  if (existsSync(gradlePath)) {
    const gradle = readFileSync(gradlePath, 'utf8')
    ok(gradle.includes('versionCode 9') && gradle.includes('versionName "2.0.2"'), 'Android build.gradle still 2.0.2 / code 9 (read-only verification)')
  } else {
    console.log('  SKIP  Android project not included in this iOS-only source archive; no Android files were changed')
  }
}

// ---------------------------------------------------------------------------
// 6. Scheme + sync script
// ---------------------------------------------------------------------------
console.log('\n[vi] test scheme and sync tooling')

{
  const schemePath = resolve(iosRoot, 'App/App.xcodeproj/xcshareddata/xcschemes/App.xcscheme')
  ok(existsSync(schemePath), 'shared App.xcscheme exists (xcodebuild test works out of the box)')
  const scheme = readFileSync(schemePath, 'utf8')
  ok(scheme.includes('CapAppTests.xctest') && scheme.includes('<TestAction'), 'scheme runs CapAppTests')
  const syncScript = resolve(repoRoot, 'scripts/sync-ios.mjs')
  ok(existsSync(syncScript), 'scripts/sync-ios.mjs exists (cap sync wrapper that preserves custom plugin registration)')
  const packageJson = JSON.parse(readFileSync(resolve(repoRoot, 'package.json'), 'utf8')) as Record<string, unknown>
  const scripts = packageJson['scripts'] as Record<string, string>
  ok(scripts && typeof scripts['sync:ios'] === 'string', 'package.json exposes bun run sync:ios')
}

// ---------------------------------------------------------------------------
console.log(`\n=== verify-ios-project: ${checks - failures}/${checks} checks passed ===`)
if (failures > 0) {
  console.error(`FAILED: ${failures} check(s) failed`)
  process.exit(1)
}
console.log('All structural checks passed. (Swift compilation, XCTest execution, and on-device behavior require macOS + Xcode — see ios/IOS-TEST-PLAN.md.)')
