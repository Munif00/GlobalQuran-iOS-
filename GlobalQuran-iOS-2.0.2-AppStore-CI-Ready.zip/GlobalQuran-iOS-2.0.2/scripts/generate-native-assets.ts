#!/usr/bin/env bun
/**
 * Global Quran - Capacitor asset source generator.
 *
 * Renders the brand assets (identical geometry to the PWA icon set - see
 * scripts/generate-mobile-assets.mjs) at the sizes @capacitor/assets needs:
 *
 * - native-assets/icon.png             1024x1024 full-bleed logo mark
 * - native-assets/icon-foreground.png  1024x1024 adaptive-icon foreground
 *                                      (gold star inside the safe zone,
 *                                      transparent background)
 * - native-assets/icon-background.png  1024x1024 solid emerald layer
 * - native-assets/splash.png           2732x2732 light splash (logo centered)
 * - native-assets/splash-dark.png      2732x2732 dark splash
 *
 * Run: bun run scripts/generate-native-assets.mjs
 * Then: bunx @capacitor/assets generate --android --assetPath native-assets
 */

import sharp from 'sharp'
import { mkdirSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const OUT = resolve(ROOT, 'native-assets')

/** Brand palette (kept in sync with globals.css + the PWA icon set). */
const EMERALD = '#0d6a4a'
const GOLD = '#c9a24b'
const LIGHT_BG = '#faf8f3'
const DARK_BG = '#171d1a'

mkdirSync(OUT, { recursive: true })

/** Full logo mark: emerald rounded square + gold Rub el Hizb star. */
function logoMarkSvg(size: number, radiusRatio = 14 / 64): Buffer {
  const r = 64 * radiusRatio
  return Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 64 64">
  <rect x="0" y="0" width="64" height="64" rx="${r.toFixed(2)}" fill="${EMERALD}"/>
  <g fill="none" stroke="${GOLD}" stroke-width="3" stroke-linejoin="round" opacity="0.95">
    <rect x="18" y="18" width="28" height="28" rx="2"/>
    <rect x="18" y="18" width="28" height="28" rx="2" transform="rotate(45 32 32)"/>
  </g>
  <circle cx="32" cy="32" r="4.5" fill="${GOLD}"/>
</svg>`,
  )
}

/** Gold star glyph alone (transparent background), inside a size canvas. */
function starGlyphLayerSvg(canvas: number, glyphFraction: number): Buffer {
  const glyph = canvas * glyphFraction
  const offset = (canvas - glyph) / 2
  return Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${canvas}" height="${canvas}" viewBox="0 0 ${canvas} ${canvas}">
  <g transform="translate(${offset} ${offset}) scale(${glyph / 64})">
    <g fill="none" stroke="${GOLD}" stroke-width="3.2" stroke-linejoin="round" opacity="0.95">
      <rect x="18" y="18" width="28" height="28" rx="2"/>
      <rect x="18" y="18" width="28" height="28" rx="2" transform="rotate(45 32 32)"/>
    </g>
    <circle cx="32" cy="32" r="4.8" fill="${GOLD}"/>
  </g>
</svg>`,
  )
}

/** Splash: brand background with the logo mark centered. */
function splashSvg(size: number, background: string, logoFraction: number): Buffer {
  const logo = Math.round(size * logoFraction)
  const offset = Math.round((size - logo) / 2)
  const r = (14 / 64) * logo
  return Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect width="${size}" height="${size}" fill="${background}"/>
  <g transform="translate(${offset} ${offset})">
    <rect width="${logo}" height="${logo}" rx="${r.toFixed(0)}" fill="${EMERALD}"/>
    <g transform="scale(${logo / 64})">
      <g fill="none" stroke="${GOLD}" stroke-width="3" stroke-linejoin="round" opacity="0.95">
        <rect x="18" y="18" width="28" height="28" rx="2"/>
        <rect x="18" y="18" width="28" height="28" rx="2" transform="rotate(45 32 32)"/>
      </g>
      <circle cx="32" cy="32" r="4.5" fill="${GOLD}"/>
    </g>
  </g>
</svg>`,
  )
}

/* 1) Legacy icon: full-bleed logo mark at 1024. */
await sharp(logoMarkSvg(1024)).png({ compressionLevel: 9 }).toFile(resolve(OUT, 'icon.png'))
console.log('created native-assets/icon.png')

/* 2) Adaptive icon foreground: gold star at 42% of the canvas (well inside
 *    the Android adaptive safe zone), transparent elsewhere. */
await sharp(starGlyphLayerSvg(1024, 0.42))
  .png({ compressionLevel: 9 })
  .toFile(resolve(OUT, 'icon-foreground.png'))
console.log('created native-assets/icon-foreground.png')

/* 3) Adaptive icon background: solid emerald layer. */
await sharp({
  create: {
    width: 1024,
    height: 1024,
    channels: 4,
    background: { r: 13, g: 106, b: 74, alpha: 1 },
  },
})
  .png({ compressionLevel: 9 })
  .toFile(resolve(OUT, 'icon-background.png'))
console.log('created native-assets/icon-background.png')

/* 4) Splash screens (light + dark), 2732x2732, logo at 20%. */
await sharp(splashSvg(2732, LIGHT_BG, 0.2)).png({ compressionLevel: 9 }).toFile(resolve(OUT, 'splash.png'))
console.log('created native-assets/splash.png')
await sharp(splashSvg(2732, DARK_BG, 0.2))
  .png({ compressionLevel: 9 })
  .toFile(resolve(OUT, 'splash-dark.png'))
console.log('created native-assets/splash-dark.png')

console.log('done.')
