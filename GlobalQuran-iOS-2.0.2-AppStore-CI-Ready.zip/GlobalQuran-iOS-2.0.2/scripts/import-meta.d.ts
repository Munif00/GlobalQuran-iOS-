/**
 * Ambient typing for Bun's `import.meta.dir` (used by the i18n tooling
 * scripts, which run exclusively under Bun). Without this declaration the
 * Next.js build-time type check rejects scripts/i18n/* and the NATIVE
 * static export fails to compile (verified: PROMPT 16 build breakage).
 *
 * The declaration is additive only - no browser code ever reads
 * `import.meta.dir`; the field is simply never flagged as unknown here.
 */

declare global {
  interface ImportMeta {
    readonly dir: string
  }
}

export {}
