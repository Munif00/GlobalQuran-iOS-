#!/usr/bin/env node
/**
 * Global Quran — iOS platform sync script.
 *
 * Wraps `npx cap sync ios` and re-appends the app's CUSTOM plugin
 * classes to ios/App/App/capacitor.config.json's packageClassList.
 *
 * Why this exists: Capacitor's CLI regenerates packageClassList from
 * the INSTALLED npm plugins only (node_modules/@capacitor/cli/dist/util/
 * iosplugin.js: writePluginJSON overwrites the key). The four custom
 * Global Quran plugins live in the CapApp-SPM Swift package
 * (ios/App/CapApp-SPM/Sources/CapApp-SPM/plugins/) and are registered
 * at runtime through the same list — CapacitorBridge.registerPlugins()
 * resolves every entry with NSClassFromString (the @objc(PluginName)
 * annotations expose exactly these names).
 *
 * Always use `bun run scripts/sync-ios.mjs` instead of raw
 * `npx cap sync ios` in this repository. (Android is unaffected —
 * `npx cap sync android` needs no wrapper; its plugins are registered
 * from MainActivity, exactly as before.)
 */

import { execSync } from 'node:child_process'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'

const repoRoot = resolve(import.meta.dirname, '..')
const capConfigPath = resolve(repoRoot, 'ios/App/App/capacitor.config.json')

/** Custom native plugins shipped in the CapApp-SPM package. */
const CUSTOM_PLUGIN_CLASSES = [
  'AdhanSchedulerPlugin',
  'DeviceBridgePlugin',
  'TtsBridgePlugin',
  'AudioSessionBridgePlugin',
]

function fail(message) {
  console.error(`[sync-ios] FAIL: ${message}`)
  process.exit(1)
}

// 1. Standard Capacitor sync (copies native/www -> ios/App/App/public,
//    regenerates capacitor.config.json + Package.swift from the config).
console.log('[sync-ios] running npx cap sync ios ...')
try {
  execSync('npx cap sync ios', { cwd: repoRoot, stdio: 'inherit' })
} catch (error) {
  fail(`npx cap sync ios failed (exit ${error.status}). Build native/www first: bun run scripts/build-native.mjs`)
}

// 2. Patch packageClassList with the custom plugin classes.
if (!existsSync(capConfigPath)) {
  fail(`missing ${capConfigPath} — did cap sync run in the right project?`)
}
let capConfig
try {
  capConfig = JSON.parse(readFileSync(capConfigPath, 'utf8'))
} catch (error) {
  fail(`cannot parse capacitor.config.json: ${error.message}`)
}

const existing = Array.isArray(capConfig.packageClassList) ? capConfig.packageClassList : []
const merged = [...existing]
for (const className of CUSTOM_PLUGIN_CLASSES) {
  if (!merged.includes(className)) merged.push(className)
}
capConfig.packageClassList = merged

writeFileSync(capConfigPath, JSON.stringify(capConfig, null, '\t') + '\n')

const added = merged.filter((name) => !existing.includes(name))
console.log(`[sync-ios] packageClassList: ${merged.length} entries${added.length ? ` (added: ${added.join(', ')})` : ''}`)

// 3. Sanity gates (fail loudly rather than ship a broken project).
for (const name of CUSTOM_PLUGIN_CLASSES) {
  const relative = `ios/App/CapApp-SPM/Sources/CapApp-SPM/plugins/${name}.swift`
  const full = resolve(repoRoot, relative)
  if (!existsSync(full)) fail(`plugin source missing: ${relative}`)
  const body = readFileSync(full, 'utf8')
  if (!body.includes(`@objc(${name})`)) {
    fail(`${relative} does not declare @objc(${name}) — the class would not be discoverable via NSClassFromString`)
  }
}

console.log('[sync-ios] done — ios platform is ready for Xcode.')
