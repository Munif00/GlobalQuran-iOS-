#!/usr/bin/env bun
/**
 * Global Quran - Native app static-export build.
 *
 * Produces the fully static web bundle (out/) that the Capacitor Android/iOS
 * app ships inside its WebView:
 *
 *  1. The Next.js API routes are moved aside (a static export cannot
 *     contain server routes; the native app replaces them with the
 *     client-side adapter in src/services/native/).
 *  2. `NATIVE_BUILD=1 next build` runs with output:'export' and an isolated
 *     distDir (.next-native), so a concurrently running dev server on
 *     port 3000 is never disturbed.
 *  3. The API routes are restored (always, even on failure).
 *  4. The export is synced into the Capacitor web dir (native/www).
 *
 * Usage: bun run scripts/build-native.mjs
 */

import { execSync } from 'node:child_process'
import { existsSync, mkdirSync, renameSync, rmSync, cpSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const apiDir = join(root, 'src', 'app', 'api')
const stagingDir = join(root, '.native-build-tmp')
const stagingApi = join(stagingDir, 'api')
const wwwDir = join(root, 'native', 'www')

/* Next 16 with a custom distDir writes the export INTO the distDir; older
 * versions wrote it to out/. Resolved AFTER the build. */
function resolveExportDir() {
  if (existsSync(join(root, '.next-native', 'index.html'))) return join(root, '.next-native')
  return join(root, 'out')
}

function fail(message) {
  console.error(`[build-native] ${message}`)
  process.exitCode = 1
}

if (!existsSync(apiDir)) {
  if (existsSync(stagingApi)) {
    fail('src/app/api is missing but a staged copy exists - restore it first (a previous build failed mid-way).')
  } else {
    fail('src/app/api not found.')
  }
}

mkdirSync(stagingDir, { recursive: true })

/* 1. Move the API routes aside for the static export. */
console.log('[build-native] staging src/app/api aside ...')
renameSync(apiDir, stagingApi)

let buildOk = false
let outDir = join(root, 'out')
try {
  /* 2. Static export build. */
  console.log('[build-native] running NATIVE_BUILD=1 next build (output: export) ...')
  execSync('npx next build', {
    cwd: root,
    stdio: 'inherit',
    env: { ...process.env, NATIVE_BUILD: '1' },
  })
  outDir = resolveExportDir()
  buildOk = existsSync(join(outDir, 'index.html'))
  if (!buildOk) fail('export did not produce index.html')
} catch (error) {
  fail(`next build failed: ${String(error).slice(0, 400)}`)
} finally {
  /* 3. Always restore the API routes. */
  console.log('[build-native] restoring src/app/api ...')
  renameSync(stagingApi, apiDir)
}

if (!buildOk) process.exit(process.exitCode || 1)

/* 4. Sync into the Capacitor web dir. */
console.log(`[build-native] syncing ${outDir} -> native/www ...`)
rmSync(wwwDir, { recursive: true, force: true })
mkdirSync(join(root, 'native'), { recursive: true })
cpSync(outDir, wwwDir, { recursive: true })
/* The web-only APK delivery folder must never be packaged inside the app
 * itself (the app does not need to download itself). */
rmSync(join(wwwDir, 'downloads'), { recursive: true, force: true })

console.log('[build-native] done: native/www is ready for `npx cap sync android`.')
