/**
 * Qibla mathematics.
 *
 * Real great-circle computations - the Qibla bearing is only ever displayed
 * when the user's actual location is known. No invented values.
 *
 * Kaaba coordinate verification (2026-11-15):
 * - The value below is the centroid of the actual Kaaba building footprint,
 *   OpenStreetMap way 103914569 (name: الكعبة, amenity=place_of_worship),
 *   retrieved live via the OpenStreetMap Nominatim API
 *   (https://nominatim.openstreetmap.org/search?q=Kaaba,+Mecca&polygon_geojson=1)
 *   - 5 corner nodes: (21.4225371, 39.8261095), (21.4224468, 39.8261735),
 *     (21.4224985, 39.8262546), (21.4225173, 39.8262411), (21.4225861,
 *     39.8261922); centroid (21.4225172, 39.8261942).
 * - Cross-checked against the Wikipedia Kaaba article coordinates
 *   21°25′21.15″N 39°49′34.10″E = (21.4225417, 39.8261389) - agreement
 *   within ~6 m.
 * - A frequently copied internet value (21.4224779, 39.8251832) lies ~100 m
 *   west of the surveyed building. The bearing difference from any point
 *   more than ~2 km away is below 0.01°, but the surveyed value is used.
 *
 * Bearing formula: initial great-circle bearing (forward azimuth) on a
 * sphere, θ = atan2(sin Δλ · cos φ₂, cos φ₁ · sin φ₂ − sin φ₁ · cos φ₂ ·
 * cos Δλ), normalized to 0-360°. Verified in scripts/verify-qibla.ts
 * against an independent ECEF-vector implementation and published city
 * Qibla values.
 */

/** Verified coordinates of the Kaaba, Makkah (see header for the evidence). */
export const KAABA_COORDINATES = {
  latitude: 21.4225172,
  longitude: 39.8261942,
} as const

/** Where the Kaaba coordinate comes from - surfaced in the UI for transparency. */
export const KAABA_COORDINATE_SOURCE =
  'OpenStreetMap way 103914569 (Kaaba building footprint), verified 2026-11-15'

const EARTH_RADIUS_KM = 6371

function toRadians(degrees: number): number {
  return (degrees * Math.PI) / 180
}

function toDegrees(radians: number): number {
  return (radians * 180) / Math.PI
}

/* ------------------------------------------------------------------ */
/* Input validation                                                    */
/* ------------------------------------------------------------------ */

/** A geodetic coordinate is valid when finite and within its real range. */
export function isValidLatitude(latitude: number): boolean {
  return Number.isFinite(latitude) && latitude >= -90 && latitude <= 90
}

export function isValidLongitude(longitude: number): boolean {
  return Number.isFinite(longitude) && longitude >= -180 && longitude <= 180
}

/** Why a Qibla computation cannot be performed for the given inputs. */
export type QiblaInputProblem =
  | 'missing_coordinates'
  | 'invalid_latitude'
  | 'invalid_longitude'
  | 'zero_accuracy_impossible'
  | 'inside_kaaba'

/** Validation outcome for Qibla inputs. */
export interface QiblaValidation {
  ok: boolean
  problem: QiblaInputProblem | null
}

/**
 * Validate coordinates before any Qibla math runs on them.
 *
 * `accuracyMeters` (from the Geolocation API, when available) is only
 * rejected when it is absurdly poor (>= 100 km) - a Qibla bearing from a
 * 100 km-wide position circle is meaningless for pointing a compass.
 */
export function validateQiblaInputs(
  latitude: number | null,
  longitude: number | null,
  accuracyMeters?: number | null,
): QiblaValidation {
  if (latitude == null || longitude == null) {
    return { ok: false, problem: 'missing_coordinates' }
  }
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
    return { ok: false, problem: 'invalid_latitude' }
  }
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    return { ok: false, problem: 'invalid_longitude' }
  }
  if (accuracyMeters != null && Number.isFinite(accuracyMeters) && accuracyMeters >= 100_000) {
    return { ok: false, problem: 'zero_accuracy_impossible' }
  }
  // Within ~30 m of the Kaaba itself the bearing is numerically meaningless
  // (any direction is "toward" it) - report it honestly instead of showing a
  // random angle.
  if (haversineDistanceKm({ latitude, longitude }, KAABA_COORDINATES) < 0.03) {
    return { ok: false, problem: 'inside_kaaba' }
  }
  return { ok: true, problem: null }
}

/* ------------------------------------------------------------------ */
/* Geometry                                                            */
/* ------------------------------------------------------------------ */

/** Great-circle distance between two coordinates, in kilometers. */
export function haversineDistanceKm(
  from: { latitude: number; longitude: number },
  to: { latitude: number; longitude: number },
): number {
  const dLat = toRadians(to.latitude - from.latitude)
  const dLon = toRadians(to.longitude - from.longitude)
  const lat1 = toRadians(from.latitude)
  const lat2 = toRadians(to.latitude)

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return EARTH_RADIUS_KM * c
}

/** Distance from a location to the Kaaba, in kilometers. */
export function distanceToKaaba(latitude: number, longitude: number): number {
  return haversineDistanceKm({ latitude, longitude }, KAABA_COORDINATES)
}

/**
 * Initial bearing (forward azimuth) from a location to the Kaaba,
 * in degrees clockwise from true north (0-360).
 */
export function qiblaBearing(latitude: number, longitude: number): number {
  const phi1 = toRadians(latitude)
  const phi2 = toRadians(KAABA_COORDINATES.latitude)
  const deltaLambda = toRadians(KAABA_COORDINATES.longitude - longitude)

  const y = Math.sin(deltaLambda)
  const x = Math.cos(phi1) * Math.tan(phi2) - Math.sin(phi1) * Math.cos(deltaLambda)

  const bearing = toDegrees(Math.atan2(y, x))
  return (bearing + 360) % 360
}

/**
 * Angular difference between two bearings (0-180), used to detect when the
 * device is aligned with the Qibla.
 */
export function bearingDifference(a: number, b: number): number {
  const diff = Math.abs(a - b) % 360
  return diff > 180 ? 360 - diff : diff
}
