/**
 * EveryAyah audio URL construction and audio-related formatting helpers.
 *
 * Shared by the server (live verification) and the client (playback).
 * The URL contract is the documented EveryAyah structure:
 *   https://everyayah.com/data/{RECITER_FOLDER}/{SURAH_3_DIGITS}{AYAH_3_DIGITS}.mp3
 *
 * Surah and ayah numbers are zero-padded to exactly three digits; anything
 * outside the authentic structure (1-114 / 1..ayahCount) is rejected here so
 * a malformed reference can never be produced.
 */

import { SURA_INDEX, SURA_COUNT } from '@/data/sura-index'

function pad3(value: number): string {
  return String(value).padStart(3, '0')
}

/** Authentic ayah count of a sura (1-114); 0 when the sura number is invalid. */
export function getSuraAyahCount(sura: number): number {
  if (!Number.isInteger(sura) || sura < 1 || sura > SURA_COUNT) return 0
  return SURA_INDEX[sura - 1].ayahCount
}

/**
 * EveryAyah MP3 URL for one ayah of one reciter folder.
 * Returns null for structurally invalid references (never a broken URL).
 */
export function everyAyahFileUrl(folder: string, sura: number, ayah: number): string | null {
  if (!Number.isInteger(sura) || sura < 1 || sura > SURA_COUNT) return null
  if (!Number.isInteger(ayah) || ayah < 1 || ayah > getSuraAyahCount(sura)) return null
  if (!/^[A-Za-z0-9_.-]+$/.test(folder)) return null
  return `https://everyayah.com/data/${folder}/${pad3(sura)}${pad3(ayah)}.mp3`
}

/** Human-readable byte size ("412 KB", "1.9 GB"). */
export function formatAudioSize(bytes: number, locale = 'en'): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '—'
  const kb = 1024
  const mb = kb * 1024
  const gb = mb * 1024
  const format = (value: number): string =>
    new Intl.NumberFormat(locale, { maximumFractionDigits: value < 10 ? 1 : 0 }).format(value)
  if (bytes >= gb) return `${format(bytes / gb)} GB`
  if (bytes >= mb) return `${format(bytes / mb)} MB`
  if (bytes >= kb) return `${format(bytes / kb)} KB`
  return `${format(bytes)} B`
}

/**
 * Estimated playback duration for a file size at a nominal bitrate.
 * Clearly an estimate (actual per-file bitrates vary); the exact duration
 * always comes from the audio element once a file is loaded.
 */
export function estimateDurationSeconds(bytes: number, bitrate: '128kbps' | '192kbps'): number {
  if (!Number.isFinite(bytes) || bytes <= 0) return 0
  const bitsPerSecond = bitrate === '192kbps' ? 192_000 : 128_000
  return (bytes * 8) / bitsPerSecond
}

/** "m:ss" / "h:mm:ss" clock formatting for durations. */
export function formatClock(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00'
  const total = Math.floor(seconds)
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const s = total % 60
  const mm = h > 0 ? String(m).padStart(2, '0') : String(m)
  const ss = String(s).padStart(2, '0')
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`
}
