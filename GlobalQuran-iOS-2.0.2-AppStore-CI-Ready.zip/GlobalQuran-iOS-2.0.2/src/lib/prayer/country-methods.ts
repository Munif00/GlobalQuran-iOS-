/**
 * Global Quran - Country to calculation-method defaults.
 *
 * Policy (mirrors the product spec):
 * - `official_national`: the AlAdhan method registry itself documents that
 *   the method represents that country's national authority standard
 *   (e.g. method 4 = Umm Al-Qura University, Makkah). This is the strongest
 *   claim that can be made - it is still a calculation standard, not a
 *   statement of government approval of this app.
 * - `regional_common`: a widely adopted regional standard (e.g. Karachi for
 *   South Asia, ISNA for North America). NOT an official government setting
 *   and labeled as such in the UI.
 * - `global_default`: Muslim World League - used where no country-specific
 *   method is documented. Never presented as official.
 *
 * The user can always override the default manually.
 */

import type { CalculationMethodId, CountryMethodDefaultDto } from '@/types'
import { GLOBAL_DEFAULT_METHOD } from './methods'

export type CountryDefaultKind = 'official_national' | 'regional_common' | 'global_default'

export interface CountryMethodDefault {
  countryCode: string
  countryName: string
  methodId: CalculationMethodId
  kind: CountryDefaultKind
}

/**
 * Documented country defaults. Every `official_national` entry corresponds
 * to an AlAdhan method that names the country's authority (verified via
 * GET /v1/methods, 2026-11-15).
 */
export const COUNTRY_METHOD_DEFAULTS: ReadonlyArray<CountryMethodDefault> = [
  // --- Official national standards (method names the authority) ---
  { countryCode: 'SA', countryName: 'Saudi Arabia', methodId: 'MAKKAH', kind: 'official_national' },
  { countryCode: 'EG', countryName: 'Egypt', methodId: 'EGYPT', kind: 'official_national' },
  { countryCode: 'TR', countryName: 'Turkey', methodId: 'TURKEY', kind: 'official_national' },
  { countryCode: 'QA', countryName: 'Qatar', methodId: 'QATAR', kind: 'official_national' },
  { countryCode: 'KW', countryName: 'Kuwait', methodId: 'KUWAIT', kind: 'official_national' },
  { countryCode: 'JO', countryName: 'Jordan', methodId: 'JORDAN', kind: 'official_national' },
  { countryCode: 'TN', countryName: 'Tunisia', methodId: 'TUNISIA', kind: 'official_national' },
  { countryCode: 'DZ', countryName: 'Algeria', methodId: 'ALGERIA', kind: 'official_national' },
  { countryCode: 'MA', countryName: 'Morocco', methodId: 'MOROCCO', kind: 'official_national' },
  { countryCode: 'SG', countryName: 'Singapore', methodId: 'SINGAPORE', kind: 'official_national' },
  { countryCode: 'ID', countryName: 'Indonesia', methodId: 'KEMENAG', kind: 'official_national' },
  { countryCode: 'MY', countryName: 'Malaysia', methodId: 'JAKIM', kind: 'official_national' },
  { countryCode: 'AE', countryName: 'United Arab Emirates', methodId: 'GULF', kind: 'official_national' },
  { countryCode: 'PT', countryName: 'Portugal', methodId: 'PORTUGAL', kind: 'official_national' },
  { countryCode: 'FR', countryName: 'France', methodId: 'FRANCE', kind: 'official_national' },
  { countryCode: 'RU', countryName: 'Russia', methodId: 'RUSSIA', kind: 'official_national' },
  { countryCode: 'IR', countryName: 'Iran', methodId: 'TEHRAN', kind: 'official_national' },
  { countryCode: 'BH', countryName: 'Bahrain', methodId: 'GULF', kind: 'official_national' },
  { countryCode: 'OM', countryName: 'Oman', methodId: 'GULF', kind: 'official_national' },

  // --- Widely used regional standards (not government settings) ---
  { countryCode: 'PK', countryName: 'Pakistan', methodId: 'KARACHI', kind: 'regional_common' },
  { countryCode: 'BD', countryName: 'Bangladesh', methodId: 'KARACHI', kind: 'regional_common' },
  { countryCode: 'IN', countryName: 'India', methodId: 'KARACHI', kind: 'regional_common' },
  { countryCode: 'AF', countryName: 'Afghanistan', methodId: 'KARACHI', kind: 'regional_common' },
  { countryCode: 'US', countryName: 'United States', methodId: 'ISNA', kind: 'regional_common' },
  { countryCode: 'CA', countryName: 'Canada', methodId: 'ISNA', kind: 'regional_common' },
  { countryCode: 'GB', countryName: 'United Kingdom', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'AU', countryName: 'Australia', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'DE', countryName: 'Germany', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'NL', countryName: 'Netherlands', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'BE', countryName: 'Belgium', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'SE', countryName: 'Sweden', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'NO', countryName: 'Norway', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'DK', countryName: 'Denmark', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'ZA', countryName: 'South Africa', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'NG', countryName: 'Nigeria', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'KE', countryName: 'Kenya', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'TZ', countryName: 'Tanzania', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'UG', countryName: 'Uganda', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'SD', countryName: 'Sudan', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'ET', countryName: 'Ethiopia', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'SO', countryName: 'Somalia', methodId: 'MWL', kind: 'regional_common' },
  { countryCode: 'DJ', countryName: 'Djibouti', methodId: 'MWL', kind: 'regional_common' },
] as const

/** The global fallback used for every country not listed above. */
export const GLOBAL_FALLBACK: CountryMethodDefault = {
  countryCode: '*',
  countryName: 'Other',
  methodId: GLOBAL_DEFAULT_METHOD,
  kind: 'global_default',
}

/**
 * Resolve the documented default method for a country. Always returns a
 * valid entry - unlisted countries get the clearly-labeled global default.
 */
export function resolveCountryDefault(countryCode: string | null | undefined): CountryMethodDefault {
  if (!countryCode) return GLOBAL_FALLBACK
  const code = countryCode.trim().toUpperCase()
  const entry = COUNTRY_METHOD_DEFAULTS.find((item) => item.countryCode === code)
  return entry ?? GLOBAL_FALLBACK
}

/** Public DTO list for the meta API (excludes the `*` sentinel). */
export function countryDefaultsForApi(): CountryMethodDefaultDto[] {
  return COUNTRY_METHOD_DEFAULTS.map((entry) => ({
    countryCode: entry.countryCode,
    countryName: entry.countryName,
    methodId: entry.methodId,
    kind: entry.kind,
  }))
}

/**
 * The i18n key explaining WHY a default was chosen - the UI always shows
 * the distinction between an official national setting and a recommendation.
 */
export function defaultKindReasonKey(kind: CountryDefaultKind): string {
  switch (kind) {
    case 'official_national':
      return 'prayer.methodKind.official'
    case 'regional_common':
      return 'prayer.methodKind.regional'
    case 'global_default':
      return 'prayer.methodKind.global'
  }
}
