/**
 * Global Quran - IANA time-zone utilities for prayer times.
 *
 * Prayer times must be pinned to a real IANA time zone (never a fixed UTC
 * offset) so that daylight-saving transitions are handled correctly. All
 * conversions below use the platform Intl implementation, which carries the
 * IANA time-zone database.
 */

/** Validate an IANA time-zone identifier. */
export function isValidTimeZone(timeZone: string | null | undefined): timeZone is string {
  if (!timeZone || typeof timeZone !== 'string' || timeZone.length === 0 || timeZone.length > 64) {
    return false
  }
  try {
    new Intl.DateTimeFormat('en-US', { timeZone })
    return true
  } catch {
    return false
  }
}

/**
 * The UTC offset (in milliseconds) in effect at a given instant in a zone.
 */
export function timeZoneOffsetMs(instant: Date, timeZone: string): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hour12: false,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).formatToParts(instant)

  const get = (type: Intl.DateTimeFormatPartTypes): number => {
    const part = parts.find((entry) => entry.type === type)
    return part ? Number(part.value) : 0
  }

  // Note: with hour12:false, the hour may come back as "24" for midnight.
  const hour = get('hour') % 24
  const asUtc = Date.UTC(
    get('year'),
    get('month') - 1,
    get('day'),
    hour,
    get('minute'),
    get('second'),
  )
  return asUtc - instant.getTime()
}

/**
 * Convert a wall-clock time in a zone to the corresponding UTC instant.
 *
 * Handles DST gaps/overlaps with the standard two-pass resolution: the
 * initial guess is corrected by the measured offset, then re-measured.
 * For non-existent wall times (spring-forward gap) the returned instant is
 * the closest valid one after the gap.
 */
export function zonedWallTimeToUtc(
  dateIso: string,
  wallTime: string,
  timeZone: string,
): Date {
  const [year, month, day] = dateIso.split('-').map(Number)
  const timeMatch = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/.exec(wallTime.trim())
  if (!timeMatch) {
    throw new Error(`Invalid wall time: ${wallTime}`)
  }
  const hour = Number(timeMatch[1])
  const minute = Number(timeMatch[2])
  const second = timeMatch[3] ? Number(timeMatch[3]) : 0

  // First guess: treat the wall time as if it were UTC.
  const guess = new Date(Date.UTC(year, month - 1, day, hour, minute, second))
  // Measure the real offset at that instant and adjust.
  const offset1 = timeZoneOffsetMs(guess, timeZone)
  const adjusted = new Date(guess.getTime() - offset1)
  // Re-measure at the adjusted instant (DST boundaries) and settle.
  const offset2 = timeZoneOffsetMs(adjusted, timeZone)
  return new Date(guess.getTime() - offset2)
}

/** Format an instant as `HH:mm` wall-clock time in a zone. */
export function formatWallTime(instant: Date, timeZone: string, hour12 = false): string {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    hour12,
  }).formatToParts(instant)
  const hour = parts.find((p) => p.type === 'hour')?.value ?? '00'
  const minute = parts.find((p) => p.type === 'minute')?.value ?? '00'
  return `${hour}:${minute}`
}

/**
 * Hijri date for a Gregorian date, via the platform's Islamic (Umm al-Qura)
 * calendar. Returns `DD-MM-YYYY` or null when the calendar is unavailable.
 * NOTE: this is a calculated date - it can differ from the official date
 * announced after moon sighting. The UI labels it accordingly.
 */
export function localHijriDate(dateIso: string): { date: string; calendar: string } | null {
  const [year, month, day] = dateIso.split('-').map(Number)
  if (!year || !month || !day) return null
  const instant = new Date(Date.UTC(year, month - 1, day, 12, 0, 0))
  for (const calendar of ['islamic-umalqura', 'islamic-civil', 'islamic']) {
    try {
      const parts = new Intl.DateTimeFormat(`en-u-ca-${calendar}`, {
        timeZone: 'UTC',
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
      }).formatToParts(instant)
      const get = (type: Intl.DateTimeFormatPartTypes): string =>
        parts.find((entry) => entry.type === type)?.value ?? ''
      const hDay = get('day')
      const hMonth = get('month')
      const hYear = get('year')
      // The Islamic year part may include era text on some platforms.
      const yearDigits = /\d+/.exec(hYear)?.[0]
      if (hDay && hMonth && yearDigits) {
        const dd = hDay.padStart(2, '0')
        const mm = hMonth.padStart(2, '0')
        return { date: `${dd}-${mm}-${yearDigits}`, calendar }
      }
    } catch {
      // Try the next calendar.
    }
  }
  return null
}

/** Whether a date string is a valid YYYY-MM-DD calendar date. */
export function isValidDateIso(value: string | null | undefined): value is string {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const [year, month, day] = value.split('-').map(Number)
  const probe = new Date(Date.UTC(year, month - 1, day))
  return (
    probe.getUTCFullYear() === year &&
    probe.getUTCMonth() === month - 1 &&
    probe.getUTCDate() === day &&
    year >= 1950 &&
    year <= 2050
  )
}

/** The number of days in a month (YYYY-MM). */
export function daysInMonth(monthIso: string): number {
  const [year, month] = monthIso.split('-').map(Number)
  return new Date(Date.UTC(year, month, 0)).getUTCDate()
}

/** Today's date (YYYY-MM-DD) in a given zone - not the server's zone. */
export function todayInZone(timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date())
  const get = (type: Intl.DateTimeFormatPartTypes): string =>
    parts.find((entry) => entry.type === type)?.value ?? '01'
  return `${get('year')}-${get('month')}-${get('day')}`
}
