/**
 * Global Quran - Curated city dataset for manual location selection.
 *
 * Scope & honesty policy:
 * - A curated list of major cities across every region the product tests
 *   (Middle East, Europe, North America, Southeast Asia, Africa, South Asia,
 *   Oceania, and high-latitude cities).
 * - Coordinates are approximate city-center values (2 decimals, ~1 km) -
 *   suitable for prayer-time calculation and honestly labeled as
 *   approximate in the UI.
 * - Time zones are IANA identifiers.
 * - The bundled list is a fallback for offline use; live geocoding
 *   (Nominatim) extends coverage to arbitrary places when online.
 */

import type { CitySearchResult } from '@/types'
import { normalizeForSearch } from '@/utils/text-normalize'

interface BundledCity {
  name: string
  region: string | null
  country: string
  countryCode: string
  latitude: number
  longitude: number
  timeZone: string
}

/* name, region, country, countryCode, lat, lng, IANA time zone */
const CITIES: BundledCity[] = [
  // --- Middle East ---
  { name: 'Makkah', region: 'Makkah Region', country: 'Saudi Arabia', countryCode: 'SA', latitude: 21.42, longitude: 39.83, timeZone: 'Asia/Riyadh' },
  { name: 'Madinah', region: 'Madinah Region', country: 'Saudi Arabia', countryCode: 'SA', latitude: 24.47, longitude: 39.61, timeZone: 'Asia/Riyadh' },
  { name: 'Riyadh', region: 'Riyadh Region', country: 'Saudi Arabia', countryCode: 'SA', latitude: 24.71, longitude: 46.68, timeZone: 'Asia/Riyadh' },
  { name: 'Jeddah', region: 'Makkah Region', country: 'Saudi Arabia', countryCode: 'SA', latitude: 21.49, longitude: 39.19, timeZone: 'Asia/Riyadh' },
  { name: 'Dammam', region: 'Eastern Province', country: 'Saudi Arabia', countryCode: 'SA', latitude: 26.42, longitude: 50.09, timeZone: 'Asia/Riyadh' },
  { name: 'Cairo', region: 'Cairo Governorate', country: 'Egypt', countryCode: 'EG', latitude: 30.04, longitude: 31.24, timeZone: 'Africa/Cairo' },
  { name: 'Alexandria', region: 'Alexandria Governorate', country: 'Egypt', countryCode: 'EG', latitude: 31.2, longitude: 29.92, timeZone: 'Africa/Cairo' },
  { name: 'Giza', region: 'Giza Governorate', country: 'Egypt', countryCode: 'EG', latitude: 30.01, longitude: 31.21, timeZone: 'Africa/Cairo' },
  { name: 'Luxor', region: 'Luxor Governorate', country: 'Egypt', countryCode: 'EG', latitude: 25.69, longitude: 32.64, timeZone: 'Africa/Cairo' },
  { name: 'Amman', region: 'Amman Governorate', country: 'Jordan', countryCode: 'JO', latitude: 31.95, longitude: 35.93, timeZone: 'Asia/Amman' },
  { name: 'Doha', region: 'Doha', country: 'Qatar', countryCode: 'QA', latitude: 25.29, longitude: 51.53, timeZone: 'Asia/Qatar' },
  { name: 'Kuwait City', region: 'Al Asimah', country: 'Kuwait', countryCode: 'KW', latitude: 29.38, longitude: 47.98, timeZone: 'Asia/Kuwait' },
  { name: 'Manama', region: 'Capital Governorate', country: 'Bahrain', countryCode: 'BH', latitude: 26.23, longitude: 50.59, timeZone: 'Asia/Bahrain' },
  { name: 'Muscat', region: 'Muscat Governorate', country: 'Oman', countryCode: 'OM', latitude: 23.59, longitude: 58.41, timeZone: 'Asia/Muscat' },
  { name: 'Abu Dhabi', region: 'Emirate of Abu Dhabi', country: 'United Arab Emirates', countryCode: 'AE', latitude: 24.45, longitude: 54.38, timeZone: 'Asia/Dubai' },
  { name: 'Dubai', region: 'Emirate of Dubai', country: 'United Arab Emirates', countryCode: 'AE', latitude: 25.2, longitude: 55.27, timeZone: 'Asia/Dubai' },
  { name: 'Sharjah', region: 'Emirate of Sharjah', country: 'United Arab Emirates', countryCode: 'AE', latitude: 25.35, longitude: 55.39, timeZone: 'Asia/Dubai' },
  { name: 'Baghdad', region: 'Baghdad Governorate', country: 'Iraq', countryCode: 'IQ', latitude: 33.31, longitude: 44.36, timeZone: 'Asia/Baghdad' },
  { name: 'Basra', region: 'Basra Governorate', country: 'Iraq', countryCode: 'IQ', latitude: 30.51, longitude: 47.81, timeZone: 'Asia/Baghdad' },
  { name: 'Erbil', region: 'Erbil Governorate', country: 'Iraq', countryCode: 'IQ', latitude: 36.19, longitude: 44.01, timeZone: 'Asia/Baghdad' },
  { name: 'Beirut', region: 'Beirut Governorate', country: 'Lebanon', countryCode: 'LB', latitude: 33.89, longitude: 35.5, timeZone: 'Asia/Beirut' },
  { name: 'Damascus', region: 'Damascus Governorate', country: 'Syria', countryCode: 'SY', latitude: 33.51, longitude: 36.29, timeZone: 'Asia/Damascus' },
  { name: 'Aleppo', region: 'Aleppo Governorate', country: 'Syria', countryCode: 'SY', latitude: 36.2, longitude: 37.13, timeZone: 'Asia/Damascus' },
  { name: 'Sanaa', region: 'Sanaa Governorate', country: 'Yemen', countryCode: 'YE', latitude: 15.35, longitude: 44.21, timeZone: 'Asia/Aden' },
  { name: 'Aden', region: 'Aden Governorate', country: 'Yemen', countryCode: 'YE', latitude: 12.79, longitude: 45.03, timeZone: 'Asia/Aden' },
  { name: 'Gaza', region: 'Gaza Strip', country: 'Palestine', countryCode: 'PS', latitude: 31.5, longitude: 34.47, timeZone: 'Asia/Hebron' },
  { name: 'Hebron', region: 'West Bank', country: 'Palestine', countryCode: 'PS', latitude: 31.53, longitude: 35.1, timeZone: 'Asia/Hebron' },
  { name: 'Nablus', region: 'West Bank', country: 'Palestine', countryCode: 'PS', latitude: 32.22, longitude: 35.26, timeZone: 'Asia/Hebron' },
  { name: 'Istanbul', region: 'Istanbul Province', country: 'Turkey', countryCode: 'TR', latitude: 41.01, longitude: 28.98, timeZone: 'Europe/Istanbul' },
  { name: 'Ankara', region: 'Ankara Province', country: 'Turkey', countryCode: 'TR', latitude: 39.93, longitude: 32.86, timeZone: 'Europe/Istanbul' },
  { name: 'Izmir', region: 'Izmir Province', country: 'Turkey', countryCode: 'TR', latitude: 38.42, longitude: 27.14, timeZone: 'Europe/Istanbul' },
  { name: 'Bursa', region: 'Bursa Province', country: 'Turkey', countryCode: 'TR', latitude: 40.19, longitude: 29.06, timeZone: 'Europe/Istanbul' },
  { name: 'Konya', region: 'Konya Province', country: 'Turkey', countryCode: 'TR', latitude: 37.87, longitude: 32.48, timeZone: 'Europe/Istanbul' },
  { name: 'Tehran', region: 'Tehran Province', country: 'Iran', countryCode: 'IR', latitude: 35.69, longitude: 51.39, timeZone: 'Asia/Tehran' },
  { name: 'Mashhad', region: 'Razavi Khorasan', country: 'Iran', countryCode: 'IR', latitude: 36.3, longitude: 59.6, timeZone: 'Asia/Tehran' },
  { name: 'Isfahan', region: 'Isfahan Province', country: 'Iran', countryCode: 'IR', latitude: 32.65, longitude: 51.67, timeZone: 'Asia/Tehran' },
  { name: 'Shiraz', region: 'Fars Province', country: 'Iran', countryCode: 'IR', latitude: 29.59, longitude: 52.58, timeZone: 'Asia/Tehran' },

  // --- Europe ---
  { name: 'London', region: 'England', country: 'United Kingdom', countryCode: 'GB', latitude: 51.51, longitude: -0.13, timeZone: 'Europe/London' },
  { name: 'Manchester', region: 'England', country: 'United Kingdom', countryCode: 'GB', latitude: 53.48, longitude: -2.24, timeZone: 'Europe/London' },
  { name: 'Birmingham', region: 'England', country: 'United Kingdom', countryCode: 'GB', latitude: 52.49, longitude: -1.89, timeZone: 'Europe/London' },
  { name: 'Bradford', region: 'England', country: 'United Kingdom', countryCode: 'GB', latitude: 53.79, longitude: -1.75, timeZone: 'Europe/London' },
  { name: 'Glasgow', region: 'Scotland', country: 'United Kingdom', countryCode: 'GB', latitude: 55.86, longitude: -4.25, timeZone: 'Europe/London' },
  { name: 'Paris', region: 'Ile-de-France', country: 'France', countryCode: 'FR', latitude: 48.86, longitude: 2.35, timeZone: 'Europe/Paris' },
  { name: 'Marseille', region: 'Provence', country: 'France', countryCode: 'FR', latitude: 43.3, longitude: 5.37, timeZone: 'Europe/Paris' },
  { name: 'Lyon', region: 'Auvergne-Rhone-Alpes', country: 'France', countryCode: 'FR', latitude: 45.76, longitude: 4.84, timeZone: 'Europe/Paris' },
  { name: 'Berlin', region: 'Berlin', country: 'Germany', countryCode: 'DE', latitude: 52.52, longitude: 13.4, timeZone: 'Europe/Berlin' },
  { name: 'Hamburg', region: 'Hamburg', country: 'Germany', countryCode: 'DE', latitude: 53.55, longitude: 9.99, timeZone: 'Europe/Berlin' },
  { name: 'Frankfurt', region: 'Hesse', country: 'Germany', countryCode: 'DE', latitude: 50.11, longitude: 8.68, timeZone: 'Europe/Berlin' },
  { name: 'Munich', region: 'Bavaria', country: 'Germany', countryCode: 'DE', latitude: 48.14, longitude: 11.58, timeZone: 'Europe/Berlin' },
  { name: 'Cologne', region: 'North Rhine-Westphalia', country: 'Germany', countryCode: 'DE', latitude: 50.94, longitude: 6.96, timeZone: 'Europe/Berlin' },
  { name: 'Amsterdam', region: 'North Holland', country: 'Netherlands', countryCode: 'NL', latitude: 52.37, longitude: 4.9, timeZone: 'Europe/Amsterdam' },
  { name: 'Rotterdam', region: 'South Holland', country: 'Netherlands', countryCode: 'NL', latitude: 51.92, longitude: 4.48, timeZone: 'Europe/Amsterdam' },
  { name: 'Brussels', region: 'Brussels', country: 'Belgium', countryCode: 'BE', latitude: 50.85, longitude: 4.35, timeZone: 'Europe/Brussels' },
  { name: 'Stockholm', region: 'Stockholm', country: 'Sweden', countryCode: 'SE', latitude: 59.33, longitude: 18.07, timeZone: 'Europe/Stockholm' },
  { name: 'Gothenburg', region: 'Vastra Gotaland', country: 'Sweden', countryCode: 'SE', latitude: 57.71, longitude: 11.97, timeZone: 'Europe/Stockholm' },
  { name: 'Oslo', region: 'Oslo', country: 'Norway', countryCode: 'NO', latitude: 59.91, longitude: 10.75, timeZone: 'Europe/Oslo' },
  { name: 'Bergen', region: 'Vestland', country: 'Norway', countryCode: 'NO', latitude: 60.39, longitude: 5.32, timeZone: 'Europe/Oslo' },
  { name: 'Trondheim', region: 'Trondelag', country: 'Norway', countryCode: 'NO', latitude: 63.43, longitude: 10.4, timeZone: 'Europe/Oslo' },
  { name: 'Copenhagen', region: 'Capital Region', country: 'Denmark', countryCode: 'DK', latitude: 55.68, longitude: 12.57, timeZone: 'Europe/Copenhagen' },
  { name: 'Helsinki', region: 'Uusimaa', country: 'Finland', countryCode: 'FI', latitude: 60.17, longitude: 24.94, timeZone: 'Europe/Helsinki' },
  { name: 'Dublin', region: 'Leinster', country: 'Ireland', countryCode: 'IE', latitude: 53.35, longitude: -6.26, timeZone: 'Europe/Dublin' },
  { name: 'Madrid', region: 'Community of Madrid', country: 'Spain', countryCode: 'ES', latitude: 40.42, longitude: -3.7, timeZone: 'Europe/Madrid' },
  { name: 'Barcelona', region: 'Catalonia', country: 'Spain', countryCode: 'ES', latitude: 41.39, longitude: 2.17, timeZone: 'Europe/Madrid' },
  { name: 'Lisbon', region: 'Lisbon', country: 'Portugal', countryCode: 'PT', latitude: 38.72, longitude: -9.14, timeZone: 'Europe/Lisbon' },
  { name: 'Rome', region: 'Lazio', country: 'Italy', countryCode: 'IT', latitude: 41.9, longitude: 12.5, timeZone: 'Europe/Rome' },
  { name: 'Milan', region: 'Lombardy', country: 'Italy', countryCode: 'IT', latitude: 45.46, longitude: 9.19, timeZone: 'Europe/Rome' },
  { name: 'Naples', region: 'Campania', country: 'Italy', countryCode: 'IT', latitude: 40.85, longitude: 14.27, timeZone: 'Europe/Rome' },
  { name: 'Vienna', region: 'Vienna', country: 'Austria', countryCode: 'AT', latitude: 48.21, longitude: 16.37, timeZone: 'Europe/Vienna' },
  { name: 'Zurich', region: 'Zurich', country: 'Switzerland', countryCode: 'CH', latitude: 47.37, longitude: 8.54, timeZone: 'Europe/Zurich' },
  { name: 'Geneva', region: 'Geneva', country: 'Switzerland', countryCode: 'CH', latitude: 46.2, longitude: 6.14, timeZone: 'Europe/Zurich' },
  { name: 'Prague', region: 'Prague', country: 'Czechia', countryCode: 'CZ', latitude: 50.08, longitude: 14.44, timeZone: 'Europe/Prague' },
  { name: 'Warsaw', region: 'Masovia', country: 'Poland', countryCode: 'PL', latitude: 52.23, longitude: 21.01, timeZone: 'Europe/Warsaw' },
  { name: 'Kyiv', region: 'Kyiv', country: 'Ukraine', countryCode: 'UA', latitude: 50.45, longitude: 30.52, timeZone: 'Europe/Kyiv' },
  { name: 'Moscow', region: 'Moscow', country: 'Russia', countryCode: 'RU', latitude: 55.76, longitude: 37.62, timeZone: 'Europe/Moscow' },
  { name: 'Saint Petersburg', region: 'Saint Petersburg', country: 'Russia', countryCode: 'RU', latitude: 59.94, longitude: 30.31, timeZone: 'Europe/Moscow' },
  { name: 'Kazan', region: 'Tatarstan', country: 'Russia', countryCode: 'RU', latitude: 55.79, longitude: 49.11, timeZone: 'Europe/Moscow' },
  { name: 'Sarajevo', region: 'Federation of Bosnia and Herzegovina', country: 'Bosnia and Herzegovina', countryCode: 'BA', latitude: 43.86, longitude: 18.41, timeZone: 'Europe/Sarajevo' },
  { name: 'Zagreb', region: 'Zagreb', country: 'Croatia', countryCode: 'HR', latitude: 45.81, longitude: 15.98, timeZone: 'Europe/Zagreb' },
  { name: 'Belgrade', region: 'Belgrade', country: 'Serbia', countryCode: 'RS', latitude: 44.79, longitude: 20.45, timeZone: 'Europe/Belgrade' },
  { name: 'Athens', region: 'Attica', country: 'Greece', countryCode: 'GR', latitude: 37.98, longitude: 23.73, timeZone: 'Europe/Athens' },
  { name: 'Sofia', region: 'Sofia-Grad', country: 'Bulgaria', countryCode: 'BG', latitude: 42.7, longitude: 23.32, timeZone: 'Europe/Sofia' },
  { name: 'Bucharest', region: 'Bucharest', country: 'Romania', countryCode: 'RO', latitude: 44.43, longitude: 26.1, timeZone: 'Europe/Bucharest' },
  { name: 'Tirana', region: 'Tirana', country: 'Albania', countryCode: 'AL', latitude: 41.33, longitude: 19.82, timeZone: 'Europe/Tirane' },
  { name: 'Skopje', region: 'Skopje', country: 'North Macedonia', countryCode: 'MK', latitude: 41.99, longitude: 21.43, timeZone: 'Europe/Skopje' },

  // --- North America ---
  { name: 'New York', region: 'New York', country: 'United States', countryCode: 'US', latitude: 40.71, longitude: -74.01, timeZone: 'America/New_York' },
  { name: 'Chicago', region: 'Illinois', country: 'United States', countryCode: 'US', latitude: 41.88, longitude: -87.63, timeZone: 'America/Chicago' },
  { name: 'Houston', region: 'Texas', country: 'United States', countryCode: 'US', latitude: 29.76, longitude: -95.37, timeZone: 'America/Chicago' },
  { name: 'Dallas', region: 'Texas', country: 'United States', countryCode: 'US', latitude: 32.78, longitude: -96.8, timeZone: 'America/Chicago' },
  { name: 'Los Angeles', region: 'California', country: 'United States', countryCode: 'US', latitude: 34.05, longitude: -118.24, timeZone: 'America/Los_Angeles' },
  { name: 'San Francisco', region: 'California', country: 'United States', countryCode: 'US', latitude: 37.77, longitude: -122.42, timeZone: 'America/Los_Angeles' },
  { name: 'Seattle', region: 'Washington', country: 'United States', countryCode: 'US', latitude: 47.61, longitude: -122.33, timeZone: 'America/Los_Angeles' },
  { name: 'Detroit', region: 'Michigan', country: 'United States', countryCode: 'US', latitude: 42.33, longitude: -83.05, timeZone: 'America/Detroit' },
  { name: 'Dearborn', region: 'Michigan', country: 'United States', countryCode: 'US', latitude: 42.32, longitude: -83.21, timeZone: 'America/Detroit' },
  { name: 'Philadelphia', region: 'Pennsylvania', country: 'United States', countryCode: 'US', latitude: 39.95, longitude: -75.17, timeZone: 'America/New_York' },
  { name: 'Atlanta', region: 'Georgia', country: 'United States', countryCode: 'US', latitude: 33.75, longitude: -84.39, timeZone: 'America/New_York' },
  { name: 'Washington', region: 'District of Columbia', country: 'United States', countryCode: 'US', latitude: 38.91, longitude: -77.04, timeZone: 'America/New_York' },
  { name: 'Boston', region: 'Massachusetts', country: 'United States', countryCode: 'US', latitude: 42.36, longitude: -71.06, timeZone: 'America/New_York' },
  { name: 'Phoenix', region: 'Arizona', country: 'United States', countryCode: 'US', latitude: 33.45, longitude: -112.07, timeZone: 'America/Phoenix' },
  { name: 'Toronto', region: 'Ontario', country: 'Canada', countryCode: 'CA', latitude: 43.65, longitude: -79.38, timeZone: 'America/Toronto' },
  { name: 'Montreal', region: 'Quebec', country: 'Canada', countryCode: 'CA', latitude: 45.5, longitude: -73.57, timeZone: 'America/Toronto' },
  { name: 'Ottawa', region: 'Ontario', country: 'Canada', countryCode: 'CA', latitude: 45.42, longitude: -75.7, timeZone: 'America/Toronto' },
  { name: 'Vancouver', region: 'British Columbia', country: 'Canada', countryCode: 'CA', latitude: 49.28, longitude: -123.12, timeZone: 'America/Vancouver' },
  { name: 'Calgary', region: 'Alberta', country: 'Canada', countryCode: 'CA', latitude: 51.05, longitude: -114.07, timeZone: 'America/Edmonton' },
  { name: 'Edmonton', region: 'Alberta', country: 'Canada', countryCode: 'CA', latitude: 53.55, longitude: -113.49, timeZone: 'America/Edmonton' },
  { name: 'Winnipeg', region: 'Manitoba', country: 'Canada', countryCode: 'CA', latitude: 49.9, longitude: -97.14, timeZone: 'America/Winnipeg' },
  { name: 'Halifax', region: 'Nova Scotia', country: 'Canada', countryCode: 'CA', latitude: 44.65, longitude: -63.58, timeZone: 'America/Halifax' },

  // --- Southeast Asia ---
  { name: 'Jakarta', region: 'Jakarta', country: 'Indonesia', countryCode: 'ID', latitude: -6.21, longitude: 106.85, timeZone: 'Asia/Jakarta' },
  { name: 'Surabaya', region: 'East Java', country: 'Indonesia', countryCode: 'ID', latitude: -7.25, longitude: 112.75, timeZone: 'Asia/Jakarta' },
  { name: 'Bandung', region: 'West Java', country: 'Indonesia', countryCode: 'ID', latitude: -6.92, longitude: 107.61, timeZone: 'Asia/Jakarta' },
  { name: 'Medan', region: 'North Sumatra', country: 'Indonesia', countryCode: 'ID', latitude: 3.6, longitude: 98.67, timeZone: 'Asia/Jakarta' },
  { name: 'Makassar', region: 'South Sulawesi', country: 'Indonesia', countryCode: 'ID', latitude: -5.15, longitude: 119.43, timeZone: 'Asia/Makassar' },
  { name: 'Pontianak', region: 'West Kalimantan', country: 'Indonesia', countryCode: 'ID', latitude: -0.03, longitude: 109.33, timeZone: 'Asia/Pontianak' },
  { name: 'Denpasar', region: 'Bali', country: 'Indonesia', countryCode: 'ID', latitude: -8.65, longitude: 115.22, timeZone: 'Asia/Makassar' },
  { name: 'Jayapura', region: 'Papua', country: 'Indonesia', countryCode: 'ID', latitude: -2.53, longitude: 140.72, timeZone: 'Asia/Jayapura' },
  { name: 'Kuala Lumpur', region: 'WP Kuala Lumpur', country: 'Malaysia', countryCode: 'MY', latitude: 3.14, longitude: 101.69, timeZone: 'Asia/Kuala_Lumpur' },
  { name: 'Putrajaya', region: 'WP Putrajaya', country: 'Malaysia', countryCode: 'MY', latitude: 2.93, longitude: 101.69, timeZone: 'Asia/Kuala_Lumpur' },
  { name: 'Johor Bahru', region: 'Johor', country: 'Malaysia', countryCode: 'MY', latitude: 1.49, longitude: 103.74, timeZone: 'Asia/Kuala_Lumpur' },
  { name: 'George Town', region: 'Pulau Pinang', country: 'Malaysia', countryCode: 'MY', latitude: 5.41, longitude: 100.33, timeZone: 'Asia/Kuala_Lumpur' },
  { name: 'Kota Kinabalu', region: 'Sabah', country: 'Malaysia', countryCode: 'MY', latitude: 5.98, longitude: 116.07, timeZone: 'Asia/Kuching' },
  { name: 'Kuching', region: 'Sarawak', country: 'Malaysia', countryCode: 'MY', latitude: 1.55, longitude: 110.34, timeZone: 'Asia/Kuching' },
  { name: 'Singapore', region: 'Singapore', country: 'Singapore', countryCode: 'SG', latitude: 1.35, longitude: 103.82, timeZone: 'Asia/Singapore' },
  { name: 'Bangkok', region: 'Bangkok', country: 'Thailand', countryCode: 'TH', latitude: 13.76, longitude: 100.5, timeZone: 'Asia/Bangkok' },
  { name: 'Manila', region: 'Metro Manila', country: 'Philippines', countryCode: 'PH', latitude: 14.6, longitude: 120.98, timeZone: 'Asia/Manila' },
  { name: 'Cebu City', region: 'Central Visayas', country: 'Philippines', countryCode: 'PH', latitude: 10.32, longitude: 123.9, timeZone: 'Asia/Manila' },
  { name: 'Davao City', region: 'Davao Region', country: 'Philippines', countryCode: 'PH', latitude: 7.07, longitude: 125.61, timeZone: 'Asia/Manila' },
  { name: 'Phnom Penh', region: 'Phnom Penh', country: 'Cambodia', countryCode: 'KH', latitude: 11.56, longitude: 104.92, timeZone: 'Asia/Phnom_Penh' },
  { name: 'Ho Chi Minh City', region: 'Southeast', country: 'Vietnam', countryCode: 'VN', latitude: 10.82, longitude: 106.63, timeZone: 'Asia/Ho_Chi_Minh' },
  { name: 'Hanoi', region: 'Hanoi', country: 'Vietnam', countryCode: 'VN', latitude: 21.03, longitude: 105.85, timeZone: 'Asia/Ho_Chi_Minh' },
  { name: 'Bandar Seri Begawan', region: 'Brunei-Muara', country: 'Brunei', countryCode: 'BN', latitude: 4.9, longitude: 114.94, timeZone: 'Asia/Brunei' },
  { name: 'Yangon', region: 'Yangon Region', country: 'Myanmar', countryCode: 'MM', latitude: 16.87, longitude: 96.2, timeZone: 'Asia/Yangon' },

  // --- Africa ---
  { name: 'Lagos', region: 'Lagos State', country: 'Nigeria', countryCode: 'NG', latitude: 6.52, longitude: 3.38, timeZone: 'Africa/Lagos' },
  { name: 'Kano', region: 'Kano State', country: 'Nigeria', countryCode: 'NG', latitude: 12.0, longitude: 8.52, timeZone: 'Africa/Lagos' },
  { name: 'Abuja', region: 'FCT', country: 'Nigeria', countryCode: 'NG', latitude: 9.06, longitude: 7.49, timeZone: 'Africa/Lagos' },
  { name: 'Accra', region: 'Greater Accra', country: 'Ghana', countryCode: 'GH', latitude: 5.6, longitude: -0.19, timeZone: 'Africa/Accra' },
  { name: 'Dakar', region: 'Dakar', country: 'Senegal', countryCode: 'SN', latitude: 14.72, longitude: -17.47, timeZone: 'Africa/Dakar' },
  { name: 'Casablanca', region: 'Casablanca-Settat', country: 'Morocco', countryCode: 'MA', latitude: 33.57, longitude: -7.59, timeZone: 'Africa/Casablanca' },
  { name: 'Rabat', region: 'Rabat-Sale-Kenitra', country: 'Morocco', countryCode: 'MA', latitude: 34.02, longitude: -6.83, timeZone: 'Africa/Casablanca' },
  { name: 'Marrakesh', region: 'Marrakesh-Safi', country: 'Morocco', countryCode: 'MA', latitude: 31.63, longitude: -8.01, timeZone: 'Africa/Casablanca' },
  { name: 'Fes', region: 'Fes-Meknes', country: 'Morocco', countryCode: 'MA', latitude: 34.03, longitude: -5.0, timeZone: 'Africa/Casablanca' },
  { name: 'Algiers', region: 'Algiers Province', country: 'Algeria', countryCode: 'DZ', latitude: 36.75, longitude: 3.06, timeZone: 'Africa/Algiers' },
  { name: 'Oran', region: 'Oran Province', country: 'Algeria', countryCode: 'DZ', latitude: 35.7, longitude: -0.63, timeZone: 'Africa/Algiers' },
  { name: 'Tunis', region: 'Tunis Governorate', country: 'Tunisia', countryCode: 'TN', latitude: 36.81, longitude: 10.18, timeZone: 'Africa/Tunis' },
  { name: 'Tripoli', region: 'Tripoli District', country: 'Libya', countryCode: 'LY', latitude: 32.89, longitude: 13.19, timeZone: 'Africa/Tripoli' },
  { name: 'Khartoum', region: 'Khartoum State', country: 'Sudan', countryCode: 'SD', latitude: 15.5, longitude: 32.56, timeZone: 'Africa/Khartoum' },
  { name: 'Nairobi', region: 'Nairobi County', country: 'Kenya', countryCode: 'KE', latitude: -1.29, longitude: 36.82, timeZone: 'Africa/Nairobi' },
  { name: 'Mombasa', region: 'Mombasa County', country: 'Kenya', countryCode: 'KE', latitude: -4.04, longitude: 39.67, timeZone: 'Africa/Nairobi' },
  { name: 'Dar es Salaam', region: 'Dar es Salaam', country: 'Tanzania', countryCode: 'TZ', latitude: -6.79, longitude: 39.21, timeZone: 'Africa/Dar_es_Salaam' },
  { name: 'Kampala', region: 'Central Region', country: 'Uganda', countryCode: 'UG', latitude: 0.35, longitude: 32.58, timeZone: 'Africa/Kampala' },
  { name: 'Addis Ababa', region: 'Addis Ababa', country: 'Ethiopia', countryCode: 'ET', latitude: 9.02, longitude: 38.75, timeZone: 'Africa/Addis_Ababa' },
  { name: 'Mogadishu', region: 'Banaadir', country: 'Somalia', countryCode: 'SO', latitude: 2.05, longitude: 45.34, timeZone: 'Africa/Mogadishu' },
  { name: 'Harare', region: 'Harare Province', country: 'Zimbabwe', countryCode: 'ZW', latitude: -17.83, longitude: 31.05, timeZone: 'Africa/Harare' },
  { name: 'Johannesburg', region: 'Gauteng', country: 'South Africa', countryCode: 'ZA', latitude: -26.2, longitude: 28.05, timeZone: 'Africa/Johannesburg' },
  { name: 'Cape Town', region: 'Western Cape', country: 'South Africa', countryCode: 'ZA', latitude: -33.92, longitude: 18.42, timeZone: 'Africa/Johannesburg' },
  { name: 'Durban', region: 'KwaZulu-Natal', country: 'South Africa', countryCode: 'ZA', latitude: -29.86, longitude: 31.02, timeZone: 'Africa/Johannesburg' },
  { name: 'Djibouti City', region: 'Djibouti', country: 'Djibouti', countryCode: 'DJ', latitude: 11.59, longitude: 43.15, timeZone: 'Africa/Djibouti' },

  // --- South Asia ---
  { name: 'Karachi', region: 'Sindh', country: 'Pakistan', countryCode: 'PK', latitude: 24.86, longitude: 67.01, timeZone: 'Asia/Karachi' },
  { name: 'Lahore', region: 'Punjab', country: 'Pakistan', countryCode: 'PK', latitude: 31.55, longitude: 74.34, timeZone: 'Asia/Karachi' },
  { name: 'Islamabad', region: 'Islamabad Capital Territory', country: 'Pakistan', countryCode: 'PK', latitude: 33.68, longitude: 73.05, timeZone: 'Asia/Karachi' },
  { name: 'Peshawar', region: 'Khyber Pakhtunkhwa', country: 'Pakistan', countryCode: 'PK', latitude: 34.01, longitude: 71.55, timeZone: 'Asia/Karachi' },
  { name: 'Quetta', region: 'Balochistan', country: 'Pakistan', countryCode: 'PK', latitude: 30.18, longitude: 66.97, timeZone: 'Asia/Karachi' },
  { name: 'Multan', region: 'Punjab', country: 'Pakistan', countryCode: 'PK', latitude: 30.2, longitude: 71.47, timeZone: 'Asia/Karachi' },
  { name: 'Faisalabad', region: 'Punjab', country: 'Pakistan', countryCode: 'PK', latitude: 31.42, longitude: 73.08, timeZone: 'Asia/Karachi' },
  { name: 'Delhi', region: 'Delhi', country: 'India', countryCode: 'IN', latitude: 28.61, longitude: 77.21, timeZone: 'Asia/Kolkata' },
  { name: 'Mumbai', region: 'Maharashtra', country: 'India', countryCode: 'IN', latitude: 19.08, longitude: 72.88, timeZone: 'Asia/Kolkata' },
  { name: 'Hyderabad', region: 'Telangana', country: 'India', countryCode: 'IN', latitude: 17.39, longitude: 78.49, timeZone: 'Asia/Kolkata' },
  { name: 'Bengaluru', region: 'Karnataka', country: 'India', countryCode: 'IN', latitude: 12.97, longitude: 77.59, timeZone: 'Asia/Kolkata' },
  { name: 'Chennai', region: 'Tamil Nadu', country: 'India', countryCode: 'IN', latitude: 13.08, longitude: 80.27, timeZone: 'Asia/Kolkata' },
  { name: 'Kolkata', region: 'West Bengal', country: 'India', countryCode: 'IN', latitude: 22.57, longitude: 88.36, timeZone: 'Asia/Kolkata' },
  { name: 'Lucknow', region: 'Uttar Pradesh', country: 'India', countryCode: 'IN', latitude: 26.85, longitude: 80.95, timeZone: 'Asia/Kolkata' },
  { name: 'Srinagar', region: 'Jammu and Kashmir', country: 'India', countryCode: 'IN', latitude: 34.08, longitude: 74.8, timeZone: 'Asia/Kolkata' },
  { name: 'Dhaka', region: 'Dhaka Division', country: 'Bangladesh', countryCode: 'BD', latitude: 23.81, longitude: 90.41, timeZone: 'Asia/Dhaka' },
  { name: 'Chittagong', region: 'Chattogram Division', country: 'Bangladesh', countryCode: 'BD', latitude: 22.36, longitude: 91.78, timeZone: 'Asia/Dhaka' },
  { name: 'Sylhet', region: 'Sylhet Division', country: 'Bangladesh', countryCode: 'BD', latitude: 24.9, longitude: 91.87, timeZone: 'Asia/Dhaka' },
  { name: 'Kathmandu', region: 'Bagmati', country: 'Nepal', countryCode: 'NP', latitude: 27.72, longitude: 85.32, timeZone: 'Asia/Kathmandu' },
  { name: 'Colombo', region: 'Western Province', country: 'Sri Lanka', countryCode: 'LK', latitude: 6.93, longitude: 79.85, timeZone: 'Asia/Colombo' },
  { name: 'Male', region: 'Male', country: 'Maldives', countryCode: 'MV', latitude: 4.18, longitude: 73.51, timeZone: 'Indian/Maldives' },

  // --- Central Asia, Caucasus, Afghanistan ---
  { name: 'Tashkent', region: 'Tashkent', country: 'Uzbekistan', countryCode: 'UZ', latitude: 41.3, longitude: 69.24, timeZone: 'Asia/Tashkent' },
  { name: 'Samarkand', region: 'Samarkand Region', country: 'Uzbekistan', countryCode: 'UZ', latitude: 39.65, longitude: 66.96, timeZone: 'Asia/Tashkent' },
  { name: 'Almaty', region: 'Almaty', country: 'Kazakhstan', countryCode: 'KZ', latitude: 43.24, longitude: 76.89, timeZone: 'Asia/Almaty' },
  { name: 'Astana', region: 'Astana', country: 'Kazakhstan', countryCode: 'KZ', latitude: 51.17, longitude: 71.43, timeZone: 'Asia/Almaty' },
  { name: 'Bishkek', region: 'Bishkek', country: 'Kyrgyzstan', countryCode: 'KG', latitude: 42.87, longitude: 74.59, timeZone: 'Asia/Bishkek' },
  { name: 'Dushanbe', region: 'Dushanbe', country: 'Tajikistan', countryCode: 'TJ', latitude: 38.56, longitude: 68.79, timeZone: 'Asia/Dushanbe' },
  { name: 'Ashgabat', region: 'Ashgabat', country: 'Turkmenistan', countryCode: 'TM', latitude: 37.96, longitude: 58.33, timeZone: 'Asia/Ashgabat' },
  { name: 'Baku', region: 'Baku', country: 'Azerbaijan', countryCode: 'AZ', latitude: 40.41, longitude: 49.87, timeZone: 'Asia/Baku' },
  { name: 'Tbilisi', region: 'Tbilisi', country: 'Georgia', countryCode: 'GE', latitude: 41.72, longitude: 44.79, timeZone: 'Asia/Tbilisi' },
  { name: 'Yerevan', region: 'Yerevan', country: 'Armenia', countryCode: 'AM', latitude: 40.18, longitude: 44.51, timeZone: 'Asia/Yerevan' },
  { name: 'Kabul', region: 'Kabul', country: 'Afghanistan', countryCode: 'AF', latitude: 34.53, longitude: 69.17, timeZone: 'Asia/Kabul' },

  // --- East Asia ---
  { name: 'Beijing', region: 'Beijing', country: 'China', countryCode: 'CN', latitude: 39.9, longitude: 116.41, timeZone: 'Asia/Shanghai' },
  { name: 'Shanghai', region: 'Shanghai', country: 'China', countryCode: 'CN', latitude: 31.23, longitude: 121.47, timeZone: 'Asia/Shanghai' },
  { name: 'Guangzhou', region: 'Guangdong', country: 'China', countryCode: 'CN', latitude: 23.13, longitude: 113.26, timeZone: 'Asia/Shanghai' },
  { name: 'Tokyo', region: 'Tokyo', country: 'Japan', countryCode: 'JP', latitude: 35.68, longitude: 139.69, timeZone: 'Asia/Tokyo' },
  { name: 'Osaka', region: 'Osaka', country: 'Japan', countryCode: 'JP', latitude: 34.69, longitude: 135.5, timeZone: 'Asia/Tokyo' },
  { name: 'Seoul', region: 'Seoul', country: 'South Korea', countryCode: 'KR', latitude: 37.57, longitude: 126.98, timeZone: 'Asia/Seoul' },

  // --- Oceania ---
  { name: 'Sydney', region: 'New South Wales', country: 'Australia', countryCode: 'AU', latitude: -33.87, longitude: 151.21, timeZone: 'Australia/Sydney' },
  { name: 'Melbourne', region: 'Victoria', country: 'Australia', countryCode: 'AU', latitude: -37.81, longitude: 144.96, timeZone: 'Australia/Melbourne' },
  { name: 'Brisbane', region: 'Queensland', country: 'Australia', countryCode: 'AU', latitude: -27.47, longitude: 153.03, timeZone: 'Australia/Brisbane' },
  { name: 'Perth', region: 'Western Australia', country: 'Australia', countryCode: 'AU', latitude: -31.95, longitude: 115.86, timeZone: 'Australia/Perth' },
  { name: 'Adelaide', region: 'South Australia', country: 'Australia', countryCode: 'AU', latitude: -34.93, longitude: 138.6, timeZone: 'Australia/Adelaide' },
  { name: 'Canberra', region: 'ACT', country: 'Australia', countryCode: 'AU', latitude: -35.28, longitude: 149.13, timeZone: 'Australia/Sydney' },
  { name: 'Auckland', region: 'Auckland', country: 'New Zealand', countryCode: 'NZ', latitude: -36.85, longitude: 174.76, timeZone: 'Pacific/Auckland' },
  { name: 'Wellington', region: 'Wellington', country: 'New Zealand', countryCode: 'NZ', latitude: -41.29, longitude: 174.78, timeZone: 'Pacific/Auckland' },
  { name: 'Christchurch', region: 'Canterbury', country: 'New Zealand', countryCode: 'NZ', latitude: -43.53, longitude: 172.64, timeZone: 'Pacific/Auckland' },
  { name: 'Suva', region: 'Central Division', country: 'Fiji', countryCode: 'FJ', latitude: -18.14, longitude: 178.44, timeZone: 'Pacific/Fiji' },

  // --- High-latitude locations (twilight handling test scenarios) ---
  { name: 'Tromso', region: 'Troms og Finnmark', country: 'Norway', countryCode: 'NO', latitude: 69.65, longitude: 18.96, timeZone: 'Europe/Oslo' },
  { name: 'Rovaniemi', region: 'Lapland', country: 'Finland', countryCode: 'FI', latitude: 66.5, longitude: 25.73, timeZone: 'Europe/Helsinki' },
  { name: 'Reykjavik', region: 'Capital Region', country: 'Iceland', countryCode: 'IS', latitude: 64.15, longitude: -21.94, timeZone: 'Atlantic/Reykjavik' },
  { name: 'Anchorage', region: 'Alaska', country: 'United States', countryCode: 'US', latitude: 61.22, longitude: -149.9, timeZone: 'America/Anchorage' },
  { name: 'Fairbanks', region: 'Alaska', country: 'United States', countryCode: 'US', latitude: 64.84, longitude: -147.72, timeZone: 'America/Anchorage' },
  { name: 'Murmansk', region: 'Murmansk Oblast', country: 'Russia', countryCode: 'RU', latitude: 68.97, longitude: 33.08, timeZone: 'Europe/Moscow' },
  { name: 'Nuuk', region: 'Sermersooq', country: 'Greenland', countryCode: 'GL', latitude: 64.18, longitude: -51.72, timeZone: 'America/Nuuk' },
  { name: 'Whitehorse', region: 'Yukon', country: 'Canada', countryCode: 'CA', latitude: 60.72, longitude: -135.05, timeZone: 'America/Whitehorse' },
  { name: 'Yellowknife', region: 'Northwest Territories', country: 'Canada', countryCode: 'CA', latitude: 62.45, longitude: -114.37, timeZone: 'America/Yellowknife' },
]

/** Pre-built search keys (name + country + region, normalized). */
const SEARCH_ENTRIES = CITIES.map((city) => ({
  city,
  key: normalizeForSearch(`${city.name} ${city.country} ${city.region ?? ''}`),
}))

export interface CitySearchOptions {
  /** Maximum number of results (default 8). */
  limit?: number
  /** Optional country filter (ISO alpha-2). */
  countryCode?: string | null
}

/**
 * Search the bundled dataset. Case-insensitive, diacritic-tolerant,
 * partial-match on city, region or country name.
 */
export function searchBundledCities(query: string, options: CitySearchOptions = {}): CitySearchResult[] {
  const limit = Math.min(Math.max(options.limit ?? 8, 1), 20)
  const normalizedQuery = normalizeForSearch(query)
  if (!normalizedQuery) return []

  const matches: Array<{ score: number; entry: (typeof SEARCH_ENTRIES)[number] }> = []
  for (const entry of SEARCH_ENTRIES) {
    if (options.countryCode && entry.city.countryCode !== options.countryCode.toUpperCase()) {
      continue
    }
    const nameKey = normalizeForSearch(entry.city.name)
    const countryKey = normalizeForSearch(entry.city.country)
    let score = 0
    if (nameKey === normalizedQuery) score = 100
    else if (nameKey.startsWith(normalizedQuery)) score = 70
    else if (nameKey.includes(normalizedQuery)) score = 50
    else if (countryKey.includes(normalizedQuery)) score = 30
    else if (entry.key.includes(normalizedQuery)) score = 20
    if (score > 0) {
      matches.push({ score, entry })
    }
  }

  matches.sort((a, b) => b.score - a.score || a.entry.city.name.localeCompare(b.entry.city.name))
  return matches.slice(0, limit).map(({ entry }) => ({
    id: `bundled:${entry.city.countryCode}:${entry.city.name}`,
    name: entry.city.name,
    region: entry.city.region,
    country: entry.city.country,
    countryCode: entry.city.countryCode,
    latitude: entry.city.latitude,
    longitude: entry.city.longitude,
    timeZone: entry.city.timeZone,
    approximate: true,
    origin: 'bundled' as const,
  }))
}

/** A small set of quick-pick cities for the first-run experience. */
export const QUICK_PICK_CITY_IDS = [
  'bundled:SA:Makkah',
  'bundled:SA:Madinah',
  'bundled:EG:Cairo',
  'bundled:TR:Istanbul',
  'bundled:GB:London',
  'bundled:ID:Jakarta',
  'bundled:MY:Kuala Lumpur',
  'bundled:US:New York',
] as const

/**
 * The distinct IANA time zones covered by the bundled city dataset - a real,
 * existing list (no invented entries), used by the manual time-zone setting
 * so users can correct a wrongly detected zone for any place they would
 * realistically select.
 */
export const BUNDLED_TIME_ZONES: string[] = Array.from(
  new Set(CITIES.map((city) => city.timeZone)),
).sort((a, b) => a.localeCompare(b))

/** Resolve a bundled-city id (used by quick picks). */
export function getBundledCityById(id: string): CitySearchResult | null {
  const match = /^bundled:([A-Z]{2}):(.+)$/.exec(id)
  if (!match) return null
  const [, countryCode, name] = match
  const city = CITIES.find((entry) => entry.countryCode === countryCode && entry.name === name)
  if (!city) return null
  return {
    id,
    name: city.name,
    region: city.region,
    country: city.country,
    countryCode: city.countryCode,
    latitude: city.latitude,
    longitude: city.longitude,
    timeZone: city.timeZone,
    approximate: true,
    origin: 'bundled',
  }
}
