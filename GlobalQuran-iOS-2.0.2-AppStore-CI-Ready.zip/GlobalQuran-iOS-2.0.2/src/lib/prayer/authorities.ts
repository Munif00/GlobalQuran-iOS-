/**
 * Global Quran - Registry of official prayer-time authorities.
 *
 * Honesty rules for this registry (they mirror the product policy):
 * 1. An authority is only listed when its existence and role are verifiable
 *    through official public sources.
 * 2. No API or endpoint is claimed to exist unless it was actually verified
 *    against the live service (see `verificationEvidence`).
 * 3. "Integrated" status means the app really retrieves data from the
 *    authority's verified endpoint at runtime. Everything else honestly
 *    falls back to the documented AlAdhan method that implements the same
 *    standard (the method's presence in AlAdhan's own registry is the
 *    documented link, and it is stated as such - never as a partnership).
 * 4. No government approval or partnership is implied anywhere.
 */

import type { AuthorityRegistryEntryDto, JakimZoneInfo } from '@/types'

/**
 * JAKIM e-Solat prayer zones. All 60 codes below were verified live on
 * 2026-11-15 against the official endpoint
 * `https://www.e-solat.gov.my/index.php?r=esolatApi/takwimsolat&period=week&zone={code}`
 * and against JAKIM's published zone list page
 * (`https://www.e-solat.gov.my/index.php?siteId=24&pageId=50`).
 * Coverage labels use the Malaysian state (zone codes are district-level;
 * the district mapping is published by JAKIM on the e-Solat site).
 */
export const JAKIM_ZONES: ReadonlyArray<JakimZoneInfo> = [
  { code: 'JHR01', state: 'Johor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'JHR02', state: 'Johor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'JHR03', state: 'Johor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'JHR04', state: 'Johor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH01', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH02', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH03', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH04', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH05', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH06', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KDH07', state: 'Kedah', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KTN01', state: 'Kelantan', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'KTN02', state: 'Kelantan', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'MLK01', state: 'Melaka', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'NGS01', state: 'Negeri Sembilan', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'NGS02', state: 'Negeri Sembilan', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'NGS03', state: 'Negeri Sembilan', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG01', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG02', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG03', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG04', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG05', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG06', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PHG07', state: 'Pahang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PLS01', state: 'Perlis', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PNG01', state: 'Pulau Pinang', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK01', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK02', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK03', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK04', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK05', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK06', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'PRK07', state: 'Perak', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'SBH01', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH02', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH03', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH04', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH05', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH06', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH07', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH08', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SBH09', state: 'Sabah', timeZone: 'Asia/Kuching' },
  { code: 'SGR01', state: 'Selangor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'SGR02', state: 'Selangor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'SGR03', state: 'Selangor', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'SWK01', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK02', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK03', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK04', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK05', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK06', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK07', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK08', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'SWK09', state: 'Sarawak', timeZone: 'Asia/Kuching' },
  { code: 'TRG01', state: 'Terengganu', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'TRG02', state: 'Terengganu', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'TRG03', state: 'Terengganu', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'TRG04', state: 'Terengganu', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'WLY01', state: 'WP Kuala Lumpur', timeZone: 'Asia/Kuala_Lumpur' },
  { code: 'WLY02', state: 'WP Putrajaya', timeZone: 'Asia/Kuala_Lumpur' },
] as const

/** Validated lookup of a JAKIM zone code. */
export function getJakimZone(code: string): JakimZoneInfo | null {
  return JAKIM_ZONES.find((zone) => zone.code === code.toUpperCase()) ?? null
}

/**
 * Map a Malaysian state name (as commonly returned by geocoding services,
 * English or Malay) to its zone-code prefix. Used only to SUGGEST zones -
 * the user always confirms which zone applies to them.
 */
const MALAYSIA_STATE_PREFIXES: ReadonlyArray<{ names: string[]; prefix: string }> = [
  { names: ['johor'], prefix: 'JHR' },
  { names: ['kedah'], prefix: 'KDH' },
  { names: ['kelantan'], prefix: 'KTN' },
  { names: ['melaka', 'malacca'], prefix: 'MLK' },
  { names: ['negeri sembilan'], prefix: 'NGS' },
  { names: ['pahang'], prefix: 'PHG' },
  { names: ['perlis'], prefix: 'PLS' },
  { names: ['pulau pinang', 'penang'], prefix: 'PNG' },
  { names: ['perak'], prefix: 'PRK' },
  { names: ['sabah'], prefix: 'SBH' },
  { names: ['selangor'], prefix: 'SGR' },
  { names: ['sarawak'], prefix: 'SWK' },
  { names: ['terengganu'], prefix: 'TRG' },
  { names: ['kuala lumpur'], prefix: 'WLY' },
  { names: ['putrajaya'], prefix: 'WLY' },
]

/** Zones for a Malaysian state (empty when the state is unknown). */
export function jakimZonesForState(stateName: string | null): JakimZoneInfo[] {
  if (!stateName) return []
  const normalized = stateName.trim().toLowerCase()
  const match = MALAYSIA_STATE_PREFIXES.find((entry) =>
    entry.names.some((name) => normalized.includes(name)),
  )
  if (!match) return []
  return JAKIM_ZONES.filter((zone) => zone.code.startsWith(match.prefix))
}

/**
 * Single-zone places that can be auto-selected safely. WLY01 IS the WP
 * Kuala Lumpur zone and WLY02 the WP Putrajaya zone by definition (the
 * federal territories each have exactly one zone); Pulau Pinang and Perlis
 * likewise have a single zone (PNG01 / PLS01). Multi-zone states are never
 * guessed - the user picks from the published list.
 */
const KNOWN_SINGLE_ZONE_PLACES: ReadonlyArray<{ match: string[]; zone: string }> = [
  { match: ['kuala lumpur'], zone: 'WLY01' },
  { match: ['putrajaya'], zone: 'WLY02' },
  { match: ['pulau pinang', 'penang', 'george town'], zone: 'PNG01' },
  { match: ['perlis', 'kangar'], zone: 'PLS01' },
  { match: ['melaka', 'malacca'], zone: 'MLK01' },
]

/** A safe automatic zone for well-known single-zone places (null otherwise). */
export function jakimZoneForKnownPlace(placeName: string | null): string | null {
  if (!placeName) return null
  const normalized = placeName.trim().toLowerCase()
  const entry = KNOWN_SINGLE_ZONE_PLACES.find((item) =>
    item.match.some((name) => normalized.includes(name)),
  )
  return entry?.zone ?? null
}

/**
 * The official authority registry. Structure mirrors the product spec:
 * country, region, authority name/type, website, endpoint, coverage, format,
 * update frequency, verification date & evidence, reliability, and the
 * honest implementation status.
 */
export const OFFICIAL_AUTHORITY_REGISTRY: ReadonlyArray<AuthorityRegistryEntryDto> = [
  {
    id: 'MY-JAKIM',
    countryCode: 'MY',
    countryName: 'Malaysia',
    region: 'Nationwide (zone-based)',
    authorityName: 'Jabatan Kemajuan Islam Malaysia (JAKIM)',
    authorityType: 'Government Islamic authority (Department of Islamic Development Malaysia)',
    website: 'https://www.e-solat.gov.my',
    endpoint: 'https://www.e-solat.gov.my/index.php?r=esolatApi/takwimsolat',
    endpointFormat: 'JSON (public, no API key)',
    coverage: 'All Malaysian states via 60 zone codes (verified list bundled with this app)',
    updateFrequency: 'Published daily; the API serves the current year',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'Official .gov.my domain. The endpoint was called live on 2026-11-15 and returned the official prayer timetable (Imsak/Fajr/Syuruk/Dhuhr/Asr/Maghrib/Isha) for all 60 published zone codes; zone codes cross-checked against the zone list page at siteId=24&pageId=50.',
    reliability: 'verified_live',
    implementation: 'integrated',
    aladhanMethod: 'JAKIM',
    aladhanMethodNote:
      'AlAdhan method 17 implements the JAKIM calculation parameters and is used as fallback when the official endpoint is unreachable or for dates beyond the published year.',
  },
  {
    id: 'SA-UMMALQURA',
    countryCode: 'SA',
    countryName: 'Saudi Arabia',
    region: 'Nationwide',
    authorityName: 'Umm Al-Qura University, Makkah',
    authorityType: 'National academic/religious institution (issuer of the official Umm Al-Qura calendar)',
    website: 'https://www.umm-alqura.org',
    endpoint: null,
    endpointFormat: null,
    coverage: 'Saudi Arabia',
    updateFrequency: 'Official Umm Al-Qura calendar, published per year',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'The authority and its calendar are publicly documented. No machine-readable public API is published by the university itself; no endpoint is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'MAKKAH',
    aladhanMethodNote:
      'AlAdhan method 4 implements the Umm Al-Qura standard (Fajr 18.5°, Isha 90 min after Maghrib). Used as the source tier for Saudi Arabia.',
  },
  {
    id: 'TR-DIYANET',
    countryCode: 'TR',
    countryName: 'Turkey',
    region: 'Nationwide',
    authorityName: 'Diyanet İşleri Başkanlığı (Presidency of Religious Affairs)',
    authorityType: 'Government religious affairs department',
    website: 'https://namazvakitleri.diyanet.gov.tr',
    endpoint: 'https://api.diyanet.gov.tr',
    endpointFormat: 'Official API - requires a registered API key',
    coverage: 'All Turkish cities and districts',
    updateFrequency: 'Published monthly by the official website and app',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'The official website publishes the national timetable. Diyanet operates an official API portal (api.diyanet.gov.tr) that requires a developer-registered API key; no key has been obtained for this app, so the endpoint is NOT used.',
    reliability: 'requires_api_key',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'TURKEY',
    aladhanMethodNote:
      'AlAdhan method 13 implements the Diyanet standard (Fajr 18°, Isha 17°); AlAdhan itself labels this method "(experimental)" - this is disclosed wherever it is used.',
  },
  {
    id: 'SG-MUIS',
    countryCode: 'SG',
    countryName: 'Singapore',
    region: 'Nationwide',
    authorityName: 'Majlis Ugama Islam Singapura (MUIS)',
    authorityType: 'Government Islamic Religious Council',
    website: 'https://www.muis.gov.sg',
    endpoint: null,
    endpointFormat: null,
    coverage: 'Singapore',
    updateFrequency: 'Published daily on the official website',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'MUIS publishes prayer times on its official website. No publicly documented machine-readable API was verified; none is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'SINGAPORE',
    aladhanMethodNote:
      'AlAdhan method 11 implements the MUIS calculation parameters (Fajr 20°, Isha 18°) and is used as the source tier for Singapore.',
  },
  {
    id: 'ID-KEMENAG',
    countryCode: 'ID',
    countryName: 'Indonesia',
    region: 'Nationwide',
    authorityName: 'Kementerian Agama Republik Indonesia (KEMENAG)',
    authorityType: 'Government ministry (Ministry of Religious Affairs)',
    website: 'https://bimasislam.kemenag.go.id',
    endpoint: null,
    endpointFormat: null,
    coverage: 'All Indonesian provinces',
    updateFrequency: 'Published monthly on the official portal',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'The ministry publishes official schedules on bimasislam.kemenag.go.id. No officially documented public API was verified; internal endpoints observed by third parties are not officially documented and are therefore NOT used.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'KEMENAG',
    aladhanMethodNote:
      'AlAdhan method 20 implements the KEMENAG parameters (Fajr 20°, Isha 18°) and is used as the source tier for Indonesia.',
  },
  {
    id: 'EG-SURVEY',
    countryCode: 'EG',
    countryName: 'Egypt',
    region: 'Nationwide',
    authorityName: 'Egyptian General Authority of Survey',
    authorityType: 'Government survey authority',
    website: null,
    endpoint: null,
    endpointFormat: null,
    coverage: 'Egypt',
    updateFrequency: 'The authority\'s parameters (Fajr 19.5°, Isha 17.5°) are the national standard',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'The authority is the documented source of the Egyptian calculation standard, represented in AlAdhan\'s registry as method 5. No public machine-readable endpoint was verified; none is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'EGYPT',
    aladhanMethodNote:
      'AlAdhan method 5 implements the Egyptian General Authority of Survey parameters and is used as the source tier for Egypt.',
  },
  {
    id: 'JO-AWQAF',
    countryCode: 'JO',
    countryName: 'Jordan',
    region: 'Nationwide',
    authorityName: 'Ministry of Awqaf, Islamic Affairs and Holy Places',
    authorityType: 'Government ministry',
    website: 'https://www.awqaf.gov.jo',
    endpoint: null,
    endpointFormat: null,
    coverage: 'Jordan',
    updateFrequency: 'Published by the ministry; represented in AlAdhan as method 23',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'The ministry is documented in AlAdhan\'s registry as the source of method 23 (Fajr 18°, Maghrib +5 min, Isha 18°). No public machine-readable endpoint was verified; none is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'JORDAN',
    aladhanMethodNote:
      'AlAdhan method 23 implements the Jordanian ministry standard and is used as the source tier for Jordan.',
  },
  {
    id: 'QA-AWQAF',
    countryCode: 'QA',
    countryName: 'Qatar',
    region: 'Nationwide',
    authorityName: 'Qatar national prayer timetable standard',
    authorityType: 'National standard (as documented in the AlAdhan method registry)',
    website: null,
    endpoint: null,
    endpointFormat: null,
    coverage: 'Qatar',
    updateFrequency: 'Represented in AlAdhan as method 10 (Fajr 18°, Isha 90 min)',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'Method 10 "Qatar" in the verified AlAdhan /v1/methods registry. No separate government endpoint was verified; none is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'QATAR',
    aladhanMethodNote: 'AlAdhan method 10 is the source tier for Qatar.',
  },
  {
    id: 'KW-AWQAF',
    countryCode: 'KW',
    countryName: 'Kuwait',
    region: 'Nationwide',
    authorityName: 'Kuwait national prayer timetable standard',
    authorityType: 'National standard (as documented in the AlAdhan method registry)',
    website: null,
    endpoint: null,
    endpointFormat: null,
    coverage: 'Kuwait',
    updateFrequency: 'Represented in AlAdhan as method 9 (Fajr 18°, Isha 17.5°)',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'Method 9 "Kuwait" in the verified AlAdhan /v1/methods registry. No separate government endpoint was verified; none is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'KUWAIT',
    aladhanMethodNote: 'AlAdhan method 9 is the source tier for Kuwait.',
  },
  {
    id: 'AE-AWQAF',
    countryCode: 'AE',
    countryName: 'United Arab Emirates',
    region: 'Nationwide (Dubai method also available)',
    authorityName: 'UAE / Dubai prayer timetable standard',
    authorityType: 'National and emirate-level standards (as documented in the AlAdhan method registry)',
    website: null,
    endpoint: null,
    endpointFormat: null,
    coverage: 'United Arab Emirates',
    updateFrequency: 'Represented in AlAdhan as methods 8 (Gulf Region) and 16 (Dubai, experimental)',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'Methods 8 and 16 in the verified AlAdhan /v1/methods registry. No separate government endpoint was verified; none is claimed.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'GULF',
    aladhanMethodNote:
      'The default for the UAE is the Gulf Region method (8); the Dubai method (16) is available as a manual choice and is labeled experimental by AlAdhan.',
  },
  {
    id: 'NA-ISNA',
    countryCode: 'US',
    countryName: 'United States & Canada',
    region: 'North America',
    authorityName: 'Islamic Society of North America (ISNA)',
    authorityType: 'Recognized national Islamic organization (not a government body)',
    website: 'https://www.isna.net',
    endpoint: null,
    endpointFormat: null,
    coverage: 'United States and Canada',
    updateFrequency: 'Represented in AlAdhan as method 2 (Fajr 15°, Isha 15°)',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'ISNA is a recognized North American organization whose calculation standard is documented as AlAdhan method 2. ISNA is not a government authority - this is stated plainly wherever it appears.',
    reliability: 'official_source_no_public_api',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'ISNA',
    aladhanMethodNote: 'AlAdhan method 2 is the source tier for the United States and Canada.',
  },
  {
    id: 'GB-NONE',
    countryCode: 'GB',
    countryName: 'United Kingdom',
    region: 'Nationwide',
    authorityName: 'No single official national authority',
    authorityType: 'None verified',
    website: null,
    endpoint: null,
    endpointFormat: null,
    coverage: 'United Kingdom',
    updateFrequency: 'Multiple standards coexist (MWL, Moonsighting Committee, local mosques)',
    lastVerified: '2026-11-15',
    verificationEvidence:
      'No UK government body publishes an official national prayer timetable. Local mosques follow different standards; no official source is claimed.',
    reliability: 'unverified',
    implementation: 'fallback_to_aladhan',
    aladhanMethod: 'MWL',
    aladhanMethodNote:
      'The Muslim World League (method 3) is offered as the default recommendation - it is NOT an official national setting. Users can select the Moonsighting Committee method or adjust times manually.',
  },
] as const

/** The honest registry summary surfaced to users. */
export const REGISTRY_SUMMARY =
  'One official authority is integrated (JAKIM, Malaysia - verified live). For all other countries the app uses the documented AlAdhan calculation method that implements that country\'s standard, with no partnership or approval implied. Countries without a national standard receive a clearly-labeled recommended default, never an invented official one.'
