/**
 * Global Quran - AlAdhan calculation method registry.
 *
 * Every entry below was verified live against the AlAdhan API
 * `GET https://api.aladhan.com/v1/methods` on 2026-11-15
 * (documentation: https://aladhan.com/calculation-methods).
 * Nothing here is invented: names, numeric ids, angle parameters and the
 * "experimental" labels come from that response. The `CUSTOM` (99) method
 * is intentionally excluded - user-defined methods are not offered.
 */

import type { CalculationMethodInfo, CalculationMethodId } from '@/types'

export interface PrayerMethodDefinition extends CalculationMethodInfo {
  /**
   * Documented parameters for the offline engine (angles in degrees,
   * intervals in minutes after a reference time). Taken from the same
   * verified /v1/methods response.
   */
  engine: {
    fajrAngle: number
    ishaAngle: number
    /** Isha interval in minutes after Maghrib; 0 = use the angle. */
    ishaIntervalMinutes: number
    /** Maghrib interval in minutes after sunset; 0 = use sunset. */
    maghribIntervalMinutes: number
    /** Maghrib angle below the horizon (Tehran/Jafari); 0 = use sunset. */
    maghribAngle: number
  }
}

/**
 * The verified method table. `engine` values mirror the documented params:
 * e.g. MAKKAH params `{ Fajr: 18.5, Isha: "90 min" }` ->
 * fajrAngle 18.5, ishaIntervalMinutes 90.
 */
export const PRAYER_METHODS: ReadonlyArray<PrayerMethodDefinition> = [
  {
    id: 'MWL',
    numericId: 3,
    name: 'Muslim World League',
    paramsSummary: 'Fajr 18° · Isha 17°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 17, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'ISNA',
    numericId: 2,
    name: 'Islamic Society of North America (ISNA)',
    paramsSummary: 'Fajr 15° · Isha 15°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 15, ishaAngle: 15, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'EGYPT',
    numericId: 5,
    name: 'Egyptian General Authority of Survey',
    paramsSummary: 'Fajr 19.5° · Isha 17.5°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 19.5, ishaAngle: 17.5, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'MAKKAH',
    numericId: 4,
    name: 'Umm Al-Qura University, Makkah',
    paramsSummary: 'Fajr 18.5° · Isha 90 min',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18.5, ishaAngle: 0, ishaIntervalMinutes: 90, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'KARACHI',
    numericId: 1,
    name: 'University of Islamic Sciences, Karachi',
    paramsSummary: 'Fajr 18° · Isha 18°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'TEHRAN',
    /** AlAdhan params: Maghrib 4.5°. */
    numericId: 7,
    name: 'Institute of Geophysics, University of Tehran',
    paramsSummary: 'Fajr 17.7° · Maghrib 4.5° · Isha 14°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 17.7, ishaAngle: 14, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 4.5 },
  },
  {
    id: 'JAFARI',
    numericId: 0,
    name: 'Shia Ithna-Ashari, Leva Institute, Qum',
    paramsSummary: 'Fajr 16° · Maghrib 4° · Isha 14°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 16, ishaAngle: 14, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 4 },
  },
  {
    id: 'GULF',
    numericId: 8,
    name: 'Gulf Region',
    paramsSummary: 'Fajr 19.5° · Isha 90 min',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 19.5, ishaAngle: 0, ishaIntervalMinutes: 90, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'KUWAIT',
    numericId: 9,
    name: 'Kuwait',
    paramsSummary: 'Fajr 18° · Isha 17.5°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 17.5, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'QATAR',
    numericId: 10,
    name: 'Qatar',
    paramsSummary: 'Fajr 18° · Isha 90 min',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 0, ishaIntervalMinutes: 90, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'SINGAPORE',
    numericId: 11,
    name: 'Majlis Ugama Islam Singapura, Singapore',
    paramsSummary: 'Fajr 20° · Isha 18°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 20, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'FRANCE',
    numericId: 12,
    name: 'Union Organization Islamic de France',
    paramsSummary: 'Fajr 12° · Isha 12°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 12, ishaAngle: 12, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'TURKEY',
    numericId: 13,
    name: 'Diyanet İşleri Başkanlığı, Turkey',
    paramsSummary: 'Fajr 18° · Isha 17°',
    /** AlAdhan labels this method "(experimental)" in /v1/methods. */
    experimental: true,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 17, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'RUSSIA',
    numericId: 14,
    name: 'Spiritual Administration of Muslims of Russia',
    paramsSummary: 'Fajr 16° · Isha 15°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 16, ishaAngle: 15, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'MOONSIGHTING',
    numericId: 15,
    name: 'Moonsighting Committee Worldwide',
    paramsSummary: 'Shafaq: general',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'DUBAI',
    numericId: 16,
    name: 'Dubai',
    paramsSummary: 'Fajr 18.2° · Isha 18.2°',
    /** AlAdhan labels this method "(experimental)" in /v1/methods. */
    experimental: true,
    localEngineSupported: true,
    engine: { fajrAngle: 18.2, ishaAngle: 18.2, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'JAKIM',
    numericId: 17,
    name: 'Jabatan Kemajuan Islam Malaysia (JAKIM)',
    paramsSummary: 'Fajr 20° · Isha 18°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 20, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'TUNISIA',
    numericId: 18,
    name: 'Tunisia',
    paramsSummary: 'Fajr 18° · Isha 18°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'ALGERIA',
    numericId: 19,
    name: 'Algeria',
    paramsSummary: 'Fajr 18° · Isha 17°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 17, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'KEMENAG',
    numericId: 20,
    name: 'Kementerian Agama Republik Indonesia',
    paramsSummary: 'Fajr 20° · Isha 18°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 20, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'MOROCCO',
    numericId: 21,
    name: 'Morocco',
    paramsSummary: 'Fajr 19° · Isha 17°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 19, ishaAngle: 17, ishaIntervalMinutes: 0, maghribIntervalMinutes: 0, maghribAngle: 0 },
  },
  {
    id: 'PORTUGAL',
    numericId: 22,
    name: 'Comunidade Islamica de Lisboa',
    paramsSummary: 'Fajr 18° · Maghrib +3 min · Isha 77 min',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 0, ishaIntervalMinutes: 77, maghribIntervalMinutes: 3, maghribAngle: 0 },
  },
  {
    id: 'JORDAN',
    numericId: 23,
    name: 'Ministry of Awqaf, Islamic Affairs and Holy Places, Jordan',
    paramsSummary: 'Fajr 18° · Maghrib +5 min · Isha 18°',
    experimental: false,
    localEngineSupported: true,
    engine: { fajrAngle: 18, ishaAngle: 18, ishaIntervalMinutes: 0, maghribIntervalMinutes: 5, maghribAngle: 0 },
  },
] as const

/** Lookup by string id (typed; returns undefined for unknown ids). */
export function getPrayerMethod(id: CalculationMethodId): PrayerMethodDefinition {
  const method = PRAYER_METHODS.find((entry) => entry.id === id)
  if (!method) {
    throw new Error(`Unknown calculation method: ${id}`)
  }
  return method
}

/** Type guard for untrusted input. */
export function isCalculationMethodId(value: unknown): value is CalculationMethodId {
  return typeof value === 'string' && PRAYER_METHODS.some((entry) => entry.id === value)
}

/** The documented global default when a country has no specific method. */
export const GLOBAL_DEFAULT_METHOD: CalculationMethodId = 'MWL'

/** When the bundled registry was verified against the live API. */
export const METHODS_VERIFIED_AT = '2026-11-15'
export const METHODS_VERIFIED_FROM =
  'https://aladhan.com/calculation-methods (verified via GET https://api.aladhan.com/v1/methods)'
