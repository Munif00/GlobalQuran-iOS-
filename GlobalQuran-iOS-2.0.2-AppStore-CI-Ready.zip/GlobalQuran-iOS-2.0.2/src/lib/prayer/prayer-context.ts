/**
 * Global Quran - shared prayer context builder.
 *
 * Extracted VERBATIM from the Prayer screen's parameter construction
 * (PROMPT 16) so the native reminder bridge computes EXACTLY the same
 * request the screen sends - one source of truth, no drift, no second
 * prayer engine. The screen now calls this helper; the native bridge calls
 * it too.
 *
 * Inputs are the persisted prayer settings + saved locations (the same
 * stores the screen reads), so both consumers stay in lock-step by
 * construction.
 */

import type { PrayerSettings, SavedPrayerLocation } from '@/types'
import type { PrayerQueryParams } from '@/services/api/prayer-api'

export interface EffectivePrayerLocation {
  id: string | null
  label: string | null
  city: string | null
  country: string | null
  countryCode: string | null
  latitude: number
  longitude: number
  timeZone: string | null
  jakimZone: string | null
}

export interface PrayerContext {
  effective: EffectivePrayerLocation
  requestTimeZone: string | null
  params: PrayerQueryParams
}

/**
 * Build the effective location + request time zone + query params from the
 * persisted state. Returns null when no location is configured yet (same
 * honest behavior as the screen: nothing to compute).
 */
export function buildPrayerContext(
  prayerSettings: Pick<
    PrayerSettings,
    | 'latitude'
    | 'longitude'
    | 'city'
    | 'countryName'
    | 'countryCode'
    | 'timeZone'
    | 'jakimZone'
    | 'timeZoneMode'
    | 'manualTimeZone'
    | 'methodMode'
    | 'calculationMethod'
    | 'madhhab'
    | 'highLatitudeRule'
    | 'adjustments'
  >,
  savedLocations: SavedPrayerLocation[],
  activeLocationId: string | null,
): PrayerContext | null {
  const activeSaved = savedLocations.find((location) => location.id === activeLocationId) ?? null

  const latitude = activeSaved?.latitude ?? prayerSettings.latitude
  const longitude = activeSaved?.longitude ?? prayerSettings.longitude
  if (latitude == null || longitude == null) return null

  const effective: EffectivePrayerLocation = {
    id: activeSaved?.id ?? null,
    label: activeSaved?.label ?? null,
    city: activeSaved?.city ?? prayerSettings.city,
    country: activeSaved?.country ?? prayerSettings.countryName,
    countryCode: activeSaved?.countryCode ?? prayerSettings.countryCode,
    latitude,
    longitude,
    timeZone: activeSaved?.timeZone ?? prayerSettings.timeZone,
    jakimZone: activeSaved?.jakimZone ?? prayerSettings.jakimZone,
  }

  const requestTimeZone =
    prayerSettings.timeZoneMode === 'manual' && prayerSettings.manualTimeZone
      ? prayerSettings.manualTimeZone
      : effective.timeZone

  const isMalaysia = effective.countryCode === 'MY'

  const params: PrayerQueryParams = {
    latitude: effective.latitude,
    longitude: effective.longitude,
    timeZone: requestTimeZone,
    countryCode: effective.countryCode,
    methodMode: prayerSettings.methodMode,
    methodId: prayerSettings.calculationMethod,
    madhhab: prayerSettings.madhhab,
    highLatitudeRule: prayerSettings.highLatitudeRule,
    adjustments: prayerSettings.adjustments,
    jakimZone: isMalaysia ? (prayerSettings.jakimZone ?? null) : null,
  }

  return { effective, requestTimeZone, params }
}
