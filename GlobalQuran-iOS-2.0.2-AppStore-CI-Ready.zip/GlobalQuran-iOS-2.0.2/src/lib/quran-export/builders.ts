/**
 * Global Quran - Export document builders (isomorphic: server + client).
 *
 * Builds a complete export of one QuranEnc translation in four formats:
 * - JSON (structured document)
 * - TXT (UTF-8 with BOM)
 * - DOCX (real Word document via the `docx` package - browser-compatible
 *   through Packer.toBlob)
 * - HTML (self-contained print document; the client prints it to PDF)
 *
 * Extracted verbatim from the export route so the web server and the
 * native app generate identical files. Arabic text is passed through
 * verbatim; only structural markers (ayah numbers, headings, separators)
 * are added around it. Every file carries the explicit rights notice.
 */

import {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  LineRuleType,
  Packer,
  Paragraph,
  TextRun,
  type IRunOptions,
} from 'docx'

export const EXPORT_SOURCE_LABEL = 'QuranEnc'

/**
 * Redistribution rights notice.
 *
 * QuranEnc does not publish per-translation licensing fields through its API,
 * so the app cannot verify whether a given translation permits redistribution.
 * Rather than fabricating a rights status, every exported file carries this
 * explicit notice. It is included in ALL four formats and in the export UI.
 */
export const RIGHTS_NOTICE =
  'Rights status: not documented by the source. This file is provided for personal use. Do not redistribute or republish it without verifying the rights with the translation publisher.'

/* ------------------------------------------------------------------ */
/* Export shapes                                                       */
/* ------------------------------------------------------------------ */

export interface ExportAya {
  number: number
  arabicText: string
  translation: string
  footnotes: string | null
}

export interface ExportSura {
  number: number
  nameArabic: string
  nameEnglish: string
  ayahCount: number
  ayat: ExportAya[]
}

export interface ExportMeta {
  key: string
  title: string
  languageCode: string
  languageName: string
  direction: 'ltr' | 'rtl'
  version: string | null
  lastUpdate: string | null
  exportedAt: string
  source: string
  suraCount: number
  ayahCount: number
  /** Redistribution rights notice (always present - see RIGHTS_NOTICE). */
  rightsNotice: string
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/** `english_rwwad` -> `quran-english-rwwad` (charset [a-z0-9-]). */
export function buildFileStem(translationKey: string): string {
  const cleaned = translationKey.replace(/_/g, '-').replace(/[^a-z0-9-]/g, '')
  return `quran-${cleaned.length > 0 ? cleaned : 'translation'}`
}

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/** Escape for HTML and keep the source's own line breaks visible. */
export function escapeHtmlMultiline(value: string): string {
  return escapeHtml(value).replace(/\n/g, '<br>')
}

/**
 * Source text (translations, footnotes) may contain embedded newlines.
 * Splitting them into runs with `break: 1` preserves those line breaks in
 * Word without altering a single character of the text.
 */
function multilineTextRuns(
  text: string,
  runOptions: Omit<IRunOptions, 'text' | 'break'>,
): TextRun[] {
  return text
    .split('\n')
    .map((line, index) =>
      new TextRun({
        ...runOptions,
        text: line,
        ...(index > 0 ? { break: 1 } : {}),
      }),
    )
}

export function contentDisposition(attachment: boolean, filename: string): string {
  return `${attachment ? 'attachment' : 'inline'}; filename="${filename}"`
}

/* ------------------------------------------------------------------ */
/* Format builders                                                     */
/* ------------------------------------------------------------------ */

/** Structured JSON document (meta + all suras). */
export function buildJsonExport(meta: ExportMeta, suras: ExportSura[]): string {
  return JSON.stringify(
    {
      meta: {
        key: meta.key,
        title: meta.title,
        languageCode: meta.languageCode,
        languageName: meta.languageName,
        direction: meta.direction,
        version: meta.version,
        lastUpdate: meta.lastUpdate,
        exportedAt: meta.exportedAt,
        source: meta.source,
        rightsNotice: meta.rightsNotice,
        suraCount: meta.suraCount,
        ayahCount: meta.ayahCount,
      },
      suras: suras.map((sura) => ({
        number: sura.number,
        nameArabic: sura.nameArabic,
        nameEnglish: sura.nameEnglish,
        ayahCount: sura.ayahCount,
        ayat: sura.ayat.map((aya) => ({
          number: aya.number,
          arabicText: aya.arabicText,
          translation: aya.translation,
          footnotes: aya.footnotes,
        })),
      })),
    },
    null,
    2,
  )
}

/** Structured plain text, UTF-8 with BOM so Windows Notepad detects UTF-8. */
export function buildTxtExport(meta: ExportMeta, suras: ExportSura[]): string {
  const frame = '='.repeat(64)
  const suraRule = '-'.repeat(64)
  const lines: string[] = []

  lines.push(frame)
  lines.push(meta.title)
  lines.push(`Language: ${meta.languageName} (${meta.languageCode})`)
  lines.push(`Source: ${EXPORT_SOURCE_LABEL} - ${meta.source}`)
  if (meta.version) lines.push(`Version: ${meta.version}`)
  if (meta.lastUpdate) lines.push(`Last update: ${meta.lastUpdate.slice(0, 10)}`)
  lines.push(`Exported: ${meta.exportedAt}`)
  lines.push(`Extent: ${meta.suraCount} suras - ${meta.ayahCount} ayat`)
  lines.push('')
  lines.push(meta.rightsNotice)
  lines.push(frame)
  lines.push('')

  for (const sura of suras) {
    lines.push(suraRule)
    lines.push(`Sura ${sura.number} - ${sura.nameArabic} (${sura.nameEnglish}) - ${sura.ayahCount} ayat`)
    lines.push(suraRule)
    for (const aya of sura.ayat) {
      lines.push(`[${aya.number}] ${aya.arabicText}`)
      lines.push(aya.translation)
      if (aya.footnotes) lines.push(`[note] ${aya.footnotes}`)
      lines.push('')
    }
  }

  return `\uFEFF${lines.join('\n')}\n`
}

/** Real Word document (docx package; browser-compatible via Packer.toBlob). */
export async function buildDocxExport(meta: ExportMeta, suras: ExportSura[]): Promise<Blob> {
  const rtl = meta.direction === 'rtl'
  const children: Paragraph[] = []

  /* Title page */
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 3400, after: 260 },
      children: [
        new TextRun({
          text: 'TRANSLATION OF THE MEANINGS OF THE HOLY QURAN',
          size: 18,
          color: 'a8a29e',
          characterSpacing: 24,
          font: 'Georgia',
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 140 },
      children: [new TextRun({ text: meta.title, bold: true, size: 44, color: '1c1917', font: 'Georgia' })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 60 },
      children: [
        new TextRun({
          text: `${meta.languageName} (${meta.languageCode})`,
          size: 24,
          color: '78716c',
          font: 'Georgia',
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 160, after: 480 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: 'b08d2f', space: 2 } },
      children: [],
    }),
  )

  const coverLines: string[] = [
    `Source: ${EXPORT_SOURCE_LABEL} (${meta.source})`,
    meta.version ? `Version: ${meta.version}` : '',
    meta.lastUpdate ? `Last update: ${meta.lastUpdate.slice(0, 10)}` : '',
    `Exported: ${meta.exportedAt.slice(0, 10)}`,
    `${meta.suraCount} suras - ${meta.ayahCount} ayat`,
    '',
    meta.rightsNotice,
  ].filter((line) => line.length > 0)

  for (const line of coverLines) {
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 90 },
        children: [new TextRun({ text: line, size: 20, color: '78716c', font: 'Georgia' })],
      }),
    )
  }

  /* Sura sections */
  for (const sura of suras) {
    children.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        pageBreakBefore: true,
        bidirectional: true,
        spacing: { after: 320 },
        children: [
          new TextRun({ text: `${sura.number}. `, bold: true, size: 28, color: '292524', font: 'Georgia' }),
          new TextRun({
            text: sura.nameArabic,
            rightToLeft: true,
            bold: true,
            size: 34,
            color: '292524',
            font: 'Amiri',
          }),
          new TextRun({ text: ` — ${sura.nameEnglish}`, size: 24, color: '78716c', font: 'Georgia' }),
          new TextRun({
            text: `   (${sura.ayahCount} ayat)`,
            size: 20,
            color: 'a8a29e',
            font: 'Georgia',
          }),
        ],
      }),
    )

    for (const aya of sura.ayat) {
      // Arabic - verbatim Uthmanic Hafs text, RTL paragraph, 18pt Amiri.
      children.push(
        new Paragraph({
          bidirectional: true,
          spacing: { after: 120, line: 340, lineRule: LineRuleType.AUTO },
          children: [
            new TextRun({ text: aya.arabicText, rightToLeft: true, size: 36, color: '1c1917', font: 'Amiri' }),
          ],
        }),
      )
      // Translation - direction follows the translation's own direction field.
      children.push(
        new Paragraph({
          bidirectional: rtl,
          alignment: AlignmentType.JUSTIFIED,
          spacing: { before: 40, after: 240 },
          children: [
            new TextRun({ text: `${aya.number} `, bold: true, size: 18, color: 'a16207', font: 'Georgia' }),
            ...multilineTextRuns(aya.translation, { size: 22, color: '1c1917', font: 'Georgia' }),
          ],
        }),
      )
      if (aya.footnotes) {
        const noteLines = aya.footnotes.split('\n')
        children.push(
          new Paragraph({
            bidirectional: rtl,
            spacing: { after: 280 },
            children: noteLines.map((line, index) =>
              new TextRun({
                text: index === 0 ? `[note] ${line}` : line,
                ...(index > 0 ? { break: 1 } : {}),
                italics: true,
                size: 18,
                color: '78716c',
                font: 'Georgia',
              }),
            ),
          }),
        )
      }
    }
  }

  const document_ = new Document({
    title: meta.title,
    subject: 'Translation of the meanings of the Holy Quran',
    creator: 'Global Quran',
    description: `Complete export of ${meta.title} (${meta.languageName}) - ${meta.suraCount} suras, ${meta.ayahCount} ayat. Source: ${EXPORT_SOURCE_LABEL} (${meta.source}).`,
    keywords: `Quran, translation, ${meta.languageName}, ${EXPORT_SOURCE_LABEL}`,
    styles: {
      default: {
        document: { run: { font: 'Georgia', size: 22, color: '1c1917' } },
        heading1: {
          run: { color: '292524', size: 32, bold: true },
          paragraph: { spacing: { before: 240, after: 240 } },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440, header: 720, footer: 720 },
          },
        },
        children,
      },
    ],
  })

  return Packer.toBlob(document_)
}

/** Self-contained print-optimized HTML document (the client prints it to PDF). */
export function buildHtmlExport(meta: ExportMeta, suras: ExportSura[]): string {
  const esc = escapeHtml
  const rtl = meta.direction === 'rtl'
  const dirAttr = rtl ? 'rtl' : 'ltr'

  const suraSections = suras
    .map((sura) => {
      const ayat = sura.ayat
        .map((aya) => {
          const footnote = aya.footnotes
            ? `\n      <p class="footnote" dir="${dirAttr}">[note] ${escapeHtmlMultiline(aya.footnotes)}</p>`
            : ''
          return `\n      <div class="ayah-pair">\
\n        <p class="arabic" dir="rtl" lang="ar">${esc(aya.arabicText)}</p>\
\n        <p class="translation" dir="${dirAttr}"><span class="ayah-num">${aya.number}</span>&#160;${escapeHtmlMultiline(aya.translation)}</p>${footnote}\
\n      </div>`
        })
        .join('')
      return `\n    <section class="sura" aria-label="Sura ${sura.number}, ${esc(sura.nameEnglish)}">\
\n      <header class="sura-head">\
\n        <p class="sura-kicker">Sura ${sura.number} - ${sura.ayahCount} ayat</p>\
\n        <h2><span class="sura-arabic" dir="rtl" lang="ar">${esc(sura.nameArabic)}</span> <span class="sura-latin">${esc(sura.nameEnglish)}</span></h2>\
\n      </header>${ayat}\
\n    </section>`
    })
    .join('')

  const coverRows: string[] = [
    `<p class="row"><span class="row-key">Source</span>${EXPORT_SOURCE_LABEL} - ${esc(meta.source)}</p>`,
  ]
  if (meta.version) {
    coverRows.push(`<p class="row"><span class="row-key">Version</span>${esc(meta.version)}</p>`)
  }
  if (meta.lastUpdate) {
    coverRows.push(
      `<p class="row"><span class="row-key">Last update</span>${esc(meta.lastUpdate.slice(0, 10))}</p>`,
    )
  }
  coverRows.push(
    `<p class="row"><span class="row-key">Exported</span>${esc(meta.exportedAt.slice(0, 10))}</p>`,
    `<p class="row"><span class="row-key">Extent</span>${meta.suraCount} suras - ${meta.ayahCount} ayat</p>`,
  )

  const rightsBlock = `\n    <p class="rights">${esc(meta.rightsNotice)}</p>`

  return `<!DOCTYPE html>
<html lang="${esc(meta.languageCode)}" dir="${dirAttr}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(meta.title)} - Global Quran export</title>
<style>
@font-face {
  font-family: 'Hafs20';
  src: url('/fonts/Hafs_20.woff2') format('woff2');
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}
@page { size: A4; margin: 20mm 16mm 22mm; }
* { box-sizing: border-box; }
html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body {
  margin: 0;
  background: #ffffff;
  color: #1c1917;
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 11pt;
  line-height: 1.65;
}
.cover { text-align: center; padding-top: 52mm; page-break-after: always; }
.cover .kicker {
  margin: 0 0 20pt;
  font-size: 9.5pt;
  letter-spacing: 0.32em;
  text-transform: uppercase;
  color: #a8a29e;
}
.cover h1 { margin: 0 0 10pt; font-size: 25pt; line-height: 1.25; color: #1c1917; }
.cover .lang { margin: 0; font-size: 12pt; color: #78716c; }
.cover .rule { width: 46mm; margin: 22pt auto; border-top: 1pt solid #b08d2f; }
.cover .rows { margin-top: 24mm; font-size: 10pt; color: #78716c; }
.cover .row { margin: 3pt 0; }
.cover .row-key { color: #a8a29e; margin-inline-end: 6pt; }
.cover .rights { margin: 14pt auto 0; max-width: 120mm; font-size: 8.5pt; color: #a16207; }
.cover .foot { margin-top: 38mm; font-size: 9pt; color: #a8a29e; }
.sura { page-break-before: always; }
.sura-head { border-bottom: 0.75pt solid #e7e5e4; padding-bottom: 5pt; margin: 0 0 14pt; }
.sura-kicker {
  margin: 0 0 3pt;
  font-size: 9pt;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: #a16207;
}
.sura-head h2 { margin: 0; font-size: 16pt; font-weight: 600; color: #292524; }
.sura-arabic { font-family: 'Hafs20', 'Amiri', serif; font-size: 19pt; }
.sura-latin { font-size: 12.5pt; font-weight: 400; color: #78716c; }
.ayah-pair { margin: 0 0 13pt; }
.arabic {
  direction: rtl;
  font-family: 'Hafs20', 'Amiri', serif;
  text-align: right;
  font-size: 17pt;
  line-height: 2.05;
  margin: 0 0 7pt;
}
.translation { margin: 0; }
.ayah-num { color: #a16207; font-weight: 700; font-size: 9.5pt; }
.footnote { margin: 4pt 0 0; font-size: 9.5pt; font-style: italic; color: #78716c; }
@media screen {
  body { padding: 18mm 14mm; }
  .cover { padding-top: 28mm; }
}
</style>
</head>
<body>
  <section class="cover" aria-label="Cover">
    <p class="kicker">Translation of the meanings of the Holy Quran</p>
    <h1>${esc(meta.title)}</h1>
    <p class="lang">${esc(meta.languageName)} (${esc(meta.languageCode)})</p>
    <div class="rule"></div>
    <div class="rows">${coverRows.join('')}</div>${rightsBlock}
    <p class="foot">Generated by Global Quran - text supplied by QuranEnc (quranenc.com), passed through verbatim.</p>
  </section>${suraSections}
</body>
</html>`
}
