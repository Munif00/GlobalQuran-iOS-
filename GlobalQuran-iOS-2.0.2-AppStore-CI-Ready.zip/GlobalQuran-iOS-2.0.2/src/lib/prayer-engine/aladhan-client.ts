/**
 * Global Quran - AlAdhan API client (server-side only).
 *
 * Documentation inspected before implementation:
 * - https://aladhan.com/prayer-times-api
 * - https://aladhan.com/calculation-methods
 * - Live verification on 2026-11-15 against:
 *   GET /v1/timings/{date}, GET /v1/calendar/{year}/{month},
 *   GET /v1/methods
 *
 * Implementation notes (observed behavior, verified live):
 * - `iso8601=true` returns full ISO 8601 instants with UTC offsets
 *   (e.g. `2026-01-01T05:37:00+03:00`) - used for all day/month requests.
 * - `timezonestring` pins the response zone; when omitted, AlAdhan
 *   auto-detects the zone from the coordinates and reports it in
 *   `data.meta.timezone` (used for location-aware zone resolution).
 * - `school=0|1` selects Standard/Shafi'i vs Hanafi Asr.
 * - `latitudeAdjustmentMethod` values: 0 NONE, 1 MIDDLE_OF_THE_NIGHT,
 *   2 ONE_SEVENTH, 3 ANGLE_BASED (the API default).
 * - The `tune` parameter was observed returning HTTP 500
 *   ("An unexpected error occurred") on 2026-11-15 for both partial and
 *   full formats, so it is NOT used - user adjustments are applied
 *   app-side instead (more robust and works for every source tier).
 * - The API is keyless for basic usage, as documented.
 */

import type { AppliedHighLatitudeRule, CalculationMethodId, Madhhab } from '@/types'
import { getPrayerMethod } from '@/lib/prayer/methods'
import { isValidTimeZone } from '@/lib/prayer/timezone'
import {
  fetchJsonWithTimeout,
  isHighLatitudeSituation,
  type SourcePrayerDay,
  type SourceTierFailure,
  type SourceTierMeta,
} from './types'

const ALADHAN_BASE = 'https://api.aladhan.com/v1'
const TIMEOUT_MS = 12_000

export interface AladhanCalcParams {
  latitude: number
  longitude: number
  /** IANA zone; when omitted the API auto-detects it from the coordinates. */
  timeZone?: string | null
  methodId: CalculationMethodId
  madhhab: Madhhab
  /** 0 NONE, 1 MIDDLE_OF_THE_NIGHT, 2 ONE_SEVENTH, 3 ANGLE_BASED. */
  latitudeAdjustmentMethod?: number | null
}

interface AladhanTimings {
  Fajr?: unknown
  Sunrise?: unknown
  Dhuhr?: unknown
  Asr?: unknown
  Maghrib?: unknown
  Isha?: unknown
}

interface AladhanDayPayload {
  timings?: AladhanTimings
  date?: {
    hijri?: { date?: unknown }
    gregorian?: { date?: unknown }
  }
  meta?: {
    timezone?: unknown
    method?: { name?: unknown }
    school?: unknown
    latitudeAdjustmentMethod?: unknown
  }
}

/** ISO 8601 with offset, e.g. `2026-01-01T05:37:00+03:00`. */
const ISO_WITH_OFFSET = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?(?:Z|[+-]\d{2}:\d{2})$/
const DATE_DD_MM_YYYY = /^(\d{2})-(\d{2})-(\d{4})$/

function parseIsoTime(value: unknown): string | null {
  if (typeof value !== 'string') return null
  const trimmed = value.split(' ')[0] // strip any "(+03)" style suffixes
  if (!ISO_WITH_OFFSET.test(trimmed)) return null
  const parsed = new Date(trimmed)
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString()
}

function parseHijriDate(payload: AladhanDayPayload): string | null {
  const raw = payload.date?.hijri?.date
  if (typeof raw === 'string' && DATE_DD_MM_YYYY.test(raw)) {
    return raw
  }
  return null
}

function mapAppliedRule(value: unknown): AppliedHighLatitudeRule | null {
  switch (value) {
    case 'MIDDLE_OF_THE_NIGHT':
      return 'middle_of_night'
    case 'ONE_SEVENTH':
      return 'one_seventh'
    case 'ANGLE_BASED':
      return 'angle_based'
    default:
      return null
  }
}

function normalizeDayPayload(
  payload: AladhanDayPayload,
  fallbackDateIso: string | null,
): SourcePrayerDay | null {
  const timings = payload.timings
  if (!timings) return null
  const fajr = parseIsoTime(timings.Fajr)
  const sunrise = parseIsoTime(timings.Sunrise)
  const dhuhr = parseIsoTime(timings.Dhuhr)
  const asr = parseIsoTime(timings.Asr)
  const maghrib = parseIsoTime(timings.Maghrib)
  const isha = parseIsoTime(timings.Isha)
  if (!fajr || !sunrise || !dhuhr || !asr || !maghrib || !isha) return null

  // The Gregorian date from the payload ("01-01-2026") when present;
  // otherwise the requested date.
  let date = fallbackDateIso
  const gregorian = payload.date?.gregorian?.date
  if (typeof gregorian === 'string') {
    const match = DATE_DD_MM_YYYY.exec(gregorian)
    if (match) {
      date = `${match[3]}-${match[2]}-${match[1]}`
    }
  }
  if (!date) return null

  return {
    date,
    hijriDate: parseHijriDate(payload),
    hijriSource: 'aladhan_hjcosa',
    fajr,
    sunrise,
    dhuhr,
    asr,
    maghrib,
    isha,
  }
}

function buildQuery(params: AladhanCalcParams, extra: Record<string, string>): string {
  const query = new URLSearchParams({
    latitude: String(params.latitude),
    longitude: String(params.longitude),
    method: String(getPrayerMethod(params.methodId).numericId),
    school: params.madhhab === 'hanafi' ? '1' : '0',
    iso8601: 'true',
    ...extra,
  })
  if (params.timeZone && isValidTimeZone(params.timeZone)) {
    query.set('timezonestring', params.timeZone)
  }
  if (params.latitudeAdjustmentMethod != null) {
    query.set('latitudeAdjustmentMethod', String(params.latitudeAdjustmentMethod))
  }
  return query.toString()
}

function buildMeta(params: AladhanCalcParams, apiMethod: string | null, appliedRule: AppliedHighLatitudeRule | null): SourceTierMeta {
  const method = getPrayerMethod(params.methodId)
  const maxAngle = Math.max(method.engine.fajrAngle, method.engine.ishaAngle)
  return {
    methodId: params.methodId,
    methodName: apiMethod ?? method.name,
    methodParams: method.paramsSummary,
    appliedRule,
    highLatitudeSituation: isHighLatitudeSituation(params.latitude, maxAngle),
  }
}

/** Convert YYYY-MM-DD to the API's DD-MM-YYYY path format. */
function toApiDatePath(dateIso: string): string {
  const [year, month, day] = dateIso.split('-')
  return `${day}-${month}-${year}`
}

export interface AladhanDayResult {
  day: SourcePrayerDay
  meta: SourceTierMeta
  /** Zone the response used (detected when not provided). */
  resolvedTimeZone: string | null
}

/**
 * Fetch one day of times. When `params.timeZone` is omitted, the API
 * auto-detects the zone and the resolved zone is returned.
 */
export async function fetchAladhanDay(
  dateIso: string,
  params: AladhanCalcParams,
): Promise<{ ok: true; result: AladhanDayResult } | { ok: false; failure: SourceTierFailure }> {
  const url = `${ALADHAN_BASE}/timings/${toApiDatePath(dateIso)}?${buildQuery(params, {})}`
  const response = await fetchJsonWithTimeout(url, TIMEOUT_MS)
  if (!response.ok) return response

  const body = response.data as { code?: unknown; data?: unknown }
  if (body.code !== 200 || typeof body.data !== 'object' || body.data === null) {
    return { ok: false, failure: { reason: 'invalid_response', detail: 'unexpected status code' } }
  }
  const payload = body.data as AladhanDayPayload
  const day = normalizeDayPayload(payload, dateIso)
  if (!day) {
    return { ok: false, failure: { reason: 'invalid_response', detail: 'missing timings' } }
  }
  const timezone = payload.meta?.timezone
  const resolvedTimeZone =
    typeof timezone === 'string' && isValidTimeZone(timezone) ? timezone : null
  const apiMethod =
    typeof payload.meta?.method?.name === 'string' ? payload.meta.method.name : null
  const appliedRule = mapAppliedRule(payload.meta?.latitudeAdjustmentMethod)

  return {
    ok: true,
    result: {
      day,
      meta: buildMeta(params, apiMethod, appliedRule),
      resolvedTimeZone: params.timeZone ?? resolvedTimeZone,
    },
  }
}

export interface AladhanMonthResult {
  days: SourcePrayerDay[]
  meta: SourceTierMeta
}

/** Fetch a whole calendar month (every date calculated by the API - never extrapolated). */
export async function fetchAladhanMonth(
  year: number,
  month: number,
  params: AladhanCalcParams,
): Promise<{ ok: true; result: AladhanMonthResult } | { ok: false; failure: SourceTierFailure }> {
  const url = `${ALADHAN_BASE}/calendar/${year}/${month}?${buildQuery(params, {})}`
  const response = await fetchJsonWithTimeout(url, TIMEOUT_MS)
  if (!response.ok) return response

  const body = response.data as { code?: unknown; data?: unknown }
  if (body.code !== 200 || !Array.isArray(body.data)) {
    return { ok: false, failure: { reason: 'invalid_response', detail: 'calendar data not an array' } }
  }
  const days: SourcePrayerDay[] = []
  for (const entry of body.data) {
    if (typeof entry !== 'object' || entry === null) continue
    const day = normalizeDayPayload(entry as AladhanDayPayload, null)
    if (day) days.push(day)
  }
  if (days.length < 28) {
    return { ok: false, failure: { reason: 'invalid_response', detail: `only ${days.length} days` } }
  }
  days.sort((a, b) => a.date.localeCompare(b.date))
  return {
    ok: true,
    result: { days, meta: buildMeta(params, null, null) },
  }
}

/**
 * Resolve the IANA zone for coordinates via AlAdhan's location-aware
 * detection (documented behavior when timezonestring is omitted).
 * Uses an explicit date path - the form verified live.
 */
export async function detectTimeZoneViaAladhan(
  latitude: number,
  longitude: number,
): Promise<string | null> {
  const query = new URLSearchParams({
    latitude: String(latitude),
    longitude: String(longitude),
    method: '3',
  })
  const response = await fetchJsonWithTimeout(
    `${ALADHAN_BASE}/timings/${toApiDatePath(todayIsoUtc())}?${query.toString()}`,
    8_000,
  )
  if (!response.ok) return null
  const body = response.data as { data?: { meta?: { timezone?: unknown } } }
  const timezone = body.data?.meta?.timezone
  return typeof timezone === 'string' && isValidTimeZone(timezone) ? timezone : null
}

/** Today's date (YYYY-MM-DD) in UTC - only used for zone detection. */
function todayIsoUtc(): string {
  return new Date().toISOString().slice(0, 10)
}
