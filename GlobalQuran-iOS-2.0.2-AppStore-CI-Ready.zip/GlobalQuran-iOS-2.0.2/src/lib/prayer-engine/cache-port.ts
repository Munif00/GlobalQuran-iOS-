/**
 * Global Quran - Prayer cache port (platform-agnostic).
 *
 * The hybrid resolver caches successful upstream payloads so live data is
 * served read-through (< 24 h) and stale data is available when every live
 * tier fails. The storage backend differs per platform:
 * - Web server: Prisma/SQLite (src/server/prayer/cache.ts).
 * - Native app: IndexedDB (src/services/native/prayer-cache.ts).
 *
 * The port must be registered before the resolver runs; the web server does
 * it via src/server/prayer/index.ts at module load, the native adapter at
 * adapter construction. A safe in-memory fallback keeps the resolver
 * functional if no backend was registered (results are simply not cached).
 */

import type { SourcePrayerDay, SourceTierMeta } from './types'

/** A cached tier payload exactly as it was fetched (pre-adjustment values). */
export interface CachedPrayerPayload {
  days: SourcePrayerDay[]
  meta: SourceTierMeta
  sourceName: string
  fetchedAt: string
}

/** What a cache backend returns: the payload, labeled as cached. */
export interface CacheReadResult extends CachedPrayerPayload {
  isCached: true
}

export interface PrayerCachePort {
  read(key: string): Promise<CacheReadResult | null>
  write(entry: {
    cacheKey: string
    kind: 'day' | 'month' | 'year'
    dateLabel: string
    sourceType: string
    sourceName: string
    payload: CachedPrayerPayload
  }): Promise<void>
}

/** Round coordinates for cache keys (2 decimals ~ 1 km - times shift by seconds). */
export function coordKeyPart(value: number): string {
  return value.toFixed(2)
}

/** In-memory fallback cache (bounded, last-write-wins per key). */
class MemoryPrayerCache implements PrayerCachePort {
  private readonly entries = new Map<string, { payload: CachedPrayerPayload; fetchedAt: string }>()
  private static readonly MAX_ENTRIES = 200

  async read(key: string): Promise<CacheReadResult | null> {
    const entry = this.entries.get(key)
    if (!entry) return null
    return { ...entry.payload, fetchedAt: entry.fetchedAt, isCached: true }
  }

  async write(entry: {
    cacheKey: string
    kind: 'day' | 'month' | 'year'
    dateLabel: string
    sourceType: string
    sourceName: string
    payload: CachedPrayerPayload
  }): Promise<void> {
    this.entries.set(entry.cacheKey, {
      payload: entry.payload,
      fetchedAt: new Date().toISOString(),
    })
    if (this.entries.size > MemoryPrayerCache.MAX_ENTRIES) {
      const oldest = this.entries.keys().next().value
      if (typeof oldest === 'string') this.entries.delete(oldest)
    }
  }
}

let activePort: PrayerCachePort = new MemoryPrayerCache()

/** Register the platform cache backend (idempotent, shape-checked). */
export function setPrayerCache(port: PrayerCachePort): void {
  if (port && typeof port.read === 'function' && typeof port.write === 'function') {
    activePort = port
  }
}

/** Read a cached payload (labeled isCached by the backend). */
export function readPrayerCachePort(key: string): Promise<CacheReadResult | null> {
  return activePort.read(key)
}

/** Write a cache payload through the registered backend. */
export function writePrayerCachePort(entry: {
  cacheKey: string
  kind: 'day' | 'month' | 'year'
  dateLabel: string
  sourceType: string
  sourceName: string
  payload: CachedPrayerPayload
}): Promise<void> {
  return activePort.write(entry)
}
