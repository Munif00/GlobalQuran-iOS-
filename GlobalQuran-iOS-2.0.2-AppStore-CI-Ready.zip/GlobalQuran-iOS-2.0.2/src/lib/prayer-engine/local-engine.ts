/**
 * Global Quran - Local astronomical prayer-time engine (offline tier 3).
 *
 * The validated fallback the resolver turns to when neither the official
 * authority (JAKIM) nor the AlAdhan API can be reached. It computes the six
 * daily times ON THE DEVICE from standard solar-position math - no network,
 * no invented data:
 *
 * - The solar model (declination, right ascension, apparent sidereal time,
 *   nutation, hour angles) is vendored below from adhan 4.4.6 (MIT,
 *   https://github.com/batoulapps/adhan-js) - the exact model the shipped
 *   engine bundled, transcribed from its ESM sources. Times agree with the
 *   AlAdhan API within the documented ~3-minute tolerance.
 * - Method angles/interval come from the app's own verified registry
 *   (`src/lib/prayer/methods.ts`, checked live against /v1/methods) - they
 *   are never duplicated here.
 * - All six times are ABSOLUTE instants (ISO 8601, UTC) anchored to the
 *   requested calendar date, so the resolver can render them in any time
 *   zone. `params.timeZone` is part of the request contract but is not
 *   needed by the math (kept for interface compatibility with the callers).
 * - High-latitude policy: pure angles are used whenever the sun actually
 *   reaches the required angle; when it does not (or the night-portion bound
 *   is tighter), the resolved night-portion rule is applied. 'auto' resolves
 *   to adhan's recommended policy (one-seventh of the night above 48°
 *   latitude, middle of the night otherwise).
 * - Honesty on failure: any day whose times cannot be computed (e.g. polar
 *   day/night - the polar-circle resolvers are intentionally NOT vendored)
 *   makes the whole request fail with `{ ok: false }`; the resolver then
 *   continues down its priority chain. No times are ever guessed.
 */

import type {
  AppliedHighLatitudeRule,
  CalculationMethodId,
  HighLatitudeRuleMode,
  Madhhab,
} from '@/types'
import { getPrayerMethod } from '@/lib/prayer/methods'
import { localHijriDate } from '@/lib/prayer/timezone'
import type { SourcePrayerDay, SourceTierMeta } from './types'

/* ------------------------------------------------------------------ */
/* Solar math - vendored from adhan 4.4.6 (MIT)                        */
/*                                                                     */
/* The subset used by this engine: MathUtils, DateUtils, Astronomical, */
/* SolarCoordinates, SolarTime, TimeComponents, Coordinates,           */
/* HighLatitudeRule, Madhab, CalculationParameters and the PrayerTimes */
/* constructor. Two unused pieces of the library are deliberately not  */
/* vendored: the AqrabBalad/AqrabYaum polar-circle resolvers (the      */
/* engine always leaves polarCircleResolution = 'Unresolved', so an    */
/* unresolvable day surfaces as an honest { ok: false }) and the       */
/* currentPrayer/nextPrayer navigation helpers.                        */
/* ------------------------------------------------------------------ */

/* ------------------------------ MathUtils --------------------------- */

function degreesToRadians(degrees: number): number {
  return (degrees * Math.PI) / 180.0
}

function radiansToDegrees(radians: number): number {
  return (radians * 180.0) / Math.PI
}

function normalizeToScale(num: number, max: number): number {
  return num - max * Math.floor(num / max)
}

function unwindAngle(angle: number): number {
  return normalizeToScale(angle, 360.0)
}

function quadrantShiftAngle(angle: number): number {
  if (angle >= -180 && angle <= 180) {
    return angle
  }
  return angle - 360 * Math.round(angle / 360)
}

/* ------------------------------ DateUtils --------------------------- */

type Rounding = 'nearest' | 'up' | 'none'

function dateByAddingDays(date: Date, days: number): Date {
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate() + days,
    date.getHours(),
    date.getMinutes(),
    date.getSeconds(),
  )
}

function dateByAddingMinutes(date: Date, minutes: number): Date {
  return dateByAddingSeconds(date, minutes * 60)
}

function dateByAddingSeconds(date: Date, seconds: number): Date {
  return new Date(date.getTime() + seconds * 1000)
}

function roundedMinute(date: Date, rounding: Rounding = 'nearest'): Date {
  const seconds = date.getUTCSeconds()
  let offset = seconds >= 30 ? 60 - seconds : -1 * seconds
  if (rounding === 'up') {
    offset = 60 - seconds
  } else if (rounding === 'none') {
    offset = 0
  }
  return dateByAddingSeconds(date, offset)
}

function isLeapYear(year: number): boolean {
  if (year % 4 !== 0) return false
  if (year % 100 === 0 && year % 400 !== 0) return false
  return true
}

function dayOfYear(date: Date): number {
  let returnedDayOfYear = 0
  const feb = isLeapYear(date.getFullYear()) ? 29 : 28
  const months = [31, feb, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  for (let i = 0; i < date.getMonth(); i++) {
    returnedDayOfYear += months[i]
  }
  return returnedDayOfYear + date.getDate()
}

function isValidDate(date: Date): boolean {
  return date instanceof Date && !isNaN(date.valueOf())
}

/* ----------------------------- Astronomical ------------------------- */
/* Equations from Jean Meeus, "Astronomical Algorithms" (adhan cites   */
/* the page for every formula below).                                  */

const Astronomical = {
  /* The geometric mean longitude of the sun in degrees. (p. 163) */
  meanSolarLongitude(julianCentury: number): number {
    const T = julianCentury
    const term1 = 280.4664567
    const term2 = 36000.76983 * T
    const term3 = 0.0003032 * Math.pow(T, 2)
    return unwindAngle(term1 + term2 + term3)
  },

  /* The geometric mean longitude of the moon in degrees. (p. 144) */
  meanLunarLongitude(julianCentury: number): number {
    const T = julianCentury
    const term1 = 218.3165
    const term2 = 481267.8813 * T
    return unwindAngle(term1 + term2)
  },

  ascendingLunarNodeLongitude(julianCentury: number): number {
    const T = julianCentury
    const term1 = 125.04452
    const term2 = 1934.136261 * T
    const term3 = 0.0020708 * Math.pow(T, 2)
    const term4 = Math.pow(T, 3) / 450000
    return unwindAngle(term1 - term2 + term3 + term4)
  },

  /* The mean anomaly of the sun. (p. 163) */
  meanSolarAnomaly(julianCentury: number): number {
    const T = julianCentury
    const term1 = 357.52911
    const term2 = 35999.05029 * T
    const term3 = 0.0001537 * Math.pow(T, 2)
    return unwindAngle(term1 + term2 - term3)
  },

  /* The Sun's equation of the center in degrees. (p. 164) */
  solarEquationOfTheCenter(julianCentury: number, meanAnomaly: number): number {
    const T = julianCentury
    const Mrad = degreesToRadians(meanAnomaly)
    const term1 = (1.914602 - 0.004817 * T - 0.000014 * Math.pow(T, 2)) * Math.sin(Mrad)
    const term2 = (0.019993 - 0.000101 * T) * Math.sin(2 * Mrad)
    const term3 = 0.000289 * Math.sin(3 * Mrad)
    return term1 + term2 + term3
  },

  /* The apparent longitude of the Sun, referred to the true equinox of
   * the date. (p. 164) */
  apparentSolarLongitude(julianCentury: number, meanLongitude: number): number {
    const T = julianCentury
    const L0 = meanLongitude
    const longitude = L0 + Astronomical.solarEquationOfTheCenter(T, Astronomical.meanSolarAnomaly(T))
    const Omega = 125.04 - 1934.136 * T
    const Lambda = longitude - 0.00569 - 0.00478 * Math.sin(degreesToRadians(Omega))
    return unwindAngle(Lambda)
  },

  /* The mean obliquity of the ecliptic, formula adopted by the
   * International Astronomical Union, in degrees. (p. 147) */
  meanObliquityOfTheEcliptic(julianCentury: number): number {
    const T = julianCentury
    const term1 = 23.439291
    const term2 = 0.013004167 * T
    const term3 = 0.0000001639 * Math.pow(T, 2)
    const term4 = 0.0000005036 * Math.pow(T, 3)
    return term1 - term2 - term3 + term4
  },

  /* The mean obliquity of the ecliptic, corrected for calculating the
   * apparent position of the sun, in degrees. (p. 165) */
  apparentObliquityOfTheEcliptic(julianCentury: number, meanObliquityOfTheEcliptic: number): number {
    const T = julianCentury
    const Epsilon0 = meanObliquityOfTheEcliptic
    const O = 125.04 - 1934.136 * T
    return Epsilon0 + 0.00256 * Math.cos(degreesToRadians(O))
  },

  /* Mean sidereal time, the hour angle of the vernal equinox, in
   * degrees. (p. 165) */
  meanSiderealTime(julianCentury: number): number {
    const T = julianCentury
    const JD = T * 36525 + 2451545.0
    const term1 = 280.46061837
    const term2 = 360.98564736629 * (JD - 2451545)
    const term3 = 0.000387933 * Math.pow(T, 2)
    const term4 = Math.pow(T, 3) / 38710000
    return unwindAngle(term1 + term2 + term3 - term4)
  },

  nutationInLongitude(
    _julianCentury: number,
    solarLongitude: number,
    lunarLongitude: number,
    ascendingNode: number,
  ): number {
    const L0 = solarLongitude
    const Lp = lunarLongitude
    const Omega = ascendingNode
    const term1 = (-17.2 / 3600) * Math.sin(degreesToRadians(Omega))
    const term2 = (1.32 / 3600) * Math.sin(2 * degreesToRadians(L0))
    const term3 = (0.23 / 3600) * Math.sin(2 * degreesToRadians(Lp))
    const term4 = (0.21 / 3600) * Math.sin(2 * degreesToRadians(Omega))
    return term1 - term2 - term3 + term4
  },

  nutationInObliquity(
    _julianCentury: number,
    solarLongitude: number,
    lunarLongitude: number,
    ascendingNode: number,
  ): number {
    const L0 = solarLongitude
    const Lp = lunarLongitude
    const Omega = ascendingNode
    const term1 = (9.2 / 3600) * Math.cos(degreesToRadians(Omega))
    const term2 = (0.57 / 3600) * Math.cos(2 * degreesToRadians(L0))
    const term3 = (0.1 / 3600) * Math.cos(2 * degreesToRadians(Lp))
    const term4 = (0.09 / 3600) * Math.cos(2 * degreesToRadians(Omega))
    return term1 + term2 + term3 - term4
  },

  altitudeOfCelestialBody(observerLatitude: number, declination: number, localHourAngle: number): number {
    const Phi = observerLatitude
    const delta = declination
    const H = localHourAngle
    const term1 = Math.sin(degreesToRadians(Phi)) * Math.sin(degreesToRadians(delta))
    const term2 =
      Math.cos(degreesToRadians(Phi)) * Math.cos(degreesToRadians(delta)) * Math.cos(degreesToRadians(H))
    return radiansToDegrees(Math.asin(term1 + term2))
  },

  approximateTransit(longitude: number, siderealTime: number, rightAscension: number): number {
    const L = longitude
    const Theta0 = siderealTime
    const a2 = rightAscension
    /* Equation from p. 102 */
    const Lw = L * -1
    const m0 = normalizeToScale((a2 + Lw - Theta0) / 360, 1)
    // For locations near the International Date Line, the normalization can
    // produce an m0 for the wrong calendar day. Compare it with a generalized
    // transit time derived from the longitude and shift by one cycle if the
    // difference exceeds half a day.
    const expectedTransit = normalizeToScale((12.0 - L / 15.0) / 24.0, 1)
    if (m0 - expectedTransit > 0.5) {
      return m0 - 1.0
    } else if (expectedTransit - m0 > 0.5) {
      return m0 + 1.0
    }
    return m0
  },

  /* The time at which the sun is at its highest point in the sky
   * (in universal time). (p. 102) */
  correctedTransit(
    approximateTransit: number,
    longitude: number,
    siderealTime: number,
    rightAscension: number,
    previousRightAscension: number,
    nextRightAscension: number,
  ): number {
    const m0 = approximateTransit
    const Lw = longitude * -1
    const Theta0 = siderealTime
    const a2 = rightAscension
    const a1 = previousRightAscension
    const a3 = nextRightAscension
    const Theta = unwindAngle(Theta0 + 360.985647 * m0)
    const a = unwindAngle(Astronomical.interpolateAngles(a2, a1, a3, m0))
    const H = quadrantShiftAngle(Theta - Lw - a)
    const dm = H / -360
    return (m0 + dm) * 24
  },

  correctedHourAngle(
    approximateTransit: number,
    angle: number,
    coordinates: Coordinates,
    afterTransit: boolean,
    siderealTime: number,
    rightAscension: number,
    previousRightAscension: number,
    nextRightAscension: number,
    declination: number,
    previousDeclination: number,
    nextDeclination: number,
  ): number {
    const m0 = approximateTransit
    const h0 = angle
    const Theta0 = siderealTime
    const a2 = rightAscension
    const a1 = previousRightAscension
    const a3 = nextRightAscension
    const d2 = declination
    const d1 = previousDeclination
    const d3 = nextDeclination

    /* Equation from p. 102 */
    const Lw = coordinates.longitude * -1
    const term1 =
      Math.sin(degreesToRadians(h0)) -
      Math.sin(degreesToRadians(coordinates.latitude)) * Math.sin(degreesToRadians(d2))
    const term2 = Math.cos(degreesToRadians(coordinates.latitude)) * Math.cos(degreesToRadians(d2))
    const H0 = radiansToDegrees(Math.acos(term1 / term2))
    const m = afterTransit ? m0 + H0 / 360 : m0 - H0 / 360
    const Theta = unwindAngle(Theta0 + 360.985647 * m)
    const a = unwindAngle(Astronomical.interpolateAngles(a2, a1, a3, m))
    const delta = Astronomical.interpolate(d2, d1, d3, m)
    const H = Theta - Lw - a
    const h = Astronomical.altitudeOfCelestialBody(coordinates.latitude, delta, H)
    const term3 = h - h0
    const term4 =
      360 * Math.cos(degreesToRadians(delta)) * Math.cos(degreesToRadians(coordinates.latitude)) * Math.sin(degreesToRadians(H))
    const dm = term3 / term4
    return (m + dm) * 24
  },

  /* Interpolation of a value given equidistant previous and next values
   * and a factor equal to the fraction of the interpolated point's time
   * over the time between values. (p. 24) */
  interpolate(y2: number, y1: number, y3: number, n: number): number {
    const a = y2 - y1
    const b = y3 - y2
    const c = b - a
    return y2 + (n / 2) * (a + b + n * c)
  },

  /* Interpolation of three angles, accounting for angle unwinding. (p. 24) */
  interpolateAngles(y2: number, y1: number, y3: number, n: number): number {
    const a = unwindAngle(y2 - y1)
    const b = unwindAngle(y3 - y2)
    const c = b - a
    return y2 + (n / 2) * (a + b + n * c)
  },

  /* The Julian Day for the given Gregorian date components. (p. 60) */
  julianDay(year: number, month: number, day: number, hours = 0): number {
    const trunc = Math.trunc
    const Y = trunc(month > 2 ? year : year - 1)
    const M = trunc(month > 2 ? month : month + 12)
    const D = day + hours / 24
    const A = trunc(Y / 100)
    const B = trunc(2 - A + trunc(A / 4))
    const i0 = trunc(365.25 * (Y + 4716))
    const i1 = trunc(30.6001 * (M + 1))
    return i0 + i1 + D + B - 1524.5
  },

  /* Julian century from the epoch. (p. 163) */
  julianCentury(julianDay: number): number {
    return (julianDay - 2451545.0) / 36525
  },

  seasonAdjustedMorningTwilight(latitude: number, day: number, year: number, sunrise: Date): Date {
    const a = 75 + (28.65 / 55.0) * Math.abs(latitude)
    const b = 75 + (19.44 / 55.0) * Math.abs(latitude)
    const c = 75 + (32.74 / 55.0) * Math.abs(latitude)
    const d = 75 + (48.1 / 55.0) * Math.abs(latitude)
    const dyy = Astronomical.daysSinceSolstice(day, year, latitude)
    const adjustment = (function () {
      if (dyy < 91) {
        return a + ((b - a) / 91.0) * dyy
      } else if (dyy < 137) {
        return b + ((c - b) / 46.0) * (dyy - 91)
      } else if (dyy < 183) {
        return c + ((d - c) / 46.0) * (dyy - 137)
      } else if (dyy < 229) {
        return d + ((c - d) / 46.0) * (dyy - 183)
      } else if (dyy < 275) {
        return c + ((b - c) / 46.0) * (dyy - 229)
      } else {
        return b + ((a - b) / 91.0) * (dyy - 275)
      }
    })()
    return dateByAddingSeconds(sunrise, Math.round(adjustment * -60.0))
  },

  seasonAdjustedEveningTwilight(
    latitude: number,
    day: number,
    year: number,
    sunset: Date,
    shafaq: ShafaqValue,
  ): Date {
    let a: number, b: number, c: number, d: number
    if (shafaq === 'ahmer') {
      a = 62 + (17.4 / 55.0) * Math.abs(latitude)
      b = 62 - (7.16 / 55.0) * Math.abs(latitude)
      c = 62 + (5.12 / 55.0) * Math.abs(latitude)
      d = 62 + (19.44 / 55.0) * Math.abs(latitude)
    } else if (shafaq === 'abyad') {
      a = 75 + (25.6 / 55.0) * Math.abs(latitude)
      b = 75 + (7.16 / 55.0) * Math.abs(latitude)
      c = 75 + (36.84 / 55.0) * Math.abs(latitude)
      d = 75 + (81.84 / 55.0) * Math.abs(latitude)
    } else {
      a = 75 + (25.6 / 55.0) * Math.abs(latitude)
      b = 75 + (2.05 / 55.0) * Math.abs(latitude)
      c = 75 - (9.21 / 55.0) * Math.abs(latitude)
      d = 75 + (6.14 / 55.0) * Math.abs(latitude)
    }
    const dyy = Astronomical.daysSinceSolstice(day, year, latitude)
    const adjustment = (function () {
      if (dyy < 91) {
        return a + ((b - a) / 91.0) * dyy
      } else if (dyy < 137) {
        return b + ((c - b) / 46.0) * (dyy - 91)
      } else if (dyy < 183) {
        return c + ((d - c) / 46.0) * (dyy - 137)
      } else if (dyy < 229) {
        return d + ((c - d) / 46.0) * (dyy - 183)
      } else if (dyy < 275) {
        return c + ((b - c) / 46.0) * (dyy - 229)
      } else {
        return b + ((a - b) / 91.0) * (dyy - 275)
      }
    })()
    return dateByAddingSeconds(sunset, Math.round(adjustment * 60.0))
  },

  daysSinceSolstice(dayOfYear: number, year: number, latitude: number): number {
    let daysSinceSolstice: number
    const northernOffset = 10
    const southernOffset = isLeapYear(year) ? 173 : 172
    const daysInYear = isLeapYear(year) ? 366 : 365
    if (latitude >= 0) {
      daysSinceSolstice = dayOfYear + northernOffset
      if (daysSinceSolstice >= daysInYear) {
        daysSinceSolstice = daysSinceSolstice - daysInYear
      }
    } else {
      daysSinceSolstice = dayOfYear - southernOffset
      if (daysSinceSolstice < 0) {
        daysSinceSolstice = daysSinceSolstice + daysInYear
      }
    }
    return daysSinceSolstice
  },
}

/* -------------------------- Solar coordinates ----------------------- */

class SolarCoordinates {
  readonly declination: number
  readonly rightAscension: number
  readonly apparentSiderealTime: number

  constructor(julianDay: number) {
    const T = Astronomical.julianCentury(julianDay)
    const L0 = Astronomical.meanSolarLongitude(T)
    const Lp = Astronomical.meanLunarLongitude(T)
    const Omega = Astronomical.ascendingLunarNodeLongitude(T)
    const Lambda = degreesToRadians(Astronomical.apparentSolarLongitude(T, L0))
    const Theta0 = Astronomical.meanSiderealTime(T)
    const dPsi = Astronomical.nutationInLongitude(T, L0, Lp, Omega)
    const dEpsilon = Astronomical.nutationInObliquity(T, L0, Lp, Omega)
    const Epsilon0 = Astronomical.meanObliquityOfTheEcliptic(T)
    const EpsilonApparent = degreesToRadians(
      Astronomical.apparentObliquityOfTheEcliptic(T, Epsilon0),
    )

    /* Declination of the sun, the angle between the rays of the Sun and
     * the plane of the Earth's equator, in degrees. (p. 165) */
    this.declination = radiansToDegrees(
      Math.asin(Math.sin(EpsilonApparent) * Math.sin(Lambda)),
    )

    /* Right ascension of the Sun, the angular distance on the celestial
     * equator from the vernal equinox to the hour circle, in degrees.
     * (p. 165) */
    this.rightAscension = unwindAngle(
      radiansToDegrees(Math.atan2(Math.cos(EpsilonApparent) * Math.sin(Lambda), Math.cos(Lambda))),
    )

    /* Apparent sidereal time, the hour angle of the vernal equinox, in
     * degrees. (p. 88) */
    this.apparentSiderealTime =
      Theta0 + (dPsi * 3600 * Math.cos(degreesToRadians(Epsilon0 + dEpsilon))) / 3600
  }
}

/* ------------------------------ SolarTime --------------------------- */

class SolarTime {
  readonly observer: Coordinates
  readonly solar: SolarCoordinates
  readonly prevSolar: SolarCoordinates
  readonly nextSolar: SolarCoordinates
  readonly approxTransit: number
  readonly transit: number
  readonly sunrise: number
  readonly sunset: number

  constructor(date: Date, coordinates: Coordinates) {
    const julianDay = Astronomical.julianDay(date.getFullYear(), date.getMonth() + 1, date.getDate(), 0)
    this.observer = coordinates
    this.solar = new SolarCoordinates(julianDay)
    this.prevSolar = new SolarCoordinates(julianDay - 1)
    this.nextSolar = new SolarCoordinates(julianDay + 1)
    const m0 = Astronomical.approximateTransit(
      coordinates.longitude,
      this.solar.apparentSiderealTime,
      this.solar.rightAscension,
    )
    const solarAltitude = -50.0 / 60.0
    this.approxTransit = m0
    this.transit = Astronomical.correctedTransit(
      m0,
      coordinates.longitude,
      this.solar.apparentSiderealTime,
      this.solar.rightAscension,
      this.prevSolar.rightAscension,
      this.nextSolar.rightAscension,
    )
    this.sunrise = Astronomical.correctedHourAngle(
      m0,
      solarAltitude,
      coordinates,
      false,
      this.solar.apparentSiderealTime,
      this.solar.rightAscension,
      this.prevSolar.rightAscension,
      this.nextSolar.rightAscension,
      this.solar.declination,
      this.prevSolar.declination,
      this.nextSolar.declination,
    )
    this.sunset = Astronomical.correctedHourAngle(
      m0,
      solarAltitude,
      coordinates,
      true,
      this.solar.apparentSiderealTime,
      this.solar.rightAscension,
      this.prevSolar.rightAscension,
      this.nextSolar.rightAscension,
      this.solar.declination,
      this.prevSolar.declination,
      this.nextSolar.declination,
    )
  }

  hourAngle(angle: number, afterTransit: boolean): number {
    return Astronomical.correctedHourAngle(
      this.approxTransit,
      angle,
      this.observer,
      afterTransit,
      this.solar.apparentSiderealTime,
      this.solar.rightAscension,
      this.prevSolar.rightAscension,
      this.nextSolar.rightAscension,
      this.solar.declination,
      this.prevSolar.declination,
      this.nextSolar.declination,
    )
  }

  afternoon(shadowLength: number): number {
    const tangent = Math.abs(this.observer.latitude - this.solar.declination)
    const inverse = shadowLength + Math.tan(degreesToRadians(tangent))
    const angle = radiansToDegrees(Math.atan(1.0 / inverse))
    return this.hourAngle(angle, true)
  }
}

/* --------------------------- TimeComponents ------------------------- */

class TimeComponents {
  readonly hours: number
  readonly minutes: number
  readonly seconds: number

  constructor(num: number) {
    this.hours = Math.floor(num)
    this.minutes = Math.floor((num - this.hours) * 60)
    this.seconds = Math.floor((num - (this.hours + this.minutes / 60)) * 60 * 60)
  }

  utcDate(year: number, month: number, date: number): Date {
    return new Date(Date.UTC(year, month, date, this.hours, this.minutes, this.seconds))
  }
}

/* ------------------------- adhan parameter types -------------------- */

class Coordinates {
  readonly latitude: number
  readonly longitude: number

  constructor(latitude: number, longitude: number) {
    this.latitude = latitude
    this.longitude = longitude
  }
}

const HighLatitudeRule = {
  MiddleOfTheNight: 'middleofthenight',
  SeventhOfTheNight: 'seventhofthenight',
  TwilightAngle: 'twilightangle',
  recommended(coordinates: Coordinates): 'middleofthenight' | 'seventhofthenight' {
    if (coordinates.latitude > 48) {
      return HighLatitudeRule.SeventhOfTheNight
    }
    return HighLatitudeRule.MiddleOfTheNight
  },
} as const

type HighLatitudeRuleValue = (typeof HighLatitudeRule)[keyof typeof HighLatitudeRule]

const Madhab = {
  Shafi: 'shafi',
  Hanafi: 'hanafi',
} as const

type MadhabValue = (typeof Madhab)[keyof typeof Madhab]

type ShafaqValue = 'general' | 'ahmer' | 'abyad'

function shadowLength(madhab: MadhabValue): 1 | 2 {
  switch (madhab) {
    case Madhab.Shafi:
      return 1
    case Madhab.Hanafi:
      return 2
    default:
      throw new Error('Invalid Madhab')
  }
}

interface PrayerAdjustmentsTable {
  fajr: number
  sunrise: number
  dhuhr: number
  asr: number
  maghrib: number
  isha: number
}

class CalculationParameters {
  madhab: MadhabValue = Madhab.Shafi
  highLatitudeRule: HighLatitudeRuleValue = HighLatitudeRule.MiddleOfTheNight
  adjustments: PrayerAdjustmentsTable = { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 }
  methodAdjustments: PrayerAdjustmentsTable = { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 }
  /* The polar-circle resolvers are not vendored (see the file header): this
   * engine always leaves this 'Unresolved'. */
  polarCircleResolution: 'Unresolved' = 'Unresolved'
  rounding: Rounding = 'nearest'
  shafaq: ShafaqValue = 'general'

  constructor(
    readonly method: string | null,
    readonly fajrAngle: number = 0,
    readonly ishaAngle: number = 0,
    readonly ishaInterval: number = 0,
    readonly maghribAngle: number = 0,
  ) {}

  /** The fraction of the night used to bound Fajr/Isha under the active
   * high-latitude rule (pure angles are still used whenever reachable). */
  nightPortions(): { fajr: number; isha: number } {
    switch (this.highLatitudeRule) {
      case HighLatitudeRule.MiddleOfTheNight:
        return { fajr: 1 / 2, isha: 1 / 2 }
      case HighLatitudeRule.SeventhOfTheNight:
        return { fajr: 1 / 7, isha: 1 / 7 }
      case HighLatitudeRule.TwilightAngle:
        return { fajr: this.fajrAngle / 60, isha: this.ishaAngle / 60 }
      default:
        throw new Error(
          `Invalid high latitude rule found when attempting to compute night portions: ${this.highLatitudeRule}`,
        )
    }
  }
}

/* ------------------------------ PrayerTimes ------------------------- */
/* The constructor computes the six times; the library's navigation      */
/* helpers (timeForPrayer/currentPrayer/nextPrayer) are unused here.     */

// Moonsighting Committee applies a special 1/7 night-fraction rule at high
// latitudes (>= 55°), where angle-based Fajr/Isha may not exist.
const HIGH_LATITUDE_THRESHOLD = 55

class PrayerTimes {
  readonly fajr: Date
  readonly sunrise: Date
  readonly dhuhr: Date
  readonly asr: Date
  readonly sunset: Date
  readonly maghrib: Date
  readonly isha: Date

  constructor(
    coordinates: Coordinates,
    date: Date,
    calculationParameters: CalculationParameters,
  ) {
    const solarTime = new SolarTime(date, coordinates)
    const tomorrow = dateByAddingDays(date, 1)
    const tomorrowSolarTime = new SolarTime(tomorrow, coordinates)
    // The polar-circle resolution branch of adhan is intentionally omitted:
    // polarCircleResolution is always 'Unresolved', so unresolvable days
    // keep their NaN times and surface as an honest { ok: false }.

    const dhuhrTime = new TimeComponents(solarTime.transit).utcDate(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
    )
    const sunriseTime = new TimeComponents(solarTime.sunrise).utcDate(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
    )
    const sunsetTime = new TimeComponents(solarTime.sunset).utcDate(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
    )
    const asrTime = new TimeComponents(
      solarTime.afternoon(shadowLength(calculationParameters.madhab)),
    ).utcDate(date.getFullYear(), date.getMonth(), date.getDate())
    const tomorrowSunrise = new TimeComponents(tomorrowSolarTime.sunrise).utcDate(
      tomorrow.getFullYear(),
      tomorrow.getMonth(),
      tomorrow.getDate(),
    )
    const night = (Number(tomorrowSunrise) - Number(sunsetTime)) / 1000

    let fajrTime = new TimeComponents(
      solarTime.hourAngle(-1 * calculationParameters.fajrAngle, false),
    ).utcDate(date.getFullYear(), date.getMonth(), date.getDate())

    // Special case for Moonsighting Committee above latitude 55.
    if (calculationParameters.method === 'MoonsightingCommittee' && coordinates.latitude >= HIGH_LATITUDE_THRESHOLD) {
      fajrTime = dateByAddingSeconds(sunriseTime, -(night / 7))
    }
    const safeFajr =
      calculationParameters.method === 'MoonsightingCommittee'
        ? Astronomical.seasonAdjustedMorningTwilight(
            coordinates.latitude,
            dayOfYear(date),
            date.getFullYear(),
            sunriseTime,
          )
        : dateByAddingSeconds(sunriseTime, -(calculationParameters.nightPortions().fajr * night))
    if (isNaN(fajrTime.getTime()) || safeFajr > fajrTime) {
      fajrTime = safeFajr
    }

    let ishaTime: Date
    if (calculationParameters.ishaInterval > 0) {
      ishaTime = dateByAddingMinutes(sunsetTime, calculationParameters.ishaInterval)
    } else {
      ishaTime = new TimeComponents(
        solarTime.hourAngle(-1 * calculationParameters.ishaAngle, true),
      ).utcDate(date.getFullYear(), date.getMonth(), date.getDate())
      if (calculationParameters.method === 'MoonsightingCommittee' && coordinates.latitude >= HIGH_LATITUDE_THRESHOLD) {
        ishaTime = dateByAddingSeconds(sunsetTime, night / 7)
      }
      const safeIsha =
        calculationParameters.method === 'MoonsightingCommittee'
          ? Astronomical.seasonAdjustedEveningTwilight(
              coordinates.latitude,
              dayOfYear(date),
              date.getFullYear(),
              sunsetTime,
              calculationParameters.shafaq,
            )
          : dateByAddingSeconds(sunsetTime, calculationParameters.nightPortions().isha * night)
      if (isNaN(ishaTime.getTime()) || safeIsha < ishaTime) {
        ishaTime = safeIsha
      }
    }

    let maghribTime = sunsetTime
    if (calculationParameters.maghribAngle) {
      const angleBasedMaghrib = new TimeComponents(
        solarTime.hourAngle(-1 * calculationParameters.maghribAngle, true),
      ).utcDate(date.getFullYear(), date.getMonth(), date.getDate())
      if (sunsetTime < angleBasedMaghrib && ishaTime > angleBasedMaghrib) {
        maghribTime = angleBasedMaghrib
      }
    }

    const fajrAdjustment =
      (calculationParameters.adjustments.fajr || 0) + (calculationParameters.methodAdjustments.fajr || 0)
    const sunriseAdjustment =
      (calculationParameters.adjustments.sunrise || 0) + (calculationParameters.methodAdjustments.sunrise || 0)
    const dhuhrAdjustment =
      (calculationParameters.adjustments.dhuhr || 0) + (calculationParameters.methodAdjustments.dhuhr || 0)
    const asrAdjustment =
      (calculationParameters.adjustments.asr || 0) + (calculationParameters.methodAdjustments.asr || 0)
    const maghribAdjustment =
      (calculationParameters.adjustments.maghrib || 0) + (calculationParameters.methodAdjustments.maghrib || 0)
    const ishaAdjustment =
      (calculationParameters.adjustments.isha || 0) + (calculationParameters.methodAdjustments.isha || 0)

    this.fajr = roundedMinute(dateByAddingMinutes(fajrTime, fajrAdjustment), calculationParameters.rounding)
    this.sunrise = roundedMinute(dateByAddingMinutes(sunriseTime, sunriseAdjustment), calculationParameters.rounding)
    this.dhuhr = roundedMinute(dateByAddingMinutes(dhuhrTime, dhuhrAdjustment), calculationParameters.rounding)
    this.asr = roundedMinute(dateByAddingMinutes(asrTime, asrAdjustment), calculationParameters.rounding)
    this.sunset = roundedMinute(sunsetTime, calculationParameters.rounding)
    this.maghrib = roundedMinute(dateByAddingMinutes(maghribTime, maghribAdjustment), calculationParameters.rounding)
    this.isha = roundedMinute(dateByAddingMinutes(ishaTime, ishaAdjustment), calculationParameters.rounding)
  }
}

// (The night-portion lookup lives on CalculationParameters, adhan API shape.)

/* ------------------------------------------------------------------ */
/* Engine                                                              */
/* ------------------------------------------------------------------ */

/** Human-readable tier name shown in the source transparency block. */
export const LOCAL_ENGINE_NAME = 'Local astronomical engine (adhan 4.4.6, MIT)'

/** The engine request, mirroring the resolver's tier-3 context. */
export interface LocalEngineParams {
  latitude: number
  longitude: number
  /** Requested IANA zone (part of the contract; times are absolute instants
   * so the math itself is zone-independent - the resolver renders in-zone). */
  timeZone: string
  methodId: CalculationMethodId
  madhhab: Madhhab
  highLatitudeRule: HighLatitudeRuleMode
}

/** A successful computation: one day per requested date plus tier metadata. */
export interface LocalDayResult {
  days: SourcePrayerDay[]
  meta: SourceTierMeta
}

/** The engine never throws: any uncomputable day fails the whole request. */
export type LocalEngineOutcome =
  | { ok: true; result: LocalDayResult }
  | { ok: false; result: null }

/** Resolve the UI's rule mode to the concrete rule the engine applies. */
function resolveAppliedRule(
  mode: HighLatitudeRuleMode,
  latitude: number,
): AppliedHighLatitudeRule {
  switch (mode) {
    case 'middle_of_night':
      return 'middle_of_night'
    case 'one_seventh':
      return 'one_seventh'
    case 'angle_based':
      return 'angle_based'
    default:
      // 'auto' -> adhan's recommended policy (one-seventh above 48°
      // latitude, middle of the night otherwise).
      return HighLatitudeRule.recommended(new Coordinates(latitude, 0)) ===
        HighLatitudeRule.SeventhOfTheNight
        ? 'one_seventh'
        : 'middle_of_night'
  }
}

/**
 * Whether, on this date, the sun fails to reach the method's twilight angle
 * at this latitude (the honest trigger for the high-latitude note in the
 * transparency block). Date-aware variant of the static registry check.
 */
function isHighLatitudeSituationOnDate(
  latitude: number,
  date: Date,
  fajrAngle: number,
  ishaAngle: number,
): boolean {
  const startOfYear = Date.UTC(date.getFullYear(), 0, 1)
  const dayOfYear =
    Math.floor((Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) - startOfYear) / 86_400_000) + 1
  const solsticeDeclination = 23.44 * Math.cos((2 * Math.PI * (dayOfYear + 10)) / 365)
  return 90 - Math.abs(latitude - solsticeDeclination) < Math.max(fajrAngle, ishaAngle)
}

/** A valid instant, or null for NaN (unresolvable) times. */
function toIsoOrNull(date: Date): string | null {
  const time = date.getTime()
  return Number.isFinite(time) ? new Date(time).toISOString() : null
}

/**
 * Compute the six prayer times for every requested date.
 *
 * Angles and intervals come from the verified method registry; the Hijri
 * date is the platform's calculated Islamic (Umm al-Qura) calendar, labeled
 * `local_calendar` and `DD-MM-YYYY` exactly like the other source tiers.
 */
export function computeLocalDays(dates: string[], params: LocalEngineParams): LocalEngineOutcome {
  const method = getPrayerMethod(params.methodId)
  const appliedRule = resolveAppliedRule(params.highLatitudeRule, params.latitude)

  const calcParams = new CalculationParameters(
    params.methodId === 'MOONSIGHTING' ? 'MoonsightingCommittee' : null,
    method.engine.fajrAngle,
    method.engine.ishaAngle,
    method.engine.ishaIntervalMinutes > 0 ? method.engine.ishaIntervalMinutes : 0,
    method.engine.maghribAngle,
  )
  calcParams.madhab = params.madhhab === 'hanafi' ? Madhab.Hanafi : Madhab.Shafi
  calcParams.highLatitudeRule =
    appliedRule === 'middle_of_night'
      ? HighLatitudeRule.MiddleOfTheNight
      : appliedRule === 'one_seventh'
        ? HighLatitudeRule.SeventhOfTheNight
        : HighLatitudeRule.TwilightAngle

  const coordinates = new Coordinates(params.latitude, params.longitude)
  const days: SourcePrayerDay[] = []
  let highLatitudeSituation = false

  for (const dateIso of dates) {
    const [year, month, day] = dateIso.split('-').map(Number)
    if (
      !Number.isInteger(year) ||
      !Number.isInteger(month) ||
      !Number.isInteger(day) ||
      month < 1 ||
      month > 12 ||
      day < 1 ||
      day > 31
    ) {
      return { ok: false, result: null }
    }
    // Mid-day anchor keeps the calendar date stable in any runtime zone.
    const date = new Date(year, month - 1, day, 12, 0, 0)
    if (Number.isNaN(date.getTime())) {
      return { ok: false, result: null }
    }

    const times = new PrayerTimes(coordinates, date, calcParams)
    const fajr = toIsoOrNull(times.fajr)
    const sunrise = toIsoOrNull(times.sunrise)
    const dhuhr = toIsoOrNull(times.dhuhr)
    const asr = toIsoOrNull(times.asr)
    const maghrib = toIsoOrNull(times.maghrib)
    const isha = toIsoOrNull(times.isha)
    if (!fajr || !sunrise || !dhuhr || !asr || !maghrib || !isha) {
      // Unresolvable day (e.g. polar day/night): fail honestly, never guess.
      return { ok: false, result: null }
    }

    if (
      isHighLatitudeSituationOnDate(
        params.latitude,
        date,
        method.engine.fajrAngle,
        method.engine.ishaAngle,
      )
    ) {
      highLatitudeSituation = true
    }

    days.push({
      date: dateIso,
      hijriDate: localHijriDate(dateIso)?.date ?? null,
      hijriSource: 'local_calendar',
      fajr,
      sunrise,
      dhuhr,
      asr,
      maghrib,
      isha,
    })
  }

  return {
    ok: true,
    result: {
      days,
      meta: {
        methodId: params.methodId,
        methodName: method.name,
        methodParams: method.paramsSummary,
        appliedRule,
        highLatitudeSituation,
      },
    },
  }
}
