/**
 * Global Quran - Prayer engine shared types (isomorphic: server + client).
 *
 * Internal contract used by the source clients (AlAdhan, JAKIM, local
 * engine), the cache, and the hybrid resolver. These are the
 * source-normalized values BEFORE user adjustments - adjustments are
 * applied app-side at serve time so they never poison the cache.
 *
 * This module is bundled into BOTH the web server and the native app
 * (Capacitor WebView). It therefore uses only Web-standard APIs.
 */

import type {
  AppliedHighLatitudeRule,
  CalculationMethodId,
  Madhhab,
  PrayerAdjustments,
  PrayerTimeRecord,
  PrayerSourceAttempt,
} from '@/types'

/** A normalized day of times from any source (pre-adjustment). */
export interface SourcePrayerDay {
  /** Gregorian date (YYYY-MM-DD). */
  date: string
  hijriDate: string | null
  hijriSource: 'jakim_official' | 'aladhan_hjcosa' | 'local_calendar' | null
  /** ISO 8601 instants. */
  fajr: string
  sunrise: string
  dhuhr: string
  asr: string
  maghrib: string
  isha: string
}

/** Metadata a source tier reports about its own result. */
export interface SourceTierMeta {
  methodId: CalculationMethodId | null
  /** Method name as documented (from the method registry or the API). */
  methodName: string | null
  /** Documented parameters summary. */
  methodParams: string | null
  /** High-latitude rule this tier applied (null = not applicable). */
  appliedRule: AppliedHighLatitudeRule | null
  /** Whether a high-latitude situation exists for these coordinates. */
  highLatitudeSituation: boolean
}

/** A successfully fetched tier result. */
export interface SourceTierResult {
  days: SourcePrayerDay[]
  meta: SourceTierMeta
  fetchedAt: string
  /** Cache key under which this tier's payload is stored. */
  cacheKey: string
  cacheKind: 'day' | 'month' | 'year'
  cacheDateLabel: string
}

/** Why a tier failed (stable codes, mapped to reasonCode on the DTO). */
export type TierFailureReason =
  | 'not_applicable'
  | 'out_of_published_range'
  | 'network_error'
  | 'invalid_response'
  | 'timeout'
  | 'no_zone_selected'
  | 'no_cached_data'

export interface SourceTierFailure {
  reason: TierFailureReason
  /** Safe, non-technical detail for server logs only. */
  detail?: string
}

export type SourceTierOutcome =
  | { ok: true; result: SourceTierResult }
  | { ok: false; failure: SourceTierFailure }

/** Attempt outcome shape used on the transparency DTO. */
export function toAttempt(
  source: PrayerSourceAttempt['source'],
  outcome: PrayerSourceAttempt['outcome'],
  reasonCode: PrayerSourceAttempt['reasonCode'],
): PrayerSourceAttempt {
  return { source, outcome, reasonCode }
}

/** Shift an ISO instant by whole minutes. */
export function shiftIsoMinutes(iso: string, minutes: number): string {
  if (!Number.isFinite(minutes) || minutes === 0) return iso
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return iso
  return new Date(date.getTime() + minutes * 60_000).toISOString()
}

/** Clamp an adjustment value to the documented range. */
export function clampAdjustment(value: number): number {
  if (!Number.isFinite(value)) return 0
  return Math.min(60, Math.max(-60, Math.round(value)))
}

export function normalizeAdjustments(adjustments: PrayerAdjustments): PrayerAdjustments {
  return {
    fajr: clampAdjustment(adjustments.fajr),
    sunrise: clampAdjustment(adjustments.sunrise),
    dhuhr: clampAdjustment(adjustments.dhuhr),
    asr: clampAdjustment(adjustments.asr),
    maghrib: clampAdjustment(adjustments.maghrib),
    isha: clampAdjustment(adjustments.isha),
  }
}

export interface RecordBuildContext {
  latitude: number
  longitude: number
  timeZone: string
  sourceType: PrayerTimeRecord['sourceType']
  sourceName: string
  authorityName: string | null
  calculationMethod: string
  calculationMethodCode: CalculationMethodId | null
  madhhab: PrayerTimeRecord['madhhab']
  adjustments: PrayerAdjustments
  fetchedAt: string
  isCached: boolean
  validationStatus: PrayerTimeRecord['validationStatus']
}

/** Apply user adjustments to a source day and build the final record. */
export function buildPrayerRecord(day: SourcePrayerDay, ctx: RecordBuildContext): PrayerTimeRecord {
  const { adjustments } = ctx
  return {
    date: day.date,
    hijriDate: day.hijriDate,
    hijriSource: day.hijriSource,
    latitude: ctx.latitude,
    longitude: ctx.longitude,
    timeZone: ctx.timeZone,
    fajr: shiftIsoMinutes(day.fajr, adjustments.fajr),
    sunrise: shiftIsoMinutes(day.sunrise, adjustments.sunrise),
    dhuhr: shiftIsoMinutes(day.dhuhr, adjustments.dhuhr),
    asr: shiftIsoMinutes(day.asr, adjustments.asr),
    maghrib: shiftIsoMinutes(day.maghrib, adjustments.maghrib),
    isha: shiftIsoMinutes(day.isha, adjustments.isha),
    sourceType: ctx.sourceType,
    sourceName: ctx.sourceName,
    authorityName: ctx.authorityName,
    calculationMethod: ctx.calculationMethod,
    calculationMethodCode: ctx.calculationMethodCode,
    madhhab: ctx.madhhab,
    adjustments,
    fetchedAt: ctx.fetchedAt,
    isCached: ctx.isCached,
    validationStatus: ctx.validationStatus,
  }
}

/**
 * Latitude above which the sun fails to reach the required twilight angle
 * around the summer solstice: 90° - obliquity (23.44°) - angle. Used to flag
 * a high-latitude situation honestly (engines still do the real work).
 */
export function isHighLatitudeSituation(
  latitude: number,
  maxTwilightAngle: number,
): boolean {
  const threshold = 90 - 23.44 - maxTwilightAngle
  return Math.abs(latitude) > threshold
}

/** Shared fetch helper with timeout + typed failure reasons. */
export async function fetchJsonWithTimeout(
  url: string,
  timeoutMs: number,
  init?: RequestInit,
): Promise<{ ok: true; data: unknown } | { ok: false; failure: SourceTierFailure }> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      ...init,
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        ...(init?.headers ?? {}),
      },
    })
    if (!response.ok) {
      return {
        ok: false,
        failure: { reason: response.status >= 500 ? 'network_error' : 'invalid_response', detail: `HTTP ${response.status}` },
      }
    }
    let data: unknown
    try {
      data = await response.json()
    } catch {
      return { ok: false, failure: { reason: 'invalid_response', detail: 'non-JSON body' } }
    }
    return { ok: true, data }
  } catch (error) {
    const isAbort = error instanceof Error && error.name === 'AbortError'
    return {
      ok: false,
      failure: { reason: isAbort ? 'timeout' : 'network_error', detail: isAbort ? undefined : String(error).slice(0, 120) },
    }
  } finally {
    clearTimeout(timer)
  }
}
