/**
 * Global Quran - Prayer API request parsing & validation (server-side).
 *
 * All external input is validated here before it reaches the resolver:
 * coordinates, dates, method ids, madhhab, high-latitude rule, the compact
 * adjustments format, and the JAKIM zone code (checked against the verified
 * registry - never passed through raw).
 */

import type {
  CalculationMethodId,
  HighLatitudeRuleMode,
  Madhhab,
  PrayerAdjustments,
} from '@/types'
import { getJakimZone } from '@/lib/prayer/authorities'
import { isCalculationMethodId } from '@/lib/prayer/methods'
import { isValidDateIso } from '@/lib/prayer/timezone'
import type { PrayerRequestContext } from './resolver'

export interface ParsedPrayerQuery {
  date: string | null
  month: string | null
  ctx: PrayerRequestContext
}

export type ParseResult =
  | { ok: true; value: ParsedPrayerQuery }
  | { ok: false; errorKey: string }

const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/
const ADJUSTMENT_ITEM_RE = /^(fajr|sunrise|dhuhr|asr|maghrib|isha):(-?\d{1,2})$/

function parseNumber(value: string | null): number | null {
  if (value == null || value.trim() === '') return null
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : null
}

/** Compact adjustments format: `fajr:5,sunrise:0,...` (all parts optional). */
function parseAdjustments(value: string | null): PrayerAdjustments | null {
  const adjustments: PrayerAdjustments = {
    fajr: 0,
    sunrise: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0,
  }
  if (value == null || value.trim() === '') return adjustments
  for (const part of value.split(',')) {
    const match = ADJUSTMENT_ITEM_RE.exec(part.trim())
    if (!match) return null
    const minutes = Math.min(60, Math.max(-60, Number(match[2])))
    adjustments[match[1] as keyof PrayerAdjustments] = minutes
  }
  return adjustments
}

export function parsePrayerQuery(searchParams: URLSearchParams): ParseResult {
  const latitude = parseNumber(searchParams.get('latitude'))
  const longitude = parseNumber(searchParams.get('longitude'))
  if (latitude == null || latitude < -90 || latitude > 90) {
    return { ok: false, errorKey: 'prayer.error.badRequest' }
  }
  if (longitude == null || longitude < -180 || longitude > 180) {
    return { ok: false, errorKey: 'prayer.error.badRequest' }
  }

  const date = searchParams.get('date')
  if (date != null && !isValidDateIso(date)) {
    return { ok: false, errorKey: 'prayer.error.badRequest' }
  }
  const month = searchParams.get('month')
  if (month != null && !MONTH_RE.test(month)) {
    return { ok: false, errorKey: 'prayer.error.badRequest' }
  }

  const rawCountry = searchParams.get('countryCode')
  const countryCode =
    rawCountry && /^[A-Za-z]{2}$/.test(rawCountry) ? rawCountry.toUpperCase() : null

  const methodMode = searchParams.get('methodMode') === 'manual' ? 'manual' : 'auto'
  const rawMethod = searchParams.get('methodId')
  let methodId: CalculationMethodId | null = null
  if (rawMethod != null && isCalculationMethodId(rawMethod)) {
    methodId = rawMethod
  }
  // Manual mode must name a real calculation method - silently substituting
  // one would present a method the user did not choose.
  if (methodMode === 'manual' && !methodId) {
    return { ok: false, errorKey: 'prayer.error.badRequest' }
  }

  const madhhab: Madhhab = searchParams.get('madhhab') === 'hanafi' ? 'hanafi' : 'standard'

  const rawRule = searchParams.get('highLatitudeRule')
  const highLatitudeRule: HighLatitudeRuleMode =
    rawRule === 'middle_of_night' || rawRule === 'one_seventh' || rawRule === 'angle_based'
      ? rawRule
      : 'auto'

  const adjustments = parseAdjustments(searchParams.get('adjustments'))
  if (!adjustments) {
    return { ok: false, errorKey: 'prayer.error.badRequest' }
  }

  const rawZone = searchParams.get('jakimZone')
  const jakimZone = rawZone != null && getJakimZone(rawZone) ? rawZone.toUpperCase() : null

  return {
    ok: true,
    value: {
      date,
      month,
      ctx: {
        latitude,
        longitude,
        timeZone: searchParams.get('timeZone'),
        countryCode,
        methodMode,
        methodId: methodId ?? 'MWL',
        madhhab,
        highLatitudeRule,
        adjustments,
        jakimZone,
      },
    },
  }
}
