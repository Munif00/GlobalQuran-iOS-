/**
 * Global Quran - Hybrid prayer-time source resolver (server-side only).
 *
 * Implements the documented priority chain:
 *   1. A verified official authority (JAKIM e-Solat, Malaysia - the only
 *      authority with a verified live public endpoint in the registry).
 *   2. The AlAdhan API with the documented calculation method for the
 *      user's country (or their manual choice).
 *   3. The validated local astronomical engine (adhan).
 *   4. Clearly-labeled cached data when everything above fails.
 *   5. An honest "unavailable" explanation - never invented times.
 *
 * Every result carries the full source transparency block, including why
 * each tier was used or skipped.
 */

import type {
  CalculationMethodId,
  HighLatitudeRuleMode,
  Madhhab,
  MethodResolution,
  PrayerAdjustments,
  PrayerCalendarResponse,
  PrayerSourceAttempt,
  PrayerSourceInfo,
  PrayerTimeRecord,
  PrayerTimesResponse,
} from '@/types'
import { getJakimZone } from '@/lib/prayer/authorities'
import { resolveCountryDefault } from '@/lib/prayer/country-methods'
import { getPrayerMethod } from '@/lib/prayer/methods'
import { daysInMonth, isValidTimeZone } from '@/lib/prayer/timezone'
import {
  fetchAladhanDay,
  fetchAladhanMonth,
  detectTimeZoneViaAladhan,
  type AladhanCalcParams,
} from './aladhan-client'
import { fetchJakimYear, currentJakimYear } from './jakim-client'
import { computeLocalDays, LOCAL_ENGINE_NAME } from './local-engine'
import { coordKeyPart, readPrayerCachePort, writePrayerCachePort, type CachedPrayerPayload } from './cache-port'
import {
  buildPrayerRecord,
  normalizeAdjustments,
  type SourcePrayerDay,
  type SourceTierMeta,
  type TierFailureReason,
} from './types'

/** How long a cached payload is considered fresh enough to serve silently. */
const FRESH_CACHE_MS = 24 * 60 * 60 * 1000

export interface PrayerRequestContext {
  latitude: number
  longitude: number
  timeZone: string | null
  countryCode: string | null
  methodMode: 'auto' | 'manual'
  methodId: CalculationMethodId
  madhhab: Madhhab
  highLatitudeRule: HighLatitudeRuleMode
  adjustments: PrayerAdjustments
  jakimZone: string | null
}

/** The authority whose standard an AlAdhan method implements (honest attribution). */
const METHOD_AUTHORITY_NAMES: Record<CalculationMethodId, string | null> = {
  MWL: 'Muslim World League',
  ISNA: 'Islamic Society of North America (ISNA)',
  EGYPT: 'Egyptian General Authority of Survey',
  MAKKAH: 'Umm Al-Qura University, Makkah',
  KARACHI: 'University of Islamic Sciences, Karachi',
  TEHRAN: 'Institute of Geophysics, University of Tehran',
  JAFARI: 'Shia Ithna-Ashari, Leva Institute, Qum',
  GULF: null,
  KUWAIT: 'Kuwait national timetable standard',
  QATAR: 'Qatar national timetable standard',
  SINGAPORE: 'Majlis Ugama Islam Singapura (MUIS)',
  FRANCE: 'Union Organization Islamic de France',
  TURKEY: 'Diyanet İşleri Başkanlığı (Diyanet)',
  RUSSIA: 'Spiritual Administration of Muslims of Russia',
  MOONSIGHTING: 'Moonsighting Committee Worldwide',
  DUBAI: 'Dubai timetable standard',
  JAKIM: 'Jabatan Kemajuan Islam Malaysia (JAKIM)',
  TUNISIA: 'Tunisia national timetable standard',
  ALGERIA: 'Algeria national timetable standard',
  KEMENAG: 'Kementerian Agama Republik Indonesia (KEMENAG)',
  MOROCCO: 'Morocco national timetable standard',
  PORTUGAL: 'Comunidade Islamica de Lisboa',
  JORDAN: 'Ministry of Awqaf, Islamic Affairs and Holy Places, Jordan',
}

function resolveMethod(ctx: PrayerRequestContext): MethodResolution {
  if (ctx.methodMode === 'manual') {
    return { mode: 'manual', methodId: ctx.methodId, countryCode: null, kind: null }
  }
  const countryDefault = resolveCountryDefault(ctx.countryCode)
  return {
    mode: 'auto',
    methodId: countryDefault.methodId,
    countryCode: countryDefault.countryCode === '*' ? null : countryDefault.countryCode,
    kind: countryDefault.kind,
  }
}

interface FetchOutcome {
  days: SourcePrayerDay[]
  meta: SourceTierMeta
  sourceName: string
  fetchedAt: string
  isCached: boolean
}

/** Fetch with read-through cache: fresh cache short-circuits; failures fall back to stale cache. */
async function fetchWithCache(args: {
  cacheKey: string
  kind: 'day' | 'month' | 'year'
  dateLabel: string
  sourceType: string
  sourceName: string
  liveFetch: () => Promise<
    { ok: true; days: SourcePrayerDay[]; meta: SourceTierMeta } | { ok: false; reason?: TierFailureReason }
  >
}): Promise<
  | { ok: true; outcome: FetchOutcome; fromCache: boolean }
  | { ok: false; cache: CachedPrayerPayload | null; reason: TierFailureReason }
> {
  const cached = await readPrayerCachePort(args.cacheKey)
  if (cached && Date.now() - new Date(cached.fetchedAt).getTime() < FRESH_CACHE_MS) {
    // Read-through: a fresh (< 24h) cached payload is served directly. This
    // is always labeled as cached data so it is never presented as a fresh
    // upstream verification (see the policy note in cache.ts).
    return {
      ok: true,
      outcome: {
        days: cached.days,
        meta: cached.meta,
        sourceName: cached.sourceName,
        fetchedAt: cached.fetchedAt,
        isCached: true,
      },
      fromCache: true,
    }
  }

  const result = await args.liveFetch()
  if (result.ok) {
    await writePrayerCachePort({
      cacheKey: args.cacheKey,
      kind: args.kind,
      dateLabel: args.dateLabel,
      sourceType: args.sourceType,
      sourceName: args.sourceName,
      payload: {
        days: result.days,
        meta: result.meta,
        sourceName: args.sourceName,
        fetchedAt: new Date().toISOString(),
      },
    })
    return {
      ok: true,
      outcome: {
        days: result.days,
        meta: result.meta,
        sourceName: args.sourceName,
        fetchedAt: new Date().toISOString(),
        isCached: false,
      },
      fromCache: false,
    }
  }

  // Upstream failed: fall back to any cache (stale is acceptable, clearly labeled).
  if (cached) {
    return {
      ok: true,
      outcome: {
        days: cached.days,
        meta: cached.meta,
        sourceName: cached.sourceName,
        fetchedAt: cached.fetchedAt,
        isCached: true,
      },
      fromCache: true,
    }
  }
  return { ok: false, cache: null, reason: result.reason ?? 'network_error' }
}

interface TierRun {
  sourceType: 'official_authority' | 'aladhan_api' | 'local_engine'
  sourceName: string
  authorityName: string | null
  registryId: string | null
  outcome: FetchOutcome | null
  attempt: PrayerSourceAttempt
  /** Extra notes surfaced in the transparency block. */
  notes: string[]
}

function latAdjustParam(rule: HighLatitudeRuleMode): number | null {
  switch (rule) {
    case 'middle_of_night':
      return 1
    case 'one_seventh':
      return 2
    case 'angle_based':
      return 3
    default:
      return null // auto -> the API default (ANGLE_BASED)
  }
}

function methodNotes(methodId: CalculationMethodId, resolution: MethodResolution): string[] {
  const notes: string[] = []
  const method = getPrayerMethod(methodId)
  if (method.experimental) {
    notes.push('prayer.note.experimentalMethod')
  }
  if (resolution.mode === 'auto') {
    if (resolution.kind === 'regional_common') {
      notes.push('prayer.note.regionalDefault')
    } else if (resolution.kind === 'global_default') {
      notes.push('prayer.note.globalDefault')
    }
  }
  return notes
}

/* ------------------------------------------------------------------ */
/* Day resolution                                                      */
/* ------------------------------------------------------------------ */

export async function resolvePrayerDay(
  dateIso: string,
  ctx: PrayerRequestContext,
): Promise<PrayerTimesResponse> {
  const attempts: PrayerSourceAttempt[] = []
  const notes: string[] = []
  const methodResolution = resolveMethod(ctx)

  /* ---- Time-zone resolution (a real IANA zone is mandatory) ---- */
  let timeZone: string | null = null
  let tzSource: PrayerSourceInfo['timeZoneSource'] = null
  if (isValidTimeZone(ctx.timeZone)) {
    timeZone = ctx.timeZone
    tzSource = 'provided'
  }

  const wantsJakim =
    (ctx.countryCode != null && ctx.countryCode.toUpperCase() === 'MY') || ctx.jakimZone != null

  /* ---- Priority 1: official authority (JAKIM e-Solat) ---- */
  if (wantsJakim) {
    const zone = ctx.jakimZone ? getJakimZone(ctx.jakimZone) : null
    if (!zone) {
      attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'no_zone_selected' })
      notes.push('prayer.note.jakimZoneNeeded')
    } else {
      // The official timetable zone pins the IANA zone for the record.
      if (!timeZone) {
        timeZone = zone.timeZone
        tzSource = 'zone_derived'
      }
      const jakimYear = currentJakimYear()
      const inPublishedYear = dateIso.startsWith(String(jakimYear))
      if (!inPublishedYear) {
        attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'out_of_published_range' })
        notes.push('prayer.note.jakimYearRange')
      } else {
        const cacheKey = `jakim:year:${jakimYear}:zone:${zone.code}`
        const jakimRun = await fetchWithCache({
          cacheKey,
          kind: 'year',
          dateLabel: String(jakimYear),
          sourceType: 'official_authority',
          sourceName: 'JAKIM e-Solat (official)',
          liveFetch: async () => {
            const result = await fetchJakimYear(zone.code)
            if (!result.ok) return { ok: false, reason: result.failure.reason }
            return { ok: true, days: result.result.days, meta: jakimMeta() }
          },
        })
        const day = jakimRun.ok
          ? jakimRun.outcome.days.find((entry) => entry.date === dateIso) ?? null
          : null

        if (!jakimRun.ok) {
          attempts.push({ source: 'jakim_esolat', outcome: 'failed', reasonCode: jakimRun.reason })
          notes.push('prayer.note.jakimFallback')
        } else if (day) {
          attempts.push({ source: 'jakim_esolat', outcome: 'used', reasonCode: 'ok' })
          notes.push('prayer.note.jakimOfficial')
          if (jakimRun.outcome.isCached) notes.push('prayer.note.cachedData')
          return liveDayResponse(dateIso, day, {
            ctx,
            attempts,
            notes,
            methodResolution,
            timeZone: zone.timeZone,
            tzSource,
            tier: {
              sourceType: 'official_authority',
              sourceName: jakimRun.outcome.isCached ? 'JAKIM e-Solat (official, cached)' : 'JAKIM e-Solat (official)',
              authorityName: 'Jabatan Kemajuan Islam Malaysia (JAKIM)',
              registryId: 'MY-JAKIM',
              fetchedAt: jakimRun.outcome.fetchedAt,
              isCached: jakimRun.outcome.isCached,
            },
            meta: jakimRun.outcome.meta,
          })
        } else {
          attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'out_of_published_range' })
          notes.push('prayer.note.jakimYearRange')
        }
      }
    }
  } else {
    attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'not_applicable' })
  }

  /* ---- Time-zone detection fallback (needed by tiers 2-3) ---- */
  if (!timeZone) {
    const detected = await detectTimeZoneViaAladhan(ctx.latitude, ctx.longitude)
    if (detected) {
      timeZone = detected
      tzSource = 'aladhan_detected'
    } else {
      return unavailableResponse(attempts, notes, 'prayer.error.noTimeZone')
    }
  }

  /* ---- Priority 2: AlAdhan API ---- */
  const methodId = methodResolution.methodId
  const method = getPrayerMethod(methodId)
  const aladhanParams: AladhanCalcParams = {
    latitude: ctx.latitude,
    longitude: ctx.longitude,
    timeZone,
    methodId,
    madhhab: ctx.madhhab,
    latitudeAdjustmentMethod: latAdjustParam(ctx.highLatitudeRule),
  }
  const aladhanKey = [
    'aladhan:day',
    dateIso,
    coordKeyPart(ctx.latitude),
    coordKeyPart(ctx.longitude),
    methodId,
    ctx.madhhab,
    ctx.highLatitudeRule,
  ].join(':')

  const aladhanRun = await fetchWithCache({
    cacheKey: aladhanKey,
    kind: 'day',
    dateLabel: dateIso,
    sourceType: 'aladhan_api',
    sourceName: 'AlAdhan API',
    liveFetch: async () => {
      const result = await fetchAladhanDay(dateIso, aladhanParams)
      if (!result.ok) return { ok: false, reason: result.failure.reason }
      return { ok: true, days: [result.result.day], meta: result.result.meta }
    },
  })

  if (aladhanRun.ok) {
    attempts.push({ source: 'aladhan_api', outcome: 'used', reasonCode: 'ok' })
    notes.push(...methodNotes(methodId, methodResolution))
    if (aladhanRun.outcome.isCached) notes.push('prayer.note.cachedData')
    if (aladhanRun.outcome.meta.highLatitudeSituation) notes.push('prayer.note.highLatitude')
    notes.push('prayer.note.hijriCalculated')
    return liveDayResponse(dateIso, aladhanRun.outcome.days[0], {
      ctx,
      attempts,
      notes,
      methodResolution,
      timeZone,
      tzSource,
      tier: {
        sourceType: 'aladhan_api',
        sourceName: aladhanRun.outcome.isCached ? 'AlAdhan API (cached)' : 'AlAdhan API',
        authorityName: METHOD_AUTHORITY_NAMES[methodId],
        registryId: null,
        fetchedAt: aladhanRun.outcome.fetchedAt,
        isCached: aladhanRun.outcome.isCached,
      },
      meta: aladhanRun.outcome.meta,
    })
  }
  attempts.push({ source: 'aladhan_api', outcome: 'failed', reasonCode: aladhanRun.reason })

  /* ---- Priority 3: local astronomical engine ---- */
  const localResult = computeLocalDays([dateIso], {
    latitude: ctx.latitude,
    longitude: ctx.longitude,
    timeZone,
    methodId,
    madhhab: ctx.madhhab,
    highLatitudeRule: ctx.highLatitudeRule === 'auto' ? 'auto' : ctx.highLatitudeRule,
  })
  if (localResult.ok) {
    attempts.push({ source: 'local_engine', outcome: 'used', reasonCode: 'ok' })
    notes.push(...methodNotes(methodId, methodResolution))
    notes.push('prayer.note.localEngine')
    if (localResult.result.meta.highLatitudeSituation) notes.push('prayer.note.highLatitude')
    notes.push('prayer.note.hijriCalculated')
    return liveDayResponse(dateIso, localResult.result.days[0], {
      ctx,
      attempts,
      notes,
      methodResolution,
      timeZone,
      tzSource,
      tier: {
        sourceType: 'local_engine',
        sourceName: LOCAL_ENGINE_NAME,
        authorityName: METHOD_AUTHORITY_NAMES[methodId],
        registryId: null,
        fetchedAt: new Date().toISOString(),
        isCached: false,
      },
      meta: localResult.result.meta,
    })
  }
  attempts.push({ source: 'local_engine', outcome: 'failed', reasonCode: 'invalid_response' })
  notes.push('prayer.note.localEngineFailed')

  /* ---- Priority 4: any cached day for these parameters ---- */
  const cachedDay = await readPrayerCachePort(aladhanKey)
  if (cachedDay && cachedDay.days[0]) {
    attempts.push({ source: 'cache', outcome: 'used', reasonCode: 'ok' })
    notes.push('prayer.note.cachedData')
    return liveDayResponse(dateIso, cachedDay.days[0], {
      ctx,
      attempts,
      notes,
      methodResolution,
      timeZone,
      tzSource,
      tier: {
        sourceType: 'aladhan_api',
        sourceName: 'AlAdhan API (cached)',
        authorityName: METHOD_AUTHORITY_NAMES[methodId],
        registryId: null,
        fetchedAt: cachedDay.fetchedAt,
        isCached: true,
      },
      meta: cachedDay.meta,
    })
  }
  attempts.push({ source: 'cache', outcome: 'failed', reasonCode: 'no_cached_data' })

  /* ---- Nothing worked: explain honestly ---- */
  return unavailableResponse(attempts, notes, 'prayer.error.noSource')
}

/* ------------------------------------------------------------------ */
/* Month resolution                                                    */
/* ------------------------------------------------------------------ */

export async function resolvePrayerMonth(
  monthIso: string,
  ctx: PrayerRequestContext,
): Promise<PrayerCalendarResponse> {
  const attempts: PrayerSourceAttempt[] = []
  const notes: string[] = []
  const methodResolution = resolveMethod(ctx)
  const [yearText, monthText] = monthIso.split('-')
  const year = Number(yearText)
  const month = Number(monthText)
  const totalDays = daysInMonth(monthIso)
  const allDates = Array.from({ length: totalDays }, (_, index) =>
    `${yearText}-${monthText}-${String(index + 1).padStart(2, '0')}`,
  )

  let timeZone: string | null = null
  let tzSource: PrayerSourceInfo['timeZoneSource'] = null
  if (isValidTimeZone(ctx.timeZone)) {
    timeZone = ctx.timeZone
    tzSource = 'provided'
  }

  const wantsJakim =
    (ctx.countryCode != null && ctx.countryCode.toUpperCase() === 'MY') || ctx.jakimZone != null

  /* ---- Priority 1: JAKIM ---- */
  if (wantsJakim) {
    const zone = ctx.jakimZone ? getJakimZone(ctx.jakimZone) : null
    if (!zone) {
      attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'no_zone_selected' })
      notes.push('prayer.note.jakimZoneNeeded')
    } else {
      if (!timeZone) {
        timeZone = zone.timeZone
        tzSource = 'zone_derived'
      }
      const jakimYear = currentJakimYear()
      const inPublishedYear = year === jakimYear
      if (!inPublishedYear) {
        attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'out_of_published_range' })
        notes.push('prayer.note.jakimYearRange')
      } else {
        const cacheKey = `jakim:year:${jakimYear}:zone:${zone.code}`
        const jakimRun = await fetchWithCache({
          cacheKey,
          kind: 'year',
          dateLabel: String(jakimYear),
          sourceType: 'official_authority',
          sourceName: 'JAKIM e-Solat (official)',
          liveFetch: async () => {
            const result = await fetchJakimYear(zone.code)
            if (!result.ok) return { ok: false, reason: result.failure.reason }
            return { ok: true, days: result.result.days, meta: jakimMeta() }
          },
        })
        const monthDays = jakimRun.ok
          ? jakimRun.outcome.days.filter((entry) => entry.date.startsWith(monthIso))
          : []

        if (!jakimRun.ok) {
          attempts.push({ source: 'jakim_esolat', outcome: 'failed', reasonCode: jakimRun.reason })
          notes.push('prayer.note.jakimFallback')
        } else if (monthDays.length === totalDays) {
          attempts.push({ source: 'jakim_esolat', outcome: 'used', reasonCode: 'ok' })
          notes.push('prayer.note.jakimOfficial')
          if (jakimRun.outcome.isCached) notes.push('prayer.note.cachedData')
          return liveMonthResponse(monthIso, monthDays, {
            ctx,
            attempts,
            notes,
            methodResolution,
            timeZone: zone.timeZone,
            tzSource,
            tier: {
              sourceType: 'official_authority',
              sourceName: jakimRun.outcome.isCached ? 'JAKIM e-Solat (official, cached)' : 'JAKIM e-Solat (official)',
              authorityName: 'Jabatan Kemajuan Islam Malaysia (JAKIM)',
              registryId: 'MY-JAKIM',
              fetchedAt: jakimRun.outcome.fetchedAt,
              isCached: jakimRun.outcome.isCached,
            },
            meta: jakimRun.outcome.meta,
          })
        } else {
          attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'out_of_published_range' })
          notes.push('prayer.note.jakimYearRange')
        }
      }
    }
  } else {
    attempts.push({ source: 'jakim_esolat', outcome: 'skipped', reasonCode: 'not_applicable' })
  }

  if (!timeZone) {
    const detected = await detectTimeZoneViaAladhan(ctx.latitude, ctx.longitude)
    if (detected) {
      timeZone = detected
      tzSource = 'aladhan_detected'
    } else {
      return unavailableMonthResponse(monthIso, attempts, notes, 'prayer.error.noTimeZone')
    }
  }

  /* ---- Priority 2: AlAdhan calendar (every date calculated by the API) ---- */
  const methodId = methodResolution.methodId
  const aladhanParams: AladhanCalcParams = {
    latitude: ctx.latitude,
    longitude: ctx.longitude,
    timeZone,
    methodId,
    madhhab: ctx.madhhab,
    latitudeAdjustmentMethod: latAdjustParam(ctx.highLatitudeRule),
  }
  const aladhanKey = [
    'aladhan:month',
    monthIso,
    coordKeyPart(ctx.latitude),
    coordKeyPart(ctx.longitude),
    methodId,
    ctx.madhhab,
    ctx.highLatitudeRule,
  ].join(':')

  const aladhanRun = await fetchWithCache({
    cacheKey: aladhanKey,
    kind: 'month',
    dateLabel: monthIso,
    sourceType: 'aladhan_api',
    sourceName: 'AlAdhan API',
    liveFetch: async () => {
      const result = await fetchAladhanMonth(year, month, aladhanParams)
      if (!result.ok) return { ok: false, reason: result.failure.reason }
      return { ok: true, days: result.result.days, meta: result.result.meta }
    },
  })

  if (aladhanRun.ok) {
    attempts.push({ source: 'aladhan_api', outcome: 'used', reasonCode: 'ok' })
    notes.push(...methodNotes(methodId, methodResolution))
    if (aladhanRun.outcome.isCached) notes.push('prayer.note.cachedData')
    if (aladhanRun.outcome.meta.highLatitudeSituation) notes.push('prayer.note.highLatitude')
    notes.push('prayer.note.hijriCalculated')
    return liveMonthResponse(monthIso, aladhanRun.outcome.days, {
      ctx,
      attempts,
      notes,
      methodResolution,
      timeZone,
      tzSource,
      tier: {
        sourceType: 'aladhan_api',
        sourceName: aladhanRun.outcome.isCached ? 'AlAdhan API (cached)' : 'AlAdhan API',
        authorityName: METHOD_AUTHORITY_NAMES[methodId],
        registryId: null,
        fetchedAt: aladhanRun.outcome.fetchedAt,
        isCached: aladhanRun.outcome.isCached,
      },
      meta: aladhanRun.outcome.meta,
    })
  }
  attempts.push({ source: 'aladhan_api', outcome: 'failed', reasonCode: aladhanRun.reason })

  /* ---- Priority 3: local engine, every day computed ---- */
  const localResult = computeLocalDays(allDates, {
    latitude: ctx.latitude,
    longitude: ctx.longitude,
    timeZone,
    methodId,
    madhhab: ctx.madhhab,
    highLatitudeRule: ctx.highLatitudeRule === 'auto' ? 'auto' : ctx.highLatitudeRule,
  })
  if (localResult.ok && localResult.result.days.length === totalDays) {
    attempts.push({ source: 'local_engine', outcome: 'used', reasonCode: 'ok' })
    notes.push(...methodNotes(methodId, methodResolution))
    notes.push('prayer.note.localEngine')
    if (localResult.result.meta.highLatitudeSituation) notes.push('prayer.note.highLatitude')
    notes.push('prayer.note.hijriCalculated')
    return liveMonthResponse(monthIso, localResult.result.days, {
      ctx,
      attempts,
      notes,
      methodResolution,
      timeZone,
      tzSource,
      tier: {
        sourceType: 'local_engine',
        sourceName: LOCAL_ENGINE_NAME,
        authorityName: METHOD_AUTHORITY_NAMES[methodId],
        registryId: null,
        fetchedAt: new Date().toISOString(),
        isCached: false,
      },
      meta: localResult.result.meta,
    })
  }
  attempts.push({ source: 'local_engine', outcome: 'failed', reasonCode: 'invalid_response' })

  const cachedMonth = await readPrayerCachePort(aladhanKey)
  if (cachedMonth && cachedMonth.days.length > 0) {
    attempts.push({ source: 'cache', outcome: 'used', reasonCode: 'ok' })
    notes.push('prayer.note.cachedData')
    return liveMonthResponse(monthIso, cachedMonth.days, {
      ctx,
      attempts,
      notes,
      methodResolution,
      timeZone,
      tzSource,
      tier: {
        sourceType: 'aladhan_api',
        sourceName: 'AlAdhan API (cached)',
        authorityName: METHOD_AUTHORITY_NAMES[methodId],
        registryId: null,
        fetchedAt: cachedMonth.fetchedAt,
        isCached: true,
      },
      meta: cachedMonth.meta,
    })
  }
  attempts.push({ source: 'cache', outcome: 'failed', reasonCode: 'no_cached_data' })

  return unavailableMonthResponse(monthIso, attempts, notes, 'prayer.error.noSource')
}

/* ------------------------------------------------------------------ */
/* Response builders                                                   */
/* ------------------------------------------------------------------ */

function jakimMeta(): SourceTierMeta {
  return {
    methodId: null,
    methodName: 'JAKIM official timetable',
    methodParams: null,
    appliedRule: null,
    highLatitudeSituation: false,
  }
}

interface TierInfo {
  sourceType: PrayerTimeRecord['sourceType']
  sourceName: string
  authorityName: string | null
  registryId: string | null
  fetchedAt: string
  isCached: boolean
}

function buildSourceInfo(args: {
  ctx: PrayerRequestContext
  methodResolution: MethodResolution
  timeZone: string
  tzSource: PrayerSourceInfo['timeZoneSource']
  tier: TierInfo
  meta: SourceTierMeta
  attempts: PrayerSourceAttempt[]
  notes: string[]
}): PrayerSourceInfo {
  const { ctx, methodResolution, tier, meta, attempts, notes } = args
  const hasAdjustments = Object.values(ctx.adjustments).some((value) => value !== 0)
  const finalNotes = [...notes]
  if (hasAdjustments) finalNotes.push('prayer.note.adjusted')

  return {
    sourceType: tier.sourceType,
    sourceName: tier.sourceName,
    authorityName: tier.authorityName,
    officialRegistryId: tier.registryId,
    calculationMethodCode: meta.methodId,
    calculationMethodName: meta.methodName,
    calculationMethodParams: meta.methodParams,
    methodResolution: tier.sourceType === 'official_authority' ? null : methodResolution,
    madhhab: ctx.madhhab,
    appliedHighLatitudeRule: meta.appliedRule,
    highLatitudeAdjusted: meta.highLatitudeSituation,
    timeZone: args.timeZone,
    timeZoneSource: args.tzSource,
    adjustments: ctx.adjustments,
    fetchedAt: tier.fetchedAt,
    isCached: tier.isCached,
    attempts,
    notes: finalNotes,
  }
}

function liveDayResponse(
  dateIso: string,
  day: SourcePrayerDay,
  args: {
    ctx: PrayerRequestContext
    methodResolution: MethodResolution
    timeZone: string
    tzSource: PrayerSourceInfo['timeZoneSource']
    tier: TierInfo
    meta: SourceTierMeta
    attempts: PrayerSourceAttempt[]
    notes: string[]
  },
): PrayerTimesResponse {
  const isJakim = args.tier.sourceType === 'official_authority'
  const record = buildPrayerRecord(day, {
    latitude: args.ctx.latitude,
    longitude: args.ctx.longitude,
    timeZone: args.timeZone,
    sourceType: args.tier.sourceType,
    sourceName: args.tier.sourceName,
    authorityName: args.tier.authorityName,
    calculationMethod: args.meta.methodName ?? 'Official timetable',
    calculationMethodCode: args.meta.methodId,
    madhhab: isJakim ? 'authority_published' : args.ctx.madhhab,
    adjustments: normalizeAdjustments(args.ctx.adjustments),
    fetchedAt: args.tier.fetchedAt,
    isCached: args.tier.isCached,
    validationStatus: args.tier.isCached ? 'cached' : 'ok',
  })
  return {
    status: 'live',
    message: null,
    messageKey: null,
    record,
    source: buildSourceInfo({ ...args }),
  }
}

function liveMonthResponse(
  monthIso: string,
  days: SourcePrayerDay[],
  args: {
    ctx: PrayerRequestContext
    methodResolution: MethodResolution
    timeZone: string
    tzSource: PrayerSourceInfo['timeZoneSource']
    tier: TierInfo
    meta: SourceTierMeta
    attempts: PrayerSourceAttempt[]
    notes: string[]
  },
): PrayerCalendarResponse {
  const isJakim = args.tier.sourceType === 'official_authority'
  const records = days.map((day) =>
    buildPrayerRecord(day, {
      latitude: args.ctx.latitude,
      longitude: args.ctx.longitude,
      timeZone: args.timeZone,
      sourceType: args.tier.sourceType,
      sourceName: args.tier.sourceName,
      authorityName: args.tier.authorityName,
      calculationMethod: args.meta.methodName ?? 'Official timetable',
      calculationMethodCode: args.meta.methodId,
      madhhab: isJakim ? 'authority_published' : args.ctx.madhhab,
      adjustments: normalizeAdjustments(args.ctx.adjustments),
      fetchedAt: args.tier.fetchedAt,
      isCached: args.tier.isCached,
      validationStatus: args.tier.isCached ? 'cached' : 'ok',
    }),
  )
  return {
    status: 'live',
    message: null,
    messageKey: null,
    month: monthIso,
    days: records,
    source: buildSourceInfo({ ...args }),
  }
}

function unavailableResponse(
  attempts: PrayerSourceAttempt[],
  notes: string[],
  messageKey: string,
): PrayerTimesResponse {
  return {
    status: 'unavailable',
    message: null,
    messageKey,
    record: null,
    source: null,
    trace: attempts,
    traceNotes: notes,
  }
}

function unavailableMonthResponse(
  monthIso: string,
  attempts: PrayerSourceAttempt[],
  notes: string[],
  messageKey: string,
): PrayerCalendarResponse {
  return {
    status: 'unavailable',
    message: null,
    messageKey,
    month: monthIso,
    days: [],
    source: null,
    trace: attempts,
    traceNotes: notes,
  }
}
