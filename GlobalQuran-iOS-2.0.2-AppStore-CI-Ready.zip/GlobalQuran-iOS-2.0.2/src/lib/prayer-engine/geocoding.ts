/**
 * Global Quran - Geocoding (isomorphic: server + native client).
 *
 * - City search: Nominatim (OpenStreetMap). The request is identified with
 *   an application User-Agent, throttled to 1 req/s, and query results are
 *   cached, in line with Nominatim's usage policy. NOTE: the policy also
 *   asks for a working contact; self-hosters should set NOMINATIM_CONTACT
 *   (email or URL) so the header can include it. The bundled curated city
 *   dataset serves most queries without any Nominatim request.
 * - Reverse geocoding: BigDataCloud's documented free client endpoint
 *   (keyless) with Nominatim as fallback.
 *
 * All upstream values are validated and reduced to safe, minimal fields -
 * no HTML, no extra properties, nothing passed through raw.
 *
 * The HTTP transport is injectable: the web server uses the shared
 * fetchJsonWithTimeout; the native app (Capacitor) routes Nominatim through
 * CapacitorHttp so the identifying User-Agent header is actually sent
 * (browsers forbid setting User-Agent on fetch). This module itself never
 * imports platform-specific code.
 */

import type { CitySearchResult, ReverseGeocodeResponse } from '@/types'
import { searchBundledCities } from '@/lib/prayer/cities'
import { fetchJsonWithTimeout, type SourceTierFailure } from './types'

const NOMINATIM_BASE = 'https://nominatim.openstreetmap.org'
const BDC_BASE = 'https://api.bigdatacloud.net/data/reverse-geocode-client'

/** Transport signature shared with fetchJsonWithTimeout. */
export type GeocodingTransport = (
  url: string,
  timeoutMs: number,
  init?: RequestInit,
) => Promise<
  { ok: true; data: unknown } | { ok: false; failure: SourceTierFailure }
>

/**
 * Honest identification per Nominatim's usage policy. A real contact address
 * cannot be invented here - operators deploying the web app should set the
 * NOMINATIM_CONTACT environment variable (e.g. 'admin@example.org') via
 * setGeocodingContact() at server boot so the header carries one. Without
 * it, requests are still identified by app name.
 */
let geocodingContact: string | null = null

/** Set the Nominatim usage-policy contact (web server boot, from env). */
export function setGeocodingContact(contact: string | null): void {
  geocodingContact = contact && contact.trim().length > 0 ? contact.trim() : null
}

function userAgent(): string {
  return geocodingContact
    ? `GlobalQuran/1.0 (prayer times; ${geocodingContact})`
    : 'GlobalQuran/1.0 (prayer times; no contact configured)'
}

/* ------------------------------------------------------------------ */
/* Nominatim throttle + query cache (usage policy: max 1 req/s)        */
/* ------------------------------------------------------------------ */

let nominatimLastRequestAt = 0
const NOMINATIM_MIN_INTERVAL_MS = 1_100
const searchCache = new Map<string, { at: number; results: CitySearchResult[] }>()
const SEARCH_CACHE_TTL_MS = 10 * 60 * 1000
const SEARCH_CACHE_MAX = 200

async function nominatimGate(): Promise<boolean> {
  const now = Date.now()
  const wait = nominatimLastRequestAt + NOMINATIM_MIN_INTERVAL_MS - now
  if (wait <= 0) {
    nominatimLastRequestAt = now
    return true
  }
  // A second concurrent caller is rejected rather than queued (the bundled
  // dataset keeps the UX responsive; the client retries online later).
  return false
}

/** Accepted Nominatim address types (settlements - the `addresstype` field,
 *  which is the display-appropriate type; the raw `type` is often
 *  "administrative" for city relations). */
const ACCEPTED_ADDRESS_TYPES = new Set([
  'city',
  'town',
  'village',
  'municipality',
  'hamlet',
  'suburb',
  'borough',
  'quarter',
])

interface NominatimPlace {
  lat?: unknown
  lon?: unknown
  display_name?: unknown
  type?: unknown
  addresstype?: unknown
  name?: unknown
  address?: { country?: unknown; country_code?: unknown; state?: unknown }
}

async function nominatimSearch(
  query: string,
  limit: number,
  transport: GeocodingTransport,
): Promise<CitySearchResult[] | null> {
  const canRun = await nominatimGate()
  if (!canRun) return null

  const params = new URLSearchParams({
    q: query,
    format: 'json',
    limit: String(Math.min(limit, 8)),
    addressdetails: '1',
    'accept-language': 'en',
  })
  const response = await transport(
    `${NOMINATIM_BASE}/search?${params.toString()}`,
    9_000,
    { headers: { 'User-Agent': userAgent() } },
  )
  if (!response.ok || !Array.isArray(response.data)) return null

  const results: CitySearchResult[] = []
  for (const raw of response.data) {
    if (typeof raw !== 'object' || raw === null) continue
    const place = raw as NominatimPlace
    const lat = Number(place.lat)
    const lon = Number(place.lon)
    const countryCode =
      typeof place.address?.country_code === 'string'
        ? place.address.country_code.toUpperCase()
        : null
    const name =
      typeof place.name === 'string' && place.name.length > 0 ? place.name : null
    const addressType =
      typeof place.addresstype === 'string' ? place.addresstype : String(place.type ?? '')
    if (
      !name ||
      !countryCode ||
      !Number.isFinite(lat) ||
      !Number.isFinite(lon) ||
      !ACCEPTED_ADDRESS_TYPES.has(addressType)
    ) {
      continue
    }
    results.push({
      id: `nominatim:${lat.toFixed(3)},${lon.toFixed(3)}`,
      name,
      region: typeof place.address?.state === 'string' ? place.address.state : null,
      country: typeof place.address?.country === 'string' ? place.address.country : countryCode,
      countryCode,
      latitude: Math.min(90, Math.max(-90, lat)),
      longitude: Math.min(180, Math.max(-180, lon)),
      timeZone: null,
      approximate: false,
      origin: 'nominatim',
    })
    if (results.length >= limit) break
  }
  return results
}

/** Enrich online results with the bundled time zone when the city is known. */
function enrichWithBundledTimeZone(results: CitySearchResult[]): CitySearchResult[] {
  return results.map((result) => {
    if (result.timeZone) return result
    const bundled = searchBundledCities(result.name, { limit: 1, countryCode: result.countryCode })
    const match = bundled[0]
    if (match && match.countryCode === result.countryCode) {
      return { ...result, timeZone: match.timeZone }
    }
    return result
  })
}

export interface CitySearchOutcome {
  status: 'live' | 'degraded'
  messageKey: string | null
  results: CitySearchResult[]
}

export async function searchCities(
  query: string,
  transport: GeocodingTransport = fetchJsonWithTimeout,
): Promise<CitySearchOutcome> {
  const trimmed = query.trim().slice(0, 100)
  if (trimmed.length < 2) {
    return { status: 'live', messageKey: null, results: [] }
  }

  const cached = searchCache.get(trimmed.toLowerCase())
  if (cached && Date.now() - cached.at < SEARCH_CACHE_TTL_MS) {
    return { status: 'live', messageKey: null, results: cached.results }
  }

  const bundled = searchBundledCities(trimmed, { limit: 8 })
  const online = await nominatimSearch(trimmed, 8, transport)

  if (online == null) {
    // Live geocoding unavailable - bundled results only (honest degraded state).
    return { status: 'degraded', messageKey: 'prayer.search.degraded', results: bundled }
  }

  // Merge: bundled first (they carry time zones), then online extras.
  const seen = new Set(bundled.map((entry) => `${entry.name}|${entry.countryCode}`))
  const onlineEnriched = enrichWithBundledTimeZone(online)
  const merged = [...bundled, ...onlineEnriched.filter((entry) => !seen.has(`${entry.name}|${entry.countryCode}`))].slice(0, 10)

  if (searchCache.size > SEARCH_CACHE_MAX) {
    searchCache.clear()
  }
  searchCache.set(trimmed.toLowerCase(), { at: Date.now(), results: merged })

  return { status: 'live', messageKey: null, results: merged }
}

/* ------------------------------------------------------------------ */
/* Reverse geocoding                                                   */
/* ------------------------------------------------------------------ */

interface BdcPayload {
  countryName?: unknown
  countryCode?: unknown
  city?: unknown
  locality?: unknown
  principalSubdivision?: unknown
}

export async function reverseGeocode(
  latitude: number,
  longitude: number,
  transport: GeocodingTransport = fetchJsonWithTimeout,
): Promise<ReverseGeocodeResponse> {
  // Primary: BigDataCloud free client endpoint (documented, keyless).
  const params = new URLSearchParams({
    latitude: String(latitude),
    longitude: String(longitude),
    localityLanguage: 'en',
  })
  const bdc = await fetchJsonWithTimeout(`${BDC_BASE}?${params.toString()}`, 8_000)
  if (bdc.ok) {
    const payload = bdc.data as BdcPayload
    const countryCode =
      typeof payload.countryCode === 'string' && /^[A-Za-z]{2}$/.test(payload.countryCode)
        ? payload.countryCode.toUpperCase()
        : null
    if (countryCode) {
      return {
        status: 'live',
        city:
          typeof payload.city === 'string' && payload.city.length > 0
            ? payload.city
            : typeof payload.locality === 'string' && payload.locality.length > 0
              ? payload.locality
              : null,
        region: typeof payload.principalSubdivision === 'string' ? payload.principalSubdivision : null,
        countryName: typeof payload.countryName === 'string' ? payload.countryName : null,
        countryCode,
      }
    }
  }

  // Fallback: Nominatim reverse (zoom=country level fields only).
  const canRun = await nominatimGate()
  if (!canRun) {
    return { status: 'unavailable', city: null, region: null, countryName: null, countryCode: null }
  }
  const query = new URLSearchParams({
    lat: String(latitude),
    lon: String(longitude),
    format: 'json',
    zoom: '10',
    addressdetails: '1',
    'accept-language': 'en',
  })
  const nominatim = await transport(
    `${NOMINATIM_BASE}/reverse?${query.toString()}`,
    9_000,
    { headers: { 'User-Agent': userAgent() } },
  )
  if (nominatim.ok) {
    const payload = nominatim.data as {
      address?: { country?: unknown; country_code?: unknown; state?: unknown; city?: unknown; town?: unknown; village?: unknown }
    }
    const countryCode =
      typeof payload.address?.country_code === 'string'
        ? payload.address.country_code.toUpperCase()
        : null
    if (countryCode) {
      return {
        status: 'live',
        city:
          [payload.address?.city, payload.address?.town, payload.address?.village].find(
            (value): value is string => typeof value === 'string' && value.length > 0,
          ) ?? null,
        region: typeof payload.address?.state === 'string' ? payload.address.state : null,
        countryName: typeof payload.address?.country === 'string' ? payload.address.country : null,
        countryCode,
      }
    }
  }

  return { status: 'unavailable', city: null, region: null, countryName: null, countryCode: null }
}
