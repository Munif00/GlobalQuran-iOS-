/**
 * Global Quran - JAKIM e-Solat official client (server-side only).
 *
 * The only INTEGRATED official authority source (Priority 1 of the hybrid
 * strategy). Verified live on 2026-11-15:
 * - Endpoint: https://www.e-solat.gov.my/index.php?r=esolatApi/takwimsolat
 *   &period=year|month|week&zone={code} (public, keyless, JSON).
 * - `period=year` returns the full current year (365 entries) with the
 *   official Hijri date per day; `period=day` was observed broken (the API
 *   answers "Please Provide 'period' parameter") and is therefore not used.
 * - Invalid zones return a clean `NO_RECORD!` status.
 * - Date labels use Malay month abbreviations (…Mei, Ogos, Okt, Dis…).
 * - Times are wall-clock "HH:mm:ss" in Malaysia Time; Peninsular zones use
 *   Asia/Kuala_Lumpur and Sabah/Sarawak use Asia/Kuching (both UTC+8, no
 *   DST - but conversion still goes through the IANA-aware utility).
 *
 * Coverage: any date within the CURRENT published year. Dates beyond it
 * honestly fall back to the AlAdhan JAKIM method (resolver handles this).
 */

import { getJakimZone } from '@/lib/prayer/authorities'
import { zonedWallTimeToUtc } from '@/lib/prayer/timezone'
import {
  fetchJsonWithTimeout,
  type SourcePrayerDay,
  type SourceTierFailure,
} from './types'

const ESOLAT_ENDPOINT = 'https://www.e-solat.gov.my/index.php'
const TIMEOUT_MS = 20_000
const USER_AGENT = 'GlobalQuran/1.0 (prayer times; contact: in-app)'

/** Malay month abbreviations used by the API's date labels. */
const MALAY_MONTHS: Record<string, number> = {
  jan: 1,
  feb: 2,
  mar: 3,
  apr: 4,
  mei: 5,
  jun: 6,
  jul: 7,
  ogo: 8,
  sep: 9,
  okt: 10,
  nov: 11,
  dis: 12,
}

interface EsolatDay {
  hijri?: unknown
  date?: unknown
  imsak?: unknown
  fajr?: unknown
  syuruk?: unknown
  dhuhr?: unknown
  asr?: unknown
  maghrib?: unknown
  isha?: unknown
}

/** Parse a date label like `15-Nov-2026` (Malay abbreviations). */
function parseEsolatDate(label: unknown): string | null {
  if (typeof label !== 'string') return null
  const match = /^(\d{1,2})-([A-Za-z]{3,4})-(\d{4})$/.exec(label.trim())
  if (!match) return null
  const day = match[1].padStart(2, '0')
  const month = MALAY_MONTHS[match[2].slice(0, 3).toLowerCase()]
  if (!month) return null
  return `${match[3]}-${String(month).padStart(2, '0')}-${day}`
}

/** Parse "HH:mm:ss" (or "HH:mm") into minutes-since-midnight, or null. */
function parseWallClock(value: unknown): { hour: number; minute: number } | null {
  if (typeof value !== 'string') return null
  const match = /^(\d{1,2}):(\d{2})(?::\d{2})?$/.exec(value.trim())
  if (!match) return null
  const hour = Number(match[1])
  const minute = Number(match[2])
  if (hour > 23 || minute > 59) return null
  return { hour, minute }
}

function parseHijri(value: unknown): string | null {
  // JAKIM Hijri format observed: "1448-06-05" (Y-M-D).
  if (typeof value !== 'string') return null
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value.trim())
  if (!match) return null
  return `${match[3]}-${match[2]}-${match[1]}`
}

function normalizeZoneDay(entry: EsolatDay, timeZone: string): SourcePrayerDay | null {
  const date = parseEsolatDate(entry.date)
  if (!date) return null
  const times: Array<keyof Pick<SourcePrayerDay, 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'>> = [
    'fajr',
    'sunrise',
    'dhuhr',
    'asr',
    'maghrib',
    'isha',
  ]
  const sources: Record<string, unknown> = {
    fajr: entry.fajr,
    sunrise: entry.syuruk, // JAKIM's sunrise is labeled "syuruk"
    dhuhr: entry.dhuhr,
    asr: entry.asr,
    maghrib: entry.maghrib,
    isha: entry.isha,
  }
  const day: Partial<SourcePrayerDay> = { date, hijriDate: parseHijri(entry.hijri), hijriSource: 'jakim_official' }
  for (const key of times) {
    const wall = parseWallClock(sources[key])
    if (!wall) return null
    const wallTime = `${String(wall.hour).padStart(2, '0')}:${String(wall.minute).padStart(2, '0')}`
    day[key] = zonedWallTimeToUtc(date, wallTime, timeZone).toISOString()
  }
  return day as SourcePrayerDay
}

export interface JakimYearResult {
  days: SourcePrayerDay[]
  zoneCode: string
  /** The year the payload covers (the currently published year). */
  year: number
}

/**
 * Fetch the full published year for a zone. Returns normalized days keyed
 * by date. Every day is the official JAKIM timetable - never extrapolated.
 */
export async function fetchJakimYear(
  zoneCode: string,
): Promise<{ ok: true; result: JakimYearResult } | { ok: false; failure: SourceTierFailure }> {
  const zone = getJakimZone(zoneCode)
  if (!zone) {
    return { ok: false, failure: { reason: 'invalid_response', detail: `unknown zone ${zoneCode}` } }
  }

  const query = new URLSearchParams({
    r: 'esolatApi/takwimsolat',
    period: 'year',
    zone: zone.code,
  })
  const response = await fetchJsonWithTimeout(
    `${ESOLAT_ENDPOINT}?${query.toString()}`,
    TIMEOUT_MS,
    { headers: { 'User-Agent': USER_AGENT } },
  )
  if (!response.ok) return response

  const body = response.data as { prayerTime?: unknown; status?: unknown }
  const payload = body.prayerTime

  // Clean "no data" shape: {"prayerTime":{"data":[...]},"status":"NO_RECORD!"}
  if (!Array.isArray(payload)) {
    return { ok: false, failure: { reason: 'invalid_response', detail: 'NO_RECORD or unexpected payload' } }
  }

  const days: SourcePrayerDay[] = []
  for (const entry of payload) {
    if (typeof entry !== 'object' || entry === null) continue
    const day = normalizeZoneDay(entry as EsolatDay, zone.timeZone)
    if (day) days.push(day)
  }
  if (days.length < 300) {
    return {
      ok: false,
      failure: { reason: 'invalid_response', detail: `only ${days.length} days for ${zone.code}` },
    }
  }
  days.sort((a, b) => a.date.localeCompare(b.date))
  const year = Number(days[0].date.slice(0, 4))

  return { ok: true, result: { days, zoneCode: zone.code, year } }
}

/** The current year in Malaysia Time (what e-Solat publishes). */
export function currentJakimYear(): number {
  return Number(new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kuala_Lumpur',
    year: 'numeric',
  }).format(new Date()))
}
