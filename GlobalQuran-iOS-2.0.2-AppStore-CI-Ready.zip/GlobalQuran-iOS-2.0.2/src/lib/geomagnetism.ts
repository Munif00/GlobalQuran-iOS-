/**
 * World Magnetic Model WMM2025 - magnetic declination.
 *
 * This module evaluates the official WMM2025 spherical-harmonic model to
 * compute the magnetic declination (the angle between magnetic north and true
 * north) for a given location, altitude and date.
 *
 * Data source (verbatim, unmodified coefficients):
 * - Model: WMM2025, released 2024-12 by NOAA/NCEI and the British Geological
 *   Survey. Epoch 2025.0, degree/order 12, validity period 2025.0 - 2029.99.
 * - File: WMM2025.COF from the official distribution package
 *   https://www.ncei.noaa.gov/sites/default/files/2024-12/WMM2025COF.zip
 *   (downloaded and embedded on 2026-11-15; SHA-256 of the package verified
 *   against the published file at fetch time by byte-for-byte re-download).
 * - The official test-value file (WMM2025_TestValues.txt) from the same
 *   package is used by `scripts/verify-qibla.ts` to validate this
 *   implementation numerically before shipping.
 *
 * Algorithm: standard WMM evaluation as documented in the WMM2025 technical
 * report - geodetic-to-geocentric conversion on WGS84, Schmidt semi-normalized
 * associated Legendre functions, time-linear Gauss coefficients, spherical
 * harmonic summation, rotation back to the geodetic frame.
 */

/** Model identification - surfaced in the UI for transparency. */
export const WMM_MODEL_INFO = {
  name: 'WMM2025',
  epoch: 2025.0,
  /** The model's validity window in decimal years. */
  validFrom: 2025.0,
  validTo: 2030.0,
  degree: 12,
  source: 'NOAA/NCEI & BGS - WMM2025 coefficient release (2024-12)',
  /** Where the coefficients were obtained from, for auditability. */
  sourceUrl: 'https://www.ncei.noaa.gov/sites/default/files/2024-12/WMM2025COF.zip',
} as const

/**
 * Gauss coefficients, exactly as published in WMM2025.COF:
 * [n, m, g (nT), h (nT), gdot (nT/yr), hdot (nT/yr)]
 */
const WMM2025_COEFFICIENTS: readonly (readonly [number, number, number, number, number, number])[] = [
  [1, 0, -29351.8, 0.0, 12.0, 0.0],
  [1, 1, -1410.8, 4545.4, 9.7, -21.5],
  [2, 0, -2556.6, 0.0, -11.6, 0.0],
  [2, 1, 2951.1, -3133.6, -5.2, -27.7],
  [2, 2, 1649.3, -815.1, -8.0, -12.1],
  [3, 0, 1361.0, 0.0, -1.3, 0.0],
  [3, 1, -2404.1, -56.6, -4.2, 4.0],
  [3, 2, 1243.8, 237.5, 0.4, -0.3],
  [3, 3, 453.6, -549.5, -15.6, -4.1],
  [4, 0, 895.0, 0.0, -1.6, 0.0],
  [4, 1, 799.5, 278.6, -2.4, -1.1],
  [4, 2, 55.7, -133.9, -6.0, 4.1],
  [4, 3, -281.1, 212.0, 5.6, 1.6],
  [4, 4, 12.1, -375.6, -7.0, -4.4],
  [5, 0, -233.2, 0.0, 0.6, 0.0],
  [5, 1, 368.9, 45.4, 1.4, -0.5],
  [5, 2, 187.2, 220.2, 0.0, 2.2],
  [5, 3, -138.7, -122.9, 0.6, 0.4],
  [5, 4, -142.0, 43.0, 2.2, 1.7],
  [5, 5, 20.9, 106.1, 0.9, 1.9],
  [6, 0, 64.4, 0.0, -0.2, 0.0],
  [6, 1, 63.8, -18.4, -0.4, 0.3],
  [6, 2, 76.9, 16.8, 0.9, -1.6],
  [6, 3, -115.7, 48.8, 1.2, -0.4],
  [6, 4, -40.9, -59.8, -0.9, 0.9],
  [6, 5, 14.9, 10.9, 0.3, 0.7],
  [6, 6, -60.7, 72.7, 0.9, 0.9],
  [7, 0, 79.5, 0.0, -0.0, 0.0],
  [7, 1, -77.0, -48.9, -0.1, 0.6],
  [7, 2, -8.8, -14.4, -0.1, 0.5],
  [7, 3, 59.3, -1.0, 0.5, -0.8],
  [7, 4, 15.8, 23.4, -0.1, 0.0],
  [7, 5, 2.5, -7.4, -0.8, -1.0],
  [7, 6, -11.1, -25.1, -0.8, 0.6],
  [7, 7, 14.2, -2.3, 0.8, -0.2],
  [8, 0, 23.2, 0.0, -0.1, 0.0],
  [8, 1, 10.8, 7.1, 0.2, -0.2],
  [8, 2, -17.5, -12.6, 0.0, 0.5],
  [8, 3, 2.0, 11.4, 0.5, -0.4],
  [8, 4, -21.7, -9.7, -0.1, 0.4],
  [8, 5, 16.9, 12.7, 0.3, -0.5],
  [8, 6, 15.0, 0.7, 0.2, -0.6],
  [8, 7, -16.8, -5.2, -0.0, 0.3],
  [8, 8, 0.9, 3.9, 0.2, 0.2],
  [9, 0, 4.6, 0.0, -0.0, 0.0],
  [9, 1, 7.8, -24.8, -0.1, -0.3],
  [9, 2, 3.0, 12.2, 0.1, 0.3],
  [9, 3, -0.2, 8.3, 0.3, -0.3],
  [9, 4, -2.5, -3.3, -0.3, 0.3],
  [9, 5, -13.1, -5.2, 0.0, 0.2],
  [9, 6, 2.4, 7.2, 0.3, -0.1],
  [9, 7, 8.6, -0.6, -0.1, -0.2],
  [9, 8, -8.7, 0.8, 0.1, 0.4],
  [9, 9, -12.9, 10.0, -0.1, 0.1],
  [10, 0, -1.3, 0.0, 0.1, 0.0],
  [10, 1, -6.4, 3.3, 0.0, 0.0],
  [10, 2, 0.2, 0.0, 0.1, -0.0],
  [10, 3, 2.0, 2.4, 0.1, -0.2],
  [10, 4, -1.0, 5.3, -0.0, 0.1],
  [10, 5, -0.6, -9.1, -0.3, -0.1],
  [10, 6, -0.9, 0.4, 0.0, 0.1],
  [10, 7, 1.5, -4.2, -0.1, 0.0],
  [10, 8, 0.9, -3.8, -0.1, -0.1],
  [10, 9, -2.7, 0.9, -0.0, 0.2],
  [10, 10, -3.9, -9.1, -0.0, -0.0],
  [11, 0, 2.9, 0.0, 0.0, 0.0],
  [11, 1, -1.5, 0.0, -0.0, -0.0],
  [11, 2, -2.5, 2.9, 0.0, 0.1],
  [11, 3, 2.4, -0.6, 0.0, -0.0],
  [11, 4, -0.6, 0.2, 0.0, 0.1],
  [11, 5, -0.1, 0.5, -0.1, -0.0],
  [11, 6, -0.6, -0.3, 0.0, -0.0],
  [11, 7, -0.1, -1.2, -0.0, 0.1],
  [11, 8, 1.1, -1.7, -0.1, -0.0],
  [11, 9, -1.0, -2.9, -0.1, 0.0],
  [11, 10, -0.2, -1.8, -0.1, 0.0],
  [11, 11, 2.6, -2.3, -0.1, 0.0],
  [12, 0, -2.0, 0.0, 0.0, 0.0],
  [12, 1, -0.2, -1.3, 0.0, -0.0],
  [12, 2, 0.3, 0.7, -0.0, 0.0],
  [12, 3, 1.2, 1.0, -0.0, -0.1],
  [12, 4, -1.3, -1.4, -0.0, 0.1],
  [12, 5, 0.6, -0.0, -0.0, -0.0],
  [12, 6, 0.6, 0.6, 0.1, -0.0],
  [12, 7, 0.5, -0.1, -0.0, -0.0],
  [12, 8, -0.1, 0.8, 0.0, 0.0],
  [12, 9, -0.4, 0.1, 0.0, -0.0],
  [12, 10, -0.2, -1.0, -0.1, -0.0],
  [12, 11, -1.3, 0.1, -0.0, 0.0],
  [12, 12, -0.7, 0.2, -0.1, -0.1],
]

const MAX_DEGREE = WMM_MODEL_INFO.degree
/** Geomagnetic reference radius (km), as defined with the model. */
const GEOMAGNETIC_REFERENCE_RADIUS_KM = 6371.2
/** WGS84 ellipsoid parameters. */
const WGS84_A_KM = 6378.137
const WGS84_F = 1 / 298.257223563
const WGS84_B_KM = WGS84_A_KM * (1 - WGS84_F)
const WGS84_E2 = (WGS84_A_KM * WGS84_A_KM - WGS84_B_KM * WGS84_B_KM) / (WGS84_A_KM * WGS84_A_KM)

/** g[n][m] and h[n][m] at the requested decimal year (nT). */
interface CoefficientArrays {
  g: number[][]
  h: number[][]
}

/** Parse the coefficient table once into triangular arrays. */
function buildBaseCoefficients(): { base: CoefficientArrays; secular: CoefficientArrays } {
  const mk = (): CoefficientArrays => {
    const g: number[][] = []
    const h: number[][] = []
    for (let n = 0; n <= MAX_DEGREE; n++) {
      g.push(new Array(n + 1).fill(0))
      h.push(new Array(n + 1).fill(0))
    }
    return { g, h }
  }
  const base = mk()
  const secular = mk()
  for (const [n, m, g, h, gdot, hdot] of WMM2025_COEFFICIENTS) {
    base.g[n][m] = g
    base.h[n][m] = h
    secular.g[n][m] = gdot
    secular.h[n][m] = hdot
  }
  return { base, secular }
}

const { base: BASE_COEFFICIENTS, secular: SECULAR_COEFFICIENTS } = buildBaseCoefficients()

/** Year interpolation of the Gauss coefficients. */
function coefficientsAt(decimalYear: number): CoefficientArrays {
  const dt = decimalYear - WMM_MODEL_INFO.epoch
  const out: CoefficientArrays = { g: [], h: [] }
  for (let n = 0; n <= MAX_DEGREE; n++) {
    const gRow = new Array(n + 1)
    const hRow = new Array(n + 1)
    for (let m = 0; m <= n; m++) {
      gRow[m] = BASE_COEFFICIENTS.g[n][m] + dt * SECULAR_COEFFICIENTS.g[n][m]
      hRow[m] = BASE_COEFFICIENTS.h[n][m] + dt * SECULAR_COEFFICIENTS.h[n][m]
    }
    out.g.push(gRow)
    out.h.push(hRow)
  }
  return out
}

/** Field components in the geodetic frame (nT). */
export interface GeomagneticField {
  /** North component X (nT). */
  x: number
  /** East component Y (nT). */
  y: number
  /** Down component Z (nT). */
  z: number
  /** Horizontal intensity H (nT). */
  horizontalIntensity: number
  /** Total intensity F (nT). */
  totalIntensity: number
  /** Declination D (degrees, positive east of true north). */
  declination: number
  /** Inclination I (degrees, positive down). */
  inclination: number
}

/** Result of a declination lookup, with honest validity information. */
export interface DeclinationResult {
  /** Declination in degrees (positive east). */
  declination: number
  /** Which model produced the value. */
  model: string
  /** True when the requested date is outside the model's validity window. */
  outsideValidityPeriod: boolean
}

/** Convert a Date to a decimal year (UTC). */
export function dateToDecimalYear(date: Date): number {
  const year = date.getUTCFullYear()
  const startOfYear = Date.UTC(year, 0, 1)
  const startOfNextYear = Date.UTC(year + 1, 0, 1)
  return year + (date.getTime() - startOfYear) / (startOfNextYear - startOfYear)
}

/**
 * Compute the full geomagnetic field for a geodetic position.
 *
 * @param latitude  geodetic latitude in degrees (-90..90)
 * @param longitude geodetic longitude in degrees (-180..180)
 * @param altitudeKm height above the WGS84 ellipsoid in km
 * @param decimalYear decimal year (e.g. 2026.37)
 */
export function computeGeomagneticField(
  latitude: number,
  longitude: number,
  altitudeKm: number,
  decimalYear: number,
): GeomagneticField {
  const phi = (latitude * Math.PI) / 180
  const lambda = (longitude * Math.PI) / 180
  const sinPhi = Math.sin(phi)
  const cosPhi = Math.cos(phi)

  /* ---- 1. Geodetic -> geocentric spherical (via ECEF) ---- */
  const n = WGS84_A_KM / Math.sqrt(1 - WGS84_E2 * sinPhi * sinPhi)
  const xEcef = (n + altitudeKm) * cosPhi * Math.cos(lambda)
  const yEcef = (n + altitudeKm) * cosPhi * Math.sin(lambda)
  const zEcef = (n * (1 - WGS84_E2) + altitudeKm) * sinPhi
  const r = Math.sqrt(xEcef * xEcef + yEcef * yEcef + zEcef * zEcef)
  const phiPrime = Math.asin(zEcef / r) // geocentric latitude

  const sinPhiPrime = Math.sin(phiPrime)
  const cosPhiPrime = Math.cos(phiPrime)
  // Colatitude theta = 90° - phi': sin(theta) = cos(phi'), cos(theta) = sin(phi').
  const sinTheta = cosPhiPrime
  const cosTheta = sinPhiPrime

  /* ---- 2. Schmidt semi-normalized Legendre functions ----
   * P[m][n] and their derivatives with respect to theta.
   */
  const p: number[][] = []
  const dp: number[][] = []
  for (let k = 0; k <= MAX_DEGREE; k++) {
    p.push(new Array(k + 1).fill(0))
    dp.push(new Array(k + 1).fill(0))
  }
  p[0][0] = 1
  dp[0][0] = 0

  // Recurrences (Schmidt semi-normalized, positive diagonal - the WMM
  // convention). The diagonal carries the sqrt(2) that distinguishes the
  // Schmidt m>=1 normalization (S(n,m) = sqrt(2 (n-m)!/(n+m)!) P(n,m))
  // from the reduced form; it propagates uniformly down each column.
  for (let nn = 1; nn <= MAX_DEGREE; nn++) {
    for (let mm = 0; mm <= nn; mm++) {
      if (nn === mm) {
        // Zonal-to-sectoral diagonal term. Schmidt semi-normalization:
        // S(1,1) = sinθ exactly, and sqrt((2n-1)/(2n)) for n >= 2.
        // (The sqrt(2) of the Schmidt m>=1 convention is fully absorbed in
        // the n=1 seed and then propagates down each column.)
        const factor = nn === 1 ? 1 : Math.sqrt((2 * nn - 1) / (2 * nn))
        p[nn][mm] = factor * sinTheta * p[nn - 1][mm - 1]
        dp[nn][mm] =
          factor * (sinTheta * dp[nn - 1][mm - 1] + cosTheta * p[nn - 1][mm - 1])
      } else {
        const knm = Math.sqrt(nn * nn - mm * mm)
        // For n = m + 1 the P(n-2, m) term is absent (its coefficient is 0).
        const knm1 = nn - 1 > mm ? Math.sqrt((nn - 1) * (nn - 1) - mm * mm) : 0
        const pPrev = nn - 2 >= mm ? p[nn - 2][mm] : 0
        const dpPrev = nn - 2 >= mm ? dp[nn - 2][mm] : 0
        p[nn][mm] =
          ((2 * nn - 1) * cosTheta * p[nn - 1][mm] - knm1 * pPrev) / knm
        dp[nn][mm] =
          ((2 * nn - 1) * (cosTheta * dp[nn - 1][mm] - sinTheta * p[nn - 1][mm]) -
            knm1 * dpPrev) / knm
      }
    }
  }

  /* ---- 3. Spherical harmonic summation ---- */
  const coeffs = coefficientsAt(decimalYear)
  const ratio = GEOMAGNETIC_REFERENCE_RADIUS_KM / r
  let ratioPow = ratio * ratio // (a/r)^(n+2), starting at n=1

  // Precompute trigonometry of longitude.
  const cosLambda: number[] = [1]
  const sinLambda: number[] = [0]
  for (let mm = 1; mm <= MAX_DEGREE; mm++) {
    cosLambda.push(Math.cos(mm * lambda))
    sinLambda.push(Math.sin(mm * lambda))
  }

  // Geocentric components: x' north, y' east, z' down (nT).
  // Derived from the potential V = a·Σ(a/r)^{n+1}(g cos mλ + h sin mλ)P̃:
  //   X' = +(1/r)∂V/∂θ, Y' = +(1/(r sinθ))∂V/∂λ, Z' = +∂V/∂r (down = -r̂).
  let xPrime = 0
  let yPrime = 0
  let zPrime = 0
  for (let nn = 1; nn <= MAX_DEGREE; nn++) {
    ratioPow *= ratio
    for (let mm = 0; mm <= nn; mm++) {
      const gc = coeffs.g[nn][mm]
      const hc = coeffs.h[nn][mm]
      const cosML = cosLambda[mm]
      const sinML = sinLambda[mm]
      const pnm = p[nn][mm]
      const dpnm = dp[nn][mm]

      // Common combination and its λ-derivative pair.
      const gcCos = gc * cosML + hc * sinML
      const gSinMinusHCos = gc * sinML - hc * cosML

      // X' = +(1/r) dV/dtheta; Y' = +(1/(r sinθ)) dV/dlambda;
      // Z' = +dV/dr (positive down). All per the WMM report with the
      // derivative in X taken with respect to (co)latitude.
      xPrime += ratioPow * gcCos * dpnm
      if (sinTheta !== 0) {
        yPrime += (ratioPow * mm * gSinMinusHCos * pnm) / sinTheta
      }
      zPrime -= (nn + 1) * ratioPow * gcCos * pnm
    }
  }

  /* ---- 4. Rotate from geocentric to geodetic frame ---- */
  // psi: angle between the geodetic normal and the geocentric radial
  // direction (positive when the geodetic latitude exceeds the geocentric one).
  const psi = phi - phiPrime
  const sinPsi = Math.sin(psi)
  const cosPsi = Math.cos(psi)
  const x = xPrime * cosPsi + zPrime * sinPsi
  const y = yPrime
  const z = zPrime * cosPsi - xPrime * sinPsi

  const hIntensity = Math.sqrt(x * x + y * y)
  const declination = (Math.atan2(y, x) * 180) / Math.PI
  const inclination = (Math.atan2(z, hIntensity) * 180) / Math.PI
  const totalIntensity = Math.sqrt(x * x + y * y + z * z)

  return {
    x,
    y,
    z,
    horizontalIntensity: hIntensity,
    totalIntensity: totalIntensity,
    declination,
    inclination,
  }
}

/**
 * Magnetic declination for a location and date, with validity information.
 * Accepts any date; `outsideValidityPeriod` flags extrapolation honestly
 * (the WMM2025 validity window is 2025.0 - 2030.0).
 */
export function magneticDeclination(
  latitude: number,
  longitude: number,
  altitudeKm: number,
  date: Date,
): DeclinationResult {
  const decimalYear = dateToDecimalYear(date)
  const field = computeGeomagneticField(latitude, longitude, altitudeKm, decimalYear)
  return {
    declination: field.declination,
    model: WMM_MODEL_INFO.name,
    outsideValidityPeriod:
      decimalYear < WMM_MODEL_INFO.validFrom || decimalYear >= WMM_MODEL_INFO.validTo,
  }
}
