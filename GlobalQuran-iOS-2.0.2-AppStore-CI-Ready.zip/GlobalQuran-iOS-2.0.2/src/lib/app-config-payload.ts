/**
 * Global Quran - /api/config payload (shared by the web route and the
 * native adapter).
 *
 * Extracted verbatim from the route so the web app and the native app
 * report byte-identical configuration and integration status. No
 * platform-specific code lives here.
 */

import { FALLBACK_LOCALE, SUPPORTED_LOCALES } from '@/i18n/config'
import { APP_VERSION } from '@/lib/app-info'

export interface AppConfigPayload {
  appVersion: string
  fallbackLocale: string
  supportedLanguages: Array<{
    code: string
    englishName: string
    nativeName: string
    direction: string
  }>
  integrations: {
    quranText: { status: string; source: string; note: string }
    translationsCatalog: { status: string; source: string; note: string }
    prayerTimes: { status: string; source: string; note: string }
    qibla: { status: string; source: string; note: string }
    offlineDownloads: { status: string; source: string; note: string }
  }
}

export function buildAppConfigPayload(): AppConfigPayload {
  return {
    appVersion: APP_VERSION,
    fallbackLocale: FALLBACK_LOCALE,
    supportedLanguages: SUPPORTED_LOCALES.map((locale) => ({
      code: locale.code,
      englishName: locale.englishName,
      nativeName: locale.nativeName,
      direction: locale.direction,
    })),
    integrations: {
      quranText: {
        status: 'live',
        source:
          'QuranEnc API v1 - /translation/sura (Uthmanic Hafs Arabic text from the official Hafs v20 package)',
        note: 'The complete Quran text with translations is served sura by sura from the documented QuranEnc endpoints.',
      },
      translationsCatalog: {
        status: 'live',
        source: 'QuranEnc API v1 (https://quranenc.com/api/v1/)',
        note: 'The catalog is synchronized live from QuranEnc with honest metadata: translator and publisher are only shown when the source documents them.',
      },
      prayerTimes: {
        status: 'live',
        source:
          'Hybrid: JAKIM e-Solat official endpoint (Malaysia, verified live) → AlAdhan API (documented country methods) → validated local astronomical engine (adhan, MIT)',
        note: 'Every result names its source, method and settings. One official authority is integrated (JAKIM, Malaysia); other countries use the AlAdhan method that implements their national standard, with no approval implied.',
      },
      qibla: {
        status: 'partial',
        source: 'Device geolocation + orientation sensors',
        note: 'Bearing and distance math is implemented; the live compass activates on sensor-capable devices only.',
      },
      offlineDownloads: {
        status: 'live',
        source:
          'QuranEnc file downloads (SQLite/PDF/EPUB) stored in IndexedDB with locally computed SHA-256 fingerprints',
        note: 'Files are downloaded directly from the source URLs the catalog publishes and stay on the device. The SHA-256 is computed locally at download time (the source publishes no digests) so any later corruption or truncation is detectable.',
      },
    },
  }
}
