'use client'

/**
 * Profile avatar picker.
 *
 * - Shows the user's custom photo (device-only data URL) or one of the
 *   built-in artwork options; the default is the Quran Mushaf illustration.
 * - Uploads are validated client-side (image type + 2 MB cap) and stored
 *   in the local preferences store - nothing is ever uploaded.
 * - The remove action restores the built-in artwork (never a blank avatar).
 */

import { useRef, useState, type ChangeEvent } from 'react'
import Image from 'next/image'
import { toast } from 'sonner'
import { Camera, Check, Trash2 } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { BUILTIN_AVATARS, usePreferencesStore } from '@/stores/preferences-store'

import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

/** Accepted upload types (sniffed from the file, not the name). */
const ACCEPTED_TYPES = ['image/png', 'image/jpeg', 'image/webp']
/** Maximum upload size (2 MB). */
const MAX_UPLOAD_BYTES = 2 * 1024 * 1024

/** Alt text per built-in avatar id. */
const BUILTIN_ALT_KEYS: Record<string, 'profile.defaultAvatarAlt' | 'profile.geometricAvatarAlt' | 'profile.domeAvatarAlt'> = {
  mushaf: 'profile.defaultAvatarAlt',
  geometric: 'profile.geometricAvatarAlt',
  dome: 'profile.domeAvatarAlt',
}

export function ProfileAvatar({ size = 'lg' }: { size?: 'lg' | 'header' }) {
  const { t } = useTranslation()
  const profile = usePreferencesStore((s) => s.profile)
  const updateProfile = usePreferencesStore((s) => s.updateProfile)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [isReading, setIsReading] = useState(false)

  const builtin = BUILTIN_AVATARS.find((entry) => entry.id === profile.builtinAvatarId)
  const builtinSrc = builtin?.src ?? BUILTIN_AVATARS[0].src
  const hasCustom = profile.avatarKind === 'custom' && Boolean(profile.customAvatar)

  const handlePick = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error(t('profile.photoNotAnImage'))
      event.target.value = ''
      return
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      toast.error(t('profile.photoTooLarge'))
      event.target.value = ''
      return
    }

    setIsReading(true)
    const reader = new FileReader()
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : null
      if (result && result.startsWith('data:image/')) {
        updateProfile({ avatarKind: 'custom', customAvatar: result })
        toast.success(t('profile.photoUpdated'))
      } else {
        toast.error(t('profile.photoNotAnImage'))
      }
      setIsReading(false)
    }
    reader.onerror = () => {
      toast.error(t('profile.photoNotAnImage'))
      setIsReading(false)
    }
    reader.readAsDataURL(file)
    event.target.value = ''
  }

  const handleRemoveCustom = () => {
    updateProfile({ avatarKind: 'builtin', customAvatar: null })
    toast(t('profile.photoRemoved'))
  }

  const dimension = size === 'lg' ? 'size-28' : 'size-16'

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
      <div className="relative shrink-0">
        <span
          className={cn(
            'relative block overflow-hidden rounded-full border-2 border-primary/25 bg-primary/10 shadow-sm',
            dimension,
          )}
        >
          {hasCustom && profile.customAvatar ? (
            // Data-URL image chosen by the user - stays on this device.
            <img
              src={profile.customAvatar}
              alt={t('profile.avatarAlt')}
              className="size-full object-cover"
            />
          ) : (
            <Image
              src={builtinSrc}
              alt={t(BUILTIN_ALT_KEYS[profile.builtinAvatarId] ?? 'profile.defaultAvatarAlt')}
              fill
              sizes={size === 'lg' ? '112px' : '64px'}
              className="object-cover"
              priority={size === 'lg'}
            />
          )}
        </span>
        <Button
          type="button"
          variant="secondary"
          size="icon"
          className="absolute -bottom-1 -end-1 size-9 rounded-full border border-border shadow-sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={isReading}
          aria-label={t('profile.changePhoto')}
          title={t('profile.changePhoto')}
        >
          <Camera aria-hidden="true" className="size-4" />
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPTED_TYPES.join(',')}
          onChange={handlePick}
          className="hidden"
        />
      </div>

      <div className="min-w-0 flex-1 space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-9"
            onClick={() => fileInputRef.current?.click()}
            disabled={isReading}
          >
            <Camera aria-hidden="true" className="size-3.5" />
            {hasCustom ? t('profile.changePhoto') : t('profile.uploadPhoto')}
          </Button>
          {hasCustom ? (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-9 text-destructive hover:text-destructive"
              onClick={handleRemoveCustom}
            >
              <Trash2 aria-hidden="true" className="size-3.5" />
              {t('profile.removePhoto')}
            </Button>
          ) : null}
        </div>

        {/* Built-in artwork picker */}
        <div>
          <p className="text-xs font-medium text-muted-foreground">{t('profile.builtinAvatars')}</p>
          <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label={t('profile.builtinAvatars')}>
            {BUILTIN_AVATARS.map((avatar) => {
              const selected =
                profile.avatarKind === 'builtin' && profile.builtinAvatarId === avatar.id
              return (
                <button
                  key={avatar.id}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => updateProfile({ avatarKind: 'builtin', builtinAvatarId: avatar.id })}
                  className={cn(
                    'relative size-12 overflow-hidden rounded-full border-2 outline-none transition-transform',
                    'focus-visible:ring-[3px] focus-visible:ring-ring/50',
                    selected
                      ? 'border-primary ring-2 ring-primary/30'
                      : 'border-border hover:scale-105',
                  )}
                  aria-label={t(BUILTIN_ALT_KEYS[avatar.id] ?? 'profile.defaultAvatarAlt')}
                >
                  <Image
                    src={avatar.src}
                    alt=""
                    fill
                    sizes="48px"
                    className="object-cover"
                  />
                  {selected ? (
                    <span className="absolute inset-0 flex items-center justify-center bg-primary/40 text-primary-foreground">
                      <Check aria-hidden="true" className="size-4" />
                    </span>
                  ) : null}
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
