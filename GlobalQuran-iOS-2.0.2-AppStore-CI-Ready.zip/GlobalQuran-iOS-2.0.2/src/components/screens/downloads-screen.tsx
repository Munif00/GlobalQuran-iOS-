'use client'

/**
 * Downloads screen - the offline library.
 *
 * Composition of the offline-library building blocks:
 * - Online/offline indicator (offline still means full access to downloads).
 * - ActiveDownloads: live jobs from the download-manager engine.
 * - The stored-files library: search, format and language filters, sorting,
 *   and per-file version updates joined against the live QuranEnc catalog
 *   (no comparison is guessed while the catalog is unavailable).
 * - ImportCard: local import with full validation.
 * - StorageManagement: quota, persistence, per-format breakdown, largest
 *   files and delete-all.
 *
 * All data comes from the real IndexedDB store; lists and quota refresh on
 * mount, every 30 seconds, and whenever a download finishes.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ArrowDownToLine, FolderOpen, Search, Wifi, WifiOff } from 'lucide-react'
import { toast } from 'sonner'

import { useTranslation } from '@/i18n'
import { getTranslationsCatalog } from '@/services/api/catalog-api'
import { describeApiError } from '@/services/api/errors'
import { enqueueDownload } from '@/services/downloads/download-manager'
import { warmViewerChunks } from '@/services/downloads/viewer-warming'
import {
  getFileStorage,
  getStorageEstimate,
  type StoredFileMetadata,
} from '@/services/storage/local-file-storage'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { useViewerStore } from '@/stores/viewer-store'
import { useNavigationStore } from '@/stores/navigation-store'
import { useReaderStore } from '@/stores/reader-store'
import { useOnlineStatus } from '@/hooks/use-online-status'
import type { DownloadFormat, StorageEstimateInfo, Translation, TranslationFile } from '@/types'
import { formatBytes, formatNumber } from '@/utils/format'
import { normalizeForSearch } from '@/utils/text-normalize'

import { PageContainer } from '@/components/design-system/page-container'
import { ScreenHeader } from '@/components/design-system/screen-header'
import { StatusBanner } from '@/components/design-system/status-banner'
import { EmptyState } from '@/components/design-system/empty-state'
import { ActiveDownloads } from '@/components/downloads/active-downloads'
import { AudioOfflineSection } from '@/components/downloads/audio-offline-section'
import { TranslationAudioSection } from '@/components/downloads/translation-audio-section'
import { ImportCard } from '@/components/downloads/import-card'
import { LibraryFileCard } from '@/components/downloads/library-file-card'
import { OfflinePacksSection } from '@/components/downloads/offline-packs-section'
import { StorageManagement } from '@/components/downloads/storage-management'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

/** Format filter values (stored files may also be validated zip archives). */
type LibraryFormatFilter = DownloadFormat | 'zip' | 'all'

/** Origin filter values for the stored-files list. */
type LibraryOriginFilter = 'all' | 'downloaded' | 'imported'

/** Library sort options. */
type LibrarySort = 'recent' | 'name'

export function DownloadsScreen() {
  const { t, locale } = useTranslation()
  const { isOnline } = useOnlineStatus()
  const openViewer = useViewerStore((s) => s.open)
  const activeIds = useDownloadManagerStore((s) => s.activeIds)

  /** null = still loading from IndexedDB; [] = loaded and empty. */
  const [files, setFiles] = useState<StoredFileMetadata[] | null>(null)
  const [loadFailed, setLoadFailed] = useState(false)
  const [estimate, setEstimate] = useState<StorageEstimateInfo | null>(null)
  const [deletingFileId, setDeletingFileId] = useState<string | null>(null)

  // Library toolbar state.
  const [searchQuery, setSearchQuery] = useState('')
  const [formatFilter, setFormatFilter] = useState<LibraryFormatFilter>('all')
  const [languageFilter, setLanguageFilter] = useState('all')
  const [originFilter, setOriginFilter] = useState<LibraryOriginFilter>('all')
  const [sortBy, setSortBy] = useState<LibrarySort>('recent')
  const navigate = useNavigationStore((s) => s.navigate)
  const closeReader = useReaderStore((s) => s.closeReader)

  // The catalog is fetched per interface locale so version joins use the
  // same records the Quran library shows.
  const catalogQuery = useQuery({
    queryKey: ['translations-catalog', locale],
    queryFn: () => getTranslationsCatalog(locale),
    staleTime: 300_000,
    retry: 1,
  })

  /**
   * Read the file list from IndexedDB. All state updates happen after the
   * await (async continuation), never synchronously inside the effect.
   */
  const loadFiles = useCallback(async () => {
    try {
      setFiles(await getFileStorage().listFiles())
      setLoadFailed(false)
    } catch {
      // Keep any previously loaded list; only fall back to empty on first load.
      setFiles((previous) => previous ?? [])
      setLoadFailed(true)
    }
  }, [])

  const loadEstimate = useCallback(async () => {
    try {
      setEstimate(await getStorageEstimate())
    } catch {
      // Estimates are informational - keep whatever was loaded before.
    }
  }, [])

  const refreshAll = useCallback(async () => {
    await Promise.all([loadFiles(), loadEstimate()])
  }, [loadFiles, loadEstimate])

  // Initial load.
  useEffect(() => {
    void loadFiles()
    void loadEstimate()
  }, [loadFiles, loadEstimate])

  // Periodic quota refresh (browser quota changes outside the app too).
  useEffect(() => {
    const interval = window.setInterval(() => {
      void loadEstimate()
    }, 30_000)
    return () => window.clearInterval(interval)
  }, [loadEstimate])

  // When a download finishes (activeIds shrinks) the library and the quota
  // need to reflect the newly stored file.
  useEffect(() => {
    void loadFiles()
    void loadEstimate()
  }, [activeIds.length, loadFiles, loadEstimate])

  // Warm the viewer library chunks for the formats actually present in the
  // offline library while online, so files can be opened later with no
  // connection (the viewers lazy-load pdfjs/epubjs/sql.js on first use).
  const viewableFormatsPresent = useMemo(
    () =>
      new Set(
        (files ?? [])
          .map((file) => file.format)
          .filter((format) => format === 'pdf' || format === 'epub' || format === 'sql'),
      ),
    [files],
  )
  useEffect(() => {
    if (isOnline && viewableFormatsPresent.size > 0) {
      void warmViewerChunks(viewableFormatsPresent)
    }
  }, [isOnline, viewableFormatsPresent])

  const catalogItems = catalogQuery.data?.items ?? null
  const catalogReady = catalogItems !== null

  /** Catalog translations keyed by their stable source key. */
  const catalogByKey = useMemo(() => {
    if (catalogItems === null) return null
    const map = new Map<string, Translation>()
    for (const item of catalogItems) map.set(item.key, item)
    return map
  }, [catalogItems])

  /**
   * Join each stored file with the catalog: the matched translation drives
   * the language label (native name first). Files without a catalog match
   * are grouped under their translation key, imports under their file name -
   * no language is ever guessed.
   */
  const libraryRows = useMemo(() => {
    if (files === null) return []
    return files.map((file) => {
      const catalogItem =
        file.translationId !== null && catalogByKey !== null
          ? catalogByKey.get(file.translationId) ?? null
          : null
      const languageLabel = catalogItem
        ? catalogItem.languageNativeName ?? catalogItem.languageName
        : (file.translationId ?? file.fileName)
      return { file, catalogItem, languageLabel }
    })
  }, [files, catalogByKey])

  /** Formats actually present in the library. */
  const formatOptions = useMemo(() => {
    if (files === null) return []
    return [...new Set(files.map((file) => file.format))].sort()
  }, [files])

  /** Language (or identity) labels present in the library. */
  const languageOptions = useMemo(() => {
    const labels = new Set<string>()
    for (const row of libraryRows) labels.add(row.languageLabel)
    return [...labels].sort((a, b) => a.localeCompare(b))
  }, [libraryRows])

  /** Filter (search + format + language + origin) and sort the stored files. */
  const visibleRows = useMemo(() => {
    const normalizedQuery = normalizeForSearch(searchQuery)
    const filtered = libraryRows.filter(({ file, languageLabel }) => {
      const matchesQuery =
        normalizedQuery.length === 0 ||
        [file.fileName, file.translationId ?? '', languageLabel].some((field) =>
          normalizeForSearch(field).includes(normalizedQuery),
        )
      const matchesFormat = formatFilter === 'all' || file.format === formatFilter
      const matchesLanguage = languageFilter === 'all' || languageLabel === languageFilter
      const matchesOrigin = originFilter === 'all' || file.origin === originFilter
      return matchesQuery && matchesFormat && matchesLanguage && matchesOrigin
    })
    const sorted = [...filtered]
    if (sortBy === 'name') {
      sorted.sort((a, b) => a.file.fileName.localeCompare(b.file.fileName))
    }
    // 'recent': listFiles already returns newest first - keep that order.
    return sorted
  }, [libraryRows, searchQuery, formatFilter, languageFilter, originFilter, sortBy])

  const totalBytes =
    files === null ? 0 : files.reduce((sum, file) => sum + file.fileSize, 0)

  /** Delete one stored file (with confirmation handled by the card). */
  const handleDeleteFile = useCallback(
    async (fileId: string) => {
      setDeletingFileId(fileId)
      try {
        await getFileStorage().deleteFile(fileId)
        await refreshAll()
        /* PROMPT 14 (Nielsen #1): "Updated" after a deletion was meaningless -
            the message now states what actually happened. */
        toast(t('downloads.fileDeleted'))
      } catch (error) {
        toast.error(t('common.error'), { description: describeApiError(error, t) })
      } finally {
        setDeletingFileId(null)
      }
    },
    [refreshAll, t],
  )

  /**
   * Update one stored copy to the catalog's current version. The engine
   * downloads the new file first and only removes the old copy after the
   * new one validates.
   */
  const handleUpdateFile = useCallback(
    async (file: StoredFileMetadata, catalogItem: Translation, catalogFile: TranslationFile) => {
      try {
        const result = await enqueueDownload(catalogItem, catalogFile, {
          replaceStoredFileId: file.id,
        })
        if (result.ok) return
        if (result.reason === 'already-downloaded') {
          toast.info(t('downloads.alreadyDownloadedTitle'), {
            description: t('downloads.alreadyDownloadedDescription'),
          })
          return
        }
        if (result.reason === 'duplicate-active') {
          toast.info(t('downloads.duplicateActiveTitle'), {
            description: t('downloads.duplicateActiveDescription'),
          })
          return
        }
        toast.error(t('common.error'), { description: t('common.errorDescription') })
      } catch (error) {
        toast.error(t('common.error'), { description: describeApiError(error, t) })
      }
    },
    [t],
  )

  return (
    <PageContainer wide>
      <ScreenHeader
        title={t('downloads.title')}
        subtitle={t('downloads.subtitle')}
        icon={ArrowDownToLine}
      />

      <div className="space-y-6">
        {/* Online / offline indicator (offline still works for downloads) */}
        <Card>
          <CardContent role="status" className="flex flex-wrap items-center gap-x-3 gap-y-2 p-3.5">
            <Badge
              variant="outline"
              className={
                isOnline
                  ? 'border-success/40 bg-success/10 text-success'
                  : 'border-warning/40 bg-warning/10 text-warning-foreground'
              }
            >
              {isOnline ? (
                <Wifi aria-hidden="true" className="size-3" />
              ) : (
                <WifiOff aria-hidden="true" className="size-3" />
              )}
              {isOnline ? t('downloads.onlineIndicator') : t('downloads.offlineIndicator')}
            </Badge>
            {!isOnline ? (
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('downloads.offlineNote')}
              </p>
            ) : null}
          </CardContent>
        </Card>

        {/* Live download jobs */}
        <ActiveDownloads />

        {/* Recitation audio stored for offline playback */}
        <AudioOfflineSection />

        {/* Translation narration audio stored for offline playback (PROMPT 10) */}
        <TranslationAudioSection />

        {/* Translations stored for offline reading (in-app packs) */}
        <OfflinePacksSection />

        {/* Stored files library */}
        <section aria-labelledby="downloads-library-heading" className="space-y-3">
          <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
            <h2
              id="downloads-library-heading"
              className="text-sm font-semibold uppercase tracking-wide text-muted-foreground"
            >
              {t('downloads.downloadsSection')}
            </h2>
            {files !== null ? (
              <p className="text-xs tabular-nums text-muted-foreground">
                {t('downloads.itemsCount', { count: formatNumber(locale, files.length) })} ·{' '}
                {formatBytes(locale, totalBytes)}
              </p>
            ) : null}
          </div>

          {files !== null && files.length > 0 ? (
            /* Toolbar stacks at every width: the search field gets a full row
               and the fixed-width selects wrap below it. A single lg row would
               always crush the search (the shell caps the main column below
               search + 740px of selects), hiding its placeholder. */
            <div className="flex min-w-0 flex-col gap-3">
              {/* Search */}
              <div className="relative w-full min-w-0">
                <Search
                  aria-hidden="true"
                  className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(event) => setSearchQuery(event.target.value)}
                  placeholder={t('downloads.searchLibrary')}
                  aria-label={t('common.search')}
                  className="h-11 w-full rounded-lg border border-input bg-background ps-9 pe-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
                />
              </div>

              {/* Filters + sort */}
              <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
                {/* Origin */}
                <div className="flex w-full min-w-0 flex-col gap-1.5 sm:w-40">
                  <span
                    id="downloads-origin-filter-label"
                    className="text-xs font-medium text-muted-foreground"
                  >
                    {t('downloads.filterOrigin')}
                  </span>
                  <Select
                    value={originFilter}
                    onValueChange={(value) => setOriginFilter(value as LibraryOriginFilter)}
                  >
                    <SelectTrigger
                      aria-labelledby="downloads-origin-filter-label"
                      className="h-11 w-full"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectItem value="all">{t('downloads.originAll')}</SelectItem>
                      <SelectItem value="downloaded">{t('downloads.originDownloaded')}</SelectItem>
                      <SelectItem value="imported">{t('downloads.originImported')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Format */}
                <div className="flex w-full min-w-0 flex-col gap-1.5 sm:w-40">
                  <span
                    id="downloads-format-filter-label"
                    className="text-xs font-medium text-muted-foreground"
                  >
                    {t('downloads.filterFormat')}
                  </span>
                  <Select
                    value={formatFilter}
                    onValueChange={(value) => setFormatFilter(value as LibraryFormatFilter)}
                  >
                    <SelectTrigger
                      aria-labelledby="downloads-format-filter-label"
                      className="h-11 w-full"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectItem value="all">{t('downloads.anyFormat')}</SelectItem>
                      {formatOptions.map((format) => (
                        <SelectItem key={format} value={format}>
                          {format.toUpperCase()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Language */}
                <div className="flex w-full min-w-0 flex-col gap-1.5 sm:w-52">
                  <span
                    id="downloads-language-filter-label"
                    className="text-xs font-medium text-muted-foreground"
                  >
                    {t('downloads.filterLanguage')}
                  </span>
                  <Select value={languageFilter} onValueChange={setLanguageFilter}>
                    <SelectTrigger
                      aria-labelledby="downloads-language-filter-label"
                      className="h-11 w-full"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      <SelectItem value="all">{t('downloads.anyLanguage')}</SelectItem>
                      {languageOptions.map((label) => (
                        <SelectItem key={label} value={label}>
                          <span dir="auto" className="truncate">
                            {label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Sort */}
                <div className="flex w-full min-w-0 flex-col gap-1.5 sm:w-44">
                  <span
                    id="downloads-sort-label"
                    className="text-xs font-medium text-muted-foreground"
                  >
                    {t('common.sort')}
                  </span>
                  <Select value={sortBy} onValueChange={(value) => setSortBy(value as LibrarySort)}>
                    <SelectTrigger aria-labelledby="downloads-sort-label" className="h-11 w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recent">{t('downloads.sortRecent')}</SelectItem>
                      <SelectItem value="name">{t('downloads.sortName')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          ) : null}

          {/* Results */}
          {files === null ? (
            <div role="status" className="space-y-3">
              <span className="sr-only">{t('common.loading')}</span>
              <Skeleton className="h-28 w-full rounded-xl" />
              <Skeleton className="h-28 w-full rounded-xl" />
            </div>
          ) : (
            <div className="space-y-3">
              {loadFailed ? (
                <StatusBanner
                  variant="error"
                  title={t('common.error')}
                  description={t('common.errorDescription')}
                  action={
                    <Button variant="outline" className="h-11" onClick={() => void loadFiles()}>
                      {t('common.retry')}
                    </Button>
                  }
                />
              ) : null}

              {files.length === 0 && !loadFailed ? (
                <div className="space-y-3">
                  <EmptyState
                    icon={FolderOpen}
                    title={t('downloads.emptyTitle')}
                    description={t('downloads.emptyDescription')}
                  />
                  {/* PROMPT 14: a dead-end empty state gains its way forward. */}
                  <div className="flex justify-center">
                    <Button
                      variant="outline"
                      className="h-11"
                      onClick={() => {
                        closeReader()
                        navigate('quran')
                      }}
                    >
                      {t('downloads.browseTranslations')}
                    </Button>
                  </div>
                </div>
              ) : files.length > 0 ? (
                visibleRows.length === 0 ? (
                  <EmptyState
                    icon={Search}
                    title={t('common.none')}
                    description={t('quran.noResultsDescription')}
                  />
                ) : (
                  /* Natural page flow: the list is part of the page scroller
                     (no nested max-height box), so nothing is clipped and no
                     second scrollbar competes with the page for horizontal
                     space. */
                  <ul className="space-y-3">
                    {visibleRows.map((row) => (
                      <LibraryFileCard
                        key={row.file.id}
                        file={row.file}
                        catalogItem={row.catalogItem}
                        catalogReady={catalogReady}
                        isDeleting={deletingFileId === row.file.id}
                        onOpen={(fileId) => openViewer(fileId)}
                        onDelete={(fileId) => void handleDeleteFile(fileId)}
                        onUpdate={(file, catalogItem, catalogFile) =>
                          void handleUpdateFile(file, catalogItem, catalogFile)
                        }
                      />
                    ))}
                  </ul>
                )
              ) : null}
            </div>
          )}
        </section>

        {/* Local import with validation */}
        <ImportCard onImported={refreshAll} />

        {/* Quota, persistence, breakdown, delete-all */}
        <StorageManagement
          files={files}
          estimate={estimate}
          deletingFileId={deletingFileId}
          onDeleteFile={(fileId) => void handleDeleteFile(fileId)}
          onRefresh={refreshAll}
        />
      </div>
    </PageContainer>
  )
}
