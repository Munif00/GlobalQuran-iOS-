'use client'

/**
 * Settings screen:
 * - Interface language: automatic (device detection) or manual, with a
 *   searchable list of all 50 supported languages, native names, and honest
 *   per-language completeness badges.
 * - Quran translation language chosen from the live QuranEnc catalog
 *   (languages that actually have translations, with real counts).
 * - Appearance: theme (light/dark/system) and text size with live preview.
 * - Prayer settings: calculation method, Asr madhhab, per-prayer adjustments.
 * - Verification management (administrator tool).
 * - Reading, integration status, about, and reset.
 */

import { useMemo, useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTheme } from 'next-themes'
import { toast } from 'sonner'
import {
  BookOpen,
  Check,
  Eye,
  Globe,
  Info,
  Minus,
  MoonStar,
  Palette,
  Plus,
  RotateCcw,
  Search,
  Settings as SettingsIcon,
  Type,
} from 'lucide-react'

import { useTranslation, getSupportedLanguagesWithCompleteness } from '@/i18n'
import type { TranslationKey } from '@/i18n/locales/en'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useReaderStore, type ReadingTheme, type TextScale } from '@/stores/reader-store'
import { useNavigationStore } from '@/stores/navigation-store'
import { useMounted } from '@/hooks/use-mounted'
import { getSuraMeta } from '@/data/sura-index'
import { getTranslationsCatalog } from '@/services/api/catalog-api'
import { LanguagePicker } from '@/components/quran/language-picker'
import type {
  CalculationMethodId,
  Madhhab,
  PrayerAdjustments,
  TextSize,
} from '@/types'
import { APP_VERSION } from '@/lib/app-info'

import { PageContainer } from '@/components/design-system/page-container'
import { ScreenHeader } from '@/components/design-system/screen-header'
import { InfoRow } from '@/components/design-system/info-row'
import { VerificationManager } from '@/components/settings/verification-manager'
import { IntegrationStatusCard } from '@/components/settings/integration-status-card'
import { CapabilityMatrixCard } from '@/components/settings/capability-matrix-card'
import { InstallCard } from '@/components/settings/install-card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

const CALCULATION_METHODS: CalculationMethodId[] = [
  'MWL',
  'ISNA',
  'EGYPT',
  'MAKKAH',
  'KARACHI',
  'TEHRAN',
  'JAFARI',
  'DUBAI',
  'KUWAIT',
  'QATAR',
  'SINGAPORE',
  'TURKEY',
  'MOONSIGHTING',
]

const ADJUSTMENT_KEYS: Array<{ field: keyof PrayerAdjustments; labelKey: TranslationKey }> = [
  { field: 'fajr', labelKey: 'prayer.fajr' },
  { field: 'sunrise', labelKey: 'prayer.sunrise' },
  { field: 'dhuhr', labelKey: 'prayer.dhuhr' },
  { field: 'asr', labelKey: 'prayer.asr' },
  { field: 'maghrib', labelKey: 'prayer.maghrib' },
  { field: 'isha', labelKey: 'prayer.isha' },
]

const TEXT_SIZES: Array<{ value: TextSize; labelKey: TranslationKey }> = [
  { value: 'sm', labelKey: 'settings.textSizeSmall' },
  { value: 'md', labelKey: 'settings.textSizeMedium' },
  { value: 'lg', labelKey: 'settings.textSizeLarge' },
  { value: 'xl', labelKey: 'settings.textSizeExtraLarge' },
]

const TEXT_SCALES: Array<{ value: TextScale; labelKey: TranslationKey }> = [
  { value: 1, labelKey: 'settings.textScaleSmallest' },
  { value: 2, labelKey: 'settings.textScaleSmall' },
  { value: 3, labelKey: 'settings.textScaleMedium' },
  { value: 4, labelKey: 'settings.textScaleLarge' },
  { value: 5, labelKey: 'settings.textScaleLargest' },
]

const READING_THEMES: Array<{ value: ReadingTheme; labelKey: TranslationKey }> = [
  { value: 'match-app', labelKey: 'settings.readingThemeMatchApp' },
  { value: 'sepia', labelKey: 'settings.readingThemeSepia' },
  { value: 'night', labelKey: 'settings.readingThemeNight' },
]

export function SettingsScreen() {
  const { t, locale } = useTranslation()

  const languageMode = usePreferencesStore((s) => s.languageMode)
  const manualLanguage = usePreferencesStore((s) => s.manualLanguage)
  const detectedLanguage = usePreferencesStore((s) => s.detectedLanguage)
  const setManualLanguage = usePreferencesStore((s) => s.setManualLanguage)
  const setLanguageModeAuto = usePreferencesStore((s) => s.setLanguageModeAuto)
  const textSize = usePreferencesStore((s) => s.textSize)
  const setTextSize = usePreferencesStore((s) => s.setTextSize)
  const preferredQuranLanguage = usePreferencesStore((s) => s.preferredQuranTranslationLanguage)
  const setPreferredQuranLanguage = usePreferencesStore(
    (s) => s.setPreferredQuranTranslationLanguage,
  )
  const lastReadingPosition = usePreferencesStore((s) => s.lastReadingPosition)
  const clearReadingPosition = usePreferencesStore((s) => s.setLastReadingPosition)
  const prayerSettings = usePreferencesStore((s) => s.prayerSettings)
  const updatePrayerSettings = usePreferencesStore((s) => s.updatePrayerSettings)
  const resetAll = usePreferencesStore((s) => s.resetAll)

  const arabicScale = useReaderStore((s) => s.arabicScale)
  const translationScale = useReaderStore((s) => s.translationScale)
  const showTranslation = useReaderStore((s) => s.showTranslation)
  const readingTheme = useReaderStore((s) => s.readingTheme)
  const setArabicScale = useReaderStore((s) => s.setArabicScale)
  const setTranslationScale = useReaderStore((s) => s.setTranslationScale)
  const toggleTranslation = useReaderStore((s) => s.toggleTranslation)
  const setReadingTheme = useReaderStore((s) => s.setReadingTheme)
  const openReader = useReaderStore((s) => s.openReader)

  const { theme, setTheme } = useTheme()
  const navigate = useNavigationStore((s) => s.navigate)
  const settingsSection = useNavigationStore((s) => s.settingsSection)
  const clearSettingsSection = useNavigationStore((s) => s.clearSettingsSection)
  const mounted = useMounted()

  const [languageSearch, setLanguageSearch] = useState('')
  /* PROMPT 14: confirm dialog state for clearing the reading position. */
  const [clearPositionConfirmOpen, setClearPositionConfirmOpen] = useState(false)

  /* Deep-link support: scroll to the requested section card once. */
  useEffect(() => {
    if (!settingsSection) return
    const element = document.getElementById(settingsSection)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' })
      element.classList.add('ring-2', 'ring-primary/40')
      const timer = window.setTimeout(() => element.classList.remove('ring-2', 'ring-primary/40'), 2400)
      clearSettingsSection()
      return () => window.clearTimeout(timer)
    }
    clearSettingsSection()
  }, [settingsSection, clearSettingsSection])

  const languages = useMemo(() => getSupportedLanguagesWithCompleteness(), [])
  const activeLanguage = languageMode === 'manual' && manualLanguage ? manualLanguage : detectedLanguage ?? 'en'

  /* Live catalog languages (only languages that actually have translations). */
  const catalogQuery = useQuery({
    queryKey: ['translations-catalog', locale],
    queryFn: () => getTranslationsCatalog(locale),
    staleTime: 300_000,
    retry: 1,
  })
  const catalogLanguages = catalogQuery.data?.languages ?? []

  const filteredLanguages = useMemo(() => {
    const query = languageSearch.trim().toLowerCase()
    if (!query) return languages
    return languages.filter(
      (language) =>
        language.englishName.toLowerCase().includes(query) ||
        language.nativeName.toLowerCase().includes(query) ||
        language.code.toLowerCase().includes(query),
    )
  }, [languages, languageSearch])

  const handleSelectLanguage = (code: string) => {
    setManualLanguage(code)
    toast(t('settings.languageChanged'))
  }

  const handleAdjustment = (field: keyof PrayerAdjustments, delta: number) => {
    const current = prayerSettings.adjustments[field]
    const next = Math.max(-60, Math.min(60, current + delta))
    updatePrayerSettings({
      adjustments: { ...prayerSettings.adjustments, [field]: next },
    })
  }

  const handleReset = () => {
    resetAll()
    setTheme('system')
    toast(t('settings.resetDone'))
  }

  return (
    <PageContainer>
      <ScreenHeader title={t('settings.title')} subtitle={t('settings.subtitle')} icon={SettingsIcon} />

      <div className="space-y-6">
        {/* Interface language */}
        <Card id="language">
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <Globe aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('settings.interfaceLanguage')}</CardTitle>
            </div>
            <CardDescription>{t('settings.interfaceLanguageDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs
              value={languageMode}
              onValueChange={(value) => {
                if (value === 'auto') {
                  setLanguageModeAuto()
                }
              }}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm font-medium text-foreground">{t('settings.languageMode')}</p>
                <TabsList>
                  <TabsTrigger value="auto">{t('settings.languageModeAuto')}</TabsTrigger>
                  <TabsTrigger
                    value="manual"
                    onClick={() => {
                      if (languageMode !== 'manual') {
                        setManualLanguage(activeLanguage)
                      }
                    }}
                  >
                    {t('settings.languageModeManual')}
                  </TabsTrigger>
                </TabsList>
              </div>
            </Tabs>

            <p className="text-xs leading-relaxed text-muted-foreground">
              {languageMode === 'auto'
                ? t('settings.automaticLanguageNote')
                : t('settings.manualLanguageNote')}
            </p>

            {/* Search */}
            <div className="relative">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              />
              <input
                type="search"
                value={languageSearch}
                onChange={(event) => setLanguageSearch(event.target.value)}
                placeholder={t('settings.searchLanguage')}
                aria-label={t('settings.searchLanguage')}
                className="h-11 w-full rounded-lg border border-input bg-background ps-9 pe-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
              />
            </div>

            {/* Language list. PROMPT 14: real listbox semantics were an ARIA
                pattern misuse without roving focus - plain buttons with
                aria-pressed are honest and keyboard-correct. */}
            <div
              aria-label={t('settings.interfaceLanguage')}
              className="max-h-96 overflow-y-auto rounded-lg border border-border/70 scrollbar-subtle"
            >
              {filteredLanguages.length === 0 ? (
                <p className="p-4 text-center text-sm text-muted-foreground">{t('common.notAvailable')}</p>
              ) : (
                filteredLanguages.map((language) => {
                  const isActive = language.code === activeLanguage
                  return (
                    <button
                      key={language.code}
                      type="button"
                      aria-pressed={isActive}
                      onClick={() => handleSelectLanguage(language.code)}
                      className={cn(
                        'flex w-full items-center justify-between gap-3 border-b border-border/50 px-3 py-3 text-start outline-none transition-colors last:border-b-0',
                        'focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:ring-inset',
                        isActive ? 'bg-primary/[0.08]' : 'hover:bg-accent/60',
                      )}
                    >
                      <span className="flex min-w-0 items-center gap-3">
                        <span
                          className={cn(
                            'flex size-5 shrink-0 items-center justify-center rounded-full border',
                            isActive ? 'border-primary bg-primary text-primary-foreground' : 'border-border',
                          )}
                        >
                          {isActive ? <Check aria-hidden="true" className="size-3" /> : null}
                        </span>
                        <span dir="auto" className="min-w-0 truncate text-sm font-medium text-foreground">
                          {language.nativeName}
                        </span>
                        <span className="hidden truncate text-xs text-muted-foreground sm:inline">
                          {language.englishName} · {language.code}
                        </span>
                      </span>
                      <Badge
                        variant="outline"
                        className={cn(
                          'shrink-0',
                          language.completeness === 100
                            ? 'border-success/40 bg-success/10 text-success'
                            : language.completeness > 0
                              ? 'border-gold/40 bg-gold/10 text-gold-foreground'
                              : 'border-border bg-muted text-muted-foreground',
                        )}
                      >
                        {language.completeness === 100
                          ? t('settings.completenessFull')
                          : t('settings.completenessPartial', { percent: language.completeness })}
                      </Badge>
                    </button>
                  )
                })
              )}
            </div>
            <p className="text-xs text-muted-foreground">{t('settings.englishFallbackNote')}</p>
          </CardContent>
        </Card>

        {/* Quran translation language (from the live catalog) */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <BookOpen aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('settings.quranTranslationLanguage')}</CardTitle>
            </div>
            <CardDescription>{t('settings.quranTranslationLanguageDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <LanguagePicker
              languages={catalogLanguages}
              value={preferredQuranLanguage ?? 'auto'}
              onChange={(value) => setPreferredQuranLanguage(value === 'auto' ? null : value)}
              specialOptions={[
                {
                  value: 'auto',
                  label: `${t('common.automatic')} (${t('common.language')}: ${activeLanguage})`,
                },
              ]}
              ariaLabel={t('settings.quranTranslationLanguage')}
              searchPlaceholder={t('quran.searchLanguages')}
              emptyLabel={t('quran.noLanguageResults')}
              formatCount={(count) => t('quran.resultsCount', { count })}
              className="sm:max-w-sm"
            />
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('settings.quranTranslationNoteLive')}
            </p>
          </CardContent>
        </Card>

        {/* Reading preferences (reader display) */}
        <Card id="reading-preferences">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <BookOpen aria-hidden="true" className="size-5 text-primary" />
                <CardTitle className="text-base">{t('settings.readingPreferences')}</CardTitle>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="h-9"
                onClick={() => {
                  openReader()
                  navigate('quran')
                }}
              >
                {t('settings.openReader')}
              </Button>
            </div>
            <CardDescription>{t('settings.readingPreferencesDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Arabic text size */}
            <div>
              <p className="text-sm font-medium text-foreground">{t('settings.arabicTextSize')}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {TEXT_SCALES.map((scale) => (
                  <button
                    key={scale.value}
                    type="button"
                    onClick={() => setArabicScale(scale.value)}
                    aria-pressed={arabicScale === scale.value}
                    className={cn(
                      'min-h-11 rounded-lg border px-4 text-sm font-medium outline-none transition-colors',
                      'focus-visible:ring-[3px] focus-visible:ring-ring/50',
                      arabicScale === scale.value
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border bg-background text-muted-foreground hover:bg-accent/60',
                    )}
                  >
                    <span
                      dir="rtl"
                      lang="ar"
                      className="font-arabic"
                      style={{
                        fontSize: `${0.8 + (scale.value - 1) * 0.22}rem`,
                        lineHeight: 1,
                      }}
                    >
                      {t(scale.labelKey)}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Translation text size */}
            <div>
              <p className="text-sm font-medium text-foreground">{t('settings.translationTextSize')}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {TEXT_SCALES.map((scale) => (
                  <button
                    key={scale.value}
                    type="button"
                    onClick={() => setTranslationScale(scale.value)}
                    aria-pressed={translationScale === scale.value}
                    className={cn(
                      'min-h-11 rounded-lg border px-4 text-sm font-medium outline-none transition-colors',
                      'focus-visible:ring-[3px] focus-visible:ring-ring/50',
                      translationScale === scale.value
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border bg-background text-muted-foreground hover:bg-accent/60',
                    )}
                  >
                    <span
                      style={{
                        fontSize: `${0.8 + (scale.value - 1) * 0.14}rem`,
                        lineHeight: 1,
                      }}
                    >
                      {t(scale.labelKey)}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Translation visibility */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium text-foreground">{t('settings.translationVisibility')}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {t('settings.translationVisibilityDescription')}
                </p>
              </div>
              <Button
                variant={showTranslation ? 'default' : 'outline'}
                className="h-11"
                onClick={toggleTranslation}
                aria-pressed={showTranslation}
              >
                <Eye aria-hidden="true" className="size-4" />
                {showTranslation ? t('common.on') : t('common.off')}
              </Button>
            </div>

            {/* Reader theme */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">{t('settings.readingTheme')}</p>
              <Tabs
                value={readingTheme}
                onValueChange={(value) => setReadingTheme(value as ReadingTheme)}
              >
                <TabsList>
                  {READING_THEMES.map((entry) => (
                    <TabsTrigger key={entry.value} value={entry.value}>
                      {t(entry.labelKey)}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card id="appearance">
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <Palette aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('settings.appearance')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">{t('settings.theme')}</p>
              <Tabs value={mounted ? (theme ?? 'system') : 'system'} onValueChange={(value) => setTheme(value)}>
                <TabsList>
                  <TabsTrigger value="light">{t('settings.themeLight')}</TabsTrigger>
                  <TabsTrigger value="dark">{t('settings.themeDark')}</TabsTrigger>
                  <TabsTrigger value="system">{t('settings.themeSystem')}</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <Separator />

            <div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-foreground">{t('settings.textSize')}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{t('settings.textSizeDescription')}</p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {TEXT_SIZES.map((size) => (
                  <button
                    key={size.value}
                    type="button"
                    onClick={() => setTextSize(size.value)}
                    aria-pressed={textSize === size.value}
                    className={cn(
                      'min-h-11 rounded-lg border px-4 text-sm font-medium outline-none transition-colors',
                      'focus-visible:ring-[3px] focus-visible:ring-ring/50',
                      textSize === size.value
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border bg-background text-muted-foreground hover:bg-accent/60',
                    )}
                  >
                    <span className="me-2 inline-block" style={{ fontSize: size.value === 'sm' ? '0.8rem' : size.value === 'lg' ? '1.15rem' : size.value === 'xl' ? '1.3rem' : '1rem' }}>
                      <Type aria-hidden="true" className="size-3.5" />
                    </span>
                    {t(size.labelKey)}
                  </button>
                ))}
              </div>
              <div className="mt-4 rounded-lg border border-border/70 bg-muted/50 p-4">
                <p
                  className="text-center leading-relaxed text-foreground"
                  style={{ fontFamily: locale === 'ar' ? 'var(--app-font-quran)' : undefined }}
                >
                  {t('settings.textSizePreview')}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Prayer settings */}
        <Card id="prayer">
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <MoonStar aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('settings.prayerSettings')}</CardTitle>
            </div>
            <CardDescription>{t('settings.prayerSettingsDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <p className="text-sm font-medium text-foreground">{t('prayer.calculationMethod')}</p>
                <Select
                  value={prayerSettings.calculationMethod}
                  onValueChange={(value) => updatePrayerSettings({ calculationMethod: value as CalculationMethodId })}
                >
                  <SelectTrigger className="w-full" aria-label={t('prayer.calculationMethod')}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {CALCULATION_METHODS.map((method) => (
                      <SelectItem key={method} value={method}>
                        {t(`prayer.method.${method}` as TranslationKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium text-foreground">{t('prayer.madhhab')}</p>
                <Select
                  value={prayerSettings.madhhab}
                  onValueChange={(value) => updatePrayerSettings({ madhhab: value as Madhhab })}
                >
                  <SelectTrigger className="w-full" aria-label={t('prayer.madhhab')}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">{t('prayer.madhhab.standard')}</SelectItem>
                    <SelectItem value="hanafi">{t('prayer.madhhab.hanafi')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-foreground">{t('prayer.adjustments')}</p>
              <p className="mt-0.5 text-xs text-muted-foreground">{t('prayer.adjustmentsDescription')}</p>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {ADJUSTMENT_KEYS.map(({ field, labelKey }) => (
                  <div
                    key={field}
                    className="flex items-center justify-between gap-2 rounded-lg border border-border/70 px-3 py-2"
                  >
                    <span className="text-sm text-foreground">{t(labelKey)}</span>
                    <span className="flex items-center gap-1.5">
                      <Button
                        variant="outline"
                        size="icon"
                        className="size-11"
                        onClick={() => handleAdjustment(field, -1)}
                        aria-label={`${t(labelKey)} -1 ${t('prayer.minutesShort')}`}
                        disabled={prayerSettings.adjustments[field] <= -60}
                      >
                        <Minus aria-hidden="true" className="size-3.5" />
                      </Button>
                      <span className="w-12 text-center text-sm font-semibold tabular-nums text-foreground">
                        {prayerSettings.adjustments[field]}
                      </span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="size-11"
                        onClick={() => handleAdjustment(field, 1)}
                        aria-label={`${t(labelKey)} +1 ${t('prayer.minutesShort')}`}
                        disabled={prayerSettings.adjustments[field] >= 60}
                      >
                        <Plus aria-hidden="true" className="size-3.5" />
                      </Button>
                      <span className="w-6 text-xs text-muted-foreground">{t('prayer.minutesShort')}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* PROMPT 16 (WCAG 2.5.8): was h-auto p-0 (~20px text height) -
                give the link a real 24px+ tap target with inline padding. */}
            <Button
              variant="link"
              className="-my-1 h-auto py-2 text-start"
              onClick={() => navigate('prayer')}
            >
              {t('settings.openPrayerScreen')}
            </Button>
          </CardContent>
        </Card>

        {/* Reading */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <BookOpen aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('settings.reading')}</CardTitle>
            </div>
            <CardDescription>{t('settings.readingDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-muted-foreground">
              {lastReadingPosition
                ? `${t('settings.lastPosition')}: ${t('home.continueReadingPosition', {
                    sura: lastReadingPosition.surah,
                    ayah: lastReadingPosition.ayah,
                  })}`
                : t('settings.noLastPosition')}
              {lastReadingPosition ? (
                <span dir="auto" className="ms-1">
                  {' · '}{getSuraMeta(lastReadingPosition.surah)?.nameArabic}
                </span>
              ) : null}
            </p>
            {/* PROMPT 14: destructive action gated by a confirm dialog (the
                position is data the user cannot recreate from memory). */}
            <Button
              variant="outline"
              onClick={() => setClearPositionConfirmOpen(true)}
              disabled={!lastReadingPosition}
              className="h-11"
            >
              {t('settings.clearPosition')}
            </Button>
          </CardContent>
        </Card>

        {/* PROMPT 14 (Nielsen #8): administrator/advanced tooling collapsed by
            default - working features preserved, out of the everyday path. */}
        <Collapsible>
          <CollapsibleTrigger className="group flex h-11 w-full items-center justify-between gap-2 rounded-lg border border-border/70 px-3 text-start text-sm font-medium text-foreground outline-none transition-colors hover:bg-muted/40 focus-visible:ring-[3px] focus-visible:ring-ring/50">
            {t('settings.advancedTools')}
            <ChevronDown aria-hidden="true" className="size-4 shrink-0 text-muted-foreground transition-transform group-data-[state=open]:rotate-180" />
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="mt-3 space-y-4">
              {/* Verification management (administrator) */}
              <VerificationManager />
              {/* Integration status (advanced information, moved from Home) */}
              <IntegrationStatusCard />
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Languages & audio coverage (the five capability categories) */}
        <CapabilityMatrixCard />

        {/* Mobile application (install on this device) */}
        <InstallCard />

        {/* About */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <Info aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('settings.about')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <dl>
              <InfoRow label={t('settings.aboutVersion')} value={APP_VERSION} />
              <InfoRow label={t('settings.aboutSources')} value={t('settings.aboutSourcesDescription')} />
              <InfoRow label={t('settings.aboutVerification')} value={t('settings.aboutVerificationDescription')} />
            </dl>
          </CardContent>
        </Card>

        {/* Reset */}
        <Card className="border-destructive/30">
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <RotateCcw aria-hidden="true" className="size-5 text-destructive" />
              <CardTitle className="text-base">{t('settings.reset')}</CardTitle>
            </div>
            <CardDescription>{t('settings.resetDescription')}</CardDescription>
          </CardHeader>
          <CardContent>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">{t('settings.reset')}</Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>{t('settings.resetConfirmTitle')}</AlertDialogTitle>
                  <AlertDialogDescription>{t('settings.resetConfirmDescription')}</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
                  <AlertDialogAction onClick={handleReset}>{t('common.confirm')}</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>

        {/* PROMPT 14: destructive confirm for clearing the reading position. */}
        <AlertDialog
          open={clearPositionConfirmOpen}
          onOpenChange={setClearPositionConfirmOpen}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t('settings.clearPositionTitle')}</AlertDialogTitle>
              <AlertDialogDescription>{t('settings.clearPositionDescription')}</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-white hover:bg-destructive/90"
                onClick={() => {
                  clearReadingPosition(null)
                  setClearPositionConfirmOpen(false)
                  toast(t('common.updated'))
                }}
              >
                {t('settings.clearPositionConfirm')}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </PageContainer>
  )
}
