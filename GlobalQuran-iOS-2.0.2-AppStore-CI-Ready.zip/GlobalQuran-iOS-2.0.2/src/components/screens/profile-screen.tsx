'use client'

/**
 * Profile screen - a personal, welcoming view of the user's reading life.
 *
 * Everything shown is real, device-local data:
 * - Reading progress from the persisted reading position (never estimated).
 * - Bookmarks (saved ayahs) from the reader store.
 * - Offline translations from the real IndexedDB pack indexes.
 * - Imported files from the real offline library metadata.
 * - Optional display name and avatar, stored only on this device.
 *
 * Empty states are helpful and honest - no fabricated statistics.
 */

import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  ArrowRight,
  BadgeCheck,
  BookOpen,
  BookmarkCheck,
  Clock,
  FileInput,
  Globe,
  HardDriveDownload,
  Info,
  MoonStar,
  Palette,
  Settings2,
  ShieldCheck,
  Trash2,
  UserRound,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useReaderStore } from '@/stores/reader-store'
import { useNavigationStore } from '@/stores/navigation-store'
import { useOfflinePacks } from '@/hooks/use-offline-packs'
import { useMounted } from '@/hooks/use-mounted'
import { getSuraMeta } from '@/data/sura-index'
import { getFileStorage } from '@/services/storage/local-file-storage'
import { formatDateTimeString, formatNumber } from '@/utils/format'
import { APP_VERSION } from '@/lib/app-info'

import { PageContainer } from '@/components/design-system/page-container'
import { ScreenHeader } from '@/components/design-system/screen-header'
import { EmptyState } from '@/components/design-system/empty-state'
import { InfoRow } from '@/components/design-system/info-row'
import { ProfileAvatar } from '@/components/profile/profile-avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

/** Load the imported-file count from the real offline library. */
async function loadLibraryCounts(): Promise<{ imported: number; downloaded: number }> {
  const files = await getFileStorage().listFiles()
  return {
    imported: files.filter((file) => file.origin === 'imported').length,
    downloaded: files.filter((file) => file.origin === 'downloaded').length,
  }
}

export function ProfileScreen() {
  const { t, locale } = useTranslation()
  const mounted = useMounted()

  const profile = usePreferencesStore((s) => s.profile)
  const updateProfile = usePreferencesStore((s) => s.updateProfile)
  const lastReadingPosition = usePreferencesStore((s) => s.lastReadingPosition)
  const bookmarks = useReaderStore((s) => s.bookmarks)
  const openReader = useReaderStore((s) => s.openReader)
  const openReaderAt = useReaderStore((s) => s.openReaderAt)
  const removeBookmark = useReaderStore((s) => s.removeBookmark)
  const requestBookmarksPanel = useReaderStore((s) => s.requestBookmarksPanel)

  const navigate = useNavigationStore((s) => s.navigate)
  const goToSettingsSection = useNavigationStore((s) => s.navigateToSettingsSection)

  const { statuses } = useOfflinePacks()
  const libraryQuery = useQuery({
    queryKey: ['profile-library-counts'],
    queryFn: loadLibraryCounts,
    staleTime: 30_000,
  })

  /* Display-name editing (optional, local-only). The draft is scoped to
   * the display name it belongs to, so it auto-discards once a new name is
   * committed - no state-resetting effect needed. */
  const [nameEdit, setNameEdit] = useState<{ forName: string | null; value: string } | null>(null)
  const nameDraft =
    nameEdit !== null && nameEdit.forName === profile.displayName ? nameEdit.value : null

  const commitName = () => {
    if (nameDraft === null) return
    const trimmed = nameDraft.trim()
    updateProfile({ displayName: trimmed.length > 0 ? trimmed.slice(0, 40) : null })
    setNameEdit(null)
  }

  /* Real statistics. */
  const offlineTranslations = useMemo(
    () =>
      statuses
        ? Object.values(statuses).filter((status) => status.complete).length
        : null,
    [statuses],
  )
  const importedFiles = libraryQuery.data?.imported ?? null
  const savedAyahs = mounted ? bookmarks.length : 0

  const recentBookmarks = useMemo(
    () => [...bookmarks].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5),
    [bookmarks],
  )

  const lastSura =
    lastReadingPosition !== null ? getSuraMeta(lastReadingPosition.surah) ?? null : null
  const suraProgress =
    lastSura && lastReadingPosition
      ? Math.min(100, Math.round((lastReadingPosition.ayah / lastSura.ayahCount) * 100))
      : 0

  /* Open the reader at one exact ayah ("Continue reading" and bookmark
   *  taps) - the reader scrolls to the ayah and briefly highlights it. */
  const openAt = (sura: number, aya: number) => {
    openReaderAt(sura, aya)
    navigate('quran')
  }

  const stats: Array<{
    key: string
    icon: typeof BookmarkCheck
    label: string
    value: number | null
  }> = [
    { key: 'bookmarks', icon: BookmarkCheck, label: t('profile.statBookmarks'), value: mounted ? savedAyahs : null },
    { key: 'downloads', icon: HardDriveDownload, label: t('profile.statDownloads'), value: offlineTranslations },
    { key: 'imports', icon: FileInput, label: t('profile.statImports'), value: importedFiles },
  ]

  const preferenceLinks: Array<{
    key: string
    icon: typeof Globe
    title: string
    description: string
    section: string
  }> = [
    {
      key: 'language',
      icon: Globe,
      title: t('profile.languageSettings'),
      description: t('profile.languageSettingsDescription'),
      section: 'language',
    },
    {
      key: 'appearance',
      icon: Palette,
      title: t('profile.appearanceSettings'),
      description: t('profile.appearanceSettingsDescription'),
      section: 'appearance',
    },
    {
      key: 'reading',
      icon: BookOpen,
      title: t('profile.readingSettings'),
      description: t('profile.readingSettingsDescription'),
      section: 'reading-preferences',
    },
    {
      key: 'prayer',
      icon: MoonStar,
      title: t('profile.prayerSettings'),
      description: t('profile.prayerSettingsDescription'),
      section: 'prayer',
    },
  ]

  return (
    <PageContainer>
      <ScreenHeader
        title={t('profile.title')}
        subtitle={t('profile.subtitle')}
        icon={UserRound}
      />

      <div className="space-y-6">
        {/* Identity: avatar, name, local-profile promise */}
        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <UserRound aria-hidden="true" className="size-5 text-primary" />
                <CardTitle className="text-base">{profile.displayName ?? t('profile.title')}</CardTitle>
              </div>
              <Badge variant="outline" className="border-primary/30 bg-primary/10 text-primary">
                <BadgeCheck aria-hidden="true" className="size-3.5" />
                {t('profile.localProfileBadge')}
              </Badge>
            </div>
            <CardDescription>{t('profile.localProfileNote')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <ProfileAvatar />

            <div className="max-w-md space-y-1.5">
              <label htmlFor="profile-display-name" className="text-sm font-medium text-foreground">
                {t('profile.displayName')}
              </label>
              <div className="flex gap-2">
                <Input
                  id="profile-display-name"
                  value={nameDraft ?? profile.displayName ?? ''}
                  placeholder={t('profile.displayNamePlaceholder')}
                  maxLength={40}
                  onChange={(event) =>
                    setNameEdit({ forName: profile.displayName, value: event.target.value })
                  }
                  onBlur={commitName}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') commitName()
                  }}
                  className="h-11"
                />
                {nameDraft !== null ? (
                  <Button variant="outline" className="h-11" onClick={commitName}>
                    {t('common.save')}
                  </Button>
                ) : null}
              </div>
              <p className="text-xs text-muted-foreground">{t('profile.displayNameNote')}</p>
            </div>
          </CardContent>
        </Card>

        {/* Reading progress */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <BookOpen aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('profile.readingProgress')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {lastReadingPosition && lastSura ? (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-foreground">
                      <span className="me-2 font-arabic text-lg leading-none text-foreground" dir="rtl">
                        {lastSura.nameArabic}
                      </span>
                      <span className="text-muted-foreground">
                        {lastSura.nameEnglish} · {t('reader.sura')} {formatNumber(locale, lastSura.number)}
                      </span>
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {t('profile.lastReadAyah', { ayah: lastReadingPosition.ayah })}
                      {' · '}
                      {t('home.continueReadingSurahProgress', {
                        ayah: lastReadingPosition.ayah,
                        count: lastSura.ayahCount,
                      })}
                    </p>
                  </div>
                  <Button
                    className="h-11"
                    onClick={() =>
                      openAt(lastReadingPosition.surah, lastReadingPosition.ayah)
                    }
                  >
                    <BookOpen aria-hidden="true" className="size-4" />
                    {t('profile.continueReading')}
                  </Button>
                </div>
                <div>
                  <Progress value={suraProgress} aria-label={t('profile.readingProgress')} />
                  <p className="mt-1.5 text-xs text-muted-foreground tabular-nums">
                    {formatNumber(locale, suraProgress)}%
                  </p>
                </div>
              </div>
            ) : (
              <EmptyState
                icon={BookOpen}
                title={t('profile.noReadingYet')}
                description={t('profile.noReadingYetDescription')}
                action={
                  <Button className="h-11" onClick={() => openReader({ sura: 1 })}>
                    <BookOpen aria-hidden="true" className="size-4" />
                    {t('home.startReading')}
                  </Button>
                }
              />
            )}
          </CardContent>
        </Card>

        {/* Statistics (all real counts) */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <Clock aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('profile.statistics')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <dl className="grid gap-4 sm:grid-cols-3">
              {stats.map((stat) => (
                <div
                  key={stat.key}
                  className="rounded-xl border border-border/70 bg-muted/40 p-4 text-center"
                >
                  <stat.icon aria-hidden="true" className="mx-auto size-5 text-primary" />
                  <dd className="mt-2 text-2xl font-semibold tabular-nums text-foreground">
                    {stat.value === null ? (
                      <Skeleton className="mx-auto h-8 w-10" />
                    ) : (
                      formatNumber(locale, stat.value)
                    )}
                  </dd>
                  <dt className="mt-1 text-xs font-medium text-muted-foreground">{stat.label}</dt>
                </div>
              ))}
            </dl>
          </CardContent>
        </Card>

        {/* Recent bookmarks (saved ayahs) */}
        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <BookmarkCheck aria-hidden="true" className="size-5 text-primary" />
                <CardTitle className="text-base">{t('profile.recentBookmarks')}</CardTitle>
              </div>
              {bookmarks.length > 0 ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-11"
                  onClick={() => {
                    requestBookmarksPanel()
                    openReader()
                    navigate('quran')
                  }}
                >
                  {t('profile.viewAllBookmarks')}
                  <ArrowRight aria-hidden="true" className="size-3.5" />
                </Button>
              ) : null}
            </div>
          </CardHeader>
          <CardContent>
            {recentBookmarks.length === 0 ? (
              <EmptyState
                icon={BookmarkCheck}
                title={t('profile.noBookmarks')}
                description={t('profile.noBookmarksDescription')}
              />
            ) : (
              <ul className="space-y-2">
                {recentBookmarks.map((bookmark) => {
                  const meta = getSuraMeta(bookmark.sura)
                  return (
                    <li
                      key={bookmark.id}
                      className="flex items-center gap-1 rounded-lg border border-border/70"
                    >
                      <button
                        type="button"
                        onClick={() => openAt(bookmark.sura, bookmark.aya)}
                        className={cn(
                          'flex min-w-0 flex-1 flex-col items-start gap-0.5 rounded-s-lg px-3 py-2.5 text-start outline-none transition-colors',
                          'focus-visible:ring-[3px] focus-visible:ring-ring/50 hover:bg-accent/60',
                        )}
                      >
                        <span className="w-full truncate text-sm font-medium text-foreground">
                          <span className="me-2 font-arabic" dir="rtl">
                            {meta?.nameArabic ?? '—'}
                          </span>
                          <span className="text-muted-foreground">{meta?.nameEnglish ?? ''}</span>
                        </span>
                        <span className="mt-0.5 block text-xs text-muted-foreground">
                          {t('profile.lastReadAyah', { ayah: bookmark.aya })}
                        </span>
                        {bookmark.preview ? (
                          <span
                            dir="auto"
                            className="w-full truncate text-xs leading-snug text-muted-foreground"
                          >
                            {bookmark.preview}
                          </span>
                        ) : null}
                        <span className="mt-0.5 block text-[11px] text-muted-foreground/80">
                          {formatDateTimeString(locale, bookmark.createdAt)}
                        </span>
                      </button>
                      <button
                        type="button"
                        aria-label={t('reader.removeBookmark')}
                        onClick={() => {
                          removeBookmark(bookmark.id)
                          toast(t('reader.bookmarkRemoved'))
                        }}
                        className="flex size-11 shrink-0 items-center justify-center rounded-e-lg text-muted-foreground outline-none transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:ring-[3px] focus-visible:ring-ring/50"
                      >
                        <Trash2 aria-hidden="true" className="size-4" />
                      </button>
                    </li>
                  )
                })}
              </ul>
            )}
          </CardContent>
        </Card>

        {/* My library */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <HardDriveDownload aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('profile.myLibrary')}</CardTitle>
            </div>
            <CardDescription>
              {offlineTranslations === null || libraryQuery.isPending
                ? t('downloads.offlineIndicator')
                : `${formatNumber(locale, offlineTranslations)} ${t('profile.statDownloads')} · ${formatNumber(
                    locale,
                    libraryQuery.data?.imported ?? 0,
                  )} ${t('profile.statImports')}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="h-11" onClick={() => navigate('downloads')}>
              <HardDriveDownload aria-hidden="true" className="size-4" />
              {t('profile.openDownloads')}
            </Button>
          </CardContent>
        </Card>

        {/* Preferences quick links */}
        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <Settings2 aria-hidden="true" className="size-5 text-primary" />
                <CardTitle className="text-base">{t('profile.preferences')}</CardTitle>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="h-11"
                onClick={() => navigate('settings')}
              >
                {t('profile.allSettings')}
                <ArrowRight aria-hidden="true" className="size-3.5" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 sm:grid-cols-2">
              {preferenceLinks.map((link) => (
                <button
                  key={link.key}
                  type="button"
                  onClick={() => goToSettingsSection(link.section)}
                  className={cn(
                    'flex items-start gap-3 rounded-xl border border-border/70 p-3.5 text-start outline-none transition-colors',
                    'focus-visible:ring-[3px] focus-visible:ring-ring/50 hover:border-primary/30 hover:bg-accent/60',
                  )}
                >
                  <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <link.icon aria-hidden="true" className="size-4.5" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-medium text-foreground">{link.title}</span>
                    <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">
                      {link.description}
                    </span>
                  </span>
                  <ArrowRight
                    aria-hidden="true"
                    className="ms-auto size-4 shrink-0 self-center text-muted-foreground rtl:rotate-180"
                  />
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <Info aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('profile.aboutApp')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <dl>
              <InfoRow label={t('settings.aboutVersion')} value={APP_VERSION} />
              <InfoRow label={t('settings.aboutSources')} value={t('settings.aboutSourcesDescription')} />
              <InfoRow
                label={t('settings.aboutVerification')}
                value={t('settings.aboutVerificationDescription')}
              />
            </dl>
          </CardContent>
        </Card>

        {/* Privacy */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2.5">
              <ShieldCheck aria-hidden="true" className="size-5 text-primary" />
              <CardTitle className="text-base">{t('profile.privacyTitle')}</CardTitle>
            </div>
            <CardDescription>{t('profile.privacyDescription')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm font-medium text-foreground">{t('profile.privacyPoints')}</p>
              <ul className="mt-2 space-y-1.5">
                {['profile.privacyPoint1', 'profile.privacyPoint2', 'profile.privacyPoint3', 'profile.privacyPoint4'].map(
                  (key) => (
                    <li key={key} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <ShieldCheck
                        aria-hidden="true"
                        className="mt-0.5 size-4 shrink-0 text-success"
                      />
                      {t(key as 'profile.privacyPoint1')}
                    </li>
                  ),
                )}
              </ul>
            </div>
            <a
              href="/PRIVACY.md"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-[3px] focus-visible:ring-ring/50 rounded"
            >
              {t('profile.privacyReadMore')}
              <ArrowRight aria-hidden="true" className="size-3.5 rtl:rotate-180" />
            </a>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  )
}
