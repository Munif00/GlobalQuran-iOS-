'use client'

/**
 * Home screen - the daily starting point.
 *
 * Layout follows the product priorities:
 * A. Welcome area (greeting, Gregorian + Hijri dates)
 * B. Continue reading - the most prominent card; reopens the exact saved
 *    ayah (real tracked position, never invented progress)
 * C. Next prayer - live data from the hybrid prayer source once a location
 *    is set; an honest setup prompt otherwise
 * D. Quick access - the six most useful destinations
 * E. Offline notice - only when actually offline
 *
 * The header carries the profile avatar (Profile & Settings) on every screen.
 */

import { useQuery } from '@tanstack/react-query'
import {
  ArrowDownToLine,
  BookMarked,
  BookOpen,
  Bookmark,
  CalendarDays,
  Clock,
  Compass,
  Languages,
  MoonStar,
  WifiOff,
} from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { useMemo } from 'react'
import { useMounted } from '@/hooks/use-mounted'
import { useInstallPrompt } from '@/hooks/use-install-prompt'
import { useOnlineStatus } from '@/hooks/use-online-status'
import {
  computeNextPrayer,
  formatCountdown,
  passedSlotKeys,
  useNow,
  usePrayerDay,
  type PrayerSlotKey,
} from '@/hooks/use-prayer-data'
import { useNavigationStore } from '@/stores/navigation-store'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useReaderStore } from '@/stores/reader-store'
import { getSuraMeta } from '@/data/sura-index'
import { getSuraNames } from '@/services/api/catalog-api'
import { todayInZone } from '@/lib/prayer/timezone'
import { formatGregorianDate, formatHijriDate, getDayPart } from '@/utils/dates'
import { formatDate, formatDateTimeString, formatNumber } from '@/utils/format'
import type { PrayerTimeRecord } from '@/types'

import { PageContainer } from '@/components/design-system/page-container'
import { AppLogoMark } from '@/components/design-system/app-logo'
import { NativeAppDownloadCard } from '@/components/app/native-app-download'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

const PRAYER_KEYS: Array<{ key: PrayerSlotKey; labelKey: TranslationKey }> = [
  { key: 'fajr', labelKey: 'prayer.fajr' },
  { key: 'sunrise', labelKey: 'prayer.sunrise' },
  { key: 'dhuhr', labelKey: 'prayer.dhuhr' },
  { key: 'asr', labelKey: 'prayer.asr' },
  { key: 'maghrib', labelKey: 'prayer.maghrib' },
  { key: 'isha', labelKey: 'prayer.isha' },
]

export function HomeScreen() {
  const { t, locale, ready } = useTranslation()
  const mounted = useMounted()
  const { isOnline } = useOnlineStatus()
  const { isStandalone } = useInstallPrompt()
  const navigate = useNavigationStore((s) => s.navigate)

  /* Reading session */
  const lastReadingPosition = usePreferencesStore((s) => s.lastReadingPosition)
  const openReader = useReaderStore((s) => s.openReader)
  const openReaderAt = useReaderStore((s) => s.openReaderAt)
  const closeReader = useReaderStore((s) => s.closeReader)
  const requestBookmarksPanel = useReaderStore((s) => s.requestBookmarksPanel)

  /* Localized sura names for the Continue-reading card. */
  const suraNamesQuery = useQuery({
    queryKey: ['sura-names', locale],
    queryFn: () => getSuraNames(locale),
    staleTime: 24 * 3600_000,
    retry: 1,
  })

  /* Live next-prayer data (hybrid source) for the saved location. */
  const now = useNow()
  const prayerSettings = usePreferencesStore((s) => s.prayerSettings)
  const savedLocations = usePreferencesStore((s) => s.savedLocations)
  const activeLocationId = usePreferencesStore((s) => s.activeLocationId)
  const activeSaved =
    savedLocations.find((location) => location.id === activeLocationId) ?? null
  const locationLatitude = activeSaved?.latitude ?? prayerSettings.latitude
  const locationLongitude = activeSaved?.longitude ?? prayerSettings.longitude
  const locationTimeZone = activeSaved?.timeZone ?? prayerSettings.timeZone
  const hasPrayerLocation = locationLatitude != null && locationLongitude != null
  const locationLabel =
    activeSaved?.label ??
    (prayerSettings.city && prayerSettings.countryName
      ? `${prayerSettings.city}, ${prayerSettings.countryName}`
      : prayerSettings.city)

  const todayValue = mounted
    ? locationTimeZone
      ? todayInZone(locationTimeZone)
      : new Date().toISOString().slice(0, 10)
    : ''
  const dayQuery = usePrayerDay(
    // Guard against the pre-mount empty date - the API would reject it.
    hasPrayerLocation && todayValue ? todayValue : null,
    hasPrayerLocation
      ? {
          latitude: locationLatitude as number,
          longitude: locationLongitude as number,
          timeZone: locationTimeZone,
          countryCode: activeSaved?.countryCode ?? prayerSettings.countryCode,
          methodMode: prayerSettings.methodMode,
          methodId: prayerSettings.calculationMethod,
          madhhab: prayerSettings.madhhab,
          highLatitudeRule: prayerSettings.highLatitudeRule,
          adjustments: prayerSettings.adjustments,
          jakimZone:
            (activeSaved?.countryCode ?? prayerSettings.countryCode) === 'MY'
              ? (prayerSettings.jakimZone ?? null)
              : null,
        }
      : null,
  )
  const todayRecord: PrayerTimeRecord | null =
    dayQuery.data?.status === 'live' ? dayQuery.data.record : null
  const passedKeys = todayRecord ? passedSlotKeys(todayRecord, now) : new Set<PrayerSlotKey>()
  const needsTomorrow =
    todayRecord != null && passedKeys.size >= 6 && todayValue !== ''
  const tomorrowValue = useMemo(
    () => (todayValue ? new Date(Date.parse(`${todayValue}T12:00:00Z`) + 86_400_000).toISOString().slice(0, 10) : ''),
    [todayValue],
  )
  const tomorrowQuery = usePrayerDay(
    needsTomorrow && tomorrowValue ? tomorrowValue : null,
    hasPrayerLocation && locationLatitude != null && locationLongitude != null && needsTomorrow
      ? {
          latitude: locationLatitude,
          longitude: locationLongitude,
          timeZone: locationTimeZone,
          countryCode: activeSaved?.countryCode ?? prayerSettings.countryCode,
          methodMode: prayerSettings.methodMode,
          methodId: prayerSettings.calculationMethod,
          madhhab: prayerSettings.madhhab,
          highLatitudeRule: prayerSettings.highLatitudeRule,
          adjustments: prayerSettings.adjustments,
          jakimZone:
            (activeSaved?.countryCode ?? prayerSettings.countryCode) === 'MY'
              ? (prayerSettings.jakimZone ?? null)
              : null,
        }
      : null,
  )
  const tomorrowRecord: PrayerTimeRecord | null =
    tomorrowQuery.data?.status === 'live' ? tomorrowQuery.data.record : null
  const nextView = todayRecord
    ? computeNextPrayer(now, todayRecord, tomorrowRecord)
    : null

  const greetingKey: TranslationKey = mounted && now
    ? ({ morning: 'home.greetingMorning', afternoon: 'home.greetingAfternoon', evening: 'home.greetingEvening', night: 'home.greetingNight' } as const)[getDayPart(now)]
    : 'home.greetingMorning'

  const displayNow = mounted ? now : null
  const gregorian = displayNow ? formatGregorianDate(locale, displayNow) : null
  const hijri = displayNow ? formatHijriDate(locale, displayNow) : null

  /* Continue-reading details (only from the real saved position). */
  const positionMeta = lastReadingPosition ? getSuraMeta(lastReadingPosition.surah) : null
  const positionSuraName =
    lastReadingPosition && positionMeta
      ? (locale === 'ar'
          ? positionMeta.nameArabic
          : suraNamesQuery.data?.names?.[String(lastReadingPosition.surah)] ?? positionMeta.nameEnglish)
      : null
  const positionAyahCount = positionMeta?.ayahCount ?? null
  const positionPercent =
    lastReadingPosition && positionAyahCount
      ? Math.min(100, Math.max(0, (lastReadingPosition.ayah / positionAyahCount) * 100))
      : 0

  /* "Continue reading": open the exact last-read surah AND ayah, scrolled
   *  into view and briefly highlighted - never a manual search for the spot
   *  (PROMPT 12 §3). */
  const openMushaf = () => {
    if (lastReadingPosition !== null) {
      openReaderAt(lastReadingPosition.surah, lastReadingPosition.ayah)
    } else {
      openReader()
    }
    navigate('quran')
  }

  return (
    <PageContainer wide>
      {/* A. Greeting and dates */}
      <section aria-labelledby="home-greeting" className="mb-6">
        <Card className="overflow-hidden border-primary/20 bg-gradient-to-b from-primary/[0.08] to-transparent">
          <CardContent className="flex items-start gap-4 p-5 sm:p-6">
            <AppLogoMark className="size-12 shrink-0 sm:size-14" />
            <div className="min-w-0 flex-1">
              <h1 id="home-greeting" className="text-xl font-semibold tracking-tight sm:text-2xl">
                {ready ? t(greetingKey) : <Skeleton className="h-7 w-40" />}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <CalendarDays aria-hidden="true" className="size-4" />
                  {gregorian ?? <Skeleton className="h-4 w-44" />}
                </span>
                {hijri ? (
                  <span className="inline-flex items-center gap-1.5">
                    <MoonStar aria-hidden="true" className="size-4 text-gold" />
                    <span>
                      {hijri}
                      <span className="ms-1 text-xs opacity-75">({t('home.hijriCalendarLabel')})</span>
                    </span>
                  </span>
                ) : null}
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* B. Continue reading - the most prominent action */}
      <section aria-labelledby="continue-reading-heading" className="mb-6">
        <Card className="border-gold/40 shadow-sm">
          <CardContent className="p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex min-w-0 items-start gap-3.5">
                <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-gold/15 text-gold">
                  <BookMarked aria-hidden="true" className="size-6" />
                </span>
                <div className="min-w-0">
                  <h2 id="continue-reading-heading" className="text-base font-semibold text-foreground">
                    {lastReadingPosition
                      ? t('home.continueReading')
                      : t('home.startReading')}
                  </h2>
                  {lastReadingPosition ? (
                    <>
                      <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-sm text-foreground">
                        <span dir="auto" className="font-medium">{positionSuraName}</span>
                        <span aria-hidden="true" className="text-muted-foreground">·</span>
                        <span className="text-muted-foreground">
                          {t('home.continueReadingPosition', {
                            sura: formatNumber(locale, lastReadingPosition.surah),
                            ayah: formatNumber(locale, lastReadingPosition.ayah),
                          })}
                        </span>
                      </p>
                      {positionAyahCount ? (
                        <div className="mt-2.5 max-w-xs">
                          <Progress
                            value={positionPercent}
                            aria-label={t('home.continueReadingSurahProgress', {
                              ayah: formatNumber(locale, lastReadingPosition.ayah),
                              count: formatNumber(locale, positionAyahCount),
                            })}
                          />
                          <p className="mt-1.5 text-xs text-muted-foreground">
                            {t('home.continueReadingSurahProgress', {
                              ayah: formatNumber(locale, lastReadingPosition.ayah),
                              count: formatNumber(locale, positionAyahCount),
                            })}
                          </p>
                          {/* PROMPT 14 (Nielsen #6): "when did I last read?" -
                              the saved timestamp was persisted but never shown. */}
                          <p className="text-xs text-muted-foreground">
                            {t('reader.lastReadAt', {
                              date: formatDateTimeString(locale, lastReadingPosition.savedAt),
                            })}
                          </p>
                        </div>
                      ) : null}
                    </>
                  ) : (
                    <p className="mt-1 max-w-md text-sm leading-relaxed text-muted-foreground">
                      {t('home.continueReadingEmptyDescription')}
                    </p>
                  )}
                </div>
              </div>
              <Button size="lg" className="h-12" onClick={openMushaf}>
                <BookOpen aria-hidden="true" className="size-4.5" />
                {lastReadingPosition ? t('home.continueReadingAction') : t('home.startReading')}
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* C. Next prayer */}
      <section aria-labelledby="next-prayer-heading" className="mb-6">
        <Card className="border-primary/30 bg-primary text-primary-foreground">
          <CardContent className="p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <Clock aria-hidden="true" className="size-5" />
                <h2 id="next-prayer-heading" className="text-sm font-semibold uppercase tracking-wide opacity-90">
                  {t('home.nextPrayer')}
                </h2>
              </div>
              {todayRecord ? (
                <Badge className="border-gold/60 bg-gold/20 text-primary-foreground">
                  {todayRecord.sourceType === 'official_authority'
                    ? t('prayer.sourceType.official_authority')
                    : todayRecord.sourceType === 'local_engine'
                      ? t('prayer.sourceType.local_engine')
                      : t('prayer.sourceType.aladhan_api')}
                </Badge>
              ) : hasPrayerLocation && dayQuery.isLoading ? (
                <Badge className="border-gold/60 bg-gold/20 text-primary-foreground">
                  {t('common.loading')}
                </Badge>
              ) : null}
            </div>

            {hasPrayerLocation ? (
              nextView ? (
                <div className="mt-4 flex flex-wrap items-baseline gap-x-4 gap-y-1">
                  <p className="text-3xl font-semibold opacity-95">
                    {t(
                      PRAYER_KEYS.find((entry) => entry.key === nextView.slot.key)?.labelKey ??
                        'prayer.nextPrayer',
                    )}
                  </p>
                  <p className="text-3xl font-semibold tabular-nums opacity-95">
                    {formatDate(locale, new Date(nextView.slot.iso), {
                      timeZone: todayRecord?.timeZone,
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                  <p className="text-lg tabular-nums opacity-80" aria-live="polite">
                    {formatCountdown(nextView.slot.instant.getTime() - now.getTime())}
                  </p>
                </div>
              ) : dayQuery.isLoading ? (
                <Skeleton className="mt-4 h-9 w-56 bg-primary-foreground/15" />
              ) : (
                <p className="mt-4 text-2xl font-semibold opacity-95">—</p>
              )
            ) : (
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p className="max-w-md text-sm leading-relaxed opacity-90">
                  {t('prayer.locationNeededDescription')}
                </p>
                <Button
                  size="lg"
                  className="h-12 bg-primary-foreground text-primary hover:bg-primary-foreground/90"
                  onClick={() => navigate('prayer')}
                >
                  <MoonStar aria-hidden="true" className="size-4.5" />
                  {t('home.setupPrayerTimes')}
                </Button>
              </div>
            )}

            {hasPrayerLocation && todayRecord ? (
              <p className="mt-3 max-w-2xl text-sm leading-relaxed opacity-85">
                {`${locationLabel ?? ''}${locationLabel ? ' · ' : ''}${todayRecord.sourceName}`}
              </p>
            ) : hasPrayerLocation && !dayQuery.isLoading ? (
              <p className="mt-3 max-w-2xl text-sm leading-relaxed opacity-85">
                {t('prayer.error.noSource')}
              </p>
            ) : null}

            {/* Daily prayers status */}
            {hasPrayerLocation ? (
              <div className="mt-5">
                <p className="mb-2 text-xs font-medium uppercase tracking-wide opacity-75">
                  {t('home.dailyPrayerStatus')}
                </p>
                <ul className="grid grid-cols-3 gap-2 sm:grid-cols-6">
                  {PRAYER_KEYS.map(({ key, labelKey }) => {
                    const isNext = nextView?.slot.key === key
                    const isPassed = passedKeys.has(key)
                    return (
                      <li
                        key={key}
                        className={cn(
                          'rounded-lg px-2 py-2 text-center',
                          isNext
                            ? 'bg-primary-foreground/25 ring-1 ring-primary-foreground/40'
                            : 'bg-primary-foreground/10',
                        )}
                      >
                        <p className="truncate text-xs font-medium opacity-90">{t(labelKey)}</p>
                        <p
                          className={cn(
                            'mt-0.5 text-sm font-semibold tabular-nums',
                            isPassed && !isNext ? 'opacity-50' : 'opacity-95',
                          )}
                        >
                          {todayRecord
                            ? formatDate(locale, new Date(todayRecord[key]), {
                                timeZone: todayRecord.timeZone,
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : '—'}
                        </p>
                      </li>
                    )
                  })}
                </ul>
              </div>
            ) : null}

            {hasPrayerLocation ? (
              <div className="mt-5">
                <Button
                  variant="secondary"
                  onClick={() => navigate('prayer')}
                  className="bg-primary-foreground text-primary hover:bg-primary-foreground/90"
                >
                  {t('settings.openPrayerScreen')}
                </Button>
              </div>
            ) : null}
          </CardContent>
        </Card>
      </section>

      {/* D. Quick access */}
      <section aria-labelledby="quick-access-heading" className="mb-6">
        <h2 id="quick-access-heading" className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          {t('home.quickAccess')}
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {[
            {
              labelKey: 'home.readQuran' as TranslationKey,
              descKey: 'home.readQuranDesc' as TranslationKey,
              icon: BookOpen,
              action: () => {
                if (lastReadingPosition !== null) {
                  openReaderAt(lastReadingPosition.surah, lastReadingPosition.ayah)
                } else {
                  openReader()
                }
                navigate('quran')
              },
            },
            {
              labelKey: 'home.quickTranslations' as TranslationKey,
              descKey: 'home.translationLibraryDesc' as TranslationKey,
              icon: Languages,
              action: () => {
                /* PROMPT 14: close any open reader session first - the user
                 *  expects the translation LIBRARY, not the reader they just
                 *  left (matches the bottom-nav "Library" behavior). */
                closeReader()
                navigate('quran')
              },
            },
            {
              labelKey: 'home.quickPrayer' as TranslationKey,
              descKey: 'home.quickPrayerDesc' as TranslationKey,
              icon: MoonStar,
              action: () => navigate('prayer'),
            },
            {
              labelKey: 'home.quickQibla' as TranslationKey,
              descKey: 'home.quickQiblaDesc' as TranslationKey,
              icon: Compass,
              action: () => navigate('qibla'),
            },
            {
              labelKey: 'home.quickBookmarks' as TranslationKey,
              descKey: 'home.quickBookmarksDesc' as TranslationKey,
              icon: Bookmark,
              action: () => {
                requestBookmarksPanel()
                openReader()
                navigate('quran')
              },
            },
            {
              labelKey: 'home.myDownloads' as TranslationKey,
              descKey: 'home.myDownloadsDesc' as TranslationKey,
              icon: ArrowDownToLine,
              action: () => navigate('downloads'),
            },
          ].map((item) => {
            const Icon = item.icon
            return (
              <Card key={item.labelKey} className="transition-shadow hover:shadow-md">
                <CardContent className="p-4 sm:p-5">
                  <button
                    type="button"
                    onClick={item.action}
                    className="flex h-full w-full flex-col items-start gap-3 text-start outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                  >
                    <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Icon aria-hidden="true" className="size-5" />
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-foreground">{t(item.labelKey)}</span>
                      <span className="mt-0.5 block text-xs leading-snug text-muted-foreground">{t(item.descKey)}</span>
                    </span>
                  </button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>

      {/* E. Install the native app (web browser mode only) */}
      {mounted && !isStandalone ? (
        <section aria-label={t('install.getAppTitle')} className="mb-6">
          <NativeAppDownloadCard />
        </section>
      ) : null}

      {/* F. Offline notice - only when actually offline */}
      {!isOnline ? (
        <section aria-label={t('home.connectionStatus')}>
          <Card className="border-warning/40 bg-warning/10">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5">
              <div className="flex min-w-0 items-center gap-3">
                <WifiOff aria-hidden="true" className="size-5 shrink-0 text-warning" />
                <p className="text-sm leading-relaxed text-foreground">
                  {t('home.offlineNotice')}
                </p>
              </div>
              <Button variant="outline" onClick={() => navigate('downloads')}>
                {t('home.offlineOpenDownloads')}
              </Button>
            </CardContent>
          </Card>
        </section>
      ) : null}
    </PageContainer>
  )
}
