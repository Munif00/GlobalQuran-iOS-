'use client'

/**
 * Global Quran - Prayer Times screen (dashboard).
 *
 * Mobile-first prayer dashboard fed by the hybrid source strategy:
 * - Hero: next prayer, live countdown, progress, Gregorian + Hijri dates,
 *   location and time zone, cached-data badge.
 * - Timeline: all six prayers; passed ones dimmed, the next one highlighted.
 * - Date navigation and a monthly timetable dialog (every date calculated
 *   individually by the source - never extrapolated).
 * - Full source transparency (see PrayerSourceSection).
 *
 * Honest states: no location -> clear setup card; source unavailable ->
 * explanation banner; cached data -> visible badge with fetch date. No
 * estimated times are ever displayed.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  AlertTriangle,
  Bell,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Database,
  Loader2,
  LocateFixed,
  MoonStar,
  RefreshCw,
  Search,
  Settings2,
  Sun,
  Sunrise,
  Sunset,
  TriangleAlert,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { buildPrayerContext } from '@/lib/prayer/prayer-context'
import {
  nativeRemindersMode,
  requestNativeReminderSync,
} from '@/services/notifications/native-reminders'
import { useGeolocation } from '@/hooks/use-geolocation'
import type { GeoCoordinates } from '@/services/location/geolocation-service'
import { useMounted } from '@/hooks/use-mounted'
import {
  computeNextPrayer,
  formatCountdown,
  formatHijriDate,
  hijriDisplayForLocale,
  passedSlotKeys,
  useNow,
  usePrayerDay,
  usePrayerMeta,
  usePrayerMonth,
  type PrayerSlotKey,
} from '@/hooks/use-prayer-data'
import { usePreferencesStore, createSavedLocation } from '@/stores/preferences-store'
import { useAdhanStore } from '@/stores/adhan-store'
import { resolveAdhanForSlot } from '@/services/notifications/prayer-notification-service'
import { getBundledCityById, QUICK_PICK_CITY_IDS } from '@/lib/prayer/cities'
import { jakimZoneForKnownPlace, jakimZonesForState, JAKIM_ZONES } from '@/lib/prayer/authorities'
import { todayInZone } from '@/lib/prayer/timezone'
import { fetchPrayerRegistry } from '@/services/api/prayer-api'
import { reverseGeocodeCoordinates } from '@/services/api/prayer-api'
import type { PrayerQueryParams } from '@/services/api/prayer-api'
import {
  currentNotificationPermission,
  prayerNotificationScheduler,
  requestNotificationPermission,
  type NotificationPermissionState,
} from '@/services/notifications/prayer-notification-service'
import type {
  CalculationMethodId,
  CalculationMethodInfo,
  CitySearchResult,
  HighLatitudeRuleMode,
  Madhhab,
  PrayerAdjustments,
  PrayerTimeRecord,
} from '@/types'
import { formatDate, formatNumber } from '@/utils/format'

import { PageContainer } from '@/components/design-system/page-container'
import { ScreenHeader } from '@/components/design-system/screen-header'
import { StatusBanner } from '@/components/design-system/status-banner'
import { EmptyState } from '@/components/design-system/empty-state'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'

import { PrayerMonthDialog } from '@/components/prayer/prayer-month-dialog'
import { PrayerLocationSection } from '@/components/prayer/prayer-location-section'
import { PrayerSourceSection } from '@/components/prayer/prayer-source-section'
import { PrayerSettingsSection } from '@/components/prayer/prayer-settings-section'
import { PrayerSettingsDialog } from '@/components/prayer/prayer-settings-dialog'
import { AdhanReminderSheet } from '@/components/prayer/adhan-reminder-sheet'

const PRAYER_ROW_ICONS: Record<PrayerSlotKey, LucideIcon> = {
  fajr: MoonStar,
  sunrise: Sunrise,
  dhuhr: Sun,
  asr: Sun,
  maghrib: Sunset,
  isha: MoonStar,
}
const PRAYER_ROW_LABELS: Record<PrayerSlotKey, TranslationKey> = {
  fajr: 'prayer.fajr',
  sunrise: 'prayer.sunrise',
  dhuhr: 'prayer.dhuhr',
  asr: 'prayer.asr',
  maghrib: 'prayer.maghrib',
  isha: 'prayer.isha',
}
const PRAYER_ORDER: PrayerSlotKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha']

function toDateInputValue(date: Date): string {
  const year = String(date.getFullYear()).padStart(4, '0')
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function shiftDateInput(value: string, delta: number): string {
  const date = new Date(`${value}T12:00:00Z`)
  date.setUTCDate(date.getUTCDate() + delta)
  return date.toISOString().slice(0, 10)
}

/** Format an ISO instant as a wall-clock time in the record's zone. */
function wallTime(locale: string, iso: string, timeZone: string): string {
  try {
    return formatDate(locale, new Date(iso), {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return '--:--'
  }
}

/**
 * Friendly UTC-offset label for the hero (e.g. `GMT+3`) - avoids showing a
 * raw IANA identifier on the main screen. The full zone id remains visible
 * in the source-information card, where it belongs.
 */
function utcOffsetLabel(locale: string, timeZone: string): string | null {
  const now = new Date()
  for (const timeZoneName of ['shortOffset', 'short'] as const) {
    try {
      const parts = new Intl.DateTimeFormat(locale, { timeZone, timeZoneName })
        .formatToParts(now)
        .find((part) => part.type === 'timeZoneName')
      if (parts?.value) return parts.value
    } catch {
      // Unsupported zone id or formatting option - try the next variant.
    }
  }
  return null
}

export function PrayerScreen() {
  const { t, locale } = useTranslation()
  const mounted = useMounted()
  const now = useNow()

  const prayerSettings = usePreferencesStore((s) => s.prayerSettings)
  const updatePrayerSettings = usePreferencesStore((s) => s.updatePrayerSettings)
  const savedLocations = usePreferencesStore((s) => s.savedLocations)
  const activeLocationId = usePreferencesStore((s) => s.activeLocationId)
  const addSavedLocation = usePreferencesStore((s) => s.addSavedLocation)
  const removeSavedLocation = usePreferencesStore((s) => s.removeSavedLocation)
  const setActiveLocationId = usePreferencesStore((s) => s.setActiveLocationId)
  const notifications = usePreferencesStore((s) => s.prayerNotifications)
  const updatePrayerNotifications = usePreferencesStore((s) => s.updatePrayerNotifications)

  const [locationNotice, setLocationNotice] = useState<
    'denied' | 'reverse_failed' | 'service_disabled' | null
  >(null)
  const [selectedDate, setSelectedDate] = useState('')
  const [monthDialogOpen, setMonthDialogOpen] = useState(false)
  const [dialogMonth, setDialogMonth] = useState('')
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [reminderOpen, setReminderOpen] = useState(false)

  /* ---------------------------------------------------------------- */
  /* Location: ONE apply path + the geolocation hook                    */
  /* ---------------------------------------------------------------- */

  /* The single apply path for acquired device coordinates: the manual
   * "Get my location" press AND the automatic post-settings acquisition
   * both run through this exact function, so the active location, prayer
   * times, and every dependent screen update identically - two entry
   * points, never two code paths that can drift. */
  const applyAcquiredCoordinates = async (position: GeoCoordinates) => {
    const deviceTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
    // Reverse geocode to identify the country (drives the method default
    // and the Malaysia authority flow). Coordinates work regardless.
    const reverse = await reverseGeocodeCoordinates(position.latitude, position.longitude)
    if (reverse.status === 'live') {
      const zones = reverse.countryCode === 'MY' ? jakimZonesForState(reverse.region) : []
      const singleZone = zones.length === 1 ? zones[0].code : null
      updatePrayerSettings({
        latitude: position.latitude,
        longitude: position.longitude,
        timeZone: deviceTimeZone,
        city: reverse.city,
        countryName: reverse.countryName,
        countryCode: reverse.countryCode,
        jakimZone: singleZone,
      })
      setLocationNotice(null)
    } else {
      // Reverse geocoding failed: keep the exact coordinates, clear the old
      // place labels - showing the previous city next to new coordinates
      // would be misleading.
      updatePrayerSettings({
        latitude: position.latitude,
        longitude: position.longitude,
        timeZone: deviceTimeZone,
        city: null,
        countryName: null,
        countryCode: null,
        jakimZone: null,
      })
      setLocationNotice('reverse_failed')
    }
    setActiveLocationId(null)
    setSelectedDate('')
  }

  /* Automatic acquisition (native settings trip): the hook resolved REAL
   * coordinates after the user enabled the device location service and
   * returned - apply them through the same path as a manual press, then
   * confirm honestly. Defined before the hook call so it can be passed
   * in as the onAutoLocated callback. */
  const handleAutoLocated = async (position: GeoCoordinates) => {
    await applyAcquiredCoordinates(position)
    toast(t('geo.notice.autoObtained'))
  }

  const {
    isRequesting,
    request,
    openSettings: openLocationSettings,
    serviceEnabled,
    getLastErrorCode,
    autoFlow,
    autoFlowErrorCode,
  } = useGeolocation({ onAutoLocated: handleAutoLocated })

  const metaQuery = usePrayerMeta()
  const registryQuery = useQuery({
    queryKey: ['prayer-registry'],
    queryFn: fetchPrayerRegistry,
    staleTime: 24 * 60 * 60 * 1000,
    retry: 0,
  })

  const methods: CalculationMethodInfo[] = metaQuery.data?.methods ?? []

  /* Effective location + request params: ONE shared builder (PROMPT 16) -
   * the same module the native reminder bridge uses, so the reminder
   * schedule always matches exactly what the screen computes. */
  const prayerContext = useMemo(
    () => buildPrayerContext(prayerSettings, savedLocations, activeLocationId),
    [prayerSettings, savedLocations, activeLocationId],
  )
  const effective = prayerContext?.effective ?? null

  const effectiveTimeZone = effective?.timeZone ?? null
  const isMalaysia = effective?.countryCode === 'MY'

  /* The user's manual zone correction applies to the request; otherwise the
   * zone detected from the location is used. */
  const requestTimeZone = prayerContext?.requestTimeZone ?? null

  const params: PrayerQueryParams | null = prayerContext?.params ?? null

  /* Today in the LOCATION's zone (not the device's). */
  const todayValue = useMemo(() => {
    if (!mounted) return ''
    return effectiveTimeZone ? todayInZone(effectiveTimeZone) : toDateInputValue(new Date())
  }, [mounted, effectiveTimeZone])

  const dateInputValue = selectedDate || todayValue
  const tomorrowValue = useMemo(
    () => (dateInputValue ? shiftDateInput(dateInputValue, 1) : ''),
    [dateInputValue],
  )

  const dayQuery = usePrayerDay(dateInputValue || null, params)
  const record: PrayerTimeRecord | null =
    dayQuery.data?.status === 'live' ? dayQuery.data.record : null

  /* Tomorrow is prefetched once five slots have passed (after Maghrib), so
   * the Fajr row is ready the moment Isha passes - no countdown gap. */
  const needsTomorrow = useMemo(() => {
    if (!record || !todayValue || dateInputValue !== todayValue) return false
    return passedSlotKeys(record, now).size >= 5
  }, [record, todayValue, dateInputValue, now])

  const tomorrowQuery = usePrayerDay(needsTomorrow ? tomorrowValue : null, params)
  const tomorrowRecord: PrayerTimeRecord | null =
    tomorrowQuery.data?.status === 'live' ? tomorrowQuery.data.record : null

  /* Persist the location's resolved time zone once (avoids re-detection).
   * Skipped while a manual correction is active - the user's choice stands. */
  const persistedTzRef = useRef<string | null>(null)
  useEffect(() => {
    if (prayerSettings.timeZoneMode === 'manual') return
    if (!record?.timeZone) return
    if (persistedTzRef.current === record.timeZone) return
    persistedTzRef.current = record.timeZone
    if (!prayerSettings.timeZone || prayerSettings.timeZone !== record.timeZone) {
      updatePrayerSettings({ timeZone: record.timeZone })
    }
  }, [record?.timeZone, prayerSettings.timeZone, prayerSettings.timeZoneMode, updatePrayerSettings])

  /* Next prayer + countdown (only meaningful when viewing today). */
  const viewingToday = dateInputValue === todayValue && todayValue !== ''
  const next = useMemo(
    () => (record && viewingToday ? computeNextPrayer(now, record, tomorrowRecord) : null),
    [record, viewingToday, now, tomorrowRecord],
  )
  const passedKeys = useMemo(
    () => (record && viewingToday ? passedSlotKeys(record, now) : new Set<PrayerSlotKey>()),
    [record, viewingToday, now],
  )
  const nextKey = viewingToday ? next?.slot.key ?? null : null

  /* Month dialog data. `dialogMonth` is set when opening; the effective
   * month falls back to the selected date's month. */
  const effectiveDialogMonth = dialogMonth || dateInputValue.slice(0, 7)
  const monthQuery = usePrayerMonth(monthDialogOpen ? effectiveDialogMonth : null, params, monthDialogOpen)
  const monthRecords = monthQuery.data?.status === 'live' ? monthQuery.data.days : []

  /* Notification scheduler sync (explicit opt-in). On the native Android
   * app the native bridge owns ALL scheduling (foreground + background);
   * the web timers stand down so the two paths can never double-fire. */
  useEffect(() => {
    prayerNotificationScheduler.setLabels({
      fajr: t('prayer.fajr'),
      sunrise: t('prayer.sunrise'),
      dhuhr: t('prayer.dhuhr'),
      asr: t('prayer.asr'),
      maghrib: t('prayer.maghrib'),
      isha: t('prayer.isha'),
    })
    prayerNotificationScheduler.setAdhanMessages({
      playingBody: t('adhan.reminder.playingBody'),
      unavailableBody: t('adhan.reminder.unavailableBody'),
      fallbackBody: t('adhan.reminder.fallbackBody'),
      silentBody: t('adhan.reminder.silentBody'),
    })
    if (nativeRemindersMode() === 'native') {
      prayerNotificationScheduler.stop()
      requestNativeReminderSync()
      return
    }
    const records = [record, tomorrowRecord].filter(
      (entry): entry is PrayerTimeRecord => entry != null,
    )
    prayerNotificationScheduler.sync(records, notifications)
  }, [record, tomorrowRecord, notifications, t])

  const notificationPermission: NotificationPermissionState = useMemo(
    () => (mounted ? currentNotificationPermission() : 'default'),
    [mounted, notifications.enabled],
  )

  /* PROMPT 14: honest dashboard status for the reminder - a revoked
   *  permission or a missing local recording must never look like a healthy
   *  active reminder (Nielsen #1). */
  const adhanManifest = useAdhanStore((s) => s.manifest)
  const dashboardAdhan = notifications.adhanSettings
  const dashboardSelectedAdhanId = dashboardAdhan.useSameForAll
    ? dashboardAdhan.sameForAllRecordingId
    : resolveAdhanForSlot('dhuhr', dashboardAdhan) ?? dashboardAdhan.sameForAllRecordingId
  const reminderPermissionBlocked =
    notifications.enabled && notificationPermission === 'denied'
  const reminderAdhanMissing =
    notifications.enabled &&
    dashboardAdhan.mode === 'audio' &&
    dashboardSelectedAdhanId != null &&
    adhanManifest[dashboardSelectedAdhanId] == null

  /* ---------------------------------------------------------------- */
  /* Location handlers                                                 */
  /* ---------------------------------------------------------------- */

  const handleUseCurrentLocation = async () => {
    setLocationNotice(null)
    const position = await request()
    if (!position) {
      /* Typed failure: a disabled system location service starts the
       * automatic settings trip INSIDE the hook - the device settings open
       * on this same press, and the notice card reflects the live trip
       * state; other failures keep the existing honest notices. */
      const code = getLastErrorCode()
      setLocationNotice(code === 'service-disabled' ? 'service_disabled' : 'denied')
      return
    }
    await applyAcquiredCoordinates(position)
    toast(t('prayer.locationSaved'))
  }

  const handleSelectCity = (result: CitySearchResult) => {
    const zones = result.countryCode === 'MY' ? jakimZonesForState(result.region) : []
    const singleZone =
      zones.length === 1
        ? zones[0].code
        : result.countryCode === 'MY'
          ? jakimZoneForKnownPlace(`${result.name} ${result.region ?? ''}`)
          : null
    updatePrayerSettings({
      city: result.name,
      countryName: result.country,
      countryCode: result.countryCode,
      latitude: result.latitude,
      longitude: result.longitude,
      timeZone: result.timeZone,
      jakimZone: singleZone,
    })
    addSavedLocation(
      createSavedLocation({
        label: `${result.name}, ${result.country}`,
        city: result.name,
        country: result.country,
        countryCode: result.countryCode,
        latitude: result.latitude,
        longitude: result.longitude,
        timeZone: result.timeZone,
        jakimZone: singleZone,
      }),
    )
    setSelectedDate('')
    toast(t('prayer.locationSaved'))
  }

  const handleSelectSaved = (id: string) => {
    const location = savedLocations.find((entry) => entry.id === id)
    if (!location) return
    updatePrayerSettings({
      city: location.city,
      countryName: location.country,
      countryCode: location.countryCode,
      latitude: location.latitude,
      longitude: location.longitude,
      timeZone: location.timeZone,
      jakimZone: location.jakimZone,
    })
    setActiveLocationId(id)
    setSelectedDate('')
    toast(t('common.updated'))
  }

  const handleSaveCurrent = () => {
    if (!effective) return
    const label =
      effective.city && effective.country
        ? `${effective.city}, ${effective.country}`
        : effective.latitude != null && effective.longitude != null
          ? `${formatNumber(locale, effective.latitude, { maximumFractionDigits: 2 })}, ${formatNumber(locale, effective.longitude, { maximumFractionDigits: 2 })}`
          : null
    if (!label) return
    addSavedLocation(
      createSavedLocation({
        label,
        city: effective.city,
        country: effective.country,
        countryCode: effective.countryCode,
        latitude: effective.latitude,
        longitude: effective.longitude,
        timeZone: effective.timeZone,
        jakimZone: effective.jakimZone,
      }),
    )
    toast(t('common.saved'))
  }

  /* ---------------------------------------------------------------- */
  /* Settings handlers                                                 */
  /* ---------------------------------------------------------------- */

  const handleMethodModeChange = (mode: 'auto' | 'manual') => {
    updatePrayerSettings({ methodMode: mode })
    toast(t('prayer.savedToast'))
  }

  const handleMethodChange = (method: CalculationMethodId) => {
    updatePrayerSettings({ calculationMethod: method, methodMode: 'manual' })
    toast(t('prayer.savedToast'))
  }

  const handleMadhhabChange = (madhhab: Madhhab) => {
    updatePrayerSettings({ madhhab })
    toast(t('prayer.savedToast'))
  }

  const handleHighLatitudeRuleChange = (rule: HighLatitudeRuleMode) => {
    updatePrayerSettings({ highLatitudeRule: rule })
    toast(t('prayer.savedToast'))
  }

  const handleAdjustmentChange = (field: keyof PrayerAdjustments, delta: number) => {
    const current = prayerSettings.adjustments[field]
    const nextValue = Math.max(-60, Math.min(60, current + delta))
    updatePrayerSettings({
      adjustments: { ...prayerSettings.adjustments, [field]: nextValue },
    })
  }

  const handleJakimZoneChange = (zone: string | null) => {
    updatePrayerSettings({ jakimZone: zone })
    toast(t('prayer.savedToast'))
  }

  const handleTimeZoneModeChange = (mode: 'auto' | 'manual') => {
    updatePrayerSettings({ timeZoneMode: mode })
    toast(t('prayer.savedToast'))
  }

  const handleManualTimeZoneChange = (zone: string | null) => {
    // Toasting happens in the settings section on zone selection.
    updatePrayerSettings({ manualTimeZone: zone })
  }

  const handleRequestNotifications = async () => {
    const permission = await requestNotificationPermission()
    if (permission === 'granted') {
      updatePrayerNotifications({ enabled: true })
      toast(t('prayer.notificationsEnabled'))
    } else if (permission === 'denied') {
      toast(t('prayer.notificationsDenied'))
    } else {
      toast(t('prayer.notificationsPermissionNeeded'))
    }
  }

  /* ---------------------------------------------------------------- */
  /* Derived display values                                            */
  /* ---------------------------------------------------------------- */

  const locationLabel = useMemo(() => {
    if (!effective) return null
    if (effective.city && effective.country) return `${effective.city}, ${effective.country}`
    if (effective.city) return effective.city
    if (effective.latitude != null && effective.longitude != null) {
      return `${formatNumber(locale, effective.latitude, { maximumFractionDigits: 3 })}, ${formatNumber(locale, effective.longitude, { maximumFractionDigits: 3 })}`
    }
    return null
  }, [effective, locale])

  const countryDefault = useMemo(() => {
    const code = effective?.countryCode ?? null
    if (!code) return null
    // Optional chaining twice: when the meta request fails, `data` is the
    // honest error object and `countryDefaults` is absent.
    return metaQuery.data?.countryDefaults?.find((entry) => entry.countryCode === code) ?? null
  }, [effective?.countryCode, metaQuery.data])

  const resolvedDefaultForSettings = countryDefault
    ? {
        methodId: countryDefault.methodId,
        kind: countryDefault.kind,
        countryName: countryDefault.countryName,
      }
    : null

  const hijriDisplay = useMemo(() => hijriDisplayForLocale(locale), [locale])
  const hijriLabel = record
    ? formatHijriDate(record.hijriDate, hijriDisplay.months, hijriDisplay.eraSuffix)
    : null
  const hijriSourceLabelKey: TranslationKey | null = record?.hijriSource
    ? ({
        jakim_official: 'prayer.hijriSource.jakim_official',
        aladhan_hjcosa: 'prayer.hijriSource.aladhan_hjcosa',
        local_calendar: 'prayer.hijriSource.local_calendar',
      }[record.hijriSource] as TranslationKey)
    : null

  const formattedDate = dateInputValue
    ? formatDate(locale, new Date(`${dateInputValue}T12:00:00Z`), {
        timeZone: 'UTC',
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : null

  /* ---------------------------------------------------------------- */
  /* Render                                                            */
  /* ---------------------------------------------------------------- */

  return (
    <PageContainer wide>
      <ScreenHeader title={t('prayer.title')} subtitle={t('prayer.subtitle')} icon={MoonStar} />

      <div className="space-y-6">
        {/* Setup state: no location yet */}
        {!effective ? (
          <Card>
            <CardContent className="py-6">
              <EmptyState
                icon={LocateFixed}
                title={t('prayer.locationNeeded')}
                description={t('prayer.locationNeededDescription')}
                action={
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Button
                      className="min-h-11"
                      onClick={() => void handleUseCurrentLocation()}
                      disabled={isRequesting}
                    >
                      {isRequesting ? (
                        <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                      ) : (
                        <LocateFixed aria-hidden="true" className="size-4" />
                      )}
                      {isRequesting ? t('common.loading') : t('prayer.useCurrentLocation')}
                    </Button>
                  </div>
                }
              />
              <div className="mt-6 space-y-3">
                <p className="text-center text-sm font-medium text-foreground">
                  {t('prayer.quickPick')}
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {QUICK_PICK_CITY_IDS.map((id) => {
                    const city = getBundledCityById(id)
                    if (!city) return null
                    return (
                      <Button
                        key={id}
                        variant="outline"
                        size="sm"
                        className="min-h-11"
                        onClick={() => handleSelectCity(city)}
                      >
                        <Search aria-hidden="true" className="size-3.5" />
                        {city.name}
                      </Button>
                    )
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Unavailable banner - the honest explanation, never invented times */}
            {dayQuery.data && dayQuery.data.status !== 'live' ? (
              <StatusBanner
                variant="warning"
                title={t('prayer.unavailableTitle')}
                description={t((dayQuery.data.messageKey ?? 'prayer.error.noSource') as TranslationKey)}
                action={
                  <Button
                    variant="outline"
                    className="h-11"
                    onClick={() => void dayQuery.refetch()}
                    disabled={dayQuery.isFetching}
                  >
                    {dayQuery.isFetching ? t('common.loading') : t('common.retry')}
                  </Button>
                }
              />
            ) : null}

            {/* Hero: next prayer + countdown */}
            <Card>
              <CardHeader>
                <div className="min-w-0 space-y-1">
                  <CardTitle className="truncate text-base">{locationLabel ?? '—'}</CardTitle>
                  <CardDescription className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span>{formattedDate ?? <Skeleton className="inline-block h-4 w-40" />}</span>
                    {record?.timeZone
                      ? utcOffsetLabel(locale, record.timeZone) ?? (
                          <span dir="ltr" className="text-xs">{record.timeZone.split('/').pop()}</span>
                        )
                      : null}
                  </CardDescription>
                </div>
                <CardAction>
                  <div className="flex items-center gap-2">
                    {/* Reminder - the PROMPT 13 entry point, near the schedule */}
                    <Button
                      variant={notifications.enabled && notificationPermission !== 'denied' ? 'default' : 'outline'}
                      size="sm"
                      className="min-h-11 gap-1.5"
                      onClick={() => setReminderOpen(true)}
                      aria-label={t('prayer.reminder.open')}
                    >
                      {reminderPermissionBlocked ? (
                        <TriangleAlert aria-hidden="true" className="size-4 text-gold" />
                      ) : (
                        <Bell aria-hidden="true" className="size-4" />
                      )}
                      {t('prayer.reminder.open')}
                    </Button>
                    {record?.isCached || dayQuery.data?.clientCache ? (
                      <Badge variant="outline" className="gap-1.5">
                        <Database aria-hidden="true" className="size-3" />
                        {t('prayer.cachedBadge')}
                      </Badge>
                    ) : null}
                    <PrayerSettingsDialog
                      open={settingsOpen}
                      onOpenChange={setSettingsOpen}
                      trigger={
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-11"
                          aria-label={t('prayer.openSettings')}
                        >
                          <Settings2 aria-hidden="true" className="size-4" />
                        </Button>
                      }
                    >
                      <PrayerSettingsSection
                        methods={methods}
                        methodMode={prayerSettings.methodMode}
                        calculationMethod={prayerSettings.calculationMethod}
                        onMethodModeChange={handleMethodModeChange}
                        onMethodChange={handleMethodChange}
                        resolvedDefault={resolvedDefaultForSettings}
                        countryName={effective.country ?? null}
                        madhhab={prayerSettings.madhhab}
                        onMadhhabChange={handleMadhhabChange}
                        highLatitudeRule={prayerSettings.highLatitudeRule}
                        onHighLatitudeRuleChange={handleHighLatitudeRuleChange}
                        timeZoneMode={prayerSettings.timeZoneMode}
                        manualTimeZone={prayerSettings.manualTimeZone}
                        autoTimeZone={effectiveTimeZone}
                        onTimeZoneModeChange={handleTimeZoneModeChange}
                        onManualTimeZoneChange={handleManualTimeZoneChange}
                        adjustments={prayerSettings.adjustments}
                        onAdjustmentChange={handleAdjustmentChange}
                        notifications={notifications}
                        onNotificationsChange={updatePrayerNotifications}
                        notificationPermission={notificationPermission}
                        onRequestNotifications={handleRequestNotifications}
                      />
                    </PrayerSettingsDialog>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-11"
                      aria-label={t('prayer.refresh')}
                      onClick={() => void dayQuery.refetch()}
                      disabled={dayQuery.isFetching}
                    >
                      {dayQuery.isFetching ? (
                        <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                      ) : (
                        <RefreshCw aria-hidden="true" className="size-4" />
                      )}
                    </Button>
                  </div>
                </CardAction>
              </CardHeader>
              <CardContent className="space-y-5">
                {hijriLabel ? (
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">{hijriLabel}</span>
                    {hijriSourceLabelKey ? (
                      <span className="ms-2 text-xs">({t(hijriSourceLabelKey)})</span>
                    ) : null}
                  </p>
                ) : null}

                {dayQuery.isLoading || (!record && dayQuery.isFetching) ? (
                  <div className="space-y-3">
                    <Skeleton className="h-8 w-40" />
                    <Skeleton className="h-12 w-56" />
                    <Skeleton className="h-2 w-full" />
                  </div>
                ) : next ? (
                  <div className="space-y-3">
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                      {t('prayer.nextPrayer')}
                      {next.recordDate !== dateInputValue ? ` · ${t('prayer.tomorrow')}` : ''}
                    </p>
                    <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                      <p className="text-2xl font-semibold text-foreground">
                        {t(PRAYER_ROW_LABELS[next.slot.key])}
                      </p>
                      <p className="text-2xl font-semibold tabular-nums text-primary">
                        {wallTime(locale, next.slot.iso, record?.timeZone ?? 'UTC')}
                      </p>
                      <p className="text-lg tabular-nums text-muted-foreground">
                        {formatCountdown(next.slot.instant.getTime() - now.getTime())}
                      </p>
                      {/* PROMPT 14 (WCAG 4.1.3): the second-by-second value is no
                          longer announced live; a minute-granular summary is
                          announced once per minute instead. */}
                      <span className="sr-only" aria-live="polite">
                        {t('prayer.countdownSr', {
                          minutes: formatNumber(
                            locale,
                            Math.max(0, Math.ceil((next.slot.instant.getTime() - now.getTime()) / 60000)),
                          ),
                          prayer: t(PRAYER_ROW_LABELS[next.slot.key]),
                        })}
                      </span>
                    </div>
                    <Progress value={Math.round(next.progress * 100)} aria-label={t('prayer.countdown')} />
                  </div>
                ) : record ? (
                  <p className="text-sm text-muted-foreground">
                    {viewingToday
                      ? t('prayer.countdownUnavailable')
                      : t('prayer.timesFor', { date: formattedDate ?? '' })}
                  </p>
                ) : (
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
                    <p>{t('prayer.noTimesToday')}</p>
                  </div>
                )}

                {/* Timeline */}
                <ul>
                  {PRAYER_ORDER.map((key) => {
                    const RowIcon = PRAYER_ROW_ICONS[key]
                    const value = record ? wallTime(locale, record[key], record.timeZone) : null
                    const isPassed = passedKeys.has(key)
                    const isNext = nextKey === key
                    const isSunrise = key === 'sunrise'
                    return (
                      <li
                        key={key}
                        className={`flex items-center justify-between gap-4 rounded-lg border-b border-border/60 py-3 last:border-b-0 ${
                          isNext ? '-mx-3 border-x border-t px-3 ring-1 ring-primary/30 first:rounded-t-xl last:rounded-b-xl' : ''
                        }`}
                      >
                        <span className="flex min-w-0 items-center gap-2.5">
                          <RowIcon
                            aria-hidden="true"
                            className={`size-4 shrink-0 ${isNext ? 'text-primary' : 'text-muted-foreground'}`}
                          />
                          <span
                            className={`truncate text-sm font-medium ${
                              isNext ? 'text-primary' : isPassed ? 'text-muted-foreground' : 'text-foreground'
                            }`}
                          >
                            {t(PRAYER_ROW_LABELS[key])}
                          </span>
                          {isSunrise ? (
                            <span className="shrink-0 rounded-full border border-border/70 px-1.5 py-0.5 text-[0.6875rem] font-normal leading-none text-muted-foreground">
                              {t('prayer.sunriseTag')}
                            </span>
                          ) : null}
                          {/* PROMPT 14 (WCAG 1.4.1): passed state is marked with
                              an icon + sr-only label, not color dimming alone. */}
                          {isPassed && !isNext ? (
                            <>
                              <Check aria-hidden="true" className="size-3.5 shrink-0 text-muted-foreground/70" />
                              <span className="sr-only">{t('prayer.passedLabel')}</span>
                            </>
                          ) : null}
                        </span>
                        <span
                          className={`shrink-0 text-sm tabular-nums ${
                            isNext ? 'font-semibold text-primary' : isPassed ? 'text-muted-foreground/70' : 'text-foreground'
                          }`}
                        >
                          {value ?? (dayQuery.isLoading ? <Skeleton className="h-5 w-14" /> : '—')}
                        </span>
                      </li>
                    )
                  })}
                </ul>
                <p className="text-xs leading-relaxed text-muted-foreground">{t('prayer.sunriseNote')}</p>

                {/* Date navigation */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-11"
                      aria-label={t('prayer.prevDay')}
                      onClick={() => setSelectedDate(shiftDateInput(dateInputValue, -1))}
                    >
                      <ChevronLeft aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                    </Button>
                    {selectedDate && selectedDate !== todayValue ? (
                      <Button
                        variant="outline"
                        className="min-h-11"
                        onClick={() => setSelectedDate('')}
                      >
                        {t('prayer.today')}
                      </Button>
                    ) : null}
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-11"
                      aria-label={t('prayer.nextDay')}
                      onClick={() => setSelectedDate(shiftDateInput(dateInputValue, 1))}
                    >
                      <ChevronRight aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="date"
                      value={dateInputValue}
                      onChange={(event) => setSelectedDate(event.target.value)}
                      aria-label={t('prayer.selectDate')}
                      className="h-11 rounded-md border border-input bg-transparent px-3 text-sm shadow-xs outline-none transition-[color,box-shadow] focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 dark:bg-input/30"
                      dir="ltr"
                    />
                    <Button
                      variant="outline"
                      className="min-h-11"
                      onClick={() => {
                        setDialogMonth(dateInputValue.slice(0, 7))
                        setMonthDialogOpen(true)
                      }}
                    >
                      <CalendarDays aria-hidden="true" className="size-4" />
                      {t('prayer.viewMonth')}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* PROMPT 14 (Nielsen #1): reminder health surfaced on the dashboard
                itself - blocked permission and missing local audio are shown as
                warnings instead of silently failing at prayer time. */}
            {reminderPermissionBlocked ? (
              <StatusBanner
                variant="warning"
                title={t('prayer.notificationsBlocked')}
                description={t('prayer.notificationsBlockedHint')}
              />
            ) : null}
            {reminderAdhanMissing ? (
              <StatusBanner variant="warning" title={t('prayer.reminder.title')} description={t('prayer.adhanNotDownloaded')} />
            ) : null}

            {/* Source transparency ("Prayer Time Information") */}
            {record && dayQuery.data?.status === 'live' && dayQuery.data.source ? (
              <PrayerSourceSection
                source={dayQuery.data.source}
                record={record}
                clientCache={dayQuery.data.clientCache ?? false}
                registry={
                  registryQuery.data?.registry?.map((entry) => ({
                    id: entry.id,
                    countryName: entry.countryName,
                    authorityName: entry.authorityName,
                    implementation: entry.implementation,
                    website: entry.website,
                  })) ?? []
                }
              />
            ) : (
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2.5">
                    <Clock aria-hidden="true" className="size-5 text-primary" />
                    <CardTitle className="text-base">{t('prayer.sourceSection')}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{t('prayer.sourcePending')}</p>
                </CardContent>
              </Card>
            )}

            {/* Location management */}
            <PrayerLocationSection
              latitude={effective.latitude}
              longitude={effective.longitude}
              isRequestingLocation={isRequesting}
              locationNotice={locationNotice}
              onUseCurrentLocation={() => void handleUseCurrentLocation()}
              onSelectCity={handleSelectCity}
              savedLocations={savedLocations}
              activeLocationId={activeLocationId}
              onSelectSaved={handleSelectSaved}
              onRemoveSaved={removeSavedLocation}
              onSaveCurrent={handleSaveCurrent}
              canSaveCurrent
              countryCode={effective.countryCode}
              jakimZone={isMalaysia ? prayerSettings.jakimZone : null}
              onJakimZoneChange={handleJakimZoneChange}
              jakimZones={isMalaysia ? JAKIM_ZONES : []}
              onOpenLocationSettings={() => void openLocationSettings()}
              canOpenLocationSettings={serviceEnabled === false}
              autoFlow={autoFlow}
              autoFlowErrorCode={autoFlowErrorCode}
            />
          </>
        )}
      </div>

      <PrayerMonthDialog
        open={monthDialogOpen}
        onOpenChange={setMonthDialogOpen}
        month={effectiveDialogMonth}
        onMonthChange={setDialogMonth}
        records={monthRecords}
        loading={monthQuery.isLoading || monthQuery.isFetching}
        onRetry={() => void monthQuery.refetch()}
        errorKey={
          monthQuery.data && monthQuery.data.status !== 'live'
            ? (monthQuery.data.messageKey ?? 'prayer.error.noSource')
            : null
        }
        locationLabel={locationLabel}
        timeZone={record?.timeZone ?? effectiveTimeZone}
        todayIso={todayValue}
      />

      {/* Adhan reminders (PROMPT 13) */}
      <AdhanReminderSheet open={reminderOpen} onOpenChange={setReminderOpen} permission={notificationPermission} />
    </PageContainer>
  )
}
