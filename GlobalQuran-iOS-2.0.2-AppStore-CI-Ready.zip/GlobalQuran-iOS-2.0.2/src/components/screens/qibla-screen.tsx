'use client'

/**
 * Qibla screen - accurate direction, honest sensors.
 *
 * Everything shown is real:
 * - The Qibla bearing and distance are great-circle computations
 *   (src/lib/qibla.ts) from the user's actual location - live GPS, or the
 *   saved location shared with the Prayer screen, or manually entered
 *   coordinates. No location, no bearing.
 * - The compass dial rotates only from real absolute sensor readings
 *   (src/services/sensors/compass-service.ts). Before the first trustworthy
 *   reading the dial shows the static, north-up "calculated direction" view.
 * - Magnetic headings (iOS compass) are corrected to true north with the
 *   WMM2025 declination for the user's location; the correction state is
 *   always disclosed, never silently applied or silently skipped.
 * - Sensor stability is monitored; the calibration guide appears only when
 *   readings are actually unstable (or on demand) - no nagging.
 */

import { useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import {
  BookOpenText,
  Compass,
  Crosshair,
  Info,
  Loader2,
  MapPin,
  MoveDiagonal,
  Navigation,
  Settings2,
  ShieldCheck,
  Smartphone,
  TriangleAlert,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useCompass } from '@/hooks/use-compass'
import { useGeolocation } from '@/hooks/use-geolocation'
import { usePreferencesStore } from '@/stores/preferences-store'
import {
  KAABA_COORDINATES,
  bearingDifference,
  distanceToKaaba,
  qiblaBearing,
  validateQiblaInputs,
} from '@/lib/qibla'
import { magneticDeclination } from '@/lib/geomagnetism'
import { formatNumber } from '@/utils/format'

import { PageContainer } from '@/components/design-system/page-container'
import { ScreenHeader } from '@/components/design-system/screen-header'
import { EmptyState } from '@/components/design-system/empty-state'
import { InfoRow } from '@/components/design-system/info-row'
import { StatusBanner } from '@/components/design-system/status-banner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------------ */
/* Tunables                                                            */
/* ------------------------------------------------------------------ */

/** Alignment tolerance in degrees for the "facing the Qibla" state. */
const ALIGNMENT_TOLERANCE_DEGREES = 5
/**
 * Sensor-reported accuracy (iOS ±degrees) above which the alignment state is
 * suppressed: with a calibration this poor, claiming "you are facing the Qibla"
 * would be dishonest. Android reports no accuracy value (null => allowed).
 */
const ALIGNMENT_MAX_SENSOR_ACCURACY = 25
/** GPS accuracy above which a low-accuracy notice is shown (meters). */
const LOW_LOCATION_ACCURACY_METERS = 100
/** Device tilt above which the "hold flatter" hint appears (degrees). */
const HIGH_TILT_DEGREES = 60

/* ------------------------------------------------------------------ */
/* Dial geometry (SVG viewBox units)                                   */
/* ------------------------------------------------------------------ */

const DIAL_VIEWBOX = 360
const DIAL_CENTER = 180
const DIAL_RING_RADIUS = 168
const DIAL_TICK_OUTER = 160
const DIAL_TICK_INNER_MINOR = 154
const DIAL_TICK_INNER_MID = 148
const DIAL_TICK_INNER_CARDINAL = 142
const DIAL_NUMBER_RADIUS = 128
const DIAL_CARDINAL_RADIUS = 128
const DIAL_KAABA_RADIUS = 92
const DIAL_KAABA_SIZE = 24
const DIAL_POINTER_SIZE = 12

/* Badge tints (design tokens only). */
const TINT_SUCCESS = 'border-success/40 bg-success/10 text-success'
const TINT_DESTRUCTIVE = 'border-destructive/40 bg-destructive/10 text-destructive'
const TINT_WARNING = 'border-gold/50 bg-gold/10 text-gold-foreground'
const TINT_MUTED = 'border-border bg-muted text-muted-foreground'

/** Parse a manually entered coordinate (accepts both "." and "," decimals). */
function parseCoordinateInput(value: string): number | null {
  const trimmed = value.trim()
  if (!trimmed) return null
  const parsed = Number.parseFloat(trimmed.replace(',', '.'))
  return Number.isFinite(parsed) ? parsed : null
}

/**
 * Tracks the OS "prefers-reduced-motion" setting (SSR-safe). SMIL
 * animations (<animate>/<animateMotion>) cannot be disabled from CSS, so
 * illustrations that use them render a static version when this is true.
 */
function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(() =>
    typeof window !== 'undefined' && typeof window.matchMedia === 'function'
      ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
      : false,
  )
  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return
    const query = window.matchMedia('(prefers-reduced-motion: reduce)')
    const onChange = () => setReduced(query.matches)
    query.addEventListener('change', onChange)
    return () => query.removeEventListener('change', onChange)
  }, [])
  return reduced
}

/* ------------------------------------------------------------------ */
/* Compass dial                                                        */
/* ------------------------------------------------------------------ */

interface QiblaDialProps {
  /** Rotation of the dial group: -(unwrapped heading) live, 0 static. */
  dialRotation: number
  /** Qibla bearing in degrees (null = no location, marker hidden). */
  bearing: number | null
  /** Live heading (null = static/calculated mode). */
  heading: number | null
  isAligned: boolean
  labels: { north: string; east: string; south: string; west: string; kaaba: string }
  locale: string
}

/**
 * The premium compass dial.
 *
 * Live mode: the whole dial (ticks, labels, north pointer, Kaaba marker)
 * rotates by -heading so dial-north points at physical north; the fixed
 * lubber line at the top marks the facing direction; the Kaaba marker sits
 * at the bearing on the rotating dial, so it reaches the lubber line exactly
 * when the device faces the Qibla.
 *
 * Static mode (no trustworthy heading): the dial stays north-up and the
 * Kaaba marker shows the calculated geographic angle from north.
 */
function QiblaDial({ dialRotation, bearing, heading, isAligned, labels, locale }: QiblaDialProps) {
  const { t } = useTranslation()

  const ticks: Array<{ angle: number; kind: 'minor' | 'mid' | 'cardinal' }> = []
  for (let angle = 0; angle < 360; angle += 5) {
    if (angle % 90 === 0) ticks.push({ angle, kind: 'cardinal' })
    else if (angle % 15 === 0) ticks.push({ angle, kind: 'mid' })
    else ticks.push({ angle, kind: 'minor' })
  }

  const cardinalLabels = [
    { angle: 0, text: labels.north },
    { angle: 90, text: labels.east },
    { angle: 180, text: labels.south },
    { angle: 270, text: labels.west },
  ]

  return (
    <svg
      viewBox={`0 0 ${DIAL_VIEWBOX} ${DIAL_VIEWBOX}`}
      role="img"
      aria-label={
        heading != null
          ? t('qibla.dialSummary', {
              bearing: formatNumber(locale, bearing ?? 0, { maximumFractionDigits: 1 }),
              heading: formatNumber(locale, heading, { maximumFractionDigits: 0 }),
            })
          : /* PROMPT 16 (honesty fix): never present a fabricated "heading
             * 0°" to screen readers when no live compass reading exists. */
            t('qibla.dialSummaryStatic', {
              bearing: formatNumber(locale, bearing ?? 0, { maximumFractionDigits: 1 }),
            })
      }
      className="h-full w-full select-none"
    >
      <defs>
        <filter id="qibla-dial-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Soft alignment halo (behind everything when aligned) */}
      <circle
        cx={DIAL_CENTER}
        cy={DIAL_CENTER}
        r={DIAL_RING_RADIUS - 6}
        className={cn('fill-success/0 transition-colors duration-500', isAligned && 'fill-success/10')}
      />

      {/* Static outer bezel */}
      <circle
        cx={DIAL_CENTER}
        cy={DIAL_CENTER}
        r={DIAL_RING_RADIUS}
        className={cn(
          'fill-muted/30 stroke-border transition-colors duration-500',
          isAligned && 'stroke-success/60',
        )}
        strokeWidth={2.5}
      />
      <circle
        cx={DIAL_CENTER}
        cy={DIAL_CENTER}
        r={DIAL_RING_RADIUS - 9}
        className="fill-none stroke-border/60"
        strokeWidth={1}
      />

      {/* Rotating dial */}
      <g
        style={{
          transform: `rotate(${dialRotation}deg)`,
          transformOrigin: `${DIAL_CENTER}px ${DIAL_CENTER}px`,
          transformBox: 'view-box',
          transition: 'transform 150ms linear',
        }}
        className="motion-reduce:transition-none"
      >
        {ticks.map((tick) => {
          const inner =
            tick.kind === 'cardinal'
              ? DIAL_TICK_INNER_CARDINAL
              : tick.kind === 'mid'
                ? DIAL_TICK_INNER_MID
                : DIAL_TICK_INNER_MINOR
          return (
            <line
              key={tick.angle}
              x1={DIAL_CENTER}
              y1={DIAL_CENTER - DIAL_TICK_OUTER}
              x2={DIAL_CENTER}
              y2={DIAL_CENTER - inner}
              transform={`rotate(${tick.angle} ${DIAL_CENTER} ${DIAL_CENTER})`}
              className={
                tick.kind === 'cardinal'
                  ? 'stroke-foreground'
                  : tick.kind === 'mid'
                    ? 'stroke-muted-foreground'
                    : 'stroke-muted-foreground/50'
              }
              strokeWidth={tick.kind === 'cardinal' ? 3 : tick.kind === 'mid' ? 2 : 1.2}
              strokeLinecap="round"
            />
          )
        })}

        {/* Degree numbers every 30°, cardinals replaced by letters */}
        {Array.from({ length: 12 }, (_, index) => {
          const angle = index * 30
          const cardinal = cardinalLabels.find((label) => label.angle === angle)
          const text = cardinal ? cardinal.text : String(angle)
          const isCardinal = cardinal != null
          return (
            <text
              key={angle}
              x={DIAL_CENTER}
              y={DIAL_CENTER - (isCardinal ? DIAL_CARDINAL_RADIUS : DIAL_NUMBER_RADIUS)}
              textAnchor="middle"
              dominantBaseline="central"
              transform={`rotate(${angle} ${DIAL_CENTER} ${DIAL_CENTER}) rotate(${-angle} ${DIAL_CENTER} ${DIAL_CENTER - DIAL_NUMBER_RADIUS})`}
              className={cn(
                'font-semibold',
                isCardinal ? 'fill-foreground text-[20px]' : 'fill-muted-foreground text-[11px]',
              )}
            >
              {text}
            </text>
          )
        })}

        {/* North pointer (rotates with the dial) */}
        <g transform={`rotate(0 ${DIAL_CENTER} ${DIAL_CENTER})`}>
          <title>{labels.north}</title>
          <path
            d={`M ${DIAL_CENTER} ${DIAL_CENTER - DIAL_TICK_OUTER - 26} L ${DIAL_CENTER - 9} ${DIAL_CENTER - DIAL_TICK_OUTER - 4} L ${DIAL_CENTER + 9} ${DIAL_CENTER - DIAL_TICK_OUTER - 4} Z`}
            className="fill-primary"
          />
        </g>

        {/* Kaaba marker at the Qibla bearing (on the rotating dial) */}
        {bearing != null ? (
          <g transform={`rotate(${bearing} ${DIAL_CENTER} ${DIAL_CENTER})`}>
            <title>{labels.kaaba}</title>
            {/* Rim pointer triangle (sits in the tick band) */}
            <path
              d={`M ${DIAL_CENTER} ${DIAL_CENTER - DIAL_RING_RADIUS + 18} L ${DIAL_CENTER - 6} ${DIAL_CENTER - DIAL_RING_RADIUS + 30} L ${DIAL_CENTER + 6} ${DIAL_CENTER - DIAL_RING_RADIUS + 30} Z`}
              className="fill-gold"
            />
            {/* Kaaba cube with kiswa band */}
            <g
              transform={`translate(${DIAL_CENTER - DIAL_KAABA_SIZE / 2} ${DIAL_CENTER - DIAL_KAABA_RADIUS - DIAL_KAABA_SIZE / 2})`}
            >
              <rect
                width={DIAL_KAABA_SIZE}
                height={DIAL_KAABA_SIZE}
                rx={3}
                className="fill-foreground stroke-border"
                strokeWidth={1.5}
              />
              <rect
                x={1.5}
                y={DIAL_KAABA_SIZE * 0.32}
                width={DIAL_KAABA_SIZE - 3}
                height={DIAL_KAABA_SIZE * 0.2}
                className="fill-gold"
              />
            </g>
          </g>
        ) : null}
      </g>

      {/* Fixed lubber line (marks the facing direction in live mode) */}
      {heading != null ? (
        <g className={cn(isAligned && 'filter-[url(#qibla-dial-glow)]')}>
          <title>Direction you are facing</title>
          <path
            d={`M ${DIAL_CENTER} ${DIAL_CENTER - DIAL_RING_RADIUS + 20} L ${DIAL_CENTER - 10} ${DIAL_CENTER - DIAL_RING_RADIUS - 2} L ${DIAL_CENTER + 10} ${DIAL_CENTER - DIAL_RING_RADIUS - 2} Z`}
            className={cn('transition-colors duration-500', isAligned ? 'fill-success' : 'fill-foreground')}
          />
        </g>
      ) : null}
    </svg>
  )
}

/* ------------------------------------------------------------------ */
/* Calibration guide                                                   */
/* ------------------------------------------------------------------ */

/** Figure-eight illustration + the three calm steps. */
function CalibrationGuide() {
  const { t } = useTranslation()
  const reducedMotion = usePrefersReducedMotion()

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="mx-auto shrink-0 sm:mx-0" aria-hidden="true">
          <svg viewBox="0 0 140 84" className="h-24 w-40">
            {/* Figure-8 path (lemniscate). SMIL cannot be paused from CSS,
                so the figure is drawn static under reduced motion. */}
            <path
              d="M 70 42 C 70 14, 118 14, 118 42 C 118 70, 70 70, 70 42 C 70 14, 22 14, 22 42 C 22 70, 70 70, 70 42 Z"
              className="fill-none stroke-primary/70"
              strokeWidth={3}
              strokeLinecap="round"
              strokeDasharray="14 10"
            >
              {reducedMotion ? null : (
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="48"
                  dur="1.6s"
                  repeatCount="indefinite"
                />
              )}
            </path>
            {/* Phone dot travelling along the 8 (parked at the crossing point
                when the user prefers reduced motion) */}
            {reducedMotion ? (
              <circle r={5} cx={70} cy={42} className="fill-primary" />
            ) : (
              <circle r={5} className="fill-primary">
                <animateMotion dur="3.2s" repeatCount="indefinite" path="M 70 42 C 70 14, 118 14, 118 42 C 118 70, 70 70, 70 42 C 70 14, 22 14, 22 42 C 22 70, 70 70, 70 42 Z" />
              </circle>
            )}
          </svg>
        </div>
        <ol className="space-y-2.5 text-sm leading-relaxed text-muted-foreground">
          <li className="flex gap-2.5">
            <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
              1
            </span>
            {t('qibla.calibrationStep1')}
          </li>
          <li className="flex gap-2.5">
            <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
              2
            </span>
            {t('qibla.calibrationStep2')}
          </li>
          <li className="flex gap-2.5">
            <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
              3
            </span>
            {t('qibla.calibrationStep3')}
          </li>
        </ol>
      </div>
      <p className="text-xs text-muted-foreground">{t('qibla.calibrationDoneHint')}</p>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Screen                                                              */
/* ------------------------------------------------------------------ */

export function QiblaScreen() {
  const { t, locale } = useTranslation()
  const {
    permission,
    coordinates,
    errorCode,
    isRequesting,
    request,
    openSettings: openLocationSettings,
    serviceEnabled,
  } = useGeolocation()

  const prayerSettings = usePreferencesStore((s) => s.prayerSettings)
  const updatePrayerSettings = usePreferencesStore((s) => s.updatePrayerSettings)

  /* ---------------------------------------------------------------- */
  /* Location: live coordinates preferred, persisted ones as fallback  */
  /* ---------------------------------------------------------------- */

  const activeLatitude = coordinates?.latitude ?? prayerSettings.latitude
  const activeLongitude = coordinates?.longitude ?? prayerSettings.longitude
  const usingLiveLocation = coordinates != null
  const activeAccuracy = coordinates?.accuracy ?? null

  const qiblaValidation = useMemo(
    () => validateQiblaInputs(activeLatitude, activeLongitude, activeAccuracy),
    [activeLatitude, activeLongitude, activeAccuracy],
  )

  const qiblaBearingValue =
    qiblaValidation.ok && activeLatitude != null && activeLongitude != null
      ? qiblaBearing(activeLatitude, activeLongitude)
      : null
  const kaabaDistance =
    qiblaValidation.ok && activeLatitude != null && activeLongitude != null
      ? distanceToKaaba(activeLatitude, activeLongitude)
      : null
  const hasLocation = qiblaBearingValue != null

  /* ---------------------------------------------------------------- */
  /* Compass                                                           */
  /* ---------------------------------------------------------------- */

  const compassLocation = useMemo(
    () =>
      activeLatitude != null && activeLongitude != null
        ? { latitude: activeLatitude, longitude: activeLongitude }
        : null,
    [activeLatitude, activeLongitude],
  )
  const compass = useCompass(compassLocation)

  const heading = compass.heading
  const formattedHeading =
    heading != null ? `${formatNumber(locale, heading, { maximumFractionDigits: 0 })}°` : null

  // The dial rotates only from real readings; without them it stays north-up
  // and shows the calculated bearing (honest static mode).
  const dialRotation = heading != null && compass.unwrappedHeading != null ? -compass.unwrappedHeading : 0

  const isAligned =
    heading != null &&
    qiblaBearingValue != null &&
    bearingDifference(heading, qiblaBearingValue) <= ALIGNMENT_TOLERANCE_DEGREES &&
    // Never claim alignment while the reading stream is unreliable: the
    // sensor must be steady, and when the platform reports its own accuracy
    // it must be within the honest-alignment limit.
    compass.stability === 'steady' &&
    (compass.sensorAccuracy == null || compass.sensorAccuracy <= ALIGNMENT_MAX_SENSOR_ACCURACY)

  /* Declination for the info card (the iOS correction uses the same model). */
  const declination = useMemo(() => {
    if (activeLatitude == null || activeLongitude == null) return null
    try {
      return magneticDeclination(activeLatitude, activeLongitude, 0, new Date())
    } catch {
      return null
    }
  }, [activeLatitude, activeLongitude])

  const compassUsable =
    compass.status === 'active' || compass.status === 'starting' || compass.status === 'idle'
  const compassUnusable = compass.status === 'unavailable' || compass.status === 'denied'
  const relativeOnly =
    compass.status === 'active' &&
    heading == null &&
    compass.sourceKind === 'relative-orientation'
  // Desktops: the API exists but no sensor ever fires. After the hook's
  // timeout this is an honest "no live compass on this device".
  const noSensorData = compass.noSensorData
  const showManualOrientation =
    compassUnusable || (compass.status === 'idle' && heading == null) || relativeOnly || noSensorData

  /* Calibration guide: auto when unstable, manual toggle otherwise. */
  const [showGuide, setShowGuide] = useState(false)
  const unstable = compass.stability === 'unstable' || compass.stability === 'stale'
  const showCalibration = showGuide || (unstable && compass.status === 'active')

  const lowAccuracy =
    activeAccuracy != null && activeAccuracy > LOW_LOCATION_ACCURACY_METERS
  const showTiltHint =
    compass.status === 'active' && compass.tilt != null && compass.tilt > HIGH_TILT_DEGREES

  /* ---------------------------------------------------------------- */
  /* Dial center + chip states                                         */
  /* ---------------------------------------------------------------- */

  const dialChip: { label: string; className: string } | null =
    compass.status === 'unavailable' || compass.status === 'denied'
      ? { label: t('qibla.compassUnavailable'), className: TINT_MUTED }
      : compass.status === 'active' && heading != null
        ? compass.stability === 'unstable'
          ? { label: t('qibla.sensorUnstable'), className: TINT_DESTRUCTIVE }
          : compass.stability === 'stale'
            ? { label: t('qibla.sensorStale'), className: TINT_WARNING }
            : { label: t('qibla.statusReady'), className: TINT_SUCCESS }
        : compass.status === 'active' && heading == null
          ? noSensorData
            ? { label: t('qibla.noSensorData'), className: TINT_WARNING }
            : relativeOnly
              ? { label: t('qibla.compassUnavailable'), className: TINT_MUTED }
              : { label: t('qibla.statusWaitingSensorData'), className: TINT_MUTED }
          : compass.status === 'starting'
            ? { label: t('qibla.statusWaitingSensorData'), className: TINT_MUTED }
            : compass.status === 'idle'
              ? { label: t('qibla.sensorsNotDetermined'), className: TINT_MUTED }
              : null

  /* ---------------------------------------------------------------- */
  /* Status badges                                                     */
  /* ---------------------------------------------------------------- */

  const locationBadge =
    permission === 'granted' && coordinates
      ? { label: t('qibla.locationPermissionGranted'), className: TINT_SUCCESS }
      : permission === 'denied'
        ? { label: t('qibla.locationPermissionDenied'), className: TINT_DESTRUCTIVE }
        : permission === 'prompt'
          ? { label: t('qibla.locationPermissionNotDetermined'), className: TINT_MUTED }
          : { label: t('common.unavailable'), className: TINT_MUTED }

  const compassBadge =
    compass.status === 'active' && heading != null
      ? unstable
        ? { label: t('qibla.sensorUnstable'), className: TINT_DESTRUCTIVE }
        : { label: t('qibla.sensorsAvailable'), className: TINT_SUCCESS }
      : compass.status === 'starting'
        ? { label: t('common.pending'), className: TINT_WARNING }
        : compass.status === 'denied'
          ? { label: t('qibla.sensorPermissionDenied'), className: TINT_DESTRUCTIVE }
          : compass.status === 'unavailable'
            ? { label: t('qibla.sensorsUnavailable'), className: TINT_MUTED }
            : { label: t('qibla.sensorsNotDetermined'), className: TINT_MUTED }

  /* ---------------------------------------------------------------- */
  /* Manual location                                                   */
  /* ---------------------------------------------------------------- */

  const [latitudeDraft, setLatitudeDraft] = useState<string | null>(null)
  const [longitudeDraft, setLongitudeDraft] = useState<string | null>(null)

  const latitudeInputValue =
    latitudeDraft ?? (prayerSettings.latitude != null ? String(prayerSettings.latitude) : '')
  const longitudeInputValue =
    longitudeDraft ?? (prayerSettings.longitude != null ? String(prayerSettings.longitude) : '')

  const parsedLatitude = parseCoordinateInput(latitudeInputValue)
  const parsedLongitude = parseCoordinateInput(longitudeInputValue)
  const latitudeValid = parsedLatitude != null && parsedLatitude >= -90 && parsedLatitude <= 90
  const longitudeValid =
    parsedLongitude != null && parsedLongitude >= -180 && parsedLongitude <= 180
  const canApplyLocation = latitudeValid && longitudeValid
  // Explain WHY Apply is disabled (WCAG 3.3.1): the invalid-coordinates hint
  // is shown only while the inputs are invalid AND at least one is non-empty.
  const manualCoordsInvalid =
    !canApplyLocation &&
    (latitudeInputValue.trim().length > 0 || longitudeInputValue.trim().length > 0)

  const handleApplyLocation = () => {
    if (parsedLatitude == null || parsedLongitude == null) return
    updatePrayerSettings({ latitude: parsedLatitude, longitude: parsedLongitude })
    setLatitudeDraft(null)
    setLongitudeDraft(null)
    toast(t('common.updated'))
  }

  /* ---------------------------------------------------------------- */
  /* Formatted real values (computed only from real data)              */
  /* ---------------------------------------------------------------- */

  const formattedBearing =
    qiblaBearingValue != null
      ? t('qibla.degreesFromNorth', {
          degrees: formatNumber(locale, qiblaBearingValue, { maximumFractionDigits: 1 }),
        })
      : null
  const formattedDistance =
    kaabaDistance != null
      ? t('qibla.kmAway', {
          distance: formatNumber(locale, kaabaDistance, {
            maximumFractionDigits: kaabaDistance < 10 ? 1 : 0,
          }),
        })
      : null
  const formattedAccuracy = activeAccuracy
    ? t('qibla.accuracyMeters', {
        meters: formatNumber(locale, activeAccuracy, { maximumFractionDigits: 0 }),
      })
    : null

  const headingReferenceLabel =
    compass.headingReference === 'true_north'
      ? t('qibla.trueNorthHeading')
      : compass.headingReference === 'magnetic'
        ? t('qibla.magneticUncorrectedHeading')
        : null

  const declinationText =
    declination != null
      ? declination.declination >= 0
        ? t('qibla.declinationValueEast', {
            value: formatNumber(locale, declination.declination, { maximumFractionDigits: 1 }),
          })
        : t('qibla.declinationValueWest', {
            value: formatNumber(locale, Math.abs(declination.declination), {
              maximumFractionDigits: 1,
            }),
          })
      : null

  const dialLabels = {
    north: t('qibla.northLabel'),
    east: t('qibla.eastLabel'),
    south: t('qibla.southLabel'),
    west: t('qibla.westLabel'),
    kaaba: t('qibla.kaabaLabel'),
  }

  return (
    <PageContainer wide>
      <ScreenHeader title={t('qibla.title')} subtitle={t('qibla.subtitle')} icon={Compass} />

      <div className="space-y-6">
        {/* Low location accuracy notice (only when it actually is low) */}
        {lowAccuracy && formattedAccuracy ? (
          <div
            role="status"
            className="flex items-start gap-3 rounded-xl border border-gold/40 bg-gold/10 p-4 text-sm text-foreground"
          >
            <TriangleAlert aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-gold" />
            <p>
              {t('qibla.locationAccuracyLow', {
                meters: formatNumber(locale, activeAccuracy ?? 0, { maximumFractionDigits: 0 }),
              })}
            </p>
          </div>
        ) : null}

        {/* Specific validation problems - honest explanations instead of a
            generic "set your location" when a location IS set but unusable */}
        {qiblaValidation.problem === 'zero_accuracy_impossible' ? (
          <StatusBanner
            variant="warning"
            title={t('qibla.accuracyProblemTitle')}
            description={t('qibla.accuracyProblemBody', {
              meters: formatNumber(locale, activeAccuracy ?? 0, { maximumFractionDigits: 0 }),
            })}
          />
        ) : null}
        {qiblaValidation.problem === 'inside_kaaba' ? (
          <StatusBanner
            variant="warning"
            title={t('qibla.atKaabaTitle')}
            description={t('qibla.atKaabaBody')}
          />
        ) : null}

        {/* Compass dial */}
        <Card>
          <CardContent className="flex flex-col items-center gap-5 p-6">
            <div className="relative mx-auto aspect-square w-full max-w-[340px]">
              <QiblaDial
                dialRotation={dialRotation}
                bearing={qiblaBearingValue}
                heading={heading}
                isAligned={isAligned}
                labels={dialLabels}
                locale={locale}
              />

              {/* Center readout (HTML overlay for crisp, locale-aware numbers) */}
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center px-14 text-center">
                {hasLocation ? (
                  formattedHeading != null ? (
                    <>
                      <span dir="ltr" className="text-4xl font-semibold tabular-nums text-foreground">
                        {formattedHeading}
                      </span>
                      <span className="mt-1 max-w-[11rem] text-xs leading-snug text-muted-foreground">
                        {headingReferenceLabel ?? t('qibla.heading')}
                      </span>
                    </>
                  ) : (
                    <>
                      <span dir="ltr" className="text-3xl font-semibold tabular-nums text-primary">
                        {formatNumber(locale, qiblaBearingValue ?? 0, { maximumFractionDigits: 1 })}°
                      </span>
                      <span className="mt-1 max-w-[11rem] text-xs leading-snug text-muted-foreground">
                        {t('qibla.qiblaBearing')}
                      </span>
                    </>
                  )
                ) : (
                  <span className="text-3xl font-semibold text-muted-foreground">—</span>
                )}
              </div>
            </div>

            {/* Live status chip */}
            {dialChip ? (
              <Badge variant="outline" className={cn('whitespace-normal text-center', dialChip.className)}>
                {dialChip.label}
              </Badge>
            ) : null}

            {/* Alignment feedback - only from real readings */}
            {isAligned ? (
              <Badge className="border-success/40 bg-success/10 px-4 py-1.5 text-sm font-semibold text-success">
                {t('qibla.alignedTitle')}
              </Badge>
            ) : null}

            {/* Tilt guidance (only while the compass runs and tilt is known) */}
            {showTiltHint ? (
              <p className="flex items-center gap-2 text-xs text-muted-foreground">
                <Smartphone aria-hidden="true" className="size-4 shrink-0" />
                <span>
                  {t('qibla.tiltHint')} · {t('qibla.tiltHintDetail')}
                </span>
              </p>
            ) : null}

            {/* Quick actions under the dial */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Button
                variant="outline"
                className="min-h-11"
                onClick={() => void request()}
                disabled={isRequesting}
              >
                {isRequesting ? (
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                ) : (
                  <MapPin aria-hidden="true" className="size-4" />
                )}
                {isRequesting ? t('qibla.statusSearchingLocation') : t('qibla.requestLocation')}
              </Button>
              {errorCode && !isRequesting && coordinates == null ? (
                <div role="alert" className="w-full space-y-2">
                  <p className="w-full text-center text-sm text-destructive">
                    {t(`geo.error.${errorCode}`)}
                  </p>
                  {errorCode === 'service-disabled' && serviceEnabled === false ? (
                    <Button variant="outline" size="sm" className="min-h-9" onClick={() => void openLocationSettings()}>
                      <Settings2 aria-hidden="true" className="size-4" />
                      {t('geo.locationSettings.open')}
                    </Button>
                  ) : null}
                </div>
              ) : null}
              {compass.status === 'active' ? (
                <Button variant="outline" className="min-h-11" onClick={compass.stop}>
                  <Compass aria-hidden="true" className="size-4" />
                  {t('qibla.stopCompass')}
                </Button>
              ) : (
                <Button
                  variant="outline"
                  className="min-h-11"
                  onClick={() => void compass.start()}
                  disabled={compass.status === 'starting' || compass.status === 'unavailable'}
                >
                  {compass.status === 'starting' ? (
                    <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                  ) : (
                    <Compass aria-hidden="true" className="size-4" />
                  )}
                  {compass.status === 'starting' ? t('common.loading') : t('qibla.enableSensors')}
                </Button>
              )}
            </div>

            {/* Live vs calculated legend */}
            {hasLocation ? (
              <p className="flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
                <span aria-hidden="true" className="inline-block size-3 rounded-[3px] border border-border bg-foreground">
                  <span className="sr-only">{t('qibla.kaabaLabel')}</span>
                </span>
                {t('qibla.kaabaLabel')}
                <span aria-hidden="true" className="text-border">·</span>
                <span aria-hidden="true" className="inline-block size-0 border-x-[5px] border-b-[9px] border-x-transparent border-b-primary">
                  <span className="sr-only">{t('qibla.northLabel')}</span>
                </span>
                {t('qibla.northLabel')}
                {heading != null ? (
                  <>
                    <span aria-hidden="true" className="text-border">·</span>
                    {t('qibla.screenRotationNote')}
                  </>
                ) : null}
              </p>
            ) : null}
          </CardContent>
        </Card>

        {/* Key figures */}
        {hasLocation && formattedBearing != null && formattedDistance != null ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Navigation aria-hidden="true" className="size-4 text-primary" />
                  <p className="text-xs font-medium">{t('qibla.qiblaBearing')}</p>
                </div>
                <p dir="ltr" className="mt-2 text-lg font-semibold tabular-nums text-foreground">
                  {formattedBearing}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin aria-hidden="true" className="size-4 text-primary" />
                  <p className="text-xs font-medium">{t('qibla.qiblaDistance')}</p>
                </div>
                <p dir="ltr" className="mt-2 text-lg font-semibold tabular-nums text-foreground">
                  {formattedDistance}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Crosshair aria-hidden="true" className="size-4 text-primary" />
                  <p className="text-xs font-medium">{t('qibla.accuracy')}</p>
                </div>
                <p dir="ltr" className="mt-2 text-lg font-semibold tabular-nums text-foreground">
                  {formattedAccuracy ?? '—'}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {usingLiveLocation
                    ? t('qibla.usingLiveLocation')
                    : t('qibla.usingSavedLocation')}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Compass aria-hidden="true" className="size-4 text-primary" />
                  <p className="text-xs font-medium">{t('qibla.heading')}</p>
                </div>
                <p dir="ltr" className="mt-2 text-lg font-semibold tabular-nums text-foreground">
                  {formattedHeading ?? '—'}
                </p>
                {headingReferenceLabel ? (
                  <p className="mt-1 text-xs text-muted-foreground">{headingReferenceLabel}</p>
                ) : null}
              </CardContent>
            </Card>
          </div>
        ) : null}

        {/* Location & sensors */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-2.5">
                  <MapPin aria-hidden="true" className="size-5 shrink-0 text-primary" />
                  <CardTitle className="text-base">{t('qibla.locationPermission')}</CardTitle>
                </div>
                <Badge
                  variant="outline"
                  className={cn('whitespace-normal text-start', locationBadge.className)}
                >
                  {locationBadge.label}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {coordinates ? (
                <p className="text-sm tabular-nums text-muted-foreground">
                  {t('common.latitude')}:{' '}
                  {formatNumber(locale, coordinates.latitude, { maximumFractionDigits: 4 })}
                  {' · '}
                  {t('common.longitude')}:{' '}
                  {formatNumber(locale, coordinates.longitude, { maximumFractionDigits: 4 })}
                  {formattedAccuracy ? ` · ${formattedAccuracy}` : ''}
                </p>
              ) : null}
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('qibla.locationPermissionNote')}
              </p>
              <Button
                variant="outline"
                className="min-h-11"
                onClick={() => void request()}
                disabled={isRequesting}
              >
                {isRequesting ? (
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                ) : null}
                {isRequesting ? t('common.loading') : t('qibla.requestLocation')}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-2.5">
                  <Smartphone aria-hidden="true" className="size-5 shrink-0 text-primary" />
                  <CardTitle className="text-base">{t('qibla.sensors')}</CardTitle>
                </div>
                <Badge
                  variant="outline"
                  className={cn('whitespace-normal text-start', compassBadge.className)}
                >
                  {compassBadge.label}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('qibla.sensorsNote')}
              </p>
              <dl>
                {compass.sensorAccuracy != null ? (
                  <InfoRow
                    label={t('qibla.sensorAccuracyLabel')}
                    value={t('qibla.sensorAccuracyValue', {
                      value: formatNumber(locale, compass.sensorAccuracy, {
                        maximumFractionDigits: 1,
                      }),
                    })}
                  />
                ) : null}
                {declinationText != null ? (
                  <InfoRow
                    label={t('qibla.declinationTitle')}
                    value={<span className="tabular-nums">{declinationText}</span>}
                  />
                ) : null}
              </dl>
              {declination != null ? (
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {t('qibla.declinationModelNote')}
                  {compass.declinationApplied
                    ? t('qibla.declinationAppliedNote')
                    : compass.headingReference === 'magnetic'
                      ? t('qibla.declinationUnavailableNote')
                      : null}
                  {declination.outsideValidityPeriod
                    ? ` ${t('qibla.declinationExtrapolated')}`
                    : ''}
                </p>
              ) : null}
              {relativeOnly ? (
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {t('qibla.relativeOrientationNote')}
                </p>
              ) : null}
              <div>
                {compass.status === 'active' ? (
                  <Button variant="outline" className="min-h-11" onClick={compass.stop}>
                    {t('qibla.stopCompass')}
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    className="min-h-11"
                    onClick={() => void compass.start()}
                    disabled={compass.status === 'starting' || compass.status === 'unavailable'}
                  >
                    {compass.status === 'starting' ? (
                      <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                    ) : null}
                    {compass.status === 'starting' ? t('common.loading') : t('qibla.enableSensors')}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Calibration - automatic when unstable, manual toggle otherwise */}
        {compassUsable ? (
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-2.5">
                  <MoveDiagonal aria-hidden="true" className="size-5 shrink-0 text-primary" />
                  <CardTitle className="text-base">{t('qibla.calibrationGuideTitle')}</CardTitle>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="min-h-11"
                  onClick={() => setShowGuide((open) => !open)}
                  aria-expanded={showCalibration}
                >
                  {showCalibration ? t('qibla.hideCalibrationGuide') : t('qibla.showCalibrationGuide')}
                </Button>
              </div>
              <CardDescription>{t('qibla.calibrationIntro')}</CardDescription>
            </CardHeader>
            {showCalibration ? (
              <CardContent className="space-y-4">
                <Separator />
                <CalibrationGuide />
              </CardContent>
            ) : null}
          </Card>
        ) : null}

        {/* Manual orientation - the honest no-compass path (no API, no
            sensors firing, permission denied, or relative-only events) */}
        {showManualOrientation ? (
          <Card>
            <CardHeader>
              <div className="flex min-w-0 items-center gap-2.5">
                <BookOpenText aria-hidden="true" className="size-5 shrink-0 text-primary" />
                <CardTitle className="text-base">{t('qibla.manualOrientationTitle')}</CardTitle>
              </div>
              <CardDescription>
                {noSensorData ? t('qibla.noSensorDataTitle') : t('qibla.noCompassTitle')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm leading-relaxed text-muted-foreground">
                {noSensorData ? t('qibla.noSensorDataBody') : t('qibla.noCompassBody')}
              </p>
              <Separator />
              <p className="text-sm leading-relaxed text-muted-foreground">
                {t('qibla.manualOrientationBody')}
              </p>
              {qiblaBearingValue != null ? (
                <p
                  dir="ltr"
                  className="rounded-xl border border-primary/30 bg-primary/5 p-4 text-center text-2xl font-semibold tabular-nums text-primary"
                >
                  {formatNumber(locale, qiblaBearingValue, { maximumFractionDigits: 1 })}°
                </p>
              ) : null}
            </CardContent>
          </Card>
        ) : null}

        {/* Manual location + direction details */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <div className="flex min-w-0 items-center gap-2.5">
                <Crosshair aria-hidden="true" className="size-5 text-primary" />
                <CardTitle className="text-base">{t('qibla.manualLocationTitle')}</CardTitle>
              </div>
              <CardDescription>{t('qibla.manualLocationDescription')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="qibla-latitude">{t('common.latitude')}</Label>
                  <Input
                    id="qibla-latitude"
                    type="number"
                    dir="ltr"
                    inputMode="decimal"
                    step="any"
                    min={-90}
                    max={90}
                    value={latitudeInputValue}
                    onChange={(event) => setLatitudeDraft(event.target.value)}
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="qibla-longitude">{t('common.longitude')}</Label>
                  <Input
                    id="qibla-longitude"
                    type="number"
                    dir="ltr"
                    inputMode="decimal"
                    step="any"
                    min={-180}
                    max={180}
                    value={longitudeInputValue}
                    onChange={(event) => setLongitudeDraft(event.target.value)}
                    className="h-11"
                  />
                </div>
              </div>
              {manualCoordsInvalid ? (
                <p role="alert" className="text-xs font-medium text-destructive">
                  {t('qibla.manualInvalid')}
                </p>
              ) : null}
              <div>
                <Button onClick={handleApplyLocation} disabled={!canApplyLocation} className="min-h-11">
                  {t('qibla.applyLocation')}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex min-w-0 items-center gap-2.5">
                <Navigation aria-hidden="true" className="size-5 text-primary" />
                <CardTitle className="text-base">{t('qibla.subtitle')}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {hasLocation && formattedBearing != null && formattedDistance != null ? (
                <div className="space-y-3">
                  <dl>
                    <InfoRow label={t('qibla.qiblaBearing')} value={formattedBearing} />
                    <InfoRow label={t('qibla.qiblaDistance')} value={formattedDistance} />
                    {formattedHeading != null ? (
                      <InfoRow
                        label={t('qibla.heading')}
                        value={
                          <span>
                            <span className="tabular-nums">{formattedHeading}</span>
                            {headingReferenceLabel ? (
                              <span className="block text-xs font-normal text-muted-foreground">
                                {headingReferenceLabel}
                              </span>
                            ) : null}
                          </span>
                        }
                      />
                    ) : null}
                    {compass.sensorAccuracy != null ? (
                      <InfoRow
                        label={t('qibla.sensorAccuracyLabel')}
                        value={t('qibla.sensorAccuracyValue', {
                          value: formatNumber(locale, compass.sensorAccuracy, {
                            maximumFractionDigits: 1,
                          }),
                        })}
                      />
                    ) : null}
                  </dl>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    {t('qibla.accuracyDisclaimer')}
                  </p>
                </div>
              ) : (
                <EmptyState
                  icon={MapPin}
                  title={t('qibla.locationNeeded')}
                  action={
                    <Button
                      variant="outline"
                      className="min-h-11"
                      onClick={() => void request()}
                      disabled={isRequesting}
                    >
                      {isRequesting ? (
                        <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                      ) : null}
                      {isRequesting ? t('common.loading') : t('qibla.requestLocation')}
                    </Button>
                  }
                />
              )}
            </CardContent>
          </Card>
        </div>

        {/* Transparency: how this direction is computed */}
        <Card>
          <CardHeader>
            <div className="flex min-w-0 items-center gap-2.5">
              <ShieldCheck aria-hidden="true" className="size-5 shrink-0 text-primary" />
              <CardTitle className="text-base">{t('qibla.transparencyTitle')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-xl border border-border bg-muted/30 p-4">
              <p className="text-sm font-medium text-foreground">{t('qibla.transparencyKaaba')}</p>
              <p dir="ltr" className="mt-1 text-sm tabular-nums text-muted-foreground">
                {formatNumber(locale, KAABA_COORDINATES.latitude, { maximumFractionDigits: 4 })}°N,{' '}
                {formatNumber(locale, KAABA_COORDINATES.longitude, { maximumFractionDigits: 4 })}°E
              </p>
              <p className="mt-1 text-xs text-muted-foreground">{t('qibla.transparencyKaabaEvidence')}</p>
            </div>
            <div className="space-y-3">
              {([
                { label: t('qibla.transparencyBearing'), value: t('qibla.transparencyBearingValue') },
                { label: t('qibla.transparencyDistance'), value: t('qibla.transparencyDistanceValue') },
                {
                  label: t('qibla.transparencyLiveVsCalculated'),
                  value: t('qibla.transparencyLiveVsCalculatedValue'),
                },
              ] as const).map((row) => (
                <div key={row.label} className="space-y-1">
                  <p className="text-sm font-medium text-foreground">{row.label}</p>
                  <p className="text-sm leading-relaxed text-muted-foreground">{row.value}</p>
                </div>
              ))}
            </div>
            <div className="flex items-start gap-3 rounded-xl border border-border bg-muted/40 p-4">
              <Info aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-primary" />
              <div className="space-y-2 text-xs leading-relaxed text-muted-foreground">
                <p>{t('qibla.accuracyDisclaimer')}</p>
                <p>{t('qibla.nativeNote')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  )
}
