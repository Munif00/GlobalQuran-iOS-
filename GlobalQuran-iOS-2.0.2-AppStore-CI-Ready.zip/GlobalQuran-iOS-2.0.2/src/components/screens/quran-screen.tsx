'use client'

/**
 * Quran & Translations library screen.
 *
 * - When the reader is open (reader store), this screen renders the ReaderView
 *   in place of the library.
 * - "The Holy Quran" hero card: read the original text right away, or jump to
 *   the translation library below.
 * - Library categories (Prompt 3 §9): All / Downloaded / Recently opened /
 *   Available offline / Imported files.
 * - Discovery (§2/§3): prominent search (language name - native or English -
 *   title, translator, publisher), quick chips for widely used languages
 *   that actually exist in the catalog, a full language selector and
 *   sorting. Only real catalog records are ever listed.
 * - Trust (§4): the known source is named consistently ("via QuranEnc");
 *   the library never labels translations as untrusted. Details and source
 *   information live in the per-translation dialog.
 * - Downloads (§6/§7): one obvious "Download" action per translation stores
 *   a complete offline pack on the device; cards and the details dialog
 *   show the real offline status computed from IndexedDB.
 */

import { useMemo, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  ArrowDownToLine,
  BookOpen,
  ExternalLink,
  HeartHandshake,
  LibraryBig,
  Search,
} from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { ReaderView } from '@/components/quran/reader-view'
import { LanguagePicker } from '@/components/quran/language-picker'
import { TranslationCard } from '@/components/quran/translation-card'
import { TranslationDetailDialog } from '@/components/quran/translation-detail-dialog'
import { ImportedFileList } from '@/components/quran/imported-file-list'
import { getTranslationsCatalog } from '@/services/api/catalog-api'
import {
  getFileStorage,
  type StoredFileMetadata,
} from '@/services/storage/local-file-storage'
import { useOfflinePacks } from '@/hooks/use-offline-packs'
import { useNavigationStore } from '@/stores/navigation-store'
import { useReaderStore } from '@/stores/reader-store'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { useViewerStore } from '@/stores/viewer-store'
import type { CatalogLanguage, Translation } from '@/types'
import { formatDateTimeString, formatNumber } from '@/utils/format'
import { normalizeForSearch } from '@/utils/text-normalize'

import { PageContainer } from '@/components/design-system/page-container'
import { ScreenHeader } from '@/components/design-system/screen-header'
import { StatusBanner } from '@/components/design-system/status-banner'
import { EmptyState } from '@/components/design-system/empty-state'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'

/** Library sort options (labels come from the i18n contract). */
type SortOption = 'title' | 'language' | 'updated'

const SORT_OPTIONS: Array<{ value: SortOption; labelKey: TranslationKey }> = [
  { value: 'updated', labelKey: 'quran.sortUpdated' },
  { value: 'title', labelKey: 'quran.sortTitle' },
  { value: 'language', labelKey: 'quran.sortLanguage' },
]

/** Library categories (Prompt 3 §9). */
type LibraryCategory = 'all' | 'downloaded' | 'recent' | 'offline' | 'imported'

const CATEGORY_OPTIONS: Array<{ value: LibraryCategory; labelKey: TranslationKey }> = [
  { value: 'all', labelKey: 'quran.categories.all' },
  { value: 'downloaded', labelKey: 'quran.categories.downloaded' },
  { value: 'recent', labelKey: 'quran.categories.recent' },
  { value: 'offline', labelKey: 'quran.categories.offline' },
  { value: 'imported', labelKey: 'quran.categories.imported' },
]

/**
 * Widely used languages the catalog is prepared to highlight (Prompt 3 §3).
 * A chip appears only when the live catalog actually has translations in
 * that language - nothing is listed for languages without real records.
 */
const COMMON_LANGUAGE_CODES = [
  'ar', 'en', 'ur', 'id', 'ms', 'tr', 'fa', 'fr', 'de', 'es',
  'ru', 'bn', 'hi', 'zh', 'ja', 'ko', 'th', 'vi', 'sw', 'ha',
] as const

/** The translation library (categories, toolbar, results, trust card). */
function QuranLibrary() {
  const { t, locale } = useTranslation()
  const openReader = useReaderStore((s) => s.openReader)
  const recentTranslations = useReaderStore((s) => s.recentTranslations)
  const lastTranslationKey = useReaderStore((s) => s.selectedTranslationKey)
  const navigate = useNavigationStore((s) => s.navigate)
  const openViewer = useViewerStore((s) => s.open)
  const activeIds = useDownloadManagerStore((s) => s.activeIds)
  const librarySectionRef = useRef<HTMLElement | null>(null)

  const [category, setCategory] = useState<LibraryCategory>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [languageFilter, setLanguageFilter] = useState('all')
  const [sortBy, setSortBy] = useState<SortOption>('updated')

  /** Translation whose dialog is open (kept mounted for the exit animation).
   *  The dialog has two pages: the regular details (info icon) and the
   *  download page (Download button). */
  const [detailsTranslation, setDetailsTranslation] = useState<Translation | null>(null)
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [dialogMode, setDialogMode] = useState<'details' | 'download'>('details')

  /** Offline pack statuses + live pack jobs (refreshes when jobs finish). */
  const { statuses: packStatuses, jobsByTranslation } = useOfflinePacks()

  /** Stored files (downloads + imports) from the offline library. The query
   *  key includes the live job count so the list refreshes whenever a
   *  download finishes. */
  const storedFilesQuery = useQuery({
    queryKey: ['stored-files', activeIds.length],
    queryFn: () => getFileStorage().listFiles(),
    staleTime: 30_000,
  })
  const storedFiles = storedFilesQuery.data ?? null

  // The catalog is fetched per interface locale so titles localize with the UI.
  const catalogQuery = useQuery({
    queryKey: ['translations-catalog', locale],
    queryFn: () => getTranslationsCatalog(locale),
    staleTime: 300_000,
    retry: 1,
    // Offline: the service falls back to the last successfully cached copy.
    networkMode: 'always',
  })

  const catalogData = catalogQuery.data ?? null
  const catalogItems = catalogData?.items ?? null

  /** Catalog languages sorted by English name for the filter dropdown. */
  const sortedLanguages = useMemo(
    () =>
      catalogData
        ? [...catalogData.languages].sort((a, b) => a.name.localeCompare(b.name))
        : [],
    [catalogData],
  )

  /** Quick chips: widely used languages that actually exist in the catalog. */
  const commonLanguages = useMemo<Array<CatalogLanguage & { label: string }>>(() => {
    if (!catalogData) return []
    const chips: Array<CatalogLanguage & { label: string }> = []
    for (const code of COMMON_LANGUAGE_CODES) {
      const language = catalogData.languages.find((entry) => entry.code === code)
      if (!language) continue
      chips.push({
        ...language,
        label: language.nativeName ?? language.name,
      })
    }
    return chips
  }, [catalogData])

  /** Personal imports (origin: imported), newest first. */
  const importedFiles = useMemo(
    () => (storedFiles ?? []).filter((file) => file.origin === 'imported'),
    [storedFiles],
  )

  /** Translation keys with any locally stored content (pack or files). */
  const downloadedKeys = useMemo(() => {
    const keys = new Set<string>()
    for (const [key, status] of Object.entries(packStatuses ?? {})) {
      if (status.cachedSuras > 0) keys.add(key)
    }
    for (const file of storedFiles ?? []) {
      if (file.origin === 'downloaded' && file.translationId) keys.add(file.translationId)
    }
    return keys
  }, [packStatuses, storedFiles])

  /** Filter (category + search + language) and sort the records. */
  const visibleTranslations = useMemo(() => {
    if (!catalogItems) return []
    const normalizedQuery = normalizeForSearch(searchQuery)

    const inCategory = (translation: Translation): boolean => {
      switch (category) {
        case 'downloaded':
          return downloadedKeys.has(translation.key)
        case 'recent':
          return recentTranslations.includes(translation.key)
        case 'offline':
          return packStatuses?.[translation.key]?.complete === true
        default:
          return true
      }
    }

    let filtered = catalogItems.filter((translation) => {
      const matchesQuery =
        normalizedQuery.length === 0 ||
        [
          translation.title,
          translation.description,
          translation.languageName,
          translation.languageNativeName,
          translation.translator,
          translation.publisher,
        ].some((field) => normalizeForSearch(field).includes(normalizedQuery))
      const matchesLanguage =
        languageFilter === 'all' || translation.languageCode === languageFilter
      return matchesQuery && matchesLanguage && inCategory(translation)
    })

    // "Recently opened": follow the reader's recency order, newest first.
    if (category === 'recent') {
      const rank = new Map(recentTranslations.map((key, index) => [key, index]))
      filtered = [...filtered].sort(
        (a, b) => (rank.get(a.key) ?? 0) - (rank.get(b.key) ?? 0),
      )
      return filtered
    }

    const sorted = [...filtered]
    switch (sortBy) {
      case 'title':
        sorted.sort((a, b) => a.title.localeCompare(b.title))
        break
      case 'language':
        sorted.sort(
          (a, b) => a.languageName.localeCompare(b.languageName) || a.title.localeCompare(b.title),
        )
        break
      case 'updated':
      default:
        sorted.sort((a, b) => {
          if (!a.lastUpdated) return 1
          if (!b.lastUpdated) return -1
          return b.lastUpdated.localeCompare(a.lastUpdated)
        })
        break
    }
    return sorted
  }, [catalogItems, category, searchQuery, languageFilter, sortBy, downloadedKeys, recentTranslations, packStatuses])

  /** Imported files filtered by the same search box. */
  const visibleImportedFiles = useMemo(() => {
    const normalizedQuery = normalizeForSearch(searchQuery)
    if (normalizedQuery.length === 0) return importedFiles
    return importedFiles.filter((file) => normalizeForSearch(file.fileName).includes(normalizedQuery))
  }, [importedFiles, searchQuery])

  /** Distinct languages among the filtered results. */
  const filteredLanguageCount = useMemo(
    () => new Set(visibleTranslations.map((translation) => translation.languageCode)).size,
    [visibleTranslations],
  )

  const hasActiveFilters = searchQuery.trim().length > 0 || languageFilter !== 'all'

  const clearFilters = () => {
    setSearchQuery('')
    setLanguageFilter('all')
  }

  /** Smooth-scroll to the library section (same screen, no navigation). */
  const scrollToLibrary = () => {
    librarySectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  /** Open the regular details page (info icon on a card). */
  const openDetails = (translation: Translation) => {
    setDetailsTranslation(translation)
    setDialogMode('details')
    setDetailsOpen(true)
  }

  /** Open the download page (Download button on a card): offline pack, file
   *  formats with their exact sizes, exports and print. */
  const openDownloads = (translation: Translation) => {
    setDetailsTranslation(translation)
    setDialogMode('download')
    setDetailsOpen(true)
  }

  return (
    <PageContainer wide>
      <ScreenHeader title={t('quran.title')} subtitle={t('quran.subtitle')} icon={BookOpen} />

      <div className="space-y-6">
        {/* The Holy Quran */}
        <section aria-labelledby="holy-quran-heading">
          <Card className="border-primary/25 bg-gradient-to-b from-primary/[0.08] to-transparent">
            <CardContent className="flex flex-wrap items-center justify-between gap-4 p-6">
              <div className="flex min-w-0 items-start gap-4">
                <span
                  aria-hidden="true"
                  className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"
                >
                  <BookOpen className="size-6" />
                </span>
                <div className="min-w-0">
                  <h2 id="holy-quran-heading" className="text-base font-semibold text-foreground">
                    {t('quran.quranTextTitle')}
                  </h2>
                  <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted-foreground">
                    {t('quran.quranTextLiveDescription')}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button className="h-11" onClick={() => openReader()}>
                  <BookOpen aria-hidden="true" className="size-4" />
                  {t('quran.readNow')}
                </Button>
                <Button variant="ghost" className="h-11" onClick={scrollToLibrary}>
                  <LibraryBig aria-hidden="true" className="size-4" />
                  {t('quran.openLibrary')}
                </Button>
                <Button variant="ghost" className="h-11" onClick={() => navigate('downloads')}>
                  <ArrowDownToLine aria-hidden="true" className="size-4" />
                  {t('quran.openDownloads')}
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Library toolbar + results (anchor target for the card button above) */}
        <section
          ref={librarySectionRef}
          id="quran-library"
          aria-labelledby="library-heading"
          className="scroll-mt-20"
        >
          <h2
            id="library-heading"
            className="text-sm font-semibold uppercase tracking-wide text-muted-foreground"
          >
            {t('home.translationLibrary')}
          </h2>

          {/* Categories. PROMPT 14: these are filters, not tabs - aria-pressed
              chips instead of a tablist without tab semantics. */}
          <div
            aria-label={t('common.filter')}
            className="mt-3 flex gap-2 overflow-x-auto pb-1 scrollbar-subtle"
          >
            {CATEGORY_OPTIONS.map((option) => {
              const isActive = category === option.value
              return (
                <button
                  key={option.value}
                  aria-pressed={isActive}
                  type="button"
                  onClick={() => setCategory(option.value)}
                  className={cn(
                    'h-11 shrink-0 rounded-full border px-4 text-sm font-medium transition-colors',
                    isActive
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground',
                  )}
                >
                  {option.value === 'imported' && importedFiles.length > 0
                    ? t('quran.categories.importedCount', {
                        count: formatNumber(locale, importedFiles.length),
                      })
                    : t(option.labelKey)}
                </button>
              )
            })}
          </div>

          {/* Toolbar */}
          <div className="mt-3 flex flex-col gap-3 lg:flex-row lg:items-end">
            {/* Search */}
            <div className="relative w-full lg:flex-1">
              <Search
                aria-hidden="true"
                className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(event) => setSearchQuery(event.target.value)}
                placeholder={t('quran.searchPlaceholder')}
                aria-label={t('common.search')}
                title={t('quran.searchHint')}
                className="h-11 w-full rounded-lg border border-input bg-background ps-9 pe-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
              />
            </div>

            {/* Language + sort */}
            <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end lg:shrink-0">
              <div className="flex w-full flex-col gap-1.5 sm:w-64">
                <span
                  id="quran-language-filter-label"
                  className="text-xs font-medium text-muted-foreground"
                >
                  {t('quran.filterByLanguage')}
                </span>
                <LanguagePicker
                  languages={sortedLanguages}
                  value={languageFilter}
                  onChange={setLanguageFilter}
                  specialOptions={[{ value: 'all', label: t('common.all') }]}
                  ariaLabel={t('quran.filterByLanguage')}
                  searchPlaceholder={t('quran.searchLanguages')}
                  emptyLabel={t('quran.noLanguageResults')}
                  formatCount={(count) => formatNumber(locale, count)}
                />
              </div>

              {category !== 'recent' && category !== 'imported' ? (
                <div className="flex w-full flex-col gap-1.5 sm:w-48">
                  <span
                    id="quran-sort-label"
                    className="text-xs font-medium text-muted-foreground"
                  >
                    {t('quran.sortBy')}
                  </span>
                  <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
                    <SelectTrigger aria-labelledby="quran-sort-label" className="h-11 w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SORT_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {t(option.labelKey)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : null}
            </div>
          </div>

          {/* Quick language chips - only languages the catalog really has */}
          {category !== 'imported' && commonLanguages.length > 0 ? (
            <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label={t('quran.filterByLanguage')}>
              {commonLanguages.map((language) => {
                const isActive = languageFilter === language.code
                return (
                  <button
                    key={language.code}
                    type="button"
                    aria-pressed={isActive}
                    onClick={() => setLanguageFilter(isActive ? 'all' : language.code)}
                    className={cn(
                      'min-h-11 rounded-full border px-3.5 text-xs font-medium transition-colors',
                      isActive
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground',
                    )}
                  >
                    <span dir="auto">{language.label}</span>
                    <span className="ms-1.5 tabular-nums opacity-70">
                      {formatNumber(locale, language.count)}
                    </span>
                  </button>
                )
              })}
            </div>
          ) : null}

          {/* Cached-catalog note (small, honest, not a banner) */}
          {catalogData?.servedFromCache ? (
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
              {t('quran.servedFromCache')}
            </p>
          ) : null}

          {/* Results */}
          <div className="mt-4 space-y-3">
            {catalogQuery.isPending ? (
              <div role="status" className="grid gap-3 sm:grid-cols-2">
                <span className="sr-only">{t('common.loading')}</span>
                {[0, 1, 2, 3, 4, 5].map((index) => (
                  <Card key={index}>
                    <CardContent className="space-y-3 p-4">
                      <Skeleton className="h-5 w-2/3" />
                      <Skeleton className="h-4 w-1/2" />
                      <div className="flex gap-2">
                        <Skeleton className="h-11 w-28" />
                        <Skeleton className="h-11 w-24" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : catalogQuery.isError ? (
              <StatusBanner
                variant="error"
                title={t('quran.catalogError')}
                description={t('common.errorDescription')}
                action={
                  <Button
                    variant="outline"
                    className="h-11"
                    onClick={() => void catalogQuery.refetch()}
                  >
                    {t('common.retry')}
                  </Button>
                }
              />
            ) : category === 'imported' ? (
              /* Imported personal files (clearly separated from the catalog) */
              storedFiles === null ? (
                <div role="status" className="space-y-3">
                  <span className="sr-only">{t('common.loading')}</span>
                  <Skeleton className="h-20 w-full rounded-xl" />
                  <Skeleton className="h-20 w-full rounded-xl" />
                </div>
              ) : importedFiles.length === 0 ? (
                <EmptyState
                  icon={LibraryBig}
                  title={t('quran.imported.emptyTitle')}
                  description={t('quran.imported.emptyDescription')}
                  action={
                    <Button variant="outline" className="h-11" onClick={() => navigate('downloads')}>
                      <ArrowDownToLine aria-hidden="true" className="size-4" />
                      {t('downloads.importFile')}
                    </Button>
                  }
                />
              ) : visibleImportedFiles.length === 0 ? (
                <EmptyState
                  icon={Search}
                  title={t('quran.noResultsTitle')}
                  description={t('quran.noResultsDescription')}
                  action={
                    <Button variant="outline" className="h-11" onClick={clearFilters}>
                      {t('quran.clearFilters')}
                    </Button>
                  }
                />
              ) : (
                <>
                  <ImportedFileList files={visibleImportedFiles} onOpen={(fileId) => openViewer(fileId)} />
                  <p className="text-xs text-muted-foreground">{t('quran.imported.manageInDownloads')}</p>
                </>
              )
            ) : catalogItems !== null && catalogItems.length > 0 ? (
              <>
                <p
                  className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground"
                  aria-live="polite"
                >
                  <span>
                    {t('quran.resultsCount', {
                      count: formatNumber(locale, visibleTranslations.length),
                    })}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {t('quran.languagesCount', {
                      count: formatNumber(locale, filteredLanguageCount),
                    })}
                  </span>
                </p>

                {visibleTranslations.length > 0 ? (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {visibleTranslations.map((translation) => (
                      <TranslationCard
                        key={translation.id}
                        translation={translation}
                        packStatus={packStatuses?.[translation.key] ?? null}
                        activeJob={jobsByTranslation.get(translation.key) ?? null}
                        isLastRead={translation.key === lastTranslationKey}
                        onOpenDetails={openDetails}
                        onOpenDownloads={openDownloads}
                      />
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={Search}
                    title={t('quran.noResultsTitle')}
                    description={t('quran.noResultsDescription')}
                    action={
                      hasActiveFilters ? (
                        <Button variant="outline" className="h-11" onClick={clearFilters}>
                          {t('quran.clearFilters')}
                        </Button>
                      ) : null
                    }
                  />
                )}
              </>
            ) : (
              <EmptyState
                icon={LibraryBig}
                title={t('quran.noResultsTitle')}
                description={t('quran.noResultsDescription')}
              />
            )}
          </div>

          {/* Source & trust - friendly, factual, no scary warnings */}
          <div className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2.5">
                  <HeartHandshake aria-hidden="true" className="size-5 text-primary" />
                  <CardTitle className="text-base">{t('quran.trust.title')}</CardTitle>
                </div>
                <CardDescription>{t('quran.trust.body')}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <Button variant="outline" className="h-11 w-fit" asChild>
                    <a
                      href={catalogData?.sourceUrl ?? 'https://quranenc.com'}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink aria-hidden="true" className="size-4" />
                      {t('quran.openSourcePage')}
                    </a>
                  </Button>
                </div>
                {catalogData?.lastSyncedAt ? (
                  <p className="text-xs text-muted-foreground">
                    {t('quran.lastSynced')}: {formatDateTimeString(locale, catalogData.lastSyncedAt)}
                  </p>
                ) : null}
              </CardContent>
            </Card>
          </div>
        </section>
      </div>

      <TranslationDetailDialog
        translation={detailsTranslation}
        mode={dialogMode}
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
      />
    </PageContainer>
  )
}

export function QuranScreen() {
  const readerOpen = useReaderStore((s) => s.readerOpen)

  // The reader replaces the library entirely while it is open.
  return readerOpen ? <ReaderView /> : <QuranLibrary />
}
