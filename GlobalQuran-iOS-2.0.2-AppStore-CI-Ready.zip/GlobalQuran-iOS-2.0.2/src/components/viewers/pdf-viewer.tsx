'use client'

/**
 * Built-in PDF viewer (pdfjs-dist, canvas rendering).
 *
 * - Loads the stored blob fully offline; the pdf.js worker is served from
 *   /pdf.worker.min.mjs (assigned once per session, after the dynamic import).
 * - One canvas renders the current page; the active RenderTask is cancelled
 *   before any re-render and the document is destroyed on unmount.
 * - Fit modes (page / width) are computed from the scroll container size and
 *   re-measured through a ResizeObserver; zoom multiplies the fit scale.
 * - Page-level text search scans pages with the shared Arabic-aware
 *   normalization (diacritic-insensitive, case-insensitive). In-page highlight
 *   is intentionally out of scope: results navigate to matching pages.
 * - The last opened page is persisted per file and resumed on the next open.
 */

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Loader2,
  Maximize2,
  Minimize2,
  Moon,
  MoveHorizontal,
  Scan,
  Search,
  Sun,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getViewerState, useViewerStateStore } from '@/stores/viewer-state-store'
import type { StoredFileMetadata } from '@/services/storage/local-file-storage'
import { getPdfWorkerBlobUrl, loadPdfjs } from '@/components/viewers/library-loader'
import { StatusBanner } from '@/components/design-system/status-banner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { formatNumber } from '@/utils/format'
import { normalizedIncludes, normalizeForSearch } from '@/utils/text-normalize'
import { cn } from '@/lib/utils'
import type { PDFDocumentProxy, RenderTask } from 'pdfjs-dist'

/** Set once per browser session (after the dynamic import resolves). */
let pdfWorkerConfigured = false

type FitMode = 'page' | 'width'

type SearchState =
  | { phase: 'idle' }
  | { phase: 'scanning' }
  | { phase: 'done'; pages: number[]; index: number }

const ZOOM_MIN = 0.5
const ZOOM_MAX = 3
const ZOOM_STEP = 0.15
/** The canvas area's p-4 padding, excluded from the fit calculation. */
const CANVAS_PADDING = 32

function clampPage(value: number, total: number): number {
  const max = Math.max(1, total)
  const parsed = Math.trunc(value)
  if (!Number.isFinite(parsed)) return 1
  return Math.min(Math.max(parsed, 1), max)
}

function nextZoom(current: number, delta: number): number {
  const raw = Math.round((current + delta) * 100) / 100
  return Math.min(Math.max(raw, ZOOM_MIN), ZOOM_MAX)
}

export interface PdfViewerProps {
  file: StoredFileMetadata
  blob: Blob
  onClose: () => void
}

export function PdfViewer({ file, blob, onClose }: PdfViewerProps) {
  const { t, locale } = useTranslation()
  const setPdfPage = useViewerStateStore((s) => s.setPdfPage)

  const rootRef = useRef<HTMLElement | null>(null)
  const containerRef = useRef<HTMLDivElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const docRef = useRef<PDFDocumentProxy | null>(null)
  const renderTaskRef = useRef<RenderTask | null>(null)
  const searchTokenRef = useRef(0)
  const rememberedTimerRef = useRef<number | null>(null)

  const [docPhase, setDocPhase] = useState<'loading' | 'ready' | 'error'>('loading')
  const [renderFailed, setRenderFailed] = useState(false)
  const [retryTick, setRetryTick] = useState(0)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [pageInput, setPageInput] = useState<string | null>(null)
  const [zoom, setZoom] = useState(1)
  const [fitMode, setFitMode] = useState<FitMode>('page')
  const [invert, setInvert] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [search, setSearch] = useState<SearchState>({ phase: 'idle' })
  const [sizeTick, setSizeTick] = useState(0)
  const [rememberedChip, setRememberedChip] = useState(false)

  const failed = docPhase === 'error' || renderFailed

  /* -------------------------------------------------------------- */
  /* Document load (initial + retry)                                 */
  /* -------------------------------------------------------------- */

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      setDocPhase('loading')
      setRenderFailed(false)
      setSearch({ phase: 'idle' })

      // Drop a previous attempt before re-parsing (retry path).
      renderTaskRef.current?.cancel()
      renderTaskRef.current = null
      const previous = docRef.current
      docRef.current = null
      if (previous) {
        try {
          // v6: destruction lives on the loading task.
          await previous.loadingTask.destroy()
        } catch {
          // Release path - the document was already gone.
        }
      }

      try {
        const pdfjs = await loadPdfjs()
        if (!pdfWorkerConfigured) {
          // Prefer the warmed in-memory worker (works offline); the static
          // URL is the fallback for a cold session.
          pdfjs.GlobalWorkerOptions.workerSrc = getPdfWorkerBlobUrl() ?? '/pdf.worker.min.mjs'
          pdfWorkerConfigured = true
        }
        const buffer = await blob.arrayBuffer()
        const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise
        if (cancelled) {
          void doc.loadingTask.destroy().catch(() => undefined)
          return
        }

        docRef.current = doc
        setTotal(doc.numPages)

        // Resume the saved page when it is still within range.
        const saved = getViewerState(file.id)?.pdfPage
        const savedPage =
          typeof saved === 'number' && saved >= 1 && saved <= doc.numPages ? saved : null
        setPage(savedPage ?? 1)
        setPageInput(null)
        setDocPhase('ready')

        if (savedPage !== null) {
          setRememberedChip(true)
          if (rememberedTimerRef.current !== null) window.clearTimeout(rememberedTimerRef.current)
          rememberedTimerRef.current = window.setTimeout(() => setRememberedChip(false), 4000)
        }
      } catch (error) {
        console.error('PdfViewer: failed to load document', error)
        if (!cancelled) setDocPhase('error')
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [retryTick, blob, file.id])

  /* Unmount: cancel the in-flight render and release the document. */
  useEffect(() => {
    return () => {
      if (rememberedTimerRef.current !== null) window.clearTimeout(rememberedTimerRef.current)
      renderTaskRef.current?.cancel()
      docRef.current?.loadingTask.destroy().catch(() => undefined)
    }
  }, [])

  /* -------------------------------------------------------------- */
  /* Page rendering                                                  */
  /* -------------------------------------------------------------- */

  useEffect(() => {
    if (docPhase !== 'ready' || renderFailed) return
    const doc = docRef.current
    const container = containerRef.current
    const canvas = canvasRef.current
    if (!doc || !container || !canvas) return

    let disposed = false

    const render = async () => {
      try {
        const pageProxy = await doc.getPage(page)
        if (disposed) return

        const base = pageProxy.getViewport({ scale: 1 })
        const availW = Math.max(120, container.clientWidth - CANVAS_PADDING)
        const availH = Math.max(160, container.clientHeight - CANVAS_PADDING)
        const fitScale =
          fitMode === 'width' ? availW / base.width : availH / base.height
        const cssScale = fitScale * zoom
        const dpr = window.devicePixelRatio || 1
        const viewport = pageProxy.getViewport({ scale: cssScale * dpr })
        // Cancel the in-flight task before re-rendering the same canvas.
        // v6 render takes the canvas itself (canvasContext is legacy).
        renderTaskRef.current?.cancel()
        if (disposed) return
        canvas.width = viewport.width
        canvas.height = viewport.height
        canvas.style.width = `${Math.round(viewport.width / dpr)}px`
        canvas.style.height = `${Math.round(viewport.height / dpr)}px`

        const task = pageProxy.render({ canvas, viewport })
        renderTaskRef.current = task
        await task.promise
        if (disposed) return

        setPdfPage(file.id, page)
      } catch (error) {
        if (disposed) return
        const name = (error as { name?: string })?.name
        if (name === 'RenderingCancelledException') return
        console.error('PdfViewer: page render failed', error)
        setRenderFailed(true)
      }
    }

    void render()
    return () => {
      disposed = true
      renderTaskRef.current?.cancel()
    }
  }, [docPhase, renderFailed, page, zoom, fitMode, sizeTick, setPdfPage, file.id])

  /* Container resize re-runs the fit calculation. The canvas area only
     exists once the document is ready, so the observer re-attaches then. */
  useEffect(() => {
    const container = containerRef.current
    if (!container) return
    const observer = new ResizeObserver(() => {
      setSizeTick((tick) => tick + 1)
    })
    observer.observe(container)
    return () => observer.disconnect()
  }, [docPhase, renderFailed])

  /* Fullscreen state tracking. */
  useEffect(() => {
    const onChange = () => setIsFullscreen(document.fullscreenElement === rootRef.current)
    document.addEventListener('fullscreenchange', onChange)
    return () => document.removeEventListener('fullscreenchange', onChange)
  }, [])

  /* -------------------------------------------------------------- */
  /* Handlers                                                        */
  /* -------------------------------------------------------------- */

  const goToPage = useCallback(
    (target: number) => {
      setPage((current) => {
        const next = clampPage(target, Math.max(total, 1))
        return next === current ? current : next
      })
      setPageInput(null)
    },
    [total],
  )

  const commitPageInput = () => {
    if (pageInput === null) return
    const parsed = Number.parseInt(pageInput, 10)
    setPageInput(null)
    if (Number.isFinite(parsed)) goToPage(parsed)
  }

  const selectFitMode = (mode: FitMode) => {
    if (fitMode === mode) return
    setFitMode(mode)
    setZoom(1) // switching fit mode resets the zoom multiplier
  }

  const toggleFullscreen = () => {
    try {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => undefined)
      } else if (rootRef.current) {
        rootRef.current
          .requestFullscreen()
          .catch((error) => console.error('PdfViewer: fullscreen failed', error))
      }
    } catch (error) {
      console.error('PdfViewer: fullscreen failed', error)
    }
  }

  const retry = () => {
    setRenderFailed(false)
    setRetryTick((tick) => tick + 1)
  }

  /* Page-level search: scan pages with the shared normalization; a new
     search supersedes the previous scan via the token ref. */
  const runSearch = async () => {
    const doc = docRef.current
    if (!doc) return
    const normalized = normalizeForSearch(query)
    const token = ++searchTokenRef.current
    if (!normalized) {
      setSearch({ phase: 'idle' })
      return
    }
    setSearch({ phase: 'scanning' })

    const found: number[] = []
    for (let index = 1; index <= doc.numPages; index++) {
      if (searchTokenRef.current !== token) return
      try {
        const pageProxy = await doc.getPage(index)
        const content = await pageProxy.getTextContent()
        const text = content.items
          .map((item) => ('str' in item ? item.str : ''))
          .join(' ')
        if (normalizedIncludes(text, normalized)) found.push(index)
      } catch (error) {
        console.error('PdfViewer: text extraction failed during search', error)
      }
    }
    if (searchTokenRef.current !== token) return

    if (found.length > 0) {
      setSearch({ phase: 'done', pages: found, index: 0 })
      goToPage(found[0])
    } else {
      setSearch({ phase: 'done', pages: [], index: -1 })
    }
  }

  const stepMatch = (delta: number) => {
    if (search.phase !== 'done' || search.pages.length === 0) return
    const count = search.pages.length
    const next = (search.index + delta + count) % count
    setSearch({ phase: 'done', pages: search.pages, index: next })
    goToPage(search.pages[next])
  }

  /* -------------------------------------------------------------- */
  /* Render                                                          */
  /* -------------------------------------------------------------- */

  const zoomPercent = Math.round(zoom * 100)

  let body: React.ReactNode
  if (failed) {
    body = (
      <div className="flex flex-1 items-center justify-center p-6">
        <div className="w-full max-w-lg">
          <StatusBanner
            variant="error"
            title={t('pdf.renderError')}
            action={
              <Button variant="outline" className="h-11" onClick={retry}>
                {t('common.retry')}
              </Button>
            }
          />
        </div>
      </div>
    )
  } else if (docPhase !== 'ready') {
    body = (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-muted-foreground">
        <Loader2 aria-hidden="true" className="size-7 animate-spin text-primary" />
        <p className="text-sm">{t('common.loading')}</p>
      </div>
    )
  } else {
    body = (
      <div ref={containerRef} className="flex-1 min-h-0 overflow-auto p-4 scrollbar-subtle">
        <div className="flex min-h-full items-center justify-center">
          <div
            className={cn(
              'rounded-lg bg-white shadow-sm',
              invert && 'invert-[0.92] hue-rotate-180',
            )}
          >
            <canvas ref={canvasRef} className="block" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <section
      ref={rootRef}
      aria-label={file.fileName}
      className="flex min-h-0 flex-1 flex-col bg-background"
    >
      {/* Toolbar */}
      <div className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur">
        <div className="flex flex-wrap items-center gap-2 p-2">
          <Button
            variant="ghost"
            size="icon"
            className="size-11 shrink-0"
            aria-label={t('viewer.close')}
            onClick={onClose}
          >
            <X aria-hidden="true" className="size-4" />
          </Button>

          <p
            dir="auto"
            className="hidden min-w-0 max-w-48 truncate text-sm font-medium text-foreground sm:inline sm:max-w-64"
          >
            {file.fileName}
          </p>

          {/* Page navigation */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              disabled={page <= 1 || failed}
              aria-label={t('pdf.prevPage')}
              onClick={() => goToPage(page - 1)}
            >
              <ChevronLeft aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>
            <span
              className="tabular-nums text-sm text-muted-foreground"
              aria-label={t('pdf.pageOf', { page, total: Math.max(total, 1) })}
            >
              {formatNumber(locale, page)} / {formatNumber(locale, Math.max(total, 1))}
            </span>
            <Input
              type="number"
              inputMode="numeric"
              min={1}
              max={Math.max(total, 1)}
              value={pageInput ?? String(page)}
              disabled={failed}
              onChange={(event) => setPageInput(event.target.value)}
              onFocus={(event) => event.target.select()}
              onBlur={commitPageInput}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  commitPageInput()
                  event.currentTarget.blur()
                }
              }}
              aria-label={t('pdf.page')}
              className="h-11 w-16 text-center tabular-nums"
            />
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              disabled={page >= total || failed}
              aria-label={t('pdf.nextPage')}
              onClick={() => goToPage(page + 1)}
            >
              <ChevronRight aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>
          </div>

          {/* Zoom */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              disabled={zoom <= ZOOM_MIN}
              aria-label={t('pdf.zoomOut')}
              onClick={() => setZoom((current) => nextZoom(current, -ZOOM_STEP))}
            >
              <ZoomOut aria-hidden="true" className="size-4" />
            </Button>
            <span className="w-14 text-center text-sm tabular-nums text-muted-foreground">
              {formatNumber(locale, zoomPercent)}%
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              disabled={zoom >= ZOOM_MAX}
              aria-label={t('pdf.zoomIn')}
              onClick={() => setZoom((current) => nextZoom(current, ZOOM_STEP))}
            >
              <ZoomIn aria-hidden="true" className="size-4" />
            </Button>
          </div>

          {/* Fit modes */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                'size-11 shrink-0',
                fitMode === 'width' && 'bg-primary/10 text-primary',
              )}
              aria-pressed={fitMode === 'width'}
              aria-label={t('pdf.fitWidth')}
              onClick={() => selectFitMode('width')}
            >
              <MoveHorizontal aria-hidden="true" className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                'size-11 shrink-0',
                fitMode === 'page' && 'bg-primary/10 text-primary',
              )}
              aria-pressed={fitMode === 'page'}
              aria-label={t('pdf.fitPage')}
              onClick={() => selectFitMode('page')}
            >
              <Scan aria-hidden="true" className="size-4" />
            </Button>
          </div>

          {/* Dark reading mode + fullscreen + search */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className={cn('size-11 shrink-0', invert && 'bg-primary/10 text-primary')}
              aria-pressed={invert}
              aria-label={t('pdf.invertMode')}
              onClick={() => setInvert((current) => !current)}
            >
              {invert ? (
                <Sun aria-hidden="true" className="size-4" />
              ) : (
                <Moon aria-hidden="true" className="size-4" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              aria-label={isFullscreen ? t('pdf.exitFullscreen') : t('pdf.fullscreen')}
              onClick={toggleFullscreen}
            >
              {isFullscreen ? (
                <Minimize2 aria-hidden="true" className="size-4" />
              ) : (
                <Maximize2 aria-hidden="true" className="size-4" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={cn('size-11 shrink-0', searchOpen && 'bg-primary/10 text-primary')}
              aria-pressed={searchOpen}
              aria-label={t('pdf.search')}
              onClick={() => setSearchOpen((current) => !current)}
            >
              <Search aria-hidden="true" className="size-4" />
            </Button>
          </div>
        </div>

        {/* Search row */}
        {searchOpen ? (
          <div className="flex flex-wrap items-center gap-2 border-t p-2">
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t('pdf.searchPlaceholder')}
              aria-label={t('pdf.search')}
              className="h-11 min-w-44 flex-1"
              onKeyDown={(event) => {
                if (event.key === 'Enter') void runSearch()
              }}
            />
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                aria-label={t('pdf.prevPage')}
                disabled={search.phase !== 'done' || search.pages.length === 0}
                onClick={() => stepMatch(-1)}
              >
                <ChevronUp aria-hidden="true" className="size-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                aria-label={t('pdf.nextPage')}
                disabled={search.phase !== 'done' || search.pages.length === 0}
                onClick={() => stepMatch(1)}
              >
                <ChevronDown aria-hidden="true" className="size-4" />
              </Button>
            </div>
            <p className="min-w-28 text-sm tabular-nums text-muted-foreground">
              {search.phase === 'scanning'
                ? t('pdf.searchRendering')
                : search.phase === 'done'
                  ? search.pages.length === 0
                    ? t('pdf.searchNoResults')
                    : t('pdf.searchResult', {
                        current: formatNumber(locale, search.index + 1),
                        count: formatNumber(locale, search.pages.length),
                      })
                  : null}
            </p>
          </div>
        ) : null}

        {/* Resumed-page note */}
        {rememberedChip ? (
          <p className="border-t bg-primary/[0.07] px-4 py-1.5 text-xs text-primary">
            {t('pdf.rememberedPage')}
          </p>
        ) : null}
      </div>

      {body}
    </section>
  )
}
