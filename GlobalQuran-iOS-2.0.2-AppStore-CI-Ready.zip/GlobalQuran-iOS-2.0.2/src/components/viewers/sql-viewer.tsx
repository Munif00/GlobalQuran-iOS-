'use client'

/**
 * Built-in SQLite translation database viewer (sql.js, wasm served locally).
 *
 * - Opens the stored file fully offline; the wasm binary is resolved from
 *   /sql-wasm.wasm and the database is closed on unmount.
 * - Verified-schema validation before rendering: a sqlite_master query must
 *   succeed and the `translations` table (id, sura, aya, translation,
 *   footnotes - the uncompressed QuranEnc export) must exist. The file
 *   contains translation text and footnotes only, never the Arabic Quran.
 * - The whole database loads once; the sura picker re-queries per sura.
 *   Stored text is rendered verbatim as plain text nodes - never transformed.
 */

import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Info, Loader2, X } from 'lucide-react'

import { getSqlWasmBinary, loadSqlJs } from '@/components/viewers/library-loader'
import { useTranslation } from '@/i18n'
import type { StoredFileMetadata } from '@/services/storage/local-file-storage'
import { SURA_INDEX, getSuraMeta } from '@/data/sura-index'
import { StatusBanner } from '@/components/design-system/status-banner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'
import type { Database, SqlValue } from 'sql.js'

type ViewerPhase = 'loading' | 'ready' | 'error'

interface SuraRow {
  aya: number
  translation: string
  footnotes: string
}

/** Coerce a stored cell to displayable text (null-safe, verbatim). */
function toText(value: SqlValue | undefined): string {
  if (value === null || value === undefined) return ''
  if (typeof value === 'string') return value
  if (typeof value === 'number') return String(value)
  // Binary cells cannot be rendered as honest text; treated as empty.
  if (value instanceof Uint8Array) return ''
  return String(value)
}

/** Coerce a stored cell to a number (null-safe). */
function toNumber(value: SqlValue | undefined): number {
  const parsed = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(parsed) ? parsed : 0
}

export interface SqlViewerProps {
  file: StoredFileMetadata
  blob: Blob
  onClose: () => void
}

export function SqlViewer({ file, blob, onClose }: SqlViewerProps) {
  const { t, locale } = useTranslation()

  const dbRef = useRef<Database | null>(null)

  const [phase, setPhase] = useState<ViewerPhase>('loading')
  const [retryTick, setRetryTick] = useState(0)
  const [rowCount, setRowCount] = useState<number | null>(null)
  const [sura, setSura] = useState(1)
  const [rows, setRows] = useState<SuraRow[]>([])
  const [infoOpen, setInfoOpen] = useState(false)

  /* -------------------------------------------------------------- */
  /* Database load (single load, retryable)                          */
  /* -------------------------------------------------------------- */

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      setPhase('loading')
      setRowCount(null)

      // Release a previous attempt before re-opening (retry path).
      const previous = dbRef.current
      dbRef.current = null
      if (previous) {
        try {
          previous.close()
        } catch {
          // Release path - already closed.
        }
      }

      try {
        const initSqlJs = await loadSqlJs()
        const SQL = await initSqlJs({
          // Prefer the warmed in-memory WASM binary (works offline); fall
          // back to the static URL for a cold session.
          ...(getSqlWasmBinary() ? { wasmBinary: getSqlWasmBinary() ?? undefined } : {}),
          locateFile: (name) => (name.endsWith('.wasm') ? '/sql-wasm.wasm' : name),
        })
        if (cancelled) return

        const buffer = await blob.arrayBuffer()
        if (cancelled) return

        const db = new SQL.Database(new Uint8Array(buffer))
        dbRef.current = db

        // Verified-schema validation: sqlite_master must be readable and the
        // translations table must exist (QuranEnc uncompressed export).
        const tableCheck = db.exec(
          "SELECT name FROM sqlite_master WHERE type='table' AND name='translations'",
        )
        const tableExists =
          tableCheck.length > 0 && tableCheck[0].values.length > 0
        if (!tableExists) throw new Error('translations table missing (verified schema)')

        const countResult = db.exec('SELECT COUNT(*) AS n FROM translations')
        const count = toNumber(countResult[0]?.values[0]?.[0])
        if (cancelled) return

        setRowCount(count)
        setPhase('ready')
      } catch (error) {
        console.error('SqlViewer: failed to open database', error)
        const db = dbRef.current
        dbRef.current = null
        if (db) {
          try {
            db.close()
          } catch {
            // Release path - already closed.
          }
        }
        if (!cancelled) setPhase('error')
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [retryTick, blob])

  /* Unmount: close the database. */
  useEffect(() => {
    return () => {
      const db = dbRef.current
      dbRef.current = null
      if (db) {
        try {
          db.close()
        } catch {
          // Release path - already closed.
        }
      }
    }
  }, [])

  /* Per-sura query (the whole database is already in memory). */
  useEffect(() => {
    if (phase !== 'ready') return
    const db = dbRef.current
    if (!db) return

    try {
      const result = db.exec(
        'SELECT aya, translation, footnotes FROM translations WHERE sura = ? ORDER BY CAST(aya AS INTEGER)',
        [sura],
      )
      const values = result[0]?.values ?? []
      setRows(
        values.map((row) => ({
          aya: toNumber(row[0]),
          translation: toText(row[1]),
          footnotes: toText(row[2]),
        })),
      )
    } catch (error) {
      console.error('SqlViewer: sura query failed', error)
      setRows([])
      setPhase('error')
    }
  }, [phase, sura])

  /* -------------------------------------------------------------- */
  /* Render                                                          */
  /* -------------------------------------------------------------- */

  const suraMeta = getSuraMeta(sura)

  let body: ReactNode
  if (phase === 'error') {
    body = (
      <div className="flex flex-1 items-center justify-center p-6">
        <div className="w-full max-w-lg">
          <StatusBanner
            variant="error"
            title={t('sql.openError')}
            action={
              <Button
                variant="outline"
                className="h-11"
                onClick={() => setRetryTick((tick) => tick + 1)}
              >
                {t('common.retry')}
              </Button>
            }
          />
        </div>
      </div>
    )
  } else if (phase === 'loading') {
    body = (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-muted-foreground">
        <Loader2 aria-hidden="true" className="size-7 animate-spin text-primary" />
        <p className="text-sm">{t('common.loading')}</p>
      </div>
    )
  } else {
    body = (
      <div className="mx-auto w-full max-w-3xl flex-1 overflow-y-auto px-4 py-6 scrollbar-subtle sm:px-6">
        {/* Sura header */}
        <header className="space-y-3 text-center">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {t('reader.sura')} {formatNumber(locale, sura)}
          </p>
          <h2 className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            <span dir="auto">{suraMeta?.nameEnglish ?? file.fileName}</span>
            {suraMeta ? (
              <span dir="rtl" lang="ar" className="font-arabic text-gold">
                {suraMeta.nameArabic}
              </span>
            ) : null}
          </h2>
          <p className="flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
            <Badge variant="outline" className="tabular-nums">
              {t('sql.ayat', { count: formatNumber(locale, rows.length) })}
            </Badge>
          </p>
        </header>

        {/* Reading surface */}
        <div className="mt-6 space-y-6 rounded-xl border border-border bg-card p-4 sm:p-6">
          {rows.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {t('sql.noRows')}
            </p>
          ) : (
            rows.map((row) => (
              <article key={row.aya} className="space-y-2">
                <Badge variant="outline" className="tabular-nums">
                  {formatNumber(locale, row.aya)}
                </Badge>
                {/* Verbatim translation text - never transformed. */}
                <p dir="auto" className="whitespace-pre-wrap leading-relaxed text-foreground">
                  {row.translation}
                </p>
                {row.footnotes ? (
                  <p dir="auto" className="text-xs leading-relaxed text-muted-foreground">
                    <span className="font-medium">{t('reader.footnotes')}:</span>{' '}
                    {row.footnotes}
                  </p>
                ) : null}
              </article>
            ))
          )}
        </div>
      </div>
    )
  }

  return (
    <section
      aria-label={file.fileName}
      className="flex min-h-0 flex-1 flex-col bg-background"
    >
      {/* Toolbar */}
      <div className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur">
        <div className="flex flex-wrap items-center gap-1.5 p-2">
          <Button
            variant="ghost"
            size="icon"
            className="size-11 shrink-0"
            aria-label={t('viewer.close')}
            onClick={onClose}
          >
            <X aria-hidden="true" className="size-4" />
          </Button>

          <p
            dir="auto"
            className="hidden min-w-0 max-w-48 truncate text-sm font-medium text-foreground sm:inline sm:max-w-64"
          >
            {file.fileName}
          </p>

          <Button
            variant="ghost"
            size="icon"
            className={cn('size-11 shrink-0', infoOpen && 'bg-primary/10 text-primary')}
            aria-pressed={infoOpen}
            aria-label={t('sql.schemaInfo')}
            onClick={() => setInfoOpen((current) => !current)}
          >
            <Info aria-hidden="true" className="size-4" />
          </Button>

          <div className="min-w-44 flex-1 sm:max-w-72">
            <Select
              value={String(sura)}
              onValueChange={(value) => {
                const parsed = Number(value)
                if (Number.isInteger(parsed) && parsed >= 1 && parsed <= 114) {
                  setSura(parsed)
                }
              }}
            >
              <SelectTrigger className="h-11 w-full" aria-label={t('sql.pickSura')}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {SURA_INDEX.map((meta) => (
                  <SelectItem key={meta.number} value={String(meta.number)}>
                    <span className="tabular-nums">{formatNumber(locale, meta.number)}</span>
                    <span dir="rtl" lang="ar" className="font-arabic">
                      · {meta.nameArabic}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Verified-schema info panel */}
        {infoOpen ? (
          <div className="space-y-2 border-t bg-muted/40 px-4 py-3 sm:px-6">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {t('sql.schemaInfo')}
              </p>
              <Badge
                variant="outline"
                className="tabular-nums border-primary/25 bg-primary/10 text-primary"
              >
                {t('sql.rows')}: {formatNumber(locale, rowCount ?? 0)}
              </Badge>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              {t('sql.schemaDescription')}
            </p>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('sql.formattingNote')}
            </p>
          </div>
        ) : null}
      </div>

      {body}
    </section>
  )
}
