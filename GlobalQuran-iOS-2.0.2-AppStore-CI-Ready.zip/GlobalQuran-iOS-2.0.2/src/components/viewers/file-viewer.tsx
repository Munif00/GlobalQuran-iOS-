'use client'

/**
 * Global built-in file viewer overlay.
 *
 * Renders itself from the viewer store: when a stored file is open it covers
 * the whole viewport, resolves the blob from IndexedDB and dispatches to the
 * right reader by format:
 * - pdf  -> PdfViewer (pdf.js, canvas rendering)
 * - epub -> EpubViewer (epubjs, sandboxed iframe)
 * - sql  -> SqlViewer (sql.js, the verified QuranEnc schema)
 * - json/txt -> an honest built-in text preview (verbatim, capped)
 * - anything else (e.g. imported zip archives) -> "no built-in reader" state.
 *
 * Everything is local: opening never touches the network. Escape closes the
 * viewer unless a Radix layer (chapters sheet, settings popover, select) is
 * open - that layer consumes the first Escape press instead.
 */

import { useEffect, useState, type ReactNode } from 'react'
import { FileArchive, FileWarning, Loader2, X } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useViewerStore } from '@/stores/viewer-store'
import {
  getFileStorage,
  type StoredFile,
} from '@/services/storage/local-file-storage'
import { EmptyState } from '@/components/design-system/empty-state'
import { Button } from '@/components/ui/button'
import { EpubViewer } from '@/components/viewers/epub-viewer'
import { PdfViewer } from '@/components/viewers/pdf-viewer'
import { SqlViewer } from '@/components/viewers/sql-viewer'

/** Hard cap for the built-in text preview (json/txt). */
const MAX_TEXT_CHARS = 500_000

type LoadPhase = 'loading' | 'ready' | 'error'

/** True while any Radix overlay layer is open (it consumes Escape first). */
function isRadixLayerOpen(): boolean {
  return (
    document.querySelector(
      '[data-state="open"][role="dialog"], [data-state="open"][role="listbox"]',
    ) !== null
  )
}

export function FileViewer() {
  const { t } = useTranslation()
  const openFileId = useViewerStore((s) => s.openFileId)
  const close = useViewerStore((s) => s.close)

  const [phase, setPhase] = useState<LoadPhase>('loading')
  const [stored, setStored] = useState<StoredFile | null>(null)
  const [textPreview, setTextPreview] = useState<string | null>(null)

  /* Resolve the stored file whenever a new one is opened. */
  useEffect(() => {
    if (openFileId === null) return

    let cancelled = false
    setPhase('loading')
    setStored(null)
    setTextPreview(null)

    const load = async () => {
      try {
        const file = await getFileStorage().getFile(openFileId)
        if (!file) throw new Error('Stored file not found')
        if (cancelled) return

        if (file.metadata.format === 'json' || file.metadata.format === 'txt') {
          // Plain-text preview: read once, cap the displayed length.
          const text = await file.blob.text()
          if (cancelled) return
          setTextPreview(text.slice(0, MAX_TEXT_CHARS))
        }

        if (cancelled) return
        setStored(file)
        setPhase('ready')
      } catch (error) {
        console.error('FileViewer: failed to open stored file', error)
        if (!cancelled) setPhase('error')
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [openFileId])

  /* Escape closes the viewer (unless an overlay layer handles it first). */
  useEffect(() => {
    if (openFileId === null) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return
      if (isRadixLayerOpen()) return
      close()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [openFileId, close])

  if (openFileId === null) return null

  const metadata = stored?.metadata ?? null

  let content: ReactNode
  if (phase === 'loading') {
    content = (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-muted-foreground">
        <Loader2 aria-hidden="true" className="size-7 animate-spin text-primary" />
        <p className="text-sm">{t('viewer.loading')}</p>
      </div>
    )
  } else if (phase === 'error') {
    content = (
      <div className="flex flex-1 items-center justify-center p-6">
        <EmptyState
          icon={FileWarning}
          title={t('viewer.openFailed')}
          description={t('viewer.openFailedDescription')}
          className="max-w-lg"
          action={
            <Button variant="outline" className="h-11" onClick={close}>
              {t('viewer.close')}
            </Button>
          }
        />
      </div>
    )
  } else if (metadata !== null && stored !== null) {
    switch (metadata.format) {
      case 'pdf':
        content = (
          <PdfViewer file={metadata} blob={stored.blob} onClose={close} />
        )
        break
      case 'epub':
        content = (
          <EpubViewer file={metadata} blob={stored.blob} onClose={close} />
        )
        break
      case 'sql':
        content = (
          <SqlViewer file={metadata} blob={stored.blob} onClose={close} />
        )
        break
      case 'json':
      case 'txt':
        content = (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex items-center gap-2 border-b bg-background/95 p-2 backdrop-blur">
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                aria-label={t('viewer.close')}
                onClick={close}
              >
                <X aria-hidden="true" className="size-4" />
              </Button>
              <p
                dir="auto"
                className="min-w-0 truncate text-sm font-medium text-foreground"
              >
                {metadata.fileName}
              </p>
            </div>
            <div className="mx-auto w-full max-w-4xl flex-1 overflow-y-auto px-4 py-4 scrollbar-subtle sm:px-6">
              {/* Verbatim text: the stored bytes are never transformed. */}
              <pre
                dir="auto"
                className="whitespace-pre-wrap break-words font-mono text-sm leading-relaxed text-foreground"
              >
                {textPreview ?? ''}
              </pre>
            </div>
          </div>
        )
        break
      default:
        // Import validation allows zip archives to be kept offline; they are
        // honestly reported as not openable in-app.
        content = (
          <div className="flex flex-1 items-center justify-center p-6">
            <EmptyState
              icon={FileArchive}
              title={t('viewer.cannotOpenTitle')}
              description={t('viewer.cannotOpenDescription')}
              className="max-w-lg"
              action={
                <Button variant="outline" className="h-11" onClick={close}>
                  {t('viewer.close')}
                </Button>
              }
            />
          </div>
        )
    }
  } else {
    content = null
  }

  return (
    /* pt-safe: in the installed app the overlay must start below the
     * notch/Dynamic Island exactly like the app header does. */
    <div className="pt-safe fixed inset-0 z-50 flex flex-col bg-background">{content}</div>
  )
}
