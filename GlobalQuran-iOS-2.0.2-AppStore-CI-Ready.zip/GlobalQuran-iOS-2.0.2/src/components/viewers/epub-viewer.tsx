'use client'

/**
 * Built-in EPUB viewer (epubjs, sandboxed iframe).
 *
 * - The stored blob is opened fully offline; the book is rendered into an
 *   iframe epubjs creates inside our container. `allowScriptedContent: false`
 *   keeps book scripts disabled; book HTML never enters the app DOM outside
 *   epubjs's own iframe.
 * - Reading theme / font size / line spacing are applied through the epubjs
 *   theme API and mirrored on the reading surface container.
 * - The reading position (CFI + spine progress) is persisted on `relocated`
 *   (throttled to ~1 write/second) and resumed on the next open; a stale CFI
 *   falls back to the beginning.
 */

import { useEffect, useRef, useState } from 'react'
import {
  ChevronLeft,
  ChevronRight,
  List,
  Loader2,
  Minus,
  Plus,
  Settings2,
  X,
} from 'lucide-react'

import { loadEpubjs } from '@/components/viewers/library-loader'
import { useTranslation } from '@/i18n'
import { getViewerState, useViewerStateStore } from '@/stores/viewer-state-store'
import type { StoredFileMetadata } from '@/services/storage/local-file-storage'
import { StatusBanner } from '@/components/design-system/status-banner'
import { Button } from '@/components/ui/button'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { Separator } from '@/components/ui/separator'
import {
  ToggleGroup,
  ToggleGroupItem,
} from '@/components/ui/toggle-group'
import { formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'
import type {
  Book as BookType,
  Location as EpubLocation,
  NavItem,
  Rendition as RenditionType,
} from 'epubjs'

type EpubTheme = 'light' | 'sepia' | 'night'

type ViewerPhase = 'loading' | 'ready' | 'error'

interface FlatNavItem {
  href: string
  label: string
  depth: number
}

const FONT_MIN = 75
const FONT_MAX = 200
const FONT_STEP = 5
const LINE_SPACINGS = [1.4, 1.7, 2.0] as const
type LineSpacing = (typeof LINE_SPACINGS)[number]

const THEME_SURFACES: Record<EpubTheme, string> = {
  light: 'bg-white',
  sepia: 'reader-surface-sepia',
  night: 'reader-surface-night',
}

/**
 * epubjs ships a Spine class typed without `length`; at runtime the spine is
 * an array-like of sections (v0.3), so progress needs this narrow cast.
 */
function getSpineLength(book: BookType): number {
  const spine = book.spine as unknown as { length?: unknown }
  return typeof spine.length === 'number' && spine.length > 0 ? spine.length : 0
}

/** NavItem.label is typed as string but can be an object in some books. */
function navLabel(item: NavItem): string {
  const raw: unknown = item.label
  if (typeof raw === 'string' && raw.trim().length > 0) return raw
  if (raw !== null && typeof raw === 'object') {
    const text = (raw as { text?: unknown }).text
    if (typeof text === 'string' && text.trim().length > 0) return text
  }
  return item.href
}

function flattenNav(items: NavItem[], depth: number, out: FlatNavItem[]): void {
  for (const item of items) {
    out.push({ href: item.href, label: navLabel(item), depth })
    if (item.subitems && item.subitems.length > 0) {
      flattenNav(item.subitems, depth + 1, out)
    }
  }
}

export interface EpubViewerProps {
  file: StoredFileMetadata
  blob: Blob
  onClose: () => void
}

export function EpubViewer({ file, blob, onClose }: EpubViewerProps) {
  const { t, locale, isRTL } = useTranslation()
  const setEpubPosition = useViewerStateStore((s) => s.setEpubPosition)

  const containerRef = useRef<HTMLDivElement | null>(null)
  const bookRef = useRef<BookType | null>(null)
  const renditionRef = useRef<RenditionType | null>(null)
  const lastSaveAtRef = useRef(0)
  const resumedTimerRef = useRef<number | null>(null)

  const [phase, setPhase] = useState<ViewerPhase>('loading')
  const [toc, setToc] = useState<FlatNavItem[]>([])
  const [chaptersOpen, setChaptersOpen] = useState(false)
  const [theme, setTheme] = useState<EpubTheme>('light')
  const [fontSizePct, setFontSizePct] = useState(100)
  const [lineSpacing, setLineSpacing] = useState<LineSpacing>(1.7)
  const [resumedChip, setResumedChip] = useState(false)

  const savedState = getViewerState(file.id)
  const [progress, setProgress] = useState(
    typeof savedState?.epubProgress === 'number' ? savedState.epubProgress : 0,
  )

  /* -------------------------------------------------------------- */
  /* Book load (single mount)                                        */
  /* -------------------------------------------------------------- */

  useEffect(() => {
    let disposed = false

    const load = async () => {
      try {
        const { Book } = await loadEpubjs()
        if (disposed) return
        const buffer = await blob.arrayBuffer()
        if (disposed) return

        // epubjs types model the constructor as (url, options); at runtime it
        // accepts the raw .epub ArrayBuffer (the openEpub binary path).
        const book = new Book(buffer as unknown as string)
        bookRef.current = book

        const onOpenFailed = (error: unknown) => {
          if (disposed) return
          console.error('EpubViewer: book open failed', error)
          setPhase('error')
        }
        book.on('openFailed', onOpenFailed)

        const container = containerRef.current
        if (!container) return

        const rendition = book.renderTo(container, {
          width: '100%',
          height: '100%',
          allowScriptedContent: false,
          spread: 'none',
        })
        renditionRef.current = rendition

        rendition.themes.register('light', {
          body: { color: '#1f2937 !important', background: '#ffffff !important' },
        })
        rendition.themes.register('sepia', {
          body: { color: '#3a2f1f !important', background: '#f4ecd8 !important' },
        })
        rendition.themes.register('night', {
          body: { color: '#d6d3cd !important', background: '#1a1c1e !important' },
        })
        rendition.themes.select('light')

        // Table of contents (labels coerced defensively).
        void book.loaded.navigation
          .then((navigation) => {
            if (disposed) return
            const flat: FlatNavItem[] = []
            flattenNav(navigation.toc, 0, flat)
            setToc(flat)
          })
          .catch((error) => {
            console.error('EpubViewer: navigation unavailable', error)
          })

        // Persist the reading position on every relocation (throttled).
        const onRelocated = (location: EpubLocation) => {
          const currentBook = bookRef.current
          const spineLength = currentBook ? getSpineLength(currentBook) : 0
          const index =
            typeof location.start.index === 'number' ? location.start.index : 0
          const raw = spineLength > 0 ? ((index + 1) / spineLength) * 100 : 0
          const percent = Math.min(Math.max(Math.round(raw), 0), 100)
          setProgress(percent)

          const now = Date.now()
          if (now - lastSaveAtRef.current >= 1000) {
            lastSaveAtRef.current = now
            setEpubPosition(file.id, location.start.cfi, percent)
          }
        }
        rendition.on('relocated', onRelocated)

        // Resume the saved CFI; a stale CFI falls back to the start.
        const savedCfiRaw = getViewerState(file.id)?.epubCfi
        const savedCfi = typeof savedCfiRaw === 'string' ? savedCfiRaw : null
        let resumed = false
        if (savedCfi) {
          try {
            await rendition.display(savedCfi)
            resumed = true
          } catch (error) {
            console.error('EpubViewer: saved position is stale, restarting', error)
            await rendition.display()
          }
        } else {
          await rendition.display()
        }
        if (disposed) return

        setPhase('ready')
        if (resumed) {
          setResumedChip(true)
          if (resumedTimerRef.current !== null) window.clearTimeout(resumedTimerRef.current)
          resumedTimerRef.current = window.setTimeout(() => setResumedChip(false), 4000)
        }
      } catch (error) {
        if (disposed) return
        console.error('EpubViewer: failed to open book', error)
        setPhase('error')
      }
    }

    void load()
    return () => {
      disposed = true
      if (resumedTimerRef.current !== null) window.clearTimeout(resumedTimerRef.current)
      const rendition = renditionRef.current
      const book = bookRef.current
      renditionRef.current = null
      bookRef.current = null
      try {
        rendition?.destroy()
      } catch {
        // Release path - already torn down.
      }
      try {
        book?.destroy()
      } catch {
        // Release path - already torn down.
      }
    }
  }, [])

  /* Reading typography: re-applied fully after every settings change. */
  useEffect(() => {
    const rendition = renditionRef.current
    if (phase !== 'ready' || !rendition) return
    rendition.themes.select(theme)
    rendition.themes.fontSize(`${fontSizePct}%`)
    rendition.themes.override('line-height', lineSpacing.toString())
  }, [phase, theme, fontSizePct, lineSpacing])

  /* -------------------------------------------------------------- */
  /* Handlers                                                        */
  /* -------------------------------------------------------------- */

  const goSection = (direction: 'prev' | 'next') => {
    const rendition = renditionRef.current
    if (!rendition) return
    const promise = direction === 'prev' ? rendition.prev() : rendition.next()
    promise.catch((error) => console.error('EpubViewer: section navigation failed', error))
  }

  const openChapter = (href: string) => {
    const rendition = renditionRef.current
    setChaptersOpen(false)
    if (!rendition) return
    rendition
      .display(href)
      .catch((error) => console.error('EpubViewer: chapter navigation failed', error))
  }

  const stepFontSize = (delta: number) => {
    setFontSizePct((current) => Math.min(Math.max(current + delta, FONT_MIN), FONT_MAX))
  }

  /* -------------------------------------------------------------- */
  /* Render                                                          */
  /* -------------------------------------------------------------- */

  return (
    <section
      aria-label={file.fileName}
      className="flex min-h-0 flex-1 flex-col bg-background"
    >
      {/* Toolbar */}
      <div className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur">
        <div className="flex flex-wrap items-center gap-1.5 p-2">
          <Button
            variant="ghost"
            size="icon"
            className="size-11 shrink-0"
            aria-label={t('viewer.close')}
            onClick={onClose}
          >
            <X aria-hidden="true" className="size-4" />
          </Button>

          <p
            dir="auto"
            className="hidden min-w-0 max-w-48 truncate text-sm font-medium text-foreground sm:inline sm:max-w-64"
          >
            {file.fileName}
          </p>

          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              aria-label={t('epub.prevSection')}
              onClick={() => goSection('prev')}
            >
              <ChevronLeft aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="size-11 shrink-0"
              aria-label={t('epub.nextSection')}
              onClick={() => goSection('next')}
            >
              <ChevronRight aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className={cn('size-11 shrink-0', chaptersOpen && 'bg-primary/10 text-primary')}
            aria-expanded={chaptersOpen}
            aria-haspopup="dialog"
            aria-label={t('epub.chapters')}
            onClick={() => setChaptersOpen(true)}
          >
            <List aria-hidden="true" className="size-4" />
          </Button>

          {/* Display settings */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                aria-label={t('reader.display')}
              >
                <Settings2 aria-hidden="true" className="size-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80">
              <div className="space-y-4">
                {/* Font size */}
                <div className="space-y-2">
                  <span className="text-xs font-medium text-muted-foreground">
                    {t('epub.fontSize')}
                  </span>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-11 shrink-0"
                      disabled={fontSizePct <= FONT_MIN}
                      aria-label={`${t('epub.fontSize')}: ${formatNumber(locale, Math.max(fontSizePct - FONT_STEP, FONT_MIN))}%`}
                      onClick={() => stepFontSize(-FONT_STEP)}
                    >
                      <Minus aria-hidden="true" className="size-4" />
                    </Button>
                    <span className="w-14 text-center text-sm tabular-nums text-foreground">
                      {formatNumber(locale, fontSizePct)}%
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-11 shrink-0"
                      disabled={fontSizePct >= FONT_MAX}
                      aria-label={`${t('epub.fontSize')}: ${formatNumber(locale, Math.min(fontSizePct + FONT_STEP, FONT_MAX))}%`}
                      onClick={() => stepFontSize(FONT_STEP)}
                    >
                      <Plus aria-hidden="true" className="size-4" />
                    </Button>
                  </div>
                </div>

                {/* Line spacing */}
                <div className="space-y-2">
                  <span className="text-xs font-medium text-muted-foreground">
                    {t('epub.lineSpacing')}
                  </span>
                  <ToggleGroup
                    type="single"
                    variant="outline"
                    size="sm"
                    className="w-full"
                    value={String(lineSpacing)}
                    onValueChange={(value) => {
                      const parsed = Number(value)
                      const match = LINE_SPACINGS.find((step) => step === parsed)
                      if (match !== undefined) setLineSpacing(match)
                    }}
                  >
                    {LINE_SPACINGS.map((step) => (
                      <ToggleGroupItem
                        key={step}
                        value={String(step)}
                        className="flex-1"
                        aria-label={`${t('epub.lineSpacing')} ${formatNumber(locale, step, { maximumFractionDigits: 1 })}`}
                      >
                        {formatNumber(locale, step, { maximumFractionDigits: 1 })}
                      </ToggleGroupItem>
                    ))}
                  </ToggleGroup>
                </div>

                <Separator />

                {/* Reading theme */}
                <div className="space-y-2">
                  <span className="text-xs font-medium text-muted-foreground">
                    {t('epub.theme')}
                  </span>
                  <ToggleGroup
                    type="single"
                    variant="outline"
                    size="sm"
                    className="w-full"
                    value={theme}
                    onValueChange={(value) => {
                      if (value === 'light' || value === 'sepia' || value === 'night') {
                        setTheme(value)
                      }
                    }}
                  >
                    <ToggleGroupItem value="light" className="flex-1">
                      {t('epub.themeLight')}
                    </ToggleGroupItem>
                    <ToggleGroupItem value="sepia" className="flex-1">
                      {t('epub.themeSepia')}
                    </ToggleGroupItem>
                    <ToggleGroupItem value="night" className="flex-1">
                      {t('epub.themeNight')}
                    </ToggleGroupItem>
                  </ToggleGroup>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          <p className="ms-auto tabular-nums text-xs text-muted-foreground">
            {t('epub.progress', { percent: formatNumber(locale, progress) })}
          </p>
        </div>

        {/* Resumed-position note */}
        {resumedChip ? (
          <p className="border-t bg-primary/[0.07] px-4 py-1.5 text-xs text-primary">
            {t('epub.rememberedPosition')}
          </p>
        ) : null}
      </div>

      {/* Reading surface / error */}
      {phase === 'error' ? (
        <div className="flex flex-1 items-center justify-center p-6">
          <div className="w-full max-w-lg">
            <StatusBanner
              variant="error"
              title={t('epub.openError')}
              action={
                <Button variant="outline" className="h-11" onClick={onClose}>
                  {t('viewer.close')}
                </Button>
              }
            />
          </div>
        </div>
      ) : (
        <div className="relative min-h-0 flex-1">
          {/* The renderTo container stays mounted with explicit dimensions;
              a veil covers it until the first section is displayed. */}
          <div
            className={cn('absolute inset-0 overflow-y-auto p-4 scrollbar-subtle', THEME_SURFACES[theme])}
          >
            <div className="mx-auto h-full max-w-2xl">
              <div ref={containerRef} className="h-full w-full" />
            </div>
          </div>
          {phase === 'loading' ? (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-background/70 p-6 text-muted-foreground backdrop-blur-sm">
              <Loader2 aria-hidden="true" className="size-7 animate-spin text-primary" />
              <p className="text-sm">{t('common.loading')}</p>
            </div>
          ) : null}
        </div>
      )}

      {/* Chapters */}
      <Sheet open={chaptersOpen} onOpenChange={setChaptersOpen}>
        {/* side "start": the sheet opens from the inline-start edge, which
            flips automatically with the interface direction. */}
        <SheetContent side={isRTL ? 'right' : 'left'} aria-describedby={undefined}>
          <SheetHeader>
            <SheetTitle>{t('epub.chapters')}</SheetTitle>
          </SheetHeader>
          <div className="scrollbar-subtle -mx-1 flex-1 overflow-y-auto px-1">
            {toc.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">
                {t('common.none')}
              </p>
            ) : (
              <nav aria-label={t('epub.chapters')}>
                <ul className="space-y-1">
                  {toc.map((item) => (
                    <li key={`${item.depth}-${item.href}`}>
                      <button
                        type="button"
                        className={cn(
                          'flex min-h-11 w-full items-center rounded-lg text-start outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50',
                          item.depth === 0 ? 'ps-3 pe-3' : 'ps-6 pe-3',
                        )}
                        onClick={() => openChapter(item.href)}
                      >
                        <span dir="auto" className="w-full truncate py-1.5 text-sm">
                          {item.label}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </nav>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </section>
  )
}
