/**
 * Shared lazy-loader + asset-warming module for the heavy viewer libraries.
 *
 * IMPORTANT - single dynamic import call sites:
 * The dynamic `import()` statements for pdfjs-dist / epubjs / sql.js live
 * ONLY in this module. Every consumer (the viewers, the chunk warming) goes
 * through these functions, so the bundler emits exactly one chunk per
 * library and warming that chunk makes it available for offline use.
 * Duplicating the import() elsewhere would create a second chunk that is
 * not warmed.
 *
 * External assets:
 * - pdfjs additionally fetches its web-worker script, and sql.js fetches a
 *   WASM binary - both at first use, over the network. `warm*` fetches them
 *   once and keeps them in memory (blob URL / ArrayBuffer), so offline
 *   opens work after warming. The pdf.js worker and the Uthmanic Hafs text
 *   it renders stay compatible because both come from the same pinned
 *   package version.
 */

import type { StoredFileMetadata } from '@/services/storage/local-file-storage'

export type PdfjsModule = typeof import('pdfjs-dist')
export type EpubjsModule = typeof import('epubjs')
export type SqlJsFactory = typeof import('sql.js')['default']

export type { StoredFileMetadata }

const PDF_WORKER_URL = '/pdf.worker.min.mjs'
const SQL_WASM_URL = '/sql-wasm.wasm'

let pdfjsPromise: Promise<PdfjsModule> | null = null
let epubjsPromise: Promise<EpubjsModule> | null = null
let sqlJsPromise: Promise<SqlJsFactory> | null = null

/** Resolved to a blob URL once the worker source has been warmed. */
let pdfWorkerBlobUrl: string | null = null
let pdfWorkerWarmPromise: Promise<string | null> | null = null
/** Cached WASM binary for sql.js (passed via wasmBinary). */
let sqlWasmBinary: ArrayBuffer | null = null
let sqlWasmWarmPromise: Promise<ArrayBuffer | null> | null = null

/* ------------------------------------------------------------------ */
/* Module loaders (single call sites)                                  */
/* ------------------------------------------------------------------ */

/** Lazily import pdfjs-dist (single shared chunk). */
export function loadPdfjs(): Promise<PdfjsModule> {
  if (!pdfjsPromise) {
    pdfjsPromise = import('pdfjs-dist')
  }
  return pdfjsPromise
}

/** Lazily import epubjs (single shared chunk). */
export function loadEpubjs(): Promise<EpubjsModule> {
  if (!epubjsPromise) {
    epubjsPromise = import('epubjs')
  }
  return epubjsPromise
}

/** Lazily import the sql.js factory (single shared chunk). */
export function loadSqlJs(): Promise<SqlJsFactory> {
  if (!sqlJsPromise) {
    sqlJsPromise = import('sql.js').then((mod) => mod.default)
  }
  return sqlJsPromise
}

/* ------------------------------------------------------------------ */
/* External asset warming                                             */
/* ------------------------------------------------------------------ */

/**
 * Fetch the pdf.js worker source once and turn it into a blob URL that
 * keeps working without a network connection. Returns the blob URL, or
 * null when the fetch fails (the caller falls back to the static URL).
 */
export function warmPdfWorker(): Promise<string | null> {
  if (pdfWorkerBlobUrl) return Promise.resolve(pdfWorkerBlobUrl)
  if (!pdfWorkerWarmPromise) {
    pdfWorkerWarmPromise = (async () => {
      try {
        const response = await fetch(PDF_WORKER_URL)
        if (!response.ok) return null
        const blob = await response.blob()
        pdfWorkerBlobUrl = URL.createObjectURL(
          new Blob([blob], { type: 'text/javascript' }),
        )
        return pdfWorkerBlobUrl
      } catch {
        return null
      } finally {
        // Allow a later retry after a failure (e.g. transient offline).
        if (!pdfWorkerBlobUrl) pdfWorkerWarmPromise = null
      }
    })()
  }
  return pdfWorkerWarmPromise
}

/** Blob URL for the warmed pdf.js worker, when available. */
export function getPdfWorkerBlobUrl(): string | null {
  return pdfWorkerBlobUrl
}

/**
 * Fetch the sql.js WASM binary once and cache it in memory so databases can
 * be opened without a network connection. Returns the binary or null.
 */
export function warmSqlWasm(): Promise<ArrayBuffer | null> {
  if (sqlWasmBinary) return Promise.resolve(sqlWasmBinary)
  if (!sqlWasmWarmPromise) {
    sqlWasmWarmPromise = (async () => {
      try {
        const response = await fetch(SQL_WASM_URL)
        if (!response.ok) return null
        sqlWasmBinary = await response.arrayBuffer()
        return sqlWasmBinary
      } catch {
        return null
      } finally {
        if (!sqlWasmBinary) sqlWasmWarmPromise = null
      }
    })()
  }
  return sqlWasmWarmPromise
}

/** The cached sql.js WASM binary, when warmed. */
export function getSqlWasmBinary(): ArrayBuffer | null {
  return sqlWasmBinary
}
