'use client'

/**
 * Global Quran - Prayer source & calculation transparency panel.
 *
 * Surfaces everything the resolver reports: which tier produced the data,
 * the authority, the documented method and parameters, how the method was
 * chosen (official national setting vs recommended default), the Asr
 * basis, the applied high-latitude rule, the time zone and its origin,
 * the fetch time, cached status, and the honest accuracy caveats.
 */

import { useState } from 'react'
import { BadgeCheck, Info, Landmark, ShieldQuestion } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import type {
  PrayerSourceAttempt,
  PrayerSourceInfo,
  PrayerTimeRecord,
} from '@/types'
import { formatDateTimeString } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { InfoRow } from '@/components/design-system/info-row'

const SOURCE_TYPE_LABELS: Record<PrayerSourceInfo['sourceType'], TranslationKey> = {
  official_authority: 'prayer.sourceType.official_authority',
  aladhan_api: 'prayer.sourceType.aladhan_api',
  local_engine: 'prayer.sourceType.local_engine',
}

const ATTEMPT_SOURCE_LABELS: Record<PrayerSourceAttempt['source'], TranslationKey> = {
  jakim_esolat: 'prayer.attempt.jakim_esolat',
  aladhan_api: 'prayer.attempt.aladhan_api',
  local_engine: 'prayer.attempt.local_engine',
  cache: 'prayer.attempt.cache',
}

const ASR_BASIS_LABELS: Record<PrayerTimeRecord['madhhab'], TranslationKey> = {
  standard: 'prayer.asrBasis.standard',
  hanafi: 'prayer.asrBasis.hanafi',
  authority_published: 'prayer.asrBasis.authority_published',
}

const HLR_LABELS: Record<string, TranslationKey> = {
  middle_of_night: 'prayer.hlr.middle_of_night',
  one_seventh: 'prayer.hlr.one_seventh',
  angle_based: 'prayer.hlr.angle_based',
}

const ATTEMPT_REASON_LABELS: Record<NonNullable<PrayerSourceAttempt['reasonCode']>, TranslationKey> = {
  ok: 'prayer.attemptReason.ok',
  not_applicable: 'prayer.attemptReason.not_applicable',
  out_of_published_range: 'prayer.attemptReason.out_of_published_range',
  network_error: 'prayer.attemptReason.network_error',
  invalid_response: 'prayer.attemptReason.invalid_response',
  timeout: 'prayer.attemptReason.timeout',
  no_zone_selected: 'prayer.attemptReason.no_zone_selected',
  no_cached_data: 'prayer.attemptReason.no_cached_data',
}

interface PrayerSourceSectionProps {
  source: PrayerSourceInfo
  record: PrayerTimeRecord
  registry: Array<{
    id: string
    countryName: string
    authorityName: string
    implementation: string
    website: string | null
  }>
  /** True when served from the client-side offline snapshot (server unreachable). */
  clientCache?: boolean
}

export function PrayerSourceSection({ source, record, registry, clientCache = false }: PrayerSourceSectionProps) {
  const { t, locale } = useTranslation()
  const [accuracyOpen, setAccuracyOpen] = useState(false)
  const [registryOpen, setRegistryOpen] = useState(false)

  const methodKindLabel: TranslationKey | null =
    source.methodResolution?.kind === 'official_national'
      ? 'prayer.methodKind.official'
      : source.methodResolution?.kind === 'regional_common'
        ? 'prayer.methodKind.regional'
        : source.methodResolution?.kind === 'global_default'
          ? 'prayer.methodKind.global'
          : null

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <Landmark aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('prayer.sourceSection')}</CardTitle>
        </div>
        <CardDescription>{source.sourceName}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant={source.sourceType === 'official_authority' ? 'default' : 'secondary'}>
            {source.sourceType === 'official_authority' ? (
              <BadgeCheck aria-hidden="true" className="size-3" />
            ) : null}
            {t(SOURCE_TYPE_LABELS[source.sourceType])}
          </Badge>
          {source.isCached ? (
            <Badge variant="outline">{t('prayer.cachedBadge')}</Badge>
          ) : null}
          {methodKindLabel ? <Badge variant="outline">{t(methodKindLabel)}</Badge> : null}
        </div>

        <dl>
          {source.authorityName ? (
            <InfoRow label={t('prayer.authority')} value={source.authorityName} />
          ) : null}
          {source.calculationMethodName ? (
            <InfoRow label={t('prayer.methodLabel')} value={source.calculationMethodName} />
          ) : null}
          {source.calculationMethodParams ? (
            <InfoRow label={t('prayer.methodParams')} value={source.calculationMethodParams} />
          ) : null}
          <InfoRow label={t('prayer.asrSetting')} value={t(ASR_BASIS_LABELS[record.madhhab])} />
          {source.appliedHighLatitudeRule ? (
            <InfoRow
              label={t('prayer.highLatitudeRule')}
              value={`${t(HLR_LABELS[source.appliedHighLatitudeRule])}${
                source.highLatitudeAdjusted ? ` · ${t('prayer.hlrApplied')}` : ''
              }`}
            />
          ) : null}
          <InfoRow label={t('prayer.timeZone')} value={source.timeZone} />
          <InfoRow
            label={t('prayer.fetchedAt')}
            value={formatDateTimeString(locale, source.fetchedAt)}
          />
        </dl>

        {source.notes.length > 0 || clientCache ? (
          <ul className="space-y-1.5">
            {clientCache ? (
              <li className="flex gap-2 text-xs leading-relaxed text-muted-foreground">
                <Info aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
                <span>{t('prayer.offlineSnapshotNote')}</span>
              </li>
            ) : null}
            {source.notes.map((note) => (
              <li key={note} className="flex gap-2 text-xs leading-relaxed text-muted-foreground">
                <Info aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
                <span>{t(note as TranslationKey)}</span>
              </li>
            ))}
          </ul>
        ) : null}

        {source.attempts.length > 0 ? (
          <Collapsible>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="h-11 w-full justify-between">
                {t('prayer.attempts')}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <ul className="mt-2 space-y-1.5 rounded-lg border border-border/70 p-3">
                {source.attempts.map((attempt, index) => (
                  <li key={`${attempt.source}-${index}`} className="flex items-center justify-between gap-3 text-xs">
                    <span className="min-w-0 truncate text-foreground">
                      {t(ATTEMPT_SOURCE_LABELS[attempt.source])}
                    </span>
                    <span
                      className={`shrink-0 tabular-nums ${
                        attempt.outcome === 'used'
                          ? 'text-primary'
                          : attempt.outcome === 'failed'
                            ? 'text-destructive'
                            : 'text-muted-foreground'
                      }`}
                    >
                      {attempt.outcome === 'used'
                        ? t('prayer.attemptOutcome.used')
                        : attempt.outcome === 'failed'
                          ? t('prayer.attemptOutcome.failed')
                          : t('prayer.attemptOutcome.skipped')}
                      {attempt.outcome !== 'used' && attempt.reasonCode
                        ? ` - ${t(ATTEMPT_REASON_LABELS[attempt.reasonCode])}`
                        : ''}
                    </span>
                  </li>
                ))}
              </ul>
            </CollapsibleContent>
          </Collapsible>
        ) : null}

        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" className="min-h-11" onClick={() => setAccuracyOpen(true)}>
            <ShieldQuestion aria-hidden="true" className="size-4" />
            {t('prayer.accuracyTitle')}
          </Button>
          <Button variant="outline" size="sm" className="min-h-11" onClick={() => setRegistryOpen(true)}>
            {t('prayer.registryTitle')}
          </Button>
        </div>

        <Dialog open={accuracyOpen} onOpenChange={setAccuracyOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{t('prayer.accuracyTitle')}</DialogTitle>
              <DialogDescription>{t('prayer.accuracyDescription')}</DialogDescription>
            </DialogHeader>
            <ul className="space-y-2 text-sm leading-relaxed text-muted-foreground">
              {(t('prayer.accuracyBody') as string)
                .split('\n')
                .filter((line) => line.length > 0)
                .map((line) => (
                  <li key={line} className="flex gap-2">
                    <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" />
                    <span>{line}</span>
                  </li>
                ))}
            </ul>
          </DialogContent>
        </Dialog>

        <Dialog open={registryOpen} onOpenChange={setRegistryOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{t('prayer.registryTitle')}</DialogTitle>
              <DialogDescription>{t('prayer.registrySummary')}</DialogDescription>
            </DialogHeader>
            <ScrollList entries={registry} />
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

function ScrollList({
  entries,
}: {
  entries: Array<{ id: string; countryName: string; authorityName: string; implementation: string; website: string | null }>
}) {
  const { t } = useTranslation()
  return (
    <div className="max-h-80 space-y-2 overflow-y-auto pe-1">
      {entries.map((entry) => (
        <div key={entry.id} className="rounded-lg border border-border/70 p-3">
          <p className="text-sm font-medium text-foreground">{entry.authorityName}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{entry.countryName}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Badge variant={entry.implementation === 'integrated' ? 'default' : 'outline'}>
              {entry.implementation === 'integrated'
                ? t('prayer.registryStatus.integrated')
                : t('prayer.registryStatus.fallback_to_aladhan')}
            </Badge>
            {entry.website ? (
              <a
                href={entry.website}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-11 items-center rounded-md px-1 text-xs text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-[3px] focus-visible:ring-ring/50"
              >
                {entry.website.replace(/^https?:\/\//, '')}
              </a>
            ) : null}
          </div>
        </div>
      ))}
    </div>
  )
}
