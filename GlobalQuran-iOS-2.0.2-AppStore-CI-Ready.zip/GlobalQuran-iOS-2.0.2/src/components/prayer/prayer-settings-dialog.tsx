'use client'

/**
 * Global Quran - Prayer calculation settings dialog.
 *
 * The secondary settings screen required by the prayer experience design:
 * the main dashboard stays focused on the times themselves, while method,
 * Asr convention, high-latitude rule, time zone, adjustments, and reminders
 * live here - one tap away, never cluttering the main screen.
 */

import type { ReactNode } from 'react'

import { useTranslation } from '@/i18n'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'

interface PrayerSettingsDialogProps {
  /** Controlled open state (owned by the prayer screen). */
  open: boolean
  onOpenChange: (open: boolean) => void
  /** The element that opens the dialog (rendered as the trigger). */
  trigger: ReactNode
  /** Settings content: the PrayerSettingsSection. */
  children: ReactNode
}

export function PrayerSettingsDialog({ open, onOpenChange, trigger, children }: PrayerSettingsDialogProps) {
  const { t } = useTranslation()

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[85vh] sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{t('settings.prayerSettings')}</DialogTitle>
          <DialogDescription>{t('prayer.settingsDialogDescription')}</DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[60vh]">{children}</ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
