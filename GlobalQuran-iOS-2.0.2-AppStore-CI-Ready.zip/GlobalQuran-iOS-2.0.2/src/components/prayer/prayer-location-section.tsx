'use client'

/**
 * Global Quran - Prayer location section.
 *
 * - Device location is requested ONLY through the explicit button, with the
 *   reason explained next to it; the position is never tracked continuously.
 * - Manual city search works without GPS: bundled curated cities (always
 *   available) merged with live geocoding when online.
 * - Saved locations let the user switch instantly; the active one is the
 *   default for the dashboard.
 * - In Malaysia, a JAKIM zone selector enables the official source tier.
 */

import { useState } from 'react'
import { toast } from 'sonner'
import { Check, Loader2, LocateFixed, MapPin, Plus, Search, Settings2, Star, Trash2 } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useCitySearch } from '@/hooks/use-prayer-data'
import type { GeoAutoFlowState } from '@/hooks/use-geolocation'
import type { GeoErrorCode } from '@/services/location/geolocation-service'
import type { CitySearchResult, JakimZoneInfo, SavedPrayerLocation } from '@/types'
import { formatNumber } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'

interface PrayerLocationSectionProps {
  latitude: number | null
  longitude: number | null
  isRequestingLocation: boolean
  locationNotice: 'denied' | 'reverse_failed' | 'service_disabled' | null
  onUseCurrentLocation: () => void
  onSelectCity: (result: CitySearchResult) => void
  savedLocations: SavedPrayerLocation[]
  activeLocationId: string | null
  onSelectSaved: (id: string) => void
  onRemoveSaved: (id: string) => void
  onSaveCurrent: () => void
  canSaveCurrent: boolean
  countryCode: string | null
  jakimZone: string | null
  onJakimZoneChange: (zone: string | null) => void
  jakimZones: readonly JakimZoneInfo[]
  /** Opens the Android system location settings (native only). */
  onOpenLocationSettings: () => void
  canOpenLocationSettings: boolean
  /** Live state of the automatic settings trip (useGeolocation). Drives
   *  the waiting / auto-locating / still-disabled / failed presentation
   *  of the service-disabled notice below. */
  autoFlow: GeoAutoFlowState
  /** Typed failure code of the automatic attempt (null when the trip ended
   *  because the service was still disabled, or outside a failed trip). */
  autoFlowErrorCode: GeoErrorCode | null
}

export function PrayerLocationSection({
  latitude,
  longitude,
  isRequestingLocation,
  locationNotice,
  onUseCurrentLocation,
  onSelectCity,
  savedLocations,
  activeLocationId,
  onSelectSaved,
  onRemoveSaved,
  onSaveCurrent,
  canSaveCurrent,
  countryCode,
  jakimZone,
  onJakimZoneChange,
  jakimZones,
  onOpenLocationSettings,
  canOpenLocationSettings,
  autoFlow,
  autoFlowErrorCode,
}: PrayerLocationSectionProps) {
  const { t, locale } = useTranslation()
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState('')
  /* PROMPT 14: saved locations are deleted only after an explicit confirm -
   *  one accidental tap on the trash icon must not drop a saved place. */
  const [pendingDelete, setPendingDelete] = useState<SavedPrayerLocation | null>(null)

  const searchQuery = useCitySearch(searchOpen ? query : '')
  const isMalaysia = countryCode === 'MY'

  /* Group JAKIM zones by state for a usable selector. */
  const zonesByState = jakimZones.reduce<Map<string, JakimZoneInfo[]>>((groups, zone) => {
    const list = groups.get(zone.state) ?? []
    list.push(zone)
    groups.set(zone.state, list)
    return groups
  }, new Map())

  const handlePick = (result: CitySearchResult) => {
    onSelectCity(result)
    setSearchOpen(false)
    setQuery('')
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <MapPin aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('prayer.locationSection')}</CardTitle>
        </div>
        <CardDescription>{t('prayer.gpsExplanation')}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <Button
            onClick={onUseCurrentLocation}
            disabled={isRequestingLocation}
            className="min-h-11"
          >
            {isRequestingLocation ? (
              <Loader2 aria-hidden="true" className="size-4 animate-spin" />
            ) : (
              <LocateFixed aria-hidden="true" className="size-4" />
            )}
            {isRequestingLocation
              ? autoFlow === 'auto-locating'
                ? t('geo.status.autoLocating')
                : t('common.loading')
              : t('prayer.useCurrentLocation')}
          </Button>
          <Button variant="outline" className="min-h-11" onClick={() => setSearchOpen(true)}>
            <Search aria-hidden="true" className="size-4" />
            {t('prayer.searchCity')}
          </Button>
        </div>

        {locationNotice === 'denied' ? (
          <p className="text-sm text-muted-foreground">{t('common.denied')}</p>
        ) : null}
        {locationNotice === 'reverse_failed' ? (
          <p className="text-sm text-muted-foreground">{t('prayer.reverseFailed')}</p>
        ) : null}
        {locationNotice === 'service_disabled' ? (
          /* The notice card reflects the LIVE state of the automatic
           * settings trip (started on the same press that failed): waiting
           * while the user is in the device settings, a spinner while the
           * position is obtained automatically on return, and the honest
           * endings - still disabled, or the automatic request failed with
           * its typed reason. Outside a trip (web / manual path) the plain
           * service-disabled explanation is shown. */
          <div role="alert" className="rounded-lg border border-warning/40 bg-warning/10 p-3 space-y-2">
            {autoFlow === 'awaiting-settings' ? (
              <p className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 aria-hidden="true" className="size-4 shrink-0 animate-spin" />
                {t('geo.status.waitingForSettings')}
              </p>
            ) : autoFlow === 'auto-locating' ? (
              <p className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 aria-hidden="true" className="size-4 shrink-0 animate-spin" />
                {t('geo.status.autoLocating')}
              </p>
            ) : autoFlow === 'succeeded' ? (
              <p className="text-sm text-muted-foreground">{t('geo.notice.autoObtained')}</p>
            ) : autoFlow === 'failed' && autoFlowErrorCode != null ? (
              <p className="text-sm text-muted-foreground">
                {t('geo.notice.autoFailed', {
                  reason: t(`geo.error.${autoFlowErrorCode}`),
                })}
              </p>
            ) : autoFlow === 'failed' ? (
              <p className="text-sm text-muted-foreground">{t('geo.notice.stillDisabled')}</p>
            ) : (
              <p className="text-sm text-muted-foreground">{t('geo.error.service-disabled')}</p>
            )}
            {/* Manual path stays available whenever no trip is in flight -
                pressing it opens the settings again (and re-arms the
                automatic trip), but nothing ever opens them on its own. */}
            {canOpenLocationSettings &&
            autoFlow !== 'awaiting-settings' &&
            autoFlow !== 'auto-locating' ? (
              <Button variant="outline" size="sm" className="min-h-9" onClick={onOpenLocationSettings}>
                <Settings2 aria-hidden="true" className="size-4" />
                {t('geo.locationSettings.open')}
              </Button>
            ) : null}
          </div>
        ) : null}

        {latitude != null && longitude != null ? (
          <p className="text-xs tabular-nums text-muted-foreground">
            {formatNumber(locale, latitude, { maximumFractionDigits: 4 })},{' '}
            {formatNumber(locale, longitude, { maximumFractionDigits: 4 })}
          </p>
        ) : null}

        {isMalaysia && jakimZones.length > 0 ? (
          <div className="space-y-2">
            <Label htmlFor="prayer-jakim-zone">{t('prayer.jakimZone')}</Label>
            <Select value={jakimZone ?? undefined} onValueChange={onJakimZoneChange}>
              <SelectTrigger id="prayer-jakim-zone" className="h-11 w-full">
                <SelectValue placeholder={t('prayer.jakimZonePlaceholder')} />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {[...zonesByState.entries()].map(([state, zones]) => (
                  <SelectGroup key={state}>
                    <SelectLabel>{state}</SelectLabel>
                    {zones.map((zone) => (
                      <SelectItem key={zone.code} value={zone.code}>
                        {zone.code} - {zone.state}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('prayer.jakimZoneHint')}
            </p>
          </div>
        ) : null}

        <Separator />

        <div className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm font-medium text-foreground">{t('prayer.savedLocations')}</p>
            <Button
              variant="outline"
              size="sm"
              className="h-11"
              onClick={onSaveCurrent}
              disabled={!canSaveCurrent}
            >
              <Plus aria-hidden="true" className="size-4" />
              {t('prayer.saveLocation')}
            </Button>
          </div>

          {savedLocations.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t('prayer.noSavedLocations')}</p>
          ) : (
            <ul className="space-y-2">
              {savedLocations.map((location) => {
                const isActive = location.id === activeLocationId
                return (
                  <li
                    key={location.id}
                    className={`flex items-center gap-2 rounded-lg border px-3 py-2 ${
                      isActive ? 'border-primary/50 bg-primary/5' : 'border-border/70'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onSelectSaved(location.id)}
                      aria-pressed={isActive}
                      className="flex min-w-0 flex-1 items-center gap-2 rounded-md py-1.5 text-start outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                    >
                      <span className="min-w-0 flex-1 truncate text-sm font-medium text-foreground">
                        {location.label}
                      </span>
                      {isActive ? (
                        <Badge variant="secondary" className="shrink-0 gap-1">
                          <Check aria-hidden="true" className="size-3" />
                          {t('prayer.defaultLocation')}
                        </Badge>
                      ) : null}
                    </button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-11 shrink-0 text-muted-foreground"
                      aria-label={`${t('common.delete')} ${location.label}`}
                      onClick={() => setPendingDelete(location)}
                    >
                      <Trash2 aria-hidden="true" className="size-4" />
                    </Button>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      </CardContent>

      {/* City search dialog */}
      <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t('prayer.searchCity')}</DialogTitle>
            <DialogDescription>{t('prayer.searchHint')}</DialogDescription>
          </DialogHeader>

          <div className="relative">
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t('prayer.searchPlaceholder')}
              aria-label={t('prayer.searchCity')}
              className="h-11 ps-9"
              autoFocus
            />
          </div>

          {searchQuery.data?.status === 'degraded' ? (
            <p className="text-xs text-muted-foreground">{t('prayer.search.degraded')}</p>
          ) : null}

          <ScrollArea className="max-h-80 -me-2">
            <div className="space-y-1 pe-2">
              {query.trim().length < 2 ? (
                <p className="px-3 py-6 text-center text-sm text-muted-foreground">
                  {t('prayer.searchHint')}
                </p>
              ) : searchQuery.isLoading ? (
                <div className="flex items-center justify-center gap-2 p-6 text-sm text-muted-foreground">
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                  {t('common.loading')}
                </div>
              ) : searchQuery.isError ? (
                /* A failed search is an error, not an empty result - it gets
                   its own honest message with a retry action. */
                <div className="flex flex-col items-center gap-2 px-3 py-6 text-center">
                  <p className="text-sm text-muted-foreground">{t('prayer.search.error')}</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-11"
                    onClick={() => void searchQuery.refetch()}
                  >
                    {t('prayer.search.retry')}
                  </Button>
                </div>
              ) : (searchQuery.data?.results?.length ?? 0) === 0 ? (
                <p className="px-3 py-6 text-center text-sm text-muted-foreground">
                  {t('common.none')}
                </p>
              ) : (
                searchQuery.data?.results?.map((result) => (
                  <button
                    key={result.id}
                    type="button"
                    onClick={() => handlePick(result)}
                    className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-start outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50"
                  >
                    <span className="flex min-w-0 flex-1 flex-col gap-0.5">
                      <span dir="auto" className="truncate text-sm font-medium text-foreground">
                        {result.name}
                      </span>
                      <span dir="auto" className="truncate text-xs text-muted-foreground">
                        {[result.region, result.country].filter(Boolean).join(', ')}
                        {result.timeZone ? ` · ${result.timeZone}` : ''}
                      </span>
                    </span>
                    {result.approximate ? (
                      <span className="shrink-0" title={t('prayer.cityApproximate')}>
                        <Star aria-hidden="true" className="size-3.5 text-muted-foreground" />
                      </span>
                    ) : null}
                  </button>
                ))
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* PROMPT 14: destructive confirm for removing a saved location. */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('prayer.removeLocationTitle')}</AlertDialogTitle>
            <AlertDialogDescription>{t('prayer.removeLocationBody')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (pendingDelete) onRemoveSaved(pendingDelete.id)
                setPendingDelete(null)
              }}
            >
              {t('common.remove')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
