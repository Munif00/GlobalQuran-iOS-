'use client'

/**
 * Global Quran - Prayer settings section.
 *
 * Rendered inside the calculation-settings dialog (a secondary screen, kept
 * off the main prayer dashboard). Contains:
 * - Method: automatic (documented country default - clearly labeled as an
 *   official national setting vs a recommended default) or manual (the full
 *   verified method registry, with AlAdhan's own "experimental" labels).
 * - Asr: Standard/Shafi'i vs Hanafi, explained in simple language, never
 *   silently changed by location.
 * - High-latitude rule: the three documented options plus automatic.
 * - Time zone: automatic from the location, with a manual correction for
 *   wrong detections (real IANA zones taken from the bundled city data).
 * - Per-prayer minute adjustments.
 * - Notification architecture preferences (permission only on explicit
 *   user action; foreground-only delivery stated honestly).
 */

import { toast } from 'sonner'
import { Bell, BellOff, Minus, MoonStar, Plus } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { BUNDLED_TIME_ZONES } from '@/lib/prayer/cities'
import type {
  CalculationMethodId,
  CalculationMethodInfo,
  HighLatitudeRuleMode,
  Madhhab,
  PrayerAdjustments,
  PrayerNotificationPreferences,
} from '@/types'
import { formatNumber } from '@/utils/format'
import type { NotificationPermissionState } from '@/services/notifications/prayer-notification-service'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'

const METHOD_LABEL_KEYS: Record<CalculationMethodId, TranslationKey> = {
  MWL: 'prayer.method.MWL',
  ISNA: 'prayer.method.ISNA',
  EGYPT: 'prayer.method.EGYPT',
  MAKKAH: 'prayer.method.MAKKAH',
  KARACHI: 'prayer.method.KARACHI',
  TEHRAN: 'prayer.method.TEHRAN',
  JAFARI: 'prayer.method.JAFARI',
  GULF: 'prayer.method.GULF',
  KUWAIT: 'prayer.method.KUWAIT',
  QATAR: 'prayer.method.QATAR',
  SINGAPORE: 'prayer.method.SINGAPORE',
  FRANCE: 'prayer.method.FRANCE',
  TURKEY: 'prayer.method.TURKEY',
  RUSSIA: 'prayer.method.RUSSIA',
  MOONSIGHTING: 'prayer.method.MOONSIGHTING',
  DUBAI: 'prayer.method.DUBAI',
  JAKIM: 'prayer.method.JAKIM',
  TUNISIA: 'prayer.method.TUNISIA',
  ALGERIA: 'prayer.method.ALGERIA',
  KEMENAG: 'prayer.method.KEMENAG',
  MOROCCO: 'prayer.method.MOROCCO',
  PORTUGAL: 'prayer.method.PORTUGAL',
  JORDAN: 'prayer.method.JORDAN',
}

const HLR_OPTIONS: Array<{ value: HighLatitudeRuleMode; labelKey: TranslationKey }> = [
  { value: 'auto', labelKey: 'prayer.hlr.auto' },
  { value: 'middle_of_night', labelKey: 'prayer.hlr.middle_of_night' },
  { value: 'one_seventh', labelKey: 'prayer.hlr.one_seventh' },
  { value: 'angle_based', labelKey: 'prayer.hlr.angle_based' },
]

const ADJUSTMENT_ROWS: Array<{ field: keyof PrayerAdjustments; labelKey: TranslationKey }> = [
  { field: 'fajr', labelKey: 'prayer.fajr' },
  { field: 'sunrise', labelKey: 'prayer.sunrise' },
  { field: 'dhuhr', labelKey: 'prayer.dhuhr' },
  { field: 'asr', labelKey: 'prayer.asr' },
  { field: 'maghrib', labelKey: 'prayer.maghrib' },
  { field: 'isha', labelKey: 'prayer.isha' },
]

interface PrayerSettingsSectionProps {
  methods: CalculationMethodInfo[]
  methodMode: 'auto' | 'manual'
  calculationMethod: CalculationMethodId
  onMethodModeChange: (mode: 'auto' | 'manual') => void
  onMethodChange: (method: CalculationMethodId) => void
  resolvedDefault: {
    methodId: CalculationMethodId
    kind: 'official_national' | 'regional_common' | 'global_default'
    countryName: string
  } | null
  countryName: string | null
  madhhab: Madhhab
  onMadhhabChange: (madhhab: Madhhab) => void
  highLatitudeRule: HighLatitudeRuleMode
  onHighLatitudeRuleChange: (rule: HighLatitudeRuleMode) => void
  /** Time-zone handling: automatic from the location or a manual correction. */
  timeZoneMode: 'auto' | 'manual'
  manualTimeZone: string | null
  /** The zone detected from the current location (context for the setting). */
  autoTimeZone: string | null
  onTimeZoneModeChange: (mode: 'auto' | 'manual') => void
  onManualTimeZoneChange: (zone: string | null) => void
  adjustments: PrayerAdjustments
  onAdjustmentChange: (field: keyof PrayerAdjustments, delta: number) => void
  notifications: PrayerNotificationPreferences
  onNotificationsChange: (patch: Partial<PrayerNotificationPreferences>) => void
  notificationPermission: NotificationPermissionState
  onRequestNotifications: () => Promise<void>
}

export function PrayerSettingsSection({
  methods,
  methodMode,
  calculationMethod,
  onMethodModeChange,
  onMethodChange,
  resolvedDefault,
  countryName,
  madhhab,
  onMadhhabChange,
  highLatitudeRule,
  onHighLatitudeRuleChange,
  timeZoneMode,
  manualTimeZone,
  autoTimeZone,
  onTimeZoneModeChange,
  onManualTimeZoneChange,
  adjustments,
  onAdjustmentChange,
  notifications,
  onNotificationsChange,
  notificationPermission,
  onRequestNotifications,
}: PrayerSettingsSectionProps) {
  const { t, locale } = useTranslation()

  const resolvedKindLabel: TranslationKey | null =
    resolvedDefault?.kind === 'official_national'
      ? 'prayer.methodKind.official'
      : resolvedDefault?.kind === 'regional_common'
        ? 'prayer.methodKind.regional'
        : resolvedDefault?.kind === 'global_default'
          ? 'prayer.methodKind.global'
          : null

  const selectedMethod = methods.find((method) => method.id === calculationMethod) ?? null

  const handleNotificationToggle = async (checked: boolean) => {
    if (checked) {
      await onRequestNotifications()
    } else {
      onNotificationsChange({ enabled: false })
    }
  }

  const handleManualZoneChange = (zone: string) => {
    onManualTimeZoneChange(zone || null)
    toast(t('prayer.savedToast'))
  }

  return (
    <div className="space-y-6">
      {/* Method selection */}
        <div className="space-y-3">
          <Label>{t('prayer.methodMode')}</Label>
          <div className="grid gap-3 sm:grid-cols-2">
            <Button
              type="button"
              variant={methodMode === 'auto' ? 'default' : 'outline'}
              className="min-h-11 justify-start"
              aria-pressed={methodMode === 'auto'}
              onClick={() => onMethodModeChange('auto')}
            >
              {t('prayer.methodMode.auto')}
            </Button>
            <Button
              type="button"
              variant={methodMode === 'manual' ? 'default' : 'outline'}
              className="min-h-11 justify-start"
              aria-pressed={methodMode === 'manual'}
              onClick={() => onMethodModeChange('manual')}
            >
              {t('prayer.methodMode.manual')}
            </Button>
          </div>

          {methodMode === 'auto' ? (
            resolvedDefault ? (
              <div className="rounded-lg border border-border/70 bg-muted/40 p-3 text-sm">
                <p className="font-medium text-foreground">
                  {t('prayer.autoResolvesTo', {
                    country: countryName ?? resolvedDefault.countryName,
                    method: t(METHOD_LABEL_KEYS[resolvedDefault.methodId]),
                  })}
                </p>
                {resolvedKindLabel ? (
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {t(resolvedKindLabel)}
                  </p>
                ) : null}
              </div>
            ) : (
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('prayer.noCountryDefault')}
              </p>
            )
          ) : (
            <div className="space-y-2">
              <Select value={calculationMethod} onValueChange={(value) => onMethodChange(value as CalculationMethodId)}>
                <SelectTrigger className="h-11 w-full" aria-label={t('prayer.calculationMethod')}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {methods.map((method) => (
                    <SelectItem key={method.id} value={method.id}>
                      {t(METHOD_LABEL_KEYS[method.id])}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedMethod ? (
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {selectedMethod.paramsSummary}
                  {selectedMethod.experimental ? ` · ${t('prayer.experimentalTag')}` : ''}
                </p>
              ) : null}
            </div>
          )}
        </div>

        {/* Asr + high latitude */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="prayer-madhhab">{t('prayer.asrSetting')}</Label>
            <Select value={madhhab} onValueChange={(value) => onMadhhabChange(value as Madhhab)}>
              <SelectTrigger id="prayer-madhhab" className="h-11 w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="standard">{t('prayer.madhhab.standard')}</SelectItem>
                <SelectItem value="hanafi">{t('prayer.madhhab.hanafi')}</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs leading-relaxed text-muted-foreground">{t('prayer.asrDescription')}</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="prayer-hlr">{t('prayer.highLatitudeSetting')}</Label>
            <Select
              value={highLatitudeRule}
              onValueChange={(value) => onHighLatitudeRuleChange(value as HighLatitudeRuleMode)}
            >
              <SelectTrigger id="prayer-hlr" className="h-11 w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {HLR_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {t(option.labelKey)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('prayer.highLatitudeDescription')}
            </p>
          </div>
        </div>

        {/* Time zone: automatic from the location, correctable manually */}
        <div className="space-y-3">
          <Label>{t('prayer.timeZoneSetting')}</Label>
          <div className="grid gap-3 sm:grid-cols-2">
            <Button
              type="button"
              variant={timeZoneMode === 'auto' ? 'default' : 'outline'}
              className="min-h-11 justify-start"
              aria-pressed={timeZoneMode === 'auto'}
              onClick={() => onTimeZoneModeChange('auto')}
            >
              {t('prayer.timeZoneMode.auto')}
            </Button>
            <Button
              type="button"
              variant={timeZoneMode === 'manual' ? 'default' : 'outline'}
              className="min-h-11 justify-start"
              aria-pressed={timeZoneMode === 'manual'}
              onClick={() => onTimeZoneModeChange('manual')}
            >
              {t('prayer.timeZoneMode.manual')}
            </Button>
          </div>

          {timeZoneMode === 'auto' ? (
            <p className="text-xs leading-relaxed text-muted-foreground">
              {autoTimeZone
                ? t('prayer.timeZoneAutoCurrent', { zone: autoTimeZone })
                : t('prayer.timeZoneAutoUnknown')}
            </p>
          ) : (
            <div className="space-y-2">
              <Select value={manualTimeZone ?? ''} onValueChange={handleManualZoneChange}>
                <SelectTrigger className="h-11 w-full" aria-label={t('prayer.timeZoneSetting')} dir="ltr">
                  <SelectValue placeholder={t('prayer.timeZoneSelectPlaceholder')} />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {BUNDLED_TIME_ZONES.map((zone) => (
                    <SelectItem key={zone} value={zone}>
                      {zone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('prayer.timeZoneManualHint')}
              </p>
            </div>
          )}
        </div>

        {/* Adjustments */}
        <div>
          <p className="text-sm font-medium text-foreground">{t('prayer.adjustments')}</p>
          <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
            {t('prayer.adjustmentsDescription')}
          </p>
          <div className="mt-3 space-y-2">
            {ADJUSTMENT_ROWS.map(({ field, labelKey }) => (
              <div
                key={field}
                className="flex items-center justify-between gap-3 rounded-lg border border-border/70 px-3 py-2"
              >
                <span className="min-w-0 truncate text-sm font-medium text-foreground">
                  {t(labelKey)}
                </span>
                <span className="flex shrink-0 items-center gap-1.5">
                  <Button
                    variant="outline"
                    size="icon"
                    className="size-11"
                    onClick={() => onAdjustmentChange(field, -1)}
                    aria-label={`${t(labelKey)} -1 ${t('prayer.minutesShort')}`}
                    disabled={adjustments[field] <= -60}
                  >
                    <Minus aria-hidden="true" className="size-4" />
                  </Button>
                  <span className="w-12 text-center text-sm font-semibold tabular-nums text-foreground">
                    {formatNumber(locale, adjustments[field])}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="size-11"
                    onClick={() => onAdjustmentChange(field, 1)}
                    aria-label={`${t(labelKey)} +1 ${t('prayer.minutesShort')}`}
                    disabled={adjustments[field] >= 60}
                  >
                    <Plus aria-hidden="true" className="size-4" />
                  </Button>
                  <span className="w-8 text-xs text-muted-foreground">{t('prayer.minutesShort')}</span>
                </span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Notifications (architecture) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="flex items-center gap-2 text-sm font-medium text-foreground">
                {notifications.enabled ? (
                  <Bell aria-hidden="true" className="size-4 text-primary" />
                ) : (
                  <BellOff aria-hidden="true" className="size-4 text-muted-foreground" />
                )}
                {t('prayer.notifications')}
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                {t('prayer.notificationsForegroundOnly')}
              </p>
            </div>
            <Switch
              checked={notifications.enabled}
              onCheckedChange={(checked) => void handleNotificationToggle(checked)}
              aria-label={t('prayer.notificationsEnable')}
            />
          </div>

          {notificationPermission === 'denied' ? (
            <p className="text-xs text-destructive">{t('prayer.notificationsDenied')}</p>
          ) : null}

          {notifications.enabled ? (
            <div className="space-y-3 rounded-lg border border-border/70 p-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="prayer-lead">{t('prayer.leadMinutes')}</Label>
                  <Input
                    id="prayer-lead"
                    type="number"
                    min={0}
                    max={60}
                    value={notifications.leadMinutes}
                    onChange={(event) => {
                      const value = Math.min(60, Math.max(0, Number(event.target.value) || 0))
                      onNotificationsChange({ leadMinutes: value })
                    }}
                    className="h-11"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('prayer.quietHours')}</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={notifications.quietHours.start}
                      onChange={(event) =>
                        onNotificationsChange({
                          quietHours: { ...notifications.quietHours, start: event.target.value },
                        })
                      }
                      className="h-11"
                      aria-label={t('prayer.quietHoursStart')}
                      disabled={!notifications.quietHours.enabled}
                      dir="ltr"
                    />
                    <span aria-hidden="true" className="text-muted-foreground">-</span>
                    <Input
                      type="time"
                      value={notifications.quietHours.end}
                      onChange={(event) =>
                        onNotificationsChange({
                          quietHours: { ...notifications.quietHours, end: event.target.value },
                        })
                      }
                      className="h-11"
                      aria-label={t('prayer.quietHoursEnd')}
                      disabled={!notifications.quietHours.enabled}
                      dir="ltr"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="prayer-quiet"
                      checked={notifications.quietHours.enabled}
                      onCheckedChange={(checked) =>
                        onNotificationsChange({
                          quietHours: { ...notifications.quietHours, enabled: checked },
                        })
                      }
                    />
                    <Label htmlFor="prayer-quiet" className="text-xs text-muted-foreground">
                      {t('prayer.quietHoursHint')}
                    </Label>
                  </div>
                </div>
              </div>

              <div>
                <Label>{t('prayer.perPrayer')}</Label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {(
                    ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as const
                  ).map((prayer) => (
                    <Button
                      key={prayer}
                      type="button"
                      variant={notifications.perPrayer[prayer] ? 'default' : 'outline'}
                      size="sm"
                      className="min-h-11"
                      aria-pressed={notifications.perPrayer[prayer]}
                      onClick={() =>
                        onNotificationsChange({
                          perPrayer: {
                            ...notifications.perPrayer,
                            [prayer]: !notifications.perPrayer[prayer],
                          },
                        })
                      }
                    >
                      {t(`prayer.${prayer}` as TranslationKey)}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="flex items-start justify-between gap-3">
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {t('prayer.adhanPrepared')}
                </p>
              </div>
            </div>
          ) : null}
        </div>
    </div>
  )
}
