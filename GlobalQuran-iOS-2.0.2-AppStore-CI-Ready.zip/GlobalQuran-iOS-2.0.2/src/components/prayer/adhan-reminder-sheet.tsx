'use client'

/**
 * Global Quran - Adhan reminder settings sheet (PROMPT 13).
 *
 * The single, simple entry point for the whole reminder feature:
 *
 *   Open Prayer Times -> tap Reminder -> configure everything here.
 *
 * Two panes with lightweight internal navigation:
 * 1. 'settings' - master switch, reminder style (Full Adhan / silent),
 *    same-Adhan-for-all vs per-prayer assignment, volume, preview of the
 *    selected Adhan, per-prayer reminder toggles, lead minutes for silent
 *    mode, and honest permission/platform notes.
 * 2. 'library'   - the muezzin list; opened for a specific selection
 *    context (all prayers, or one prayer such as a separate Fajr pick).
 *
 * The ideal user journey stays intact:
 * tap Reminder -> Choose a muezzin -> Play Preview (auto-downloads) ->
 * Select -> enable reminders.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import {
  ArrowLeft,
  Bell,
  BellOff,
  BellRing,
  CheckCircle2,
  ChevronRight,
  Clock,
  Info,
  MoonStar,
  Play,
  Square,
  Sun,
  Sunrise,
  Sunset,
  TriangleAlert,
  Volume2,
} from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useAdhanStore } from '@/stores/adhan-store'
import { useAdhanCatalog } from '@/hooks/use-adhan-catalog'
import { adhanPlayer } from '@/services/audio/adhan-player'
import {
  isAndroidNativeShell,
  isIosNativeShell,
  isRealNativePlatform,
} from '@/services/platform/native-mode'
import {
  getStoredAdhanBlob,
  restoreAdhanManifest,
} from '@/services/downloads/adhan-download-manager'
import { resolveAdhanForSlot } from '@/services/notifications/prayer-notification-service'
import {
  nativeRemindersMode,
  getNativeReminderStatus,
  requestNativeNotificationPermission,
  requestNativeReminderSync,
  type NativeReminderStatusView,
} from '@/services/notifications/native-reminders'
import type { PrayerNotificationPreferences } from '@/types'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { AdhanMuezzinList } from '@/components/prayer/adhan-muezzin-list'

type SelectionContext =
  | { kind: 'all' }
  | { kind: 'prayer'; slot: 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha' }

type PrayerSlotId = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'

const PRAYER_ROWS: Array<{ slot: PrayerSlotId; labelKey: TranslationKey; icon: typeof Sun }> = [
  { slot: 'fajr', labelKey: 'prayer.fajr', icon: MoonStar },
  { slot: 'dhuhr', labelKey: 'prayer.dhuhr', icon: Sun },
  { slot: 'asr', labelKey: 'prayer.asr', icon: Sun },
  { slot: 'maghrib', labelKey: 'prayer.maghrib', icon: Sunset },
  /* PROMPT 14: isha is the night prayer - a crescent/night metaphor, not
   *  sunrise (the dashboard already uses MoonStar for isha). */
  { slot: 'isha', labelKey: 'prayer.isha', icon: MoonStar },
]

export interface AdhanReminderSheetProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** PROMPT 14: live notification permission state ('default' | 'granted' |
   *  'denied' | 'unsupported'), so a revoked permission is never silently
   *  presented as an active reminder. */
  permission: NotificationPermission | 'unsupported'
}

/** Format the next native reminder time in the event's own zone (honest:
 *  shows the wall-clock time the reminder will fire at, not the device's
 *  local time). */
function formatNativeNextTime(at: number, timeZone: string | null, locale: string): string {
  try {
    return new Intl.DateTimeFormat(locale, {
      ...(timeZone ? { timeZone } : {}),
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(at))
  } catch {
    return new Intl.DateTimeFormat(locale, { hour: '2-digit', minute: '2-digit' }).format(new Date(at))
  }
}

export function AdhanReminderSheet({ open, onOpenChange, permission }: AdhanReminderSheetProps) {
  const { t, locale } = useTranslation()
  const notifications = usePreferencesStore((s) => s.prayerNotifications)
  const updatePrayerNotifications = usePreferencesStore((s) => s.updatePrayerNotifications)
  const manifest = useAdhanStore((s) => s.manifest)
  const restored = useAdhanStore((s) => s.restored)

  const catalogQuery = useAdhanCatalog()
  const catalog = catalogQuery.data?.recordings ?? []

  const [pane, setPane] = useState<'settings' | 'library'>('settings')
  const [context, setContext] = useState<SelectionContext>({ kind: 'all' })
  const [previewBusy, setPreviewBusy] = useState(false)
  const [previewPlaying, setPreviewPlaying] = useState(false)
  const [nativeStatus, setNativeStatus] = useState<NativeReminderStatusView | null>(null)

  /* PROMPT 16: refresh the native scheduling status whenever the sheet is
   * open and after any preference change. Web/PWA: stays null (the honest
   * "reminders fire while the app is open" note is shown instead). */
  useEffect(() => {
    if (!open) return
    let cancelled = false
    const refresh = () => {
      void getNativeReminderStatus().then((status) => {
        if (!cancelled) setNativeStatus(status)
      })
    }
    refresh()
    return () => {
      cancelled = true
    }
  }, [open, notifications, manifest])

  /* Restore the persisted Adhan manifest once. PROMPT 14: no longer gated on
   *  the sheet being open - the sheet is permanently mounted, so restoring at
   *  mount time means the "Offline ready" badges are truthful by the time the
   *  user first opens the sheet (no "Not downloaded" flash for stored files). */
  useEffect(() => {
    if (!restored) {
      void restoreAdhanManifest()
    }
  }, [restored])

  /* Stop any preview playback when the sheet closes. */
  useEffect(() => {
    if (!open) {
      adhanPlayer.stop()
      setPreviewPlaying(false)
      setPane('settings')
      setContext({ kind: 'all' })
    }
  }, [open])

  const adhan = notifications.adhanSettings

  const effectiveSelectedId = useMemo(() => {
    if (context.kind === 'all') return adhan.sameForAllRecordingId
    return resolveAdhanForSlot(context.slot, adhan)
  }, [context, adhan])

  const catalogById = useMemo(() => {
    const map = new Map<string, (typeof catalog)[number]>()
    for (const entry of catalog) map.set(entry.id, entry)
    return map
  }, [catalog])

  const handleEnable = useCallback(
    async (checked: boolean) => {
      if (checked) {
        if (nativeRemindersMode() === 'native') {
          // Native app: permission flows through the plugin (Android 13+
          // POST_NOTIFICATIONS). The web Notification API cannot display
          // anything inside the WebView.
          const result = await requestNativeNotificationPermission()
          if (result === 'granted') {
            updatePrayerNotifications({ enabled: true })
            toast(t('prayer.notificationsEnabled'))
            requestNativeReminderSync()
          } else if (result === 'denied') {
            toast(t('prayer.notificationsDenied'))
          } else {
            toast(t('prayer.notificationsPermissionNeeded'))
          }
          return
        }
        const { requestNotificationPermission } = await import(
          '@/services/notifications/prayer-notification-service'
        )
        const permission = await requestNotificationPermission()
        if (permission === 'granted') {
          updatePrayerNotifications({ enabled: true })
          toast(t('prayer.notificationsEnabled'))
        } else if (permission === 'denied') {
          toast(t('prayer.notificationsDenied'))
        } else {
          toast(t('prayer.notificationsPermissionNeeded'))
        }
      } else {
        updatePrayerNotifications({ enabled: false })
      }
    },
    [updatePrayerNotifications, t],
  )

  const openLibrary = useCallback((target: SelectionContext) => {
    setContext(target)
    setPane('library')
  }, [])

  const handleSelectInLibrary = useCallback(
    (adhanId: string) => {
      if (context.kind === 'all') {
        updatePrayerNotifications({
          adhanSettings: { ...adhan, sameForAllRecordingId: adhanId, useSameForAll: true },
        })
      } else {
        updatePrayerNotifications({
          adhanSettings: {
            ...adhan,
            useSameForAll: false,
            perPrayerRecordingIds: {
              ...adhan.perPrayerRecordingIds,
              [context.slot]: adhanId,
            },
          },
        })
      }
      toast(t('common.saved'))
      setPane('settings')
    },
    [context, adhan, updatePrayerNotifications, t],
  )

  const handlePreviewSelected = useCallback(async () => {
    const targetId =
      adhan.useSameForAll
        ? adhan.sameForAllRecordingId
        : resolveAdhanForSlot('dhuhr', adhan) ?? adhan.sameForAllRecordingId
    if (!targetId) {
      toast(t('prayer.reminder.selectFirst'))
      return
    }
    if (previewPlaying) {
      adhanPlayer.stop()
      setPreviewPlaying(false)
      return
    }
    const stored = await getStoredAdhanBlob(targetId)
    if (stored === null) {
      /* PROMPT 14 (Nielsen #3/#9): the toast now offers the way forward
       *  instead of only describing it. */
      toast(t('prayer.reminder.notStored'), {
        action: { label: t('adhan.library.title'), onClick: () => openLibrary(context) },
      })
      return
    }
    const entry = catalogById.get(targetId)
    setPreviewBusy(true)
    const played = await adhanPlayer.playBlob(
      stored,
      {
        adhanId: targetId,
        muezzinEn: entry?.muezzinEn ?? '',
        muezzinAr: entry?.muezzinAr ?? '',
      },
      adhan.volume,
    )
    setPreviewBusy(false)
    if (played) setPreviewPlaying(true)
  }, [adhan, previewPlaying, catalogById])

  /* Listen for the end of the selected preview so the button resets. */
  useEffect(() => {
    const remove = adhanPlayer.addListener({
      onEnded: () => setPreviewPlaying(false),
      onStateChange: (state) => {
        if (state === 'idle') setPreviewPlaying(false)
      },
    })
    return remove
  }, [])

  const updateAdhan = (patch: Partial<PrayerNotificationPreferences['adhanSettings']>) => {
    updatePrayerNotifications({ adhanSettings: { ...adhan, ...patch } })
  }

  const selectedEntryName = (id: string | null): string => {
    if (!id) return t('prayer.reminder.noRecordingSelected')
    const entry = catalogById.get(id)
    if (!entry) return id
    return locale.startsWith('ar') ? entry.muezzinAr : entry.muezzinEn
  }

  const isStored = (id: string | null): boolean => {
    if (!id) return false
    return manifest[id] != null
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="inset-x-0 bottom-0 mx-auto flex h-[85dvh] max-h-[85dvh] w-full max-w-lg flex-col rounded-t-2xl p-0 sm:max-w-xl md:inset-y-0 md:left-auto md:right-0 md:h-full md:max-h-full md:w-[420px] md:rounded-none md:border-l"
      >
        {pane === 'settings' ? (
          <>
            <SheetHeader className="pb-3">
              <SheetTitle className="flex items-center gap-2">
                {notifications.enabled ? (
                  <Bell aria-hidden="true" className="size-5 text-primary" />
                ) : (
                  <BellOff aria-hidden="true" className="size-5 text-muted-foreground" />
                )}
                {t('prayer.reminder.title')}
              </SheetTitle>
              <SheetDescription>{t('prayer.reminder.description')}</SheetDescription>
            </SheetHeader>

            <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-6">
              {/* Master switch */}
              <div className="flex items-center justify-between gap-3 rounded-xl border border-border/70 p-4">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground">{t('prayer.reminder.enable')}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                    {t('prayer.reminder.enableAllHint')}
                  </p>
                </div>
                <Switch
                  checked={notifications.enabled}
                  onCheckedChange={(checked) => void handleEnable(checked)}
                  aria-label={t('prayer.reminder.enable')}
                />
              </div>

              {/* PROMPT 14 (Nielsen #1): a revoked OS permission must never look
                  like an active reminder - the state is surfaced here, at the
                  point of control, with the recovery instruction. */}
              {notifications.enabled && permission === 'denied' ? (
                <p
                  role="alert"
                  className="mt-2 flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-xs leading-relaxed text-foreground"
                >
                  <TriangleAlert aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-warning" />
                  <span>
                    <span className="block font-medium">{t('prayer.notificationsBlocked')}</span>
                    {t('prayer.notificationsBlockedHint')}
                  </span>
                </p>
              ) : null}

              {/* PROMPT 16: native background scheduling status (Android app
                  only; stays hidden on web/PWA where the honest "while the
                  app is open" note applies instead). */}
              {nativeStatus ? (
                <section className="mt-4 space-y-3 rounded-xl border border-border/70 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <Label className="text-sm">{t('prayer.reminder.nativeTitle')}</Label>
                    <Badge variant="outline" className="border-emerald-600/40 text-emerald-700 dark:text-emerald-400">
                      {t('adhan.library.offlineReady')}
                    </Badge>
                  </div>
                  <ul className="space-y-2 text-xs leading-relaxed text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                      <span>{t('prayer.reminder.nativeActive')}</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Clock aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
                      <span>
                        {nativeStatus.nextAt && nativeStatus.nextSlot
                          ? t('prayer.reminder.nativeNext', {
                              slot: nativeStatus.nextSlot,
                              time: formatNativeNextTime(nativeStatus.nextAt, nativeStatus.nextTimeZone, locale),
                            })
                          : t('prayer.reminder.nativeNone')}
                        {nativeStatus.exact ? ` ${t('prayer.reminder.nativeExact')}` : null}
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <BellRing aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
                      <span className="flex min-w-0 flex-1 flex-wrap items-center gap-x-2">
                        <span>
                          {t('prayer.reminder.nativePermission')}:{' '}
                          {nativeStatus.notificationPermission === 'granted'
                            ? t('prayer.reminder.nativePermissionGranted')
                            : t('prayer.reminder.nativePermissionDenied')}
                        </span>
                        {nativeStatus.notificationPermission === 'denied' ? (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8"
                            onClick={() => {
                              void requestNativeNotificationPermission().then((result) => {
                                if (result === 'granted') requestNativeReminderSync()
                                void getNativeReminderStatus().then((status) => setNativeStatus(status))
                              })
                            }}
                          >
                            {t('prayer.reminder.grant')}
                          </Button>
                        ) : null}
                      </span>
                    </li>
                  </ul>
                  <p className="border-t border-border/70 pt-3 text-xs leading-relaxed text-muted-foreground">
                    {t('prayer.reminder.nativeSoundNote')}
                  </p>
                </section>
              ) : null}

              {notifications.enabled ? (
                <div className="mt-4 space-y-4">
                  {/* Reminder style */}
                  <section className="space-y-2">
                    <Label>{t('prayer.reminder.mode')}</Label>
                    <div className="grid gap-2 sm:grid-cols-2">
                      <button
                        type="button"
                        onClick={() => updateAdhan({ mode: 'audio' })}
                        aria-pressed={adhan.mode === 'audio'}
                        className={`rounded-xl border p-3 text-start outline-none transition-colors focus-visible:ring-[3px] focus-visible:ring-ring/50 ${
                          adhan.mode === 'audio'
                            ? 'border-primary bg-primary/5'
                            : 'border-border/70 hover:bg-muted/40'
                        }`}
                      >
                        <span className="flex items-center gap-2 text-sm font-medium text-foreground">
                          <Volume2 aria-hidden="true" className="size-4 text-primary" />
                          {t('prayer.reminder.mode.audio')}
                        </span>
                        <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                          {t('prayer.reminder.mode.audioDescription')}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => updateAdhan({ mode: 'silent' })}
                        aria-pressed={adhan.mode === 'silent'}
                        className={`rounded-xl border p-3 text-start outline-none transition-colors focus-visible:ring-[3px] focus-visible:ring-ring/50 ${
                          adhan.mode === 'silent'
                            ? 'border-primary bg-primary/5'
                            : 'border-border/70 hover:bg-muted/40'
                        }`}
                      >
                        <span className="flex items-center gap-2 text-sm font-medium text-foreground">
                          <Bell aria-hidden="true" className="size-4 text-muted-foreground" />
                          {t('prayer.reminder.mode.silent')}
                        </span>
                        <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                          {t('prayer.reminder.mode.silentDescription')}
                        </span>
                      </button>
                    </div>
                  </section>

                  {adhan.mode === 'audio' ? (
                    <section className="space-y-3 rounded-xl border border-border/70 p-4">
                      {/* Same Adhan for all prayers */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between gap-3">
                          <Label className="text-sm">{t('prayer.reminder.sameForAll')}</Label>
                          <Switch
                            checked={adhan.useSameForAll}
                            onCheckedChange={(checked) => updateAdhan({ useSameForAll: checked })}
                            aria-label={t('prayer.reminder.sameForAll')}
                          />
                        </div>
                        <p className="text-xs leading-relaxed text-muted-foreground">
                          {t('prayer.reminder.sameForAllHint')}
                        </p>
                      </div>

                      <Separator />

                      {adhan.useSameForAll ? (
                        /* One recording for every prayer */
                        <button
                          type="button"
                          onClick={() => openLibrary({ kind: 'all' })}
                          className="flex w-full items-center justify-between gap-3 rounded-lg border border-border/70 px-3 py-3 text-start outline-none transition-colors hover:bg-muted/40 focus-visible:ring-[3px] focus-visible:ring-ring/50"
                        >
                          <span className="min-w-0">
                            <span dir="rtl" className="block truncate text-sm font-medium text-foreground">
                              {selectedEntryName(adhan.sameForAllRecordingId)}
                            </span>
                            <span className="mt-0.5 block text-xs text-muted-foreground">
                              {isStored(adhan.sameForAllRecordingId)
                                ? t('adhan.library.offlineReady')
                                : t('prayer.reminder.notStored')}
                            </span>
                          </span>
                          <span className="flex shrink-0 items-center gap-1 text-xs font-medium text-primary">
                            {t('prayer.reminder.change')}
                            <ChevronRight aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                          </span>
                        </button>
                      ) : (
                        /* Per-prayer assignment */
                        <div className="space-y-2">
                          <p className="text-xs font-medium text-foreground">{t('prayer.reminder.assignTitle')}</p>
                          <ul className="space-y-1.5">
                            {PRAYER_ROWS.map(({ slot, labelKey, icon: RowIcon }) => {
                              const assigned = resolveAdhanForSlot(slot, adhan)
                              return (
                                <li key={slot}>
                                  <button
                                    type="button"
                                    onClick={() => openLibrary({ kind: 'prayer', slot })}
                                    className="flex w-full items-center justify-between gap-3 rounded-lg border border-border/70 px-3 py-2.5 text-start outline-none transition-colors hover:bg-muted/40 focus-visible:ring-[3px] focus-visible:ring-ring/50"
                                  >
                                    <span className="flex min-w-0 items-center gap-2">
                                      <RowIcon aria-hidden="true" className="size-4 shrink-0 text-muted-foreground" />
                                      <span className="min-w-0">
                                        <span className="block text-sm font-medium text-foreground">{t(labelKey)}</span>
                                        <span dir="rtl" className="block truncate text-xs text-muted-foreground">
                                          {selectedEntryName(assigned)}
                                          {isStored(assigned) ? (
                                            <Badge variant="outline" className="ms-1.5 h-4 border-emerald-600/40 px-1 text-[10px] text-emerald-700 dark:text-emerald-400">
                                              {t('adhan.library.offlineReady')}
                                            </Badge>
                                          ) : null}
                                        </span>
                                      </span>
                                    </span>
                                    <span className="flex shrink-0 items-center gap-1 text-xs font-medium text-primary">
                                      {t('prayer.reminder.change')}
                                      <ChevronRight aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                                    </span>
                                  </button>
                                </li>
                              )
                            })}
                          </ul>
                          <p className="text-xs leading-relaxed text-muted-foreground">{t('adhan.library.fajrNote')}</p>
                        </div>
                      )}

                      <Separator />

                      {/* Volume */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm">{t('prayer.reminder.volume')}</Label>
                          <span className="text-xs tabular-nums text-muted-foreground">
                            {Math.round(adhan.volume * 100)}%
                          </span>
                        </div>
                        <Slider
                          value={[Math.round(adhan.volume * 100)]}
                          min={0}
                          max={100}
                          step={5}
                          onValueChange={(value) => {
                            const volume = Math.min(1, Math.max(0, (value[0] ?? 100) / 100))
                            updateAdhan({ volume })
                            adhanPlayer.setVolume(volume)
                          }}
                          aria-label={t('prayer.reminder.volume')}
                        />
                        {/* 2.0.1: honest note about WHERE the scheduled Adhan
                            plays (alarm output, temporary raise + exact restore,
                            independent of notification muting). Shown ONLY in
                            the native ANDROID shell - on web the claim would be
                            false (the web scheduler has no alarm-output path),
                            and on iOS the delivery model is different (see the
                            iOS note below). */}
                        {isAndroidNativeShell() ? (
                          <p className="text-xs leading-relaxed text-muted-foreground">
                            {t('adhan.reminder.alarmOutputNote')}
                          </p>
                        ) : null}
                        {/* iOS (2.0.2 iOS port): the honest platform delivery
                            note - a notification-based reminder with the
                            system's sound limits, Silent/Focus respected, no
                            delivery after force-quit. Never a false parity
                            claim. */}
                        {isIosNativeShell() ? (
                          <p className="text-xs leading-relaxed text-muted-foreground">
                            {t('adhan.reminder.iosDeliveryNote')}
                          </p>
                        ) : null}
                      </div>

                      {/* Preview the selected Adhan */}
                      <Button
                        variant="outline"
                        className="h-11 w-full justify-center gap-2"
                        onClick={() => void handlePreviewSelected()}
                        disabled={previewBusy}
                      >
                        {previewPlaying ? (
                          <Square aria-hidden="true" className="size-4" />
                        ) : (
                          <Play aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                        )}
                        {previewPlaying
                          ? t('adhan.library.stopPreview')
                          : t('prayer.reminder.previewSelected')}
                      </Button>

                      <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
                        <Info aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
                        {t('prayer.reminder.leadAtExactTime')}
                      </p>
                    </section>
                  ) : (
                    /* Silent mode: lead minutes */
                    <section className="space-y-2 rounded-xl border border-border/70 p-4">
                      <Label htmlFor="reminder-lead">{t('prayer.leadMinutes')}</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="reminder-lead"
                          type="number"
                          min={0}
                          max={60}
                          value={notifications.leadMinutes}
                          onChange={(event) => {
                            const value = Math.min(60, Math.max(0, Number(event.target.value) || 0))
                            updatePrayerNotifications({ leadMinutes: value })
                          }}
                          className="h-11"
                          dir="ltr"
                        />
                      </div>
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        {t('prayer.reminder.leadHint')}
                      </p>
                    </section>
                  )}

                  {/* Per-prayer reminder toggles */}
                  <section className="space-y-2 rounded-xl border border-border/70 p-4">
                    <Label>{t('prayer.perPrayer')}</Label>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {(['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as const).map((prayer) => (
                        <Button
                          key={prayer}
                          type="button"
                          variant={notifications.perPrayer[prayer] ? 'default' : 'outline'}
                          size="sm"
                          className="min-h-11"
                          aria-pressed={notifications.perPrayer[prayer]}
                          onClick={() =>
                            updatePrayerNotifications({
                              perPrayer: {
                                ...notifications.perPrayer,
                                [prayer]: !notifications.perPrayer[prayer],
                              },
                            })
                          }
                        >
                          {t(`prayer.${prayer}` as TranslationKey)}
                        </Button>
                      ))}
                    </div>
                  </section>
                </div>
              ) : null}

              {/* Honest platform note - platform-aware (PROMPT 16). Native
                  Android: reminders fire through the alarm system even when
                  the app is closed. Web/PWA: reminders fire while the app is
                  open (stated plainly, never overstated). */}
              <p className="mt-4 flex items-start gap-2 rounded-lg border border-border/70 bg-muted/30 p-3 text-xs leading-relaxed text-muted-foreground">
                <Info aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
                {nativeStatus
                  ? t('prayer.reminder.platformNoteNative', { days: String(nativeStatus.horizonDays) })
                  : t('prayer.reminder.platformNote')}
              </p>
            </div>
          </>
        ) : (
          /* ---------------------- Library pane ---------------------- */
          <>
            <SheetHeader className="pb-3">
              <SheetTitle className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="-ms-2 size-11"
                  onClick={() => setPane('settings')}
                  aria-label={t('common.back')}
                >
                  <ArrowLeft aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                </Button>
                {t('adhan.library.title')}
              </SheetTitle>
              <SheetDescription>{t('adhan.library.description')}</SheetDescription>
            </SheetHeader>

            <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-6">
              {catalogQuery.isLoading ? (
                <p className="py-8 text-center text-sm text-muted-foreground">{t('common.loading')}</p>
              ) : catalogQuery.isError ? (
                /* PROMPT 14 (Nielsen #9): a dead-end error becomes a retry. */
                <div className="space-y-3 py-8 text-center">
                  <p className="text-sm text-destructive">{t('adhan.library.downloadFailed')}</p>
                  <Button
                    variant="outline"
                    className="h-11"
                    onClick={() => void catalogQuery.refetch()}
                    disabled={catalogQuery.isFetching}
                  >
                    {catalogQuery.isFetching ? t('common.loading') : t('common.retry')}
                  </Button>
                </div>
              ) : (
                <AdhanMuezzinList
                  catalog={catalog}
                  selectedId={effectiveSelectedId}
                  onSelect={handleSelectInLibrary}
                  previewVolume={adhan.volume}
                />
              )}
              <p className="mt-4 text-center text-xs text-muted-foreground">
                {t('adhan.library.sourceAttribution')}
              </p>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
