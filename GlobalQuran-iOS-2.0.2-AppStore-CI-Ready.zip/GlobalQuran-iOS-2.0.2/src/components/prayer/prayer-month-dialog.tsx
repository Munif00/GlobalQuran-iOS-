'use client'

/**
 * Global Quran - Monthly prayer timetable dialog.
 *
 * Every row comes from the resolver's calendar response - each date is
 * calculated or retrieved individually by the source (JAKIM per-day
 * official data / AlAdhan calendar / local engine), never extrapolated
 * from a single day. Exports contain exactly what is displayed.
 */

import { useMemo } from 'react'
import { toast } from 'sonner'
import { ChevronLeft, ChevronRight, Copy, Download, Loader2, Share2 } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import type { PrayerTimeRecord } from '@/types'
import { formatDate } from '@/utils/format'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'

interface PrayerMonthDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  month: string
  onMonthChange: (month: string) => void
  records: PrayerTimeRecord[]
  loading: boolean
  errorKey: string | null
  locationLabel: string | null
  timeZone: string | null
  todayIso: string | null
  /** PROMPT 14: recovery path for the month load failure (Nielsen #9). */
  onRetry?: () => void
}

const TIME_COLUMNS: Array<{ key: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'; labelKey: 'prayer.fajr' | 'prayer.sunrise' | 'prayer.dhuhr' | 'prayer.asr' | 'prayer.maghrib' | 'prayer.isha' }> = [
  { key: 'fajr', labelKey: 'prayer.fajr' },
  { key: 'sunrise', labelKey: 'prayer.sunrise' },
  { key: 'dhuhr', labelKey: 'prayer.dhuhr' },
  { key: 'asr', labelKey: 'prayer.asr' },
  { key: 'maghrib', labelKey: 'prayer.maghrib' },
  { key: 'isha', labelKey: 'prayer.isha' },
]

/** PROMPT 14: friendly zone label (e.g. `GMT+3 · Aden`) instead of the raw
 *  IANA id - matches the hero, which already hides the identifier. */
function friendlyZoneLabel(timeZone: string | null): string {
  if (!timeZone) return ''
  const city = timeZone.split('/').pop()?.replace(/_/g, ' ') ?? timeZone
  for (const timeZoneName of ['shortOffset', 'short'] as const) {
    try {
      const parts = new Intl.DateTimeFormat('en', { timeZone, timeZoneName })
        .formatToParts(new Date())
        .find((part) => part.type === 'timeZoneName')
      if (parts?.value) return `${parts.value} · ${city}`
    } catch {
      // Unsupported zone id or option - try the next variant.
    }
  }
  return city
}

function shiftMonth(month: string, delta: number): string {
  const [year, monthNumber] = month.split('-').map(Number)
  const date = new Date(Date.UTC(year, monthNumber - 1 + delta, 1))
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`
}

/** Format an ISO instant as a wall-clock time in the record's zone (locale default). */
function wallTime(iso: string, timeZone: string, locale: string): string {
  try {
    return formatDate(locale, new Date(iso), {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return '--:--'
  }
}

/** Unambiguous 24-hour export format (data exports stay locale-independent). */
function wallTimeExport(iso: string, timeZone: string): string {
  try {
    return formatDate('en-GB', new Date(iso), {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    })
  } catch {
    return '--:--'
  }
}

export function PrayerMonthDialog({
  open,
  onOpenChange,
  month,
  onMonthChange,
  records,
  loading,
  errorKey,
  locationLabel,
  timeZone,
  todayIso,
  onRetry,
}: PrayerMonthDialogProps) {
  const { t, locale } = useTranslation()

  const monthLabel = useMemo(() => {
    const [year, monthNumber] = month.split('-').map(Number)
    return formatDate(locale, new Date(Date.UTC(year, monthNumber - 1, 1)), {
      year: 'numeric',
      month: 'long',
    })
  }, [locale, month])

  const asText = useMemo(() => {
    const header = `${t('prayer.monthTitle')} - ${monthLabel}${locationLabel ? ` - ${locationLabel}` : ''}`
    const columns = TIME_COLUMNS.map((column) => t(column.labelKey))
    const lines = [header, ['', ...columns].join(',')]
    for (const record of records) {
      const day = record.date.slice(8, 10)
      const times = TIME_COLUMNS.map((column) => wallTimeExport(record[column.key], record.timeZone))
      lines.push([day, ...times].join(','))
    }
    return lines.join('\n')
  }, [records, monthLabel, locationLabel, t])

  const asCsv = useMemo(() => {
    const columns = TIME_COLUMNS.map((column) => t(column.labelKey))
    const lines = [
      ['date', ...columns].join(','),
      ...records.map((record) => {
        const times = TIME_COLUMNS.map((column) => wallTimeExport(record[column.key], record.timeZone))
        return [record.date, ...times].join(',')
      }),
    ]
    return lines.join('\n')
  }, [records, t])

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(asText)
      toast(t('prayer.copied'))
    } catch {
      toast(t('prayer.copyFailed'))
    }
  }

  const handleDownload = () => {
    const blob = new Blob([asCsv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `prayer-times-${month}.csv`
    anchor.click()
    URL.revokeObjectURL(url)
    toast(t('prayer.csvDownloaded'))
  }

  const handleShare = async () => {
    if (typeof navigator !== 'undefined' && 'share' in navigator) {
      try {
        await navigator.share({ title: t('prayer.monthTitle'), text: asText })
      } catch {
        // User dismissed the share sheet - not an error.
      }
    } else {
      toast(t('prayer.shareUnavailable'))
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="truncate">{monthLabel}</span>
          </DialogTitle>
          <DialogDescription className="truncate">
            {locationLabel ? `${locationLabel}` : t('prayer.monthTitle')}
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-between gap-2">
          <Button
            variant="outline"
            size="icon"
            className="size-11"
            aria-label={t('prayer.prevMonth')}
            onClick={() => onMonthChange(shiftMonth(month, -1))}
          >
            <ChevronLeft aria-hidden="true" className="size-4 rtl:-scale-x-100" />
          </Button>
          <p className="min-w-0 flex-1 text-center text-sm text-muted-foreground" dir="ltr">
            {friendlyZoneLabel(timeZone)}
          </p>
          <Button
            variant="outline"
            size="icon"
            className="size-11"
            aria-label={t('prayer.nextMonth')}
            onClick={() => onMonthChange(shiftMonth(month, 1))}
          >
            <ChevronRight aria-hidden="true" className="size-4 rtl:-scale-x-100" />
          </Button>
        </div>

        <ScrollArea className="max-h-[50vh]">
          {loading ? (
            <div className="space-y-2 p-1">
              {Array.from({ length: 8 }).map((_, index) => (
                <Skeleton key={index} className="h-9 w-full" />
              ))}
            </div>
          ) : errorKey ? (
            <div className="space-y-3 p-4 text-center">
              <p className="text-sm text-muted-foreground">{t(errorKey as TranslationKey)}</p>
              {onRetry ? (
                <Button variant="outline" className="h-11" onClick={onRetry}>
                  {t('common.retry')}
                </Button>
              ) : null}
            </div>
          ) : records.length === 0 ? (
            <p className="p-4 text-center text-sm text-muted-foreground">{t('common.none')}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[34rem] border-collapse text-sm">
              <thead>
                <tr className="border-b text-muted-foreground">
                  <th scope="col" className="p-2 text-start font-medium">
                    {t('prayer.dateLabel')}
                  </th>
                  {TIME_COLUMNS.map((column) => (
                    <th scope="col" key={column.key} className="p-2 text-end font-medium">
                      {t(column.labelKey)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {records.map((record) => {
                  const isToday = todayIso === record.date
                  return (
                    <tr
                      key={record.date}
                      className={`border-b border-border/50 ${isToday ? 'bg-primary/10 font-semibold' : ''}`}
                    >
                      <td className="p-2 text-start tabular-nums">
                        {formatDate(locale, new Date(`${record.date}T12:00:00Z`), {
                          timeZone: 'UTC',
                          day: 'numeric',
                          month: 'short',
                        })}
                      </td>
                      {TIME_COLUMNS.map((column) => (
                        <td key={column.key} className="p-2 text-end tabular-nums">
                          {wallTime(record[column.key], record.timeZone, locale)}
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
            </div>
          )}
          {records.length > 0 ? (
            <p className="mt-3 border-t border-border/60 pt-3 text-xs leading-relaxed text-muted-foreground">
              {t('prayer.sunriseNote')}
            </p>
          ) : null}
        </ScrollArea>

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" className="min-h-11" onClick={() => void handleCopy()} disabled={records.length === 0}>
            <Copy aria-hidden="true" className="size-4" />
            {t('prayer.copyText')}
          </Button>
          <Button variant="outline" className="min-h-11" onClick={handleDownload} disabled={records.length === 0}>
            <Download aria-hidden="true" className="size-4" />
            {t('prayer.downloadCsv')}
          </Button>
          <Button variant="outline" className="min-h-11" onClick={() => void handleShare()} disabled={records.length === 0}>
            <Share2 aria-hidden="true" className="size-4" />
            {t('prayer.share')}
          </Button>
          {loading ? (
            <Loader2 aria-hidden="true" className="ms-auto size-4 animate-spin text-muted-foreground" />
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  )
}
