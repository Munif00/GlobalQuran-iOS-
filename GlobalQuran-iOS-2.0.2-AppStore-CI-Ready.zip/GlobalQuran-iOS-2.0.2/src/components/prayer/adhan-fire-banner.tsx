'use client'

/**
 * Global Quran - Adhan fire banner (PROMPT 16).
 *
 * Shows when a prayer reminder fires while the NATIVE app is in the
 * foreground: the full Adhan plays through the single Adhan player (with an
 * honest stop control), and this banner states what is happening in the
 * user's language - because inside an Android WebView the web Notification
 * API cannot display anything.
 *
 * On web/PWA the banner stays inactive (real web Notifications are shown by
 * the browser there); it also never shows for quiet-muted events.
 */

import { useEffect } from 'react'
import { BellRing, Square, X } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useAdhanFireStore } from '@/stores/adhan-fire-store'
import { adhanPlayer } from '@/services/audio/adhan-player'
import {
  nativeStopAdhanPlayback,
  onAdhanNativePlaybackEnded,
} from '@/services/native/adhan-native-playback'
import { Button } from '@/components/ui/button'

export function AdhanFireBanner() {
  const { t } = useTranslation()
  const banner = useAdhanFireStore((s) => s.banner)
  const dismiss = useAdhanFireStore((s) => s.dismiss)

  /* Auto-dismiss when playback ends, errors, or is stopped elsewhere. */
  useEffect(() => {
    if (!banner) return
    const remove = adhanPlayer.addListener({
      onEnded: () => dismiss(),
      onStateChange: (state) => {
        if (state === 'idle') dismiss()
      },
    })
    /* iOS native foreground playback (volume-aware): same auto-dismiss
     * wiring for the native player's completion event. */
    let removeNative: (() => void) | null = null
    void onAdhanNativePlaybackEnded(() => dismiss()).then((unsub) => {
      removeNative = unsub
    })
    /* Non-playing outcomes fade after 10 s (the honest message stays long
     * enough to read, never blocks the UI). */
    let timer = 0
    if (banner.state !== 'played') {
      timer = window.setTimeout(() => dismiss(), 10_000)
    }
    return () => {
      remove()
      removeNative?.()
      if (timer !== 0) window.clearTimeout(timer)
    }
  }, [banner, dismiss])

  if (!banner) return null

  const isPlaying = banner.state === 'played'

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed inset-x-0 top-16 z-50 mx-auto flex w-full max-w-md items-start gap-3 rounded-xl border border-primary/30 bg-card/95 p-4 shadow-lg backdrop-blur supports-[backdrop-filter]:bg-card/90"
    >
      <BellRing aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-primary" />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-foreground">
          {banner.title} <span className="text-muted-foreground">· {t('adhan.fire.bannerTitle')}</span>
        </p>
        <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{banner.body}</p>
        {isPlaying ? (
          <Button
            variant="outline"
            size="sm"
            className="mt-2 h-9 gap-2"
            onClick={() => {
              void nativeStopAdhanPlayback()
              adhanPlayer.stop()
              dismiss()
            }}
          >
            <Square aria-hidden="true" className="size-3.5" />
            {t('adhan.fire.stop')}
          </Button>
        ) : null}
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="size-8 shrink-0"
        aria-label={t('common.close')}
        onClick={() => {
          if (isPlaying) {
            void nativeStopAdhanPlayback()
            adhanPlayer.stop()
          }
          dismiss()
        }}
      >
        <X aria-hidden="true" className="size-4" />
      </Button>
    </div>
  )
}
