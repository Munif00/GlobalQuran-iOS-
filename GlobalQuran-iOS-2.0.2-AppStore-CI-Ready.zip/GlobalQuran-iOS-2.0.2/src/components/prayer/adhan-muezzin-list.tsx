'use client'

/**
 * Global Quran - Adhan muezzin list (PROMPT 13).
 *
 * The browsing surface of the verified Adhan library. One row per
 * recording; each row shows the muezzin's name in Arabic and English, the
 * official recording title, verified country info, duration, exact size,
 * real download status, and:
 *
 * - Play Preview: when the recording is not stored yet, this MANDATORY
 *   button starts the automatic download (with a live progress bar and
 *   percentage), verifies the complete file, stores it persistently, and
 *   then plays it from local storage. When already stored, it plays
 *   immediately offline. Only one preview can ever play at a time -
 *   starting another stops the previous one.
 * - Select: chooses this recording for the current selection context.
 * - Delete (stored recordings only): asks for confirmation, clearly warns
 *   when the recording is currently selected for prayers, then removes the
 *   local file. A deleted recording can be downloaded again at any time.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  Loader2,
  Play,
  RefreshCw,
  Square,
  Trash2,
  Volume2,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { formatBytes, formatNumber } from '@/utils/format'
import type { AdhanCatalogEntry } from '@/types'
import type { AdhanProgress } from '@/stores/adhan-store'
import { useAdhanStore } from '@/stores/adhan-store'
import { usePreferencesStore } from '@/stores/preferences-store'
import { adhanPlayer } from '@/services/audio/adhan-player'
import {
  deleteAdhanRecording,
  ensureAdhanDownloaded,
} from '@/services/downloads/adhan-download-manager'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'

export interface AdhanMuezzinListProps {
  /** The verified catalog (never empty in practice - guarded by the parent). */
  catalog: AdhanCatalogEntry[]
  /** The recording currently chosen for the active selection context. */
  selectedId: string | null
  /** Choose this recording for the active context. */
  onSelect: (adhanId: string) => void
  /** PROMPT 14: preview volume follows the reminder volume setting (the
   *  settings pane preview already did - the library preview must match). */
  previewVolume: number
}

function formatDuration(locale: string, seconds: number): string {
  const whole = Math.max(0, Math.round(seconds))
  const minutes = Math.floor(whole / 60)
  const rest = whole % 60
  return `${formatNumber(locale, minutes)}:${formatNumber(locale, rest, { minimumIntegerDigits: 2 })}`
}

export function AdhanMuezzinList({ catalog, selectedId, onSelect, previewVolume }: AdhanMuezzinListProps) {
  const { t, locale, isRTL } = useTranslation()
  const progressMap = useAdhanStore((s) => s.progress)
  const manifest = useAdhanStore((s) => s.manifest)
  /* The full adhan assignment state - used to warn honestly when deleting a
   * recording that is in use by ANY prayer (not just the visible context). */
  const adhanSettings = usePreferencesStore((s) => s.prayerNotifications.adhanSettings)

  /* Live preview player state. */
  const [playerState, setPlayerState] = useState<'idle' | 'playing' | 'paused'>('idle')
  const [playingId, setPlayingId] = useState<string | null>(null)
  const [position, setPosition] = useState(0)
  const [duration, setDuration] = useState(0)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<AdhanCatalogEntry | null>(null)

  useEffect(() => {
    const remove = adhanPlayer.addListener({
      onStateChange: (state) => setPlayerState(state),
      onTime: (positionSeconds, durationSeconds) => {
        setPosition(positionSeconds)
        setDuration(durationSeconds)
      },
      onEnded: () => {
        setPlayingId(null)
        setPosition(0)
        setDuration(0)
      },
      onError: () => {
        toast(t('adhan.library.playbackError'))
      },
    })
    return remove
  }, [t])

  const stopPreview = useCallback(() => {
    adhanPlayer.stop()
    setPlayingId(null)
    setPosition(0)
    setDuration(0)
  }, [])

  const handlePlayPreview = useCallback(
    async (entry: AdhanCatalogEntry) => {
      // Toggling the currently playing preview pauses it; tapping again
      // RESUMES from the same position (PROMPT 14: the label said "Play
      // preview" while the action reset to the start - a misleading
      // affordance). A full stop happens only when starting a different
      // preview or closing the sheet.
      if (playingId === entry.id && playerState !== 'idle') {
        if (playerState === 'paused') {
          adhanPlayer.resume()
        } else {
          adhanPlayer.pause()
        }
        return
      }
      // Starting a different preview stops the previous one completely -
      // enforced by the single Adhan player.
      setBusyId(entry.id)
      const result = await ensureAdhanDownloaded(entry)
      setBusyId(null)
      if (!result.ok) {
        // The failed state is rendered inline per row (with its Retry
        // button and the differentiated copy) - no duplicate toast.
        return
      }
      // result.blob is the verified local file; the player plays it from
      // local storage (never a stream).
      setPlayingId(entry.id)
      setPosition(0)
      setDuration(0)
      const played = await adhanPlayer.playBlob(
        result.blob,
        {
          adhanId: entry.id,
          muezzinEn: entry.muezzinEn,
          muezzinAr: entry.muezzinAr,
        },
        previewVolume,
      )
      if (!played) {
        setPlayingId(null)
        toast(t('adhan.library.playbackError'))
      }
    },
    [playingId, playerState, previewVolume, t],
  )

  const handleConfirmDelete = useCallback(async () => {
    if (!deleteTarget) return
    const ok = await deleteAdhanRecording(deleteTarget.id)
    if (!ok) {
      toast(t('adhan.library.deleteFailed'))
    }
    if (playingId === deleteTarget.id) {
      stopPreview()
    }
    setDeleteTarget(null)
  }, [deleteTarget, playingId, stopPreview, t])

  /** True when the recording is assigned to any prayer or is the
   *  same-for-all selection - deleting it needs the clear in-use warning. */
  const isRecordingInUse = useCallback(
    (id: string): boolean => {
      if (adhanSettings.useSameForAll) return adhanSettings.sameForAllRecordingId === id
      return (Object.values(adhanSettings.perPrayerRecordingIds) as Array<string | null>).includes(id)
    },
    [adhanSettings],
  )

  const rows = useMemo(
    () =>
      catalog.map((entry) => {
        const progress: AdhanProgress | undefined = progressMap[entry.id]
        const stored = manifest[entry.id] != null
        const isPlayingThis = playingId === entry.id && playerState === 'playing'
        const isPausedThis = playingId === entry.id && playerState === 'paused'
        const percent =
          progress && progress.totalBytes > 0
            ? Math.min(100, Math.round((progress.receivedBytes / progress.totalBytes) * 100))
            : 0
        return { entry, progress, stored, isPlayingThis, isPausedThis, percent }
      }),
    [catalog, progressMap, manifest, playingId, playerState],
  )

  return (
    <div className="space-y-3">
      <ul className="space-y-3">
        {rows.map(({ entry, progress, stored, isPlayingThis, isPausedThis, percent }) => (
          <li
            key={entry.id}
            className={`rounded-xl border p-4 transition-colors ${
              selectedId === entry.id ? 'border-primary/60 bg-primary/5' : 'border-border/70'
            }`}
          >
            {/* Names */}
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 space-y-0.5">
                <p dir="rtl" className="truncate text-base font-semibold text-foreground">
                  {entry.muezzinAr}
                </p>
                <p className="truncate text-sm text-muted-foreground">{entry.muezzinEn}</p>
                <p className="truncate text-xs leading-relaxed text-muted-foreground/90">
                  {locale.startsWith('ar') ? entry.titleAr : entry.title}
                  {entry.country ? ` · ${entry.country}` : ''}
                </p>
                <p className="text-xs tabular-nums text-muted-foreground">
                  {t('adhan.library.durationLabel')} {formatDuration(locale, entry.durationSeconds)}
                  {' · '}
                  {t('adhan.library.sizeLabel')} {formatBytes(locale, entry.sizeBytes)}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                {stored ? (
                  <Badge variant="outline" className="gap-1 border-emerald-600/40 text-emerald-700 dark:text-emerald-400">
                    <CheckCircle2 aria-hidden="true" className="size-3" />
                    {t('adhan.library.offlineReady')}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    {t('adhan.library.notDownloaded')}
                  </Badge>
                )}
                {selectedId === entry.id ? (
                  <Badge className="gap-1">
                    <CheckCircle2 aria-hidden="true" className="size-3" />
                    {t('adhan.library.selected')}
                  </Badge>
                ) : null}
              </div>
            </div>

            {/* Download progress (real, byte-accurate) */}
            {progress && progress.phase === 'downloading' ? (
              <div className="mt-3 space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <Download aria-hidden="true" className="size-3 animate-pulse" />
                    {t('adhan.library.downloading')}
                  </span>
                  <span className="tabular-nums">
                    {formatNumber(locale, percent)}% · {formatBytes(locale, progress.receivedBytes)}
                  </span>
                </div>
                <Progress value={percent} aria-label={t('adhan.library.downloading')} />
              </div>
            ) : null}
            {progress && progress.phase === 'verifying' ? (
              <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
                <Loader2 aria-hidden="true" className="size-3.5 animate-spin" />
                {t('adhan.library.verifying')}
              </p>
            ) : null}
            {progress && progress.phase === 'failed' ? (
              <div className="mt-3 flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/5 p-2.5 text-xs text-destructive">
                <AlertTriangle aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
                <p className="min-w-0 flex-1">
                  {progress.errorKey === 'adhan.download.corrupt'
                    ? t('adhan.library.corruptFailed')
                    : progress.errorKey === 'adhan.download.unsupported'
                      ? t('adhan.library.storageFailed')
                      : t('adhan.library.downloadFailed')}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-11 gap-1.5"
                  onClick={() => void handlePlayPreview(entry)}
                >
                  <RefreshCw aria-hidden="true" className="size-3.5" />
                  {t('adhan.library.retry')}
                </Button>
              </div>
            ) : null}

            {/* Live preview progress */}
            {isPlayingThis && duration > 0 ? (
              <div className="mt-3 space-y-1">
                <Progress value={Math.min(100, (position / duration) * 100)} aria-label={t('adhan.player.playing')} />
                <div className="flex items-center justify-between text-xs tabular-nums text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <Volume2 aria-hidden="true" className="size-3" />
                    {t('adhan.player.playing')}
                  </span>
                  <span dir="ltr">
                    {formatDuration(locale, position)} / {formatDuration(locale, duration)}
                  </span>
                </div>
              </div>
            ) : null}

            {/* Actions */}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button
                variant={isPlayingThis ? 'default' : 'outline'}
                size="sm"
                className="min-h-11 gap-2"
                onClick={() => void handlePlayPreview(entry)}
                disabled={busyId === entry.id && progress?.phase === 'downloading'}
              >
                {busyId === entry.id && progress?.phase === 'downloading' ? (
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                ) : isPlayingThis ? (
                  <Square aria-hidden="true" className="size-4" />
                ) : isPausedThis ? (
                  <Play aria-hidden="true" className={`size-4 ${isRTL ? '-scale-x-100' : ''}`} />
                ) : (
                  <Play aria-hidden="true" className={`size-4 ${isRTL ? '-scale-x-100' : ''}`} />
                )}
                {isPlayingThis
                  ? t('adhan.library.stopPreview')
                  : isPausedThis
                    ? t('common.resume')
                    : t('adhan.library.playPreview')}
              </Button>
              <Button
                variant={selectedId === entry.id ? 'secondary' : 'default'}
                size="sm"
                className="min-h-11"
                onClick={() => onSelect(entry.id)}
                disabled={selectedId === entry.id}
              >
                {selectedId === entry.id ? t('adhan.library.selected') : t('adhan.library.select')}
              </Button>
              {stored ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="min-h-11 gap-1.5 text-muted-foreground hover:text-destructive"
                  onClick={() => setDeleteTarget(entry)}
                  aria-label={`${t('adhan.library.delete')} - ${entry.muezzinEn}`}
                >
                  <Trash2 aria-hidden="true" className="size-4" />
                  {t('adhan.library.delete')}
                </Button>
              ) : null}
            </div>

            {/* PROMPT 14 (Nielsen #5): disclose the data cost of the first play
                next to the button that triggers it. */}
            {!stored ? (
              <p className="mt-1.5 text-xs text-muted-foreground">
                {t('adhan.library.playDownloadHint', { size: formatBytes(locale, entry.sizeBytes) })}
              </p>
            ) : null}
          </li>
        ))}
      </ul>

      {/* Delete confirmation - clearly informs when the file is in use. */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('adhan.library.deleteConfirmTitle')}</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2">
                <p>{t('adhan.library.deleteConfirmBody')}</p>
                {deleteTarget && isRecordingInUse(deleteTarget.id) ? (
                  <p className="flex items-start gap-2 rounded-lg border border-amber-600/40 bg-amber-500/10 p-2.5 text-amber-700 dark:text-amber-400">
                    <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
                    {t('adhan.library.deleteSelectedWarning')}
                  </p>
                ) : null}
              </div>
            </AlertDialogDescription>
            <AlertDialogFooter>
              <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-white hover:bg-destructive/90"
                onClick={() => void handleConfirmDelete()}
              >
                {t('common.delete')}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogHeader>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
