/**
 * Application logo mark: a Rub el Hizb inspired geometric emblem
 * (two rotated squares - the classic Islamic eight-pointed star)
 * in gold on deep emerald. Pure SVG, scales crisply, no external assets.
 */

import { cn } from '@/lib/utils'

export function AppLogoMark({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 64 64"
      role="img"
      aria-label="Global Quran"
      className={cn('size-10', className)}
      {...props}
    >
      <rect x="0" y="0" width="64" height="64" rx="14" fill="var(--primary)" />
      {/* Eight-pointed star: two rotated squares */}
      <g
        fill="none"
        stroke="var(--gold)"
        strokeWidth="3"
        strokeLinejoin="round"
        opacity="0.95"
      >
        <rect x="18" y="18" width="28" height="28" rx="2" />
        <rect x="18" y="18" width="28" height="28" rx="2" transform="rotate(45 32 32)" />
      </g>
      <circle cx="32" cy="32" r="4.5" fill="var(--gold)" />
    </svg>
  )
}

/** Logo with bilingual wordmark. */
export function AppLogo({
  className,
  showWordmark = true,
  compact = false,
}: {
  className?: string
  showWordmark?: boolean
  compact?: boolean
}) {
  return (
    <div className={cn('flex items-center gap-3', className)}>
      <AppLogoMark className={compact ? 'size-9' : 'size-10'} />
      {showWordmark ? (
        <div className="min-w-0 leading-tight">
          <p className="truncate text-sm font-semibold tracking-tight text-foreground">
            Global Quran
          </p>
          <p
            dir="rtl"
            lang="ar"
            className={cn(
              'truncate text-[11px] text-muted-foreground',
              compact ? 'text-[10px]' : 'text-xs',
            )}
            style={{ fontFamily: 'var(--app-font-quran)' }}
          >
            القرآن الكريم وترجمات معانيه
          </p>
        </div>
      ) : null}
    </div>
  )
}
