'use client'

/**
 * Standard page container used by every screen for consistent spacing.
 */

import { cn } from '@/lib/utils'

export function PageContainer({
  children,
  className,
  wide = false,
}: {
  children: React.ReactNode
  className?: string
  wide?: boolean
}) {
  return (
    <div
      className={cn(
        // min-w-0 lets the container shrink inside flex ancestors instead of
        // forcing horizontal overflow (long words, wide cards, RTL text).
        'mx-auto min-w-0 w-full px-4 pb-10 pt-6 sm:px-6 md:pt-8',
        wide ? 'max-w-5xl' : 'max-w-3xl',
        className,
      )}
    >
      {children}
    </div>
  )
}
