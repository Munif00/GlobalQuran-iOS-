'use client'

/**
 * Status banners for honest communication: pending integrations, notes,
 * warnings, errors. Soft tinted surfaces - calm, not alarming.
 */

import type { LucideIcon } from 'lucide-react'
import { Clock, Info, TriangleAlert, CircleAlert, CircleCheck } from 'lucide-react'

import { cn } from '@/lib/utils'

export type StatusBannerVariant = 'info' | 'pending' | 'warning' | 'error' | 'success'

const VARIANT_STYLES: Record<StatusBannerVariant, { wrapper: string; icon: string }> = {
  info: {
    wrapper: 'border-primary/25 bg-primary/[0.07] text-primary dark:bg-primary/10',
    icon: 'text-primary',
  },
  pending: {
    wrapper: 'border-gold/35 bg-gold/[0.12] text-accent-foreground',
    icon: 'text-gold',
  },
  warning: {
    wrapper: 'border-warning/40 bg-warning/[0.13]',
    icon: 'text-warning',
  },
  error: {
    wrapper: 'border-destructive/30 bg-destructive/[0.08]',
    icon: 'text-destructive',
  },
  success: {
    wrapper: 'border-success/30 bg-success/[0.1]',
    icon: 'text-success',
  },
}

const VARIANT_ICONS: Record<StatusBannerVariant, LucideIcon> = {
  info: Info,
  pending: Clock,
  warning: TriangleAlert,
  error: CircleAlert,
  success: CircleCheck,
}

export function StatusBanner({
  variant = 'info',
  title,
  description,
  icon: CustomIcon,
  action,
  className,
}: {
  variant?: StatusBannerVariant
  title: string
  description?: string
  icon?: LucideIcon
  action?: React.ReactNode
  className?: string
}) {
  const Icon = CustomIcon ?? VARIANT_ICONS[variant]
  return (
    <div
      role={variant === 'error' ? 'alert' : 'status'}
      className={cn(
        'flex gap-3 rounded-xl border p-4 text-start',
        VARIANT_STYLES[variant].wrapper,
        className,
      )}
    >
      <Icon aria-hidden="true" className={cn('mt-0.5 size-5 shrink-0', VARIANT_STYLES[variant].icon)} />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold leading-snug">{title}</p>
        {description ? (
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{description}</p>
        ) : null}
        {action ? <div className="mt-3">{action}</div> : null}
      </div>
    </div>
  )
}
