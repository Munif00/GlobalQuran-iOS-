'use client'

/**
 * Badge for the four verification states. `official_verified` is emerald,
 * awaiting review is gold, not verified is neutral, rejected is destructive.
 */

import { useTranslation } from '@/i18n'
import type { VerificationStatus } from '@/types'

import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const STATUS_STYLES: Record<VerificationStatus, string> = {
  official_verified: 'border-success/40 bg-success/15 text-success',
  awaiting_verification: 'border-gold/40 bg-gold/15 text-gold-foreground',
  not_verified: 'border-border bg-muted text-muted-foreground',
  rejected: 'border-destructive/40 bg-destructive/10 text-destructive',
}

export function VerificationBadge({
  status,
  className,
}: {
  status: VerificationStatus
  className?: string
}) {
  const { t } = useTranslation()
  const key = `quran.verification.${status}` as const
  return (
    <Badge variant="outline" className={cn('font-medium', STATUS_STYLES[status], className)}>
      {t(key)}
    </Badge>
  )
}
