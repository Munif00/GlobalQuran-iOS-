'use client'

/**
 * Simple label/value row used across detail cards.
 */

import { cn } from '@/lib/utils'

export function InfoRow({
  label,
  value,
  className,
}: {
  label: string
  value: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        'flex items-baseline justify-between gap-4 border-b border-border/60 py-2.5 last:border-b-0',
        className,
      )}
    >
      <dt className="shrink-0 text-sm text-muted-foreground">{label}</dt>
      <dd className="min-w-0 text-end text-sm font-medium text-foreground">{value}</dd>
    </div>
  )
}
