'use client'

/**
 * Sticky top header: brand, live connection status, theme toggle and the
 * profile avatar - the predictable, always-visible entry point to the
 * Profile screen on every screen (mobile included, where Profile is not
 * in the bottom bar). The avatar shows the user's chosen image or the
 * default Quran Mushaf artwork.
 */

import { Moon, Sun, Wifi, WifiOff } from 'lucide-react'
import { useTheme } from 'next-themes'
import Image from 'next/image'

import { useTranslation } from '@/i18n'
import { useOnlineStatus } from '@/hooks/use-online-status'
import { useMounted } from '@/hooks/use-mounted'
import { useNavigationStore } from '@/stores/navigation-store'
import { BUILTIN_AVATARS, usePreferencesStore } from '@/stores/preferences-store'

import { AppLogo } from '@/components/design-system/app-logo'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function AppHeader() {
  const { t } = useTranslation()
  const { isOnline } = useOnlineStatus()
  const { theme, resolvedTheme, setTheme } = useTheme()
  const navigate = useNavigationStore((s) => s.navigate)
  const mounted = useMounted()
  const profile = usePreferencesStore((s) => s.profile)
  // `resolvedTheme` follows the actual rendered theme, including the
  // 'system' preference. The mounted gate keeps SSR and the first client
  // render identical (next-themes reads localStorage only on the client) -
  // without it the toggle triggers a hydration mismatch for users who chose
  // a non-default theme.
  const isDark =
    mounted && (theme === 'dark' || (theme === 'system' && resolvedTheme === 'dark'))

  const builtin = BUILTIN_AVATARS.find((entry) => entry.id === profile.builtinAvatarId)
  const avatarSrc =
    profile.avatarKind === 'custom' && profile.customAvatar
      ? profile.customAvatar
      : builtin?.src ?? BUILTIN_AVATARS[0].src

  return (
    <header
      className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-md"
      /* Installed-app full-bleed status bar (black-translucent): the header
       * renders underneath the clock/notch and pads its content down by the
       * device inset. In a normal browser tab the inset is 0 (or landscape
       * notch width on the sides, handled by the browser). */
      style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
    >
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-2 px-4 sm:px-6">
        <button
          type="button"
          onClick={() => navigate('home')}
          className="rounded-lg p-1.5 outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
          aria-label={t('nav.home')}
        >
          <AppLogo compact />
        </button>

        <div className="flex-1" />

        {/* Connection status */}
        <span
          role="status"
          aria-live="polite"
          className={cn(
            'flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium',
            /* PROMPT 14: text uses foreground (>= 4.5:1 on the tint); the
             * icon keeps the semantic color (>= 3:1 non-text contrast). */
            isOnline
              ? 'border-success/30 bg-success/10 text-foreground'
              : 'border-warning/40 bg-warning/10 text-foreground',
          )}
        >
          {isOnline ? (
            <Wifi aria-hidden="true" className="size-3.5 text-success" />
          ) : (
            <WifiOff aria-hidden="true" className="size-3.5 text-warning" />
          )}
          <span className="hidden sm:inline">
            {isOnline ? t('common.online') : t('common.offline')}
          </span>
          <span className="sr-only sm:hidden">
            {isOnline ? t('common.online') : t('common.offline')}
          </span>
        </span>

        {/* Theme toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(isDark ? 'light' : 'dark')}
          aria-label={isDark ? t('settings.themeLight') : t('settings.themeDark')}
          className="rounded-full"
        >
          {isDark ? (
            <Sun aria-hidden="true" className="size-4.5" />
          ) : (
            <Moon aria-hidden="true" className="size-4.5" />
          )}
        </Button>

        {/* Profile */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate('profile')}
          aria-label={t('nav.profile')}
          title={t('nav.profile')}
          className="size-11 rounded-full"
        >
          <span className="relative flex size-9 items-center justify-center overflow-hidden rounded-full border border-primary/30 bg-primary/10">
            {mounted && profile.avatarKind === 'custom' && profile.customAvatar ? (
              // User-uploaded image (data URL) - plain img keeps it simple.
              <img
                src={profile.customAvatar}
                alt={t('profile.avatarAlt')}
                className="size-full object-cover"
              />
            ) : (
              <Image
                src={avatarSrc}
                alt={t('profile.avatarAlt')}
                fill
                sizes="36px"
                className="object-cover"
              />
            )}
          </span>
        </Button>
      </div>
    </header>
  )
}
