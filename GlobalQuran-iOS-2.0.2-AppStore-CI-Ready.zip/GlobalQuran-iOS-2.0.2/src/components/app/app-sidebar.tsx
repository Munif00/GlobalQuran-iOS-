'use client'

/**
 * Desktop sidebar navigation. Sticks below the header for the full
 * viewport height. Layout uses logical properties, so it flips to the
 * right side in RTL languages automatically.
 *
 * Primary destinations first, then a visually separated secondary group
 * (Downloads, Settings) so the main destinations stay uncluttered.
 */

import { useTranslation } from '@/i18n'
import { useNavigationStore } from '@/stores/navigation-store'
import { useReaderStore } from '@/stores/reader-store'

import {
  PRIMARY_NAV_ITEMS,
  SECONDARY_NAV_ITEMS,
  getActiveDestination,
  useNavActivate,
  type NavItem,
} from './nav-config'
import { AppLogo } from '@/components/design-system/app-logo'
import { cn } from '@/lib/utils'

function SidebarButton({ item, isActive, activate }: {
  item: NavItem
  isActive: boolean
  activate: (destination: NavItem['destination']) => void
}) {
  const { t } = useTranslation()
  const Icon = item.icon
  return (
    <button
      type="button"
      onClick={() => activate(item.destination)}
      aria-current={isActive ? 'page' : undefined}
      className={cn(
        'relative flex min-h-11 items-center gap-3 rounded-lg px-3 py-2.5 text-start text-sm font-medium outline-none transition-colors',
        'focus-visible:ring-[3px] focus-visible:ring-ring/50',
        isActive
          ? 'bg-primary/10 text-primary'
          : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
      )}
    >
      <Icon aria-hidden="true" className="size-5 shrink-0" />
      <span className="truncate">{t(item.labelKey)}</span>
      {isActive ? (
        <span
          aria-hidden="true"
          className="absolute inset-y-2 start-0 w-1 rounded-full bg-primary"
        />
      ) : null}
    </button>
  )
}

export function AppSidebar() {
  const { t } = useTranslation()
  const activeScreen = useNavigationStore((s) => s.activeScreen)
  const readerOpen = useReaderStore((s) => s.readerOpen)
  const activate = useNavActivate()
  const activeDestination = getActiveDestination(activeScreen, readerOpen)

  return (
    <aside className="sticky top-16 hidden h-[calc(100vh-4rem)] w-64 shrink-0 flex-col border-e border-border/70 bg-sidebar/60 px-4 py-6 md:flex">
      <nav aria-label={t('nav.navigation')} className="flex min-h-0 flex-1 flex-col gap-1">
        {PRIMARY_NAV_ITEMS.map((item) => (
          <SidebarButton
            key={item.destination}
            item={item}
            isActive={activeDestination === item.destination}
            activate={activate}
          />
        ))}

        {/* Secondary destinations, visually separated */}
        <div
          role="group"
          aria-label={t('nav.moreDestinations')}
          className="mt-4 space-y-1 border-t border-border/70 pt-4"
        >
          {SECONDARY_NAV_ITEMS.map((item) => (
            <SidebarButton
              key={item.destination}
              item={item}
              isActive={activeDestination === item.destination}
              activate={activate}
            />
          ))}
        </div>
      </nav>

      <div className="mt-6 border-t border-border/70 pt-4">
        <AppLogo compact showWordmark={false} className="mb-2" />
        <p className="text-xs text-muted-foreground">{t('footer.tagline')}</p>
      </div>
    </aside>
  )
}
