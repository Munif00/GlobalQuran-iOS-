'use client'

/**
 * Shared navigation configuration.
 *
 * Destinations follow the product structure:
 * - Primary: Home, Quran (Mushaf), Translation Library, Prayer Times, Qibla.
 * - Secondary: Downloads, Profile & Settings - grouped logically instead of
 *   crowding the mobile bottom bar.
 *
 * "Quran" and "Library" both live on the `quran` screen; they differ by the
 * reader state, so the active destination is derived from
 * (activeScreen, readerOpen) and activation opens/closes the reader.
 */

import {
  ArrowDownToLine,
  BookOpen,
  Compass,
  Home,
  LibraryBig,
  MoonStar,
  Settings,
  UserRound,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

import type { AppScreen } from '@/types'
import type { TranslationKey } from '@/i18n/locales/en'
import { useNavigationStore } from '@/stores/navigation-store'
import { useReaderStore } from '@/stores/reader-store'

/** UI-level navigation destinations. */
export type NavDestination =
  | 'home'
  | 'mushaf'
  | 'library'
  | 'downloads'
  | 'prayer'
  | 'qibla'
  | 'settings'
  | 'profile'

export interface NavItem {
  destination: NavDestination
  icon: LucideIcon
  /** Full label (sidebar, desktop). */
  labelKey: TranslationKey
  /** Compact label (mobile bottom bar). */
  shortLabelKey: TranslationKey
}

/** Primary destinations shown in the bottom bar and at the top of the sidebar. */
export const PRIMARY_NAV_ITEMS: readonly NavItem[] = [
  { destination: 'home', icon: Home, labelKey: 'nav.home', shortLabelKey: 'nav.homeShort' },
  { destination: 'mushaf', icon: BookOpen, labelKey: 'nav.mushaf', shortLabelKey: 'nav.mushafShort' },
  {
    destination: 'library',
    icon: LibraryBig,
    labelKey: 'nav.library',
    shortLabelKey: 'nav.libraryShort',
  },
  { destination: 'prayer', icon: MoonStar, labelKey: 'nav.prayer', shortLabelKey: 'nav.prayerShort' },
  { destination: 'qibla', icon: Compass, labelKey: 'nav.qibla', shortLabelKey: 'nav.qiblaShort' },
] as const

/** Secondary destinations grouped below the primary ones (desktop sidebar). */
export const SECONDARY_NAV_ITEMS: readonly NavItem[] = [
  {
    destination: 'profile',
    icon: UserRound,
    labelKey: 'nav.profile',
    shortLabelKey: 'nav.profileShort',
  },
  {
    destination: 'downloads',
    icon: ArrowDownToLine,
    labelKey: 'nav.downloads',
    shortLabelKey: 'nav.downloadsShort',
  },
  {
    destination: 'settings',
    icon: Settings,
    labelKey: 'nav.settings',
    shortLabelKey: 'nav.settingsShort',
  },
] as const

/**
 * Resolve which destination is currently active. The `quran` screen shows
 * either the Mushaf (reader open) or the translation library.
 */
export function getActiveDestination(screen: AppScreen, readerOpen: boolean): NavDestination {
  if (screen === 'quran') return readerOpen ? 'mushaf' : 'library'
  return screen
}

/**
 * Activation handler shared by the bottom bar, the sidebar and quick links.
 * Opening the Mushaf keeps the last sura; opening the Library closes the
 * reader without losing the reading session.
 */
export function useNavActivate(): (destination: NavDestination) => void {
  const navigate = useNavigationStore((s) => s.navigate)
  const openReader = useReaderStore((s) => s.openReader)
  const closeReader = useReaderStore((s) => s.closeReader)

  return (destination) => {
    switch (destination) {
      case 'mushaf':
        openReader()
        navigate('quran')
        break
      case 'library':
        closeReader()
        navigate('quran')
        break
      default:
        navigate(destination)
        break
    }
  }
}
