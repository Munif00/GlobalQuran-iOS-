'use client'

/**
 * Client providers: theme (next-themes), server state (TanStack Query),
 * i18n bootstrapping, and toasts.
 */

import { useEffect, useRef, useState } from 'react'
import { ThemeProvider } from 'next-themes'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Toaster } from '@/components/ui/sonner'

import { useTranslation } from '@/i18n'
import { detectDeviceLocale, getLocaleDefinition } from '@/i18n/config'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useReaderStore } from '@/stores/reader-store'
import { useAudioStore } from '@/stores/audio-store'
import { useViewerStateStore } from '@/stores/viewer-state-store'
import { useNarrationStore } from '@/stores/narration-store'
import { restorePersistedJobs } from '@/services/downloads/download-manager'
import { restorePersistedPackJobs } from '@/services/downloads/offline-pack-manager'
import { restorePersistedAudioBatches } from '@/services/downloads/audio-download-manager'
import { restorePersistedTranslationAudioBatches } from '@/services/downloads/translation-audio-download-manager'
import { initNativeReminders } from '@/services/notifications/native-reminders'
import { restoreAdhanManifest } from '@/services/downloads/adhan-download-manager'

/**
 * Applies persisted preferences after mount:
 * - rehydrates the preferences store (language mode, manual choice, text size)
 * - detects the device language once per launch (when in automatic mode)
 * - keeps <html lang/dir/data-text-size> in sync with the active language
 */
function I18nBootstrap() {
  const languageMode = usePreferencesStore((s) => s.languageMode)
  const manualLanguage = usePreferencesStore((s) => s.manualLanguage)
  const detectedLanguage = usePreferencesStore((s) => s.detectedLanguage)
  const textSize = usePreferencesStore((s) => s.textSize)

  useEffect(() => {
    void usePreferencesStore.persist.rehydrate()
    void useReaderStore.persist.rehydrate()
    void useViewerStateStore.persist.rehydrate()
    void useAudioStore.persist.rehydrate()
    void useNarrationStore.persist.rehydrate()
    // Restore download-manager jobs from IndexedDB (interrupted transfers
    // become resumable; completed ones stay visible in My Downloads).
    void restorePersistedJobs()
    void restorePersistedPackJobs()
    void restorePersistedAudioBatches()
    void restorePersistedTranslationAudioBatches()
    // Restore the verified Adhan library manifest (offline-ready badges are
    // honest from the first render) and initialize the native reminder
    // bridge (no-op on web/PWA; on Android it activates background
    // scheduling and mirrors the Adhan audio for notification sounds).
    void restoreAdhanManifest()
    void initNativeReminders()
  }, [])

  /*
   * Device-language detection. In automatic mode the interface follows the
   * device language - refreshed on every launch and whenever the user
   * switches back to "Use device language". A manually chosen language is
   * never overwritten.
   */
  useEffect(() => {
    if (languageMode === 'auto') {
      usePreferencesStore.getState().setDetectedLanguage(detectDeviceLocale())
    }
  }, [languageMode])

  useEffect(() => {
    const active =
      languageMode === 'manual' && manualLanguage ? manualLanguage : detectedLanguage ?? 'en'
    const definition = getLocaleDefinition(active)
    document.documentElement.lang = definition.code
    document.documentElement.dir = definition.direction
  }, [languageMode, manualLanguage, detectedLanguage])

  useEffect(() => {
    document.documentElement.dataset.textSize = textSize
  }, [textSize])

  return null
}

/**
 * Registers the service worker so the installed PWA can start offline.
 * Network-first navigation keeps development live-reload working; the
 * cached shell only serves as the fallback when the network is down.
 */
function ServiceWorkerBootstrap() {
  const { t } = useTranslation()
  const tRef = useRef(t)
  /* Keep the latest translator available to late callbacks (toasts) without
   * re-running the registration effect on language changes. */
  useEffect(() => {
    tRef.current = t
  }, [t])
  const shownFor = useRef<ServiceWorker | null>(null)

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return

    /* Offer the update exactly once per new worker: a non-dismissable toast
     * with a "Refresh" action. Activating the waiting worker fires
     * controllerchange, which reloads the page once onto the new version -
     * the same flow native apps use for staged updates. */
    let reloading = false
    const onControllerChange = () => {
      if (reloading) return
      reloading = true
      window.location.reload()
    }

    const offerUpdate = (worker: ServiceWorker) => {
      if (shownFor.current === worker) return
      shownFor.current = worker
      toast(tRef.current('install.updateAvailable'), {
        duration: Infinity,
        action: {
          label: tRef.current('install.updateNow'),
          onClick: () => worker.postMessage({ type: 'SKIP_WAITING' }),
        },
      })
    }

    const watchRegistration = (registration: ServiceWorkerRegistration) => {
      if (registration.waiting && navigator.serviceWorker.controller) {
        offerUpdate(registration.waiting)
      }
      registration.addEventListener('updatefound', () => {
        const installing = registration.installing
        if (!installing) return
        installing.addEventListener('statechange', () => {
          if (
            installing.state === 'installed' &&
            navigator.serviceWorker.controller
          ) {
            offerUpdate(installing)
          }
        })
      })
    }

    const register = () => {
      navigator.serviceWorker
        .register('/sw.js')
        .then(watchRegistration)
        .catch(() => {
          // Registration failures are non-fatal - the app still works online.
        })
    }

    navigator.serviceWorker.addEventListener('controllerchange', onControllerChange)
    if (document.readyState === 'complete') register()
    else {
      window.addEventListener('load', register, { once: true })
    }
    return () => {
      navigator.serviceWorker.removeEventListener('controllerchange', onControllerChange)
      window.removeEventListener('load', register)
    }
  }, [])
  return null
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 60_000,
            retry: 1,
            refetchOnWindowFocus: false,
          },
        },
      }),
  )

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <QueryClientProvider client={queryClient}>
        <I18nBootstrap />
        <ServiceWorkerBootstrap />
        {children}
        <Toaster richColors position="top-center" closeButton />
      </QueryClientProvider>
    </ThemeProvider>
  )
}
