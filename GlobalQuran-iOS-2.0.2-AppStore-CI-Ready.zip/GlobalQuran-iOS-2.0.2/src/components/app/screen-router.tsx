'use client'

/**
 * Screen router: swaps the active screen inside the single `/` page with a
 * subtle opacity-only transition, scrolls to top on navigation, and respects
 * the reduced-motion preference.
 *
 * The transition is deliberately opacity-only: any y-offset (the previous
 * y:8 enter / y:-8 exit) made freshly opened screens appear to jump or float
 * vertically, which read as an unstable page (especially Downloads). Opacity
 * alone keeps the 0.18s easeOut crossfade without moving content.
 */

import { useEffect } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'

import { useNavigationStore } from '@/stores/navigation-store'

import { HomeScreen } from '@/components/screens/home-screen'
import { QuranScreen } from '@/components/screens/quran-screen'
import { DownloadsScreen } from '@/components/screens/downloads-screen'
import { PrayerScreen } from '@/components/screens/prayer-screen'
import { QiblaScreen } from '@/components/screens/qibla-screen'
import { SettingsScreen } from '@/components/screens/settings-screen'
import { ProfileScreen } from '@/components/screens/profile-screen'

export function ScreenRouter() {
  const activeScreen = useNavigationStore((s) => s.activeScreen)
  const prefersReducedMotion = useReducedMotion()

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior })
  }, [activeScreen])

  const transition = prefersReducedMotion
    ? { duration: 0 }
    : { duration: 0.18, ease: 'easeOut' as const }

  // Opacity only - never translate the screen (see file comment).
  const initial = prefersReducedMotion ? false : { opacity: 0 }
  const exit = prefersReducedMotion ? { opacity: 1 } : { opacity: 0 }

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={activeScreen}
        initial={initial}
        animate={{ opacity: 1 }}
        exit={exit}
        transition={transition}
      >
        {activeScreen === 'home' ? <HomeScreen /> : null}
        {activeScreen === 'quran' ? <QuranScreen /> : null}
        {activeScreen === 'downloads' ? <DownloadsScreen /> : null}
        {activeScreen === 'prayer' ? <PrayerScreen /> : null}
        {activeScreen === 'qibla' ? <QiblaScreen /> : null}
        {activeScreen === 'settings' ? <SettingsScreen /> : null}
        {activeScreen === 'profile' ? <ProfileScreen /> : null}
      </motion.div>
    </AnimatePresence>
  )
}
