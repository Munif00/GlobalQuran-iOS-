'use client'

/**
 * Install dialog: platform-aware instructions for installing Global Quran
 * as a standalone application.
 *
 * - Android / desktop browsers that expose `beforeinstallprompt`: a single
 *   primary button opens the native install dialog.
 * - Android browsers without the event (e.g. Firefox): numbered menu steps.
 * - iOS / iPadOS Safari: numbered Share -> "Add to Home Screen" steps with
 *   replica toolbar glyphs so the steps are instantly recognizable.
 * - When the app already runs in standalone mode, an honest "already
 *   installed" state with the app version is shown instead.
 */

import { useMemo } from 'react'
import { Check, MonitorDown, Share, Smartphone, WifiOff } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useInstallPrompt } from '@/hooks/use-install-prompt'
import { APP_VERSION } from '@/lib/app-info'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

/** iOS toolbar "Add" plus glyph (Safari calls the confirmation button "Add"). */
function PlusGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={cn('size-5', className)}>
      <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

/** Android browser menu (⋮) glyph. */
function KebabGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={cn('size-5', className)}>
      <g fill="currentColor">
        <circle cx="12" cy="5" r="1.8" />
        <circle cx="12" cy="12" r="1.8" />
        <circle cx="12" cy="19" r="1.8" />
      </g>
    </svg>
  )
}

/** Numbered instruction step with a leading glyph. */
function Step({
  number,
  icon,
  children,
}: {
  number: number
  icon: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <li className="flex items-start gap-3">
      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
        {number}
      </span>
      <span className="flex min-w-0 flex-1 items-start gap-2.5 pt-0.5">
        <span className="flex size-7 shrink-0 items-center justify-center rounded-md border border-border bg-muted/50 text-foreground [&>svg]:size-4.5">
          {icon}
        </span>
        <span className="text-sm leading-relaxed text-foreground">{children}</span>
      </span>
    </li>
  )
}

export interface InstallDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function InstallDialog({ open, onOpenChange }: InstallDialogProps) {
  const { t } = useTranslation()
  const { platform, isStandalone, canInstall, install, isPrompting } = useInstallPrompt()

  const benefits = useMemo(
    () => [
      { icon: WifiOff, title: t('install.benefitOfflineTitle'), body: t('install.benefitOfflineBody') },
      { icon: Smartphone, title: t('install.benefitHomeTitle'), body: t('install.benefitHomeBody') },
      { icon: MonitorDown, title: t('install.benefitFullscreenTitle'), body: t('install.benefitFullscreenBody') },
    ],
    [t],
  )

  const nativePromptAvailable = platform !== 'ios' && canInstall

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto sm:max-w-md">
        {isStandalone ? (
          <>
            <DialogHeader>
              <DialogTitle>{t('install.alreadyInstalled')}</DialogTitle>
              <DialogDescription>{t('install.alreadyInstalledDescription')}</DialogDescription>
            </DialogHeader>
            <div className="flex items-center gap-3 rounded-xl border border-success/30 bg-success/10 p-4">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
                <Check aria-hidden="true" className="size-5" />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground">{t('common.appName')}</p>
                <p className="text-xs text-muted-foreground">
                  {t('common.version')} {APP_VERSION} · {t('install.settingsStatusInstalled')}
                </p>
              </div>
            </div>
          </>
        ) : (
          <>
            <DialogHeader>
              <div className="mb-1 flex items-center gap-3">
                {/* Brand mark (matches <AppLogoMark />) */}
                <svg viewBox="0 0 64 64" role="img" aria-label={t('common.appName')} className="size-12 rounded-xl">
                  <rect width="64" height="64" rx="14" className="fill-primary" />
                  <g fill="none" strokeWidth="3" strokeLinejoin="round" className="stroke-gold" opacity="0.95">
                    <rect x="18" y="18" width="28" height="28" rx="2" />
                    <rect x="18" y="18" width="28" height="28" rx="2" transform="rotate(45 32 32)" />
                  </g>
                  <circle cx="32" cy="32" r="4.5" className="fill-gold" />
                </svg>
                <div className="min-w-0">
                  <DialogTitle className="text-start">{t('install.dialogTitle')}</DialogTitle>
                </div>
              </div>
              <DialogDescription>{t('install.dialogDescription')}</DialogDescription>
            </DialogHeader>

            {/* Benefits */}
            <ul className="grid grid-cols-1 gap-2.5 sm:grid-cols-3 sm:gap-2">
              {benefits.map(({ icon: Icon, title, body }) => (
                <li
                  key={title}
                  className="flex items-start gap-2.5 rounded-xl border border-border/70 bg-muted/40 p-3 sm:flex-col sm:gap-2"
                >
                  <Icon aria-hidden="true" className="size-5 shrink-0 text-primary" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-foreground">{title}</p>
                    <p className="mt-0.5 hidden text-[11px] leading-snug text-muted-foreground sm:block">
                      {body}
                    </p>
                  </div>
                </li>
              ))}
            </ul>

            {/* Platform-specific action */}
            {nativePromptAvailable ? (
              <div className="space-y-3">
                <Button
                  className="h-12 w-full text-base"
                  onClick={() => void install()}
                  disabled={isPrompting}
                >
                  {isPrompting ? t('common.loading') : t('install.installButton')}
                </Button>
                <p className="text-center text-xs text-muted-foreground">{t('install.installOnAndroid')}</p>
              </div>
            ) : platform === 'ios' ? (
              <div className="space-y-3">
                <p className="text-sm font-semibold text-foreground">{t('install.iosTitle')}</p>
                <ol className="space-y-3">
                  <Step number={1} icon={<Share aria-hidden="true" />}>
                    {t('install.iosStep1')}
                  </Step>
                  <Step number={2} icon={<PlusGlyph />}>
                    {t('install.iosStep2')}
                  </Step>
                  <Step number={3} icon={<Check aria-hidden="true" />}>
                    {t('install.iosStep3')}
                  </Step>
                </ol>
              </div>
            ) : platform === 'android' ? (
              <div className="space-y-3">
                <p className="text-sm font-semibold text-foreground">{t('install.androidMenuTitle')}</p>
                <ol className="space-y-3">
                  <Step number={1} icon={<KebabGlyph />}>
                    {t('install.androidMenuStep1')}
                  </Step>
                  <Step number={2} icon={<PlusGlyph />}>
                    {t('install.androidMenuStep2')}
                  </Step>
                  <Step number={3} icon={<Check aria-hidden="true" />}>
                    {t('install.androidMenuStep3')}
                  </Step>
                </ol>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm font-semibold text-foreground">{t('install.desktopTitle')}</p>
                <ol className="space-y-3">
                  <Step number={1} icon={<MonitorDown aria-hidden="true" />}>
                    {t('install.desktopStep1')}
                  </Step>
                  <Step number={2} icon={<Check aria-hidden="true" />}>
                    {t('install.desktopStep2')}
                  </Step>
                </ol>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
