'use client'

/**
 * Mobile bottom navigation: five primary destinations with clear labels,
 * safe-area aware, 44px+ touch targets. Fixed to the bottom of the viewport.
 * Profile, Downloads and Settings stay reachable through the always-visible
 * header avatar button (Profile) and the Library/Home screens.
 */

import { useTranslation } from '@/i18n'
import { useReaderStore } from '@/stores/reader-store'
import { useNavigationStore } from '@/stores/navigation-store'

import { PRIMARY_NAV_ITEMS, getActiveDestination, useNavActivate } from './nav-config'
import { cn } from '@/lib/utils'

export function BottomNav() {
  const { t } = useTranslation()
  const activeScreen = useNavigationStore((s) => s.activeScreen)
  const readerOpen = useReaderStore((s) => s.readerOpen)
  const activate = useNavActivate()
  const activeDestination = getActiveDestination(activeScreen, readerOpen)

  return (
    <nav
      aria-label={t('nav.navigation')}
      className="fixed inset-x-0 bottom-0 z-40 border-t border-border/70 bg-background/95 backdrop-blur-md md:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="grid grid-cols-5">
        {PRIMARY_NAV_ITEMS.map((item) => {
          const isActive = activeDestination === item.destination
          const Icon = item.icon
          return (
            <button
              key={item.destination}
              type="button"
              onClick={() => activate(item.destination)}
              aria-current={isActive ? 'page' : undefined}
              className={cn(
                'relative flex min-h-[3.5rem] flex-col items-center justify-center gap-1 px-1 py-2 outline-none transition-colors',
                'focus-visible:ring-[3px] focus-visible:ring-ring/50',
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {isActive ? (
                <span
                  aria-hidden="true"
                  className="absolute top-0 h-0.5 w-8 rounded-full bg-primary"
                />
              ) : null}
              <Icon aria-hidden="true" className="size-5 shrink-0" />
              <span className="w-full truncate text-center text-xs font-medium leading-tight">
                {t(item.shortLabelKey)}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
