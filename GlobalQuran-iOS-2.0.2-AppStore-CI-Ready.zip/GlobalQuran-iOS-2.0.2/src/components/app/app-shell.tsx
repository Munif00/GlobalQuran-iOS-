'use client'

/**
 * Application shell:
 * - skip-to-content link (keyboard accessibility)
 * - sticky header (all breakpoints)
 * - sidebar navigation on desktop, bottom bar on mobile
 * - main content column with the footer pushed to the bottom (mt-auto)
 * - the whole layout flips for RTL languages via logical properties
 */

import { useEffect } from 'react'

import { useTranslation } from '@/i18n'
import { initBackButtonController } from '@/services/navigation/back-button'
import { initNavigationSync } from '@/stores/navigation-store'
import { cn } from '@/lib/utils'

import { AppHeader } from './app-header'
import { AppSidebar } from './app-sidebar'
import { BottomNav } from './bottom-nav'
import { AppFooter } from './app-footer'
import { ScreenRouter } from './screen-router'
import { DuaSplash } from './dua-splash'
import { InstallBanner } from './install-banner'
import { AdhanFireBanner } from '@/components/prayer/adhan-fire-banner'
import { FileViewer } from '@/components/viewers/file-viewer'
import { AudioPlayerBar } from '@/components/quran/audio-player-bar'
import { NarrationPlayerBar } from '@/components/quran/narration-player-bar'

export function AppShell() {
  const { t } = useTranslation()

  useEffect(() => {
    const cleanup = initNavigationSync()
    return cleanup
  }, [])

  /* Android hardware Back routing (native Android shell only - installs
   * nothing on web/iOS; see services/navigation/back-button.ts). */
  useEffect(() => {
    const cleanup = initBackButtonController()
    return cleanup
  }, [])

  return (
    <div className="app-shell-height flex flex-col bg-background">
      {/* Skip link: first tab stop, jumps keyboard users to the main content */}
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-primary focus:px-4 focus:py-2.5 focus:text-sm focus:font-medium focus:text-primary-foreground focus:shadow-lg"
      >
        {t('common.skipToContent')}
      </a>
      <AppHeader />
      <div className="mx-auto flex w-full max-w-6xl flex-1">
        <AppSidebar />
        <main id="main" className="flex min-w-0 flex-1 flex-col">
          <div className="flex-1">
            <ScreenRouter />
          </div>
          <AppFooter />
        </main>
      </div>
      {/* Spacer so the fixed bottom bar never covers the footer on mobile.
       * Height = nav bar (4rem) + device home-indicator inset. */}
      <div
        aria-hidden="true"
        className="h-16 md:hidden"
        style={{ height: 'calc(4rem + env(safe-area-inset-bottom, 0px))' }}
      />
      <BottomNav />
      {/* Audio player bars (app-wide, fixed above the bottom navigation on
       * mobile / at the bottom on desktop). Both are self-hiding - each
       * renders only while its session exists. Narration (PROMPT 10) stacks
       * ABOVE recitation: the two sessions are independent, but the session
       * coordinator guarantees they are never audible at the same time. */}
      <div
        className={cn(
          'fixed inset-x-0 z-40 flex flex-col',
          'bottom-[calc(4rem+env(safe-area-inset-bottom,0px))] md:bottom-0',
        )}
      >
        <NarrationPlayerBar />
        <AudioPlayerBar />
      </div>
      {/* Polite install invitation (Android / iOS / desktop) */}
      <InstallBanner />
      {/* In-app Adhan fire banner (native foreground path, PROMPT 16).
       * Self-hiding; renders nothing outside an active fire event. */}
      <AdhanFireBanner />
      {/* Built-in offline file viewer (self-activates from the viewer store) */}
      <FileViewer />
      {/* Opening Dua splash: a passive overlay on top of the fully mounted
          application. State restoration, hash deep links, and the file
          viewer all initialize normally underneath - the splash only covers
          them for its five seconds and never mutates any navigation state. */}
      <DuaSplash />
    </div>
  )
}
