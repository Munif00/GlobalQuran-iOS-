'use client'

/**
 * Footer: sticks to the bottom of the content column (mt-auto), with extra
 * bottom padding on mobile so the fixed bottom navigation never covers it.
 */

import { useTranslation } from '@/i18n'

import { APP_VERSION } from '@/lib/app-info'

export function AppFooter() {
  const { t } = useTranslation()

  return (
    <footer className="mt-auto border-t border-border/70 bg-card/40">
      <div className="mx-auto w-full max-w-6xl px-4 py-6 pb-[calc(5rem+env(safe-area-inset-bottom))] sm:px-6 md:pb-8">
        <div className="flex flex-col items-center gap-2 text-center">
          <p className="text-sm font-medium text-foreground">{t('footer.tagline')}</p>
          <p className="text-xs text-muted-foreground">{t('footer.sources')}</p>
          <p className="text-xs text-muted-foreground">
            {t('footer.version', { version: APP_VERSION })} · {t('footer.rights')}
          </p>
          {/* Privacy policy - the in-app statement is kept short and honest;
              the full policy ships as PRIVACY.md with the deployment.
              PROMPT 16 (WCAG 2.2 AA 2.5.8): the link gets inline padding so
              its tap target is at least 24x24 CSS px (was ~15px text-only). */}
          <p className="max-w-xl text-xs leading-relaxed text-muted-foreground">
            {t('footer.privacySummary')}{' '}
            <a
              href="/PRIVACY.md"
              className="-mx-2 -my-2 inline-block rounded px-2 py-2 font-medium text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-[3px] focus-visible:ring-ring/50"
            >
              {t('footer.privacyLink')}
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}
