'use client'

/**
 * Smart install banner.
 *
 * A single, polite invitation to install the app:
 * - appears once per session, 20 seconds after launch (after the opening
 *   splash, once the user has seen the app);
 * - never appears when the app already runs in standalone mode;
 * - stays dismissed for 14 days after "Not now" (persisted);
 * - Android/desktop with a native prompt: "Install" opens the browser's
 *   own install dialog directly;
 * - iOS (and browsers without the prompt): "Install" opens the guided
 *   step-by-step dialog instead.
 *
 * On phones it floats above the bottom navigation; on desktop it docks to
 * the bottom-end corner like a system toast.
 */

import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Download, X } from 'lucide-react'

import { useTranslation } from '@/i18n'
import {
  INSTALL_BANNER_DISMISSED_KEY,
  INSTALL_BANNER_REOFFER_MS,
  useInstallPrompt,
} from '@/hooks/use-install-prompt'
import { Button } from '@/components/ui/button'
import { InstallDialog } from '@/components/app/install-dialog'

/** Delay before the banner first appears (milliseconds). */
const BANNER_DELAY_MS = 20_000

/** True when the user dismissed the banner recently (client only). */
function isDismissedRecently(): boolean {
  try {
    const raw = window.localStorage.getItem(INSTALL_BANNER_DISMISSED_KEY)
    if (!raw) return false
    const dismissedAt = Number(raw)
    if (!Number.isFinite(dismissedAt)) return false
    return Date.now() - dismissedAt < INSTALL_BANNER_REOFFER_MS
  } catch {
    return false
  }
}

export function InstallBanner() {
  const { t } = useTranslation()
  const prefersReducedMotion = useReducedMotion()
  const { mounted, platform, isStandalone, canInstall, install, wasInstalled } = useInstallPrompt()

  const [show, setShow] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)

  /* Reveal after the delay - only when installing is relevant. */
  useEffect(() => {
    if (!mounted || !canInstall || isStandalone) return
    if (isDismissedRecently()) return
    const timer = setTimeout(() => setShow(true), BANNER_DELAY_MS)
    return () => clearTimeout(timer)
  }, [mounted, canInstall, isStandalone])

  const dismiss = useCallback(() => {
    setShow(false)
    try {
      window.localStorage.setItem(INSTALL_BANNER_DISMISSED_KEY, String(Date.now()))
    } catch {
      // Private mode - the banner simply stays session-scoped.
    }
  }, [])

  const handleInstall = useCallback(() => {
    if (platform !== 'ios') {
      // Android/desktop: try the native prompt; if the browser never fired
      // the event, fall through to the guided dialog.
      void install().then((outcome) => {
        if (outcome === 'unavailable') setDialogOpen(true)
      })
    } else {
      // iOS: there is no programmatic install - show the Share steps.
      setDialogOpen(true)
    }
  }, [install, platform])

  return (
    <>
      <AnimatePresence>
        {/* Retired immediately once the app finished installing. */}
        {show && !wasInstalled ? (
          <motion.aside
            key="install-banner"
            role="dialog"
            aria-label={t('install.bannerTitle')}
            initial={
              prefersReducedMotion
                ? { opacity: 0 }
                : { opacity: 0, y: 24, scale: 0.98 }
            }
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={
              prefersReducedMotion
                ? { opacity: 0 }
                : { opacity: 0, y: 16, scale: 0.98 }
            }
            transition={{ duration: 0.35, ease: 'easeOut' }}
            /* Phones: docked above the bottom navigation (nav is 4rem tall
             * plus the device home-indicator inset). Desktop: corner toast. */
            className="fixed z-50 mx-auto w-[calc(100%-1.5rem)] max-w-sm rounded-2xl border border-border/70 bg-card p-4 shadow-xl shadow-black/10 md:inset-x-auto md:bottom-4 md:end-4 md:mx-0"
            style={{
              bottom: 'calc(4.25rem + env(safe-area-inset-bottom, 0px))',
            }}
          >
            <div className="flex items-start gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Download aria-hidden="true" className="size-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-foreground">{t('install.bannerTitle')}</p>
                <p className="mt-0.5 text-xs leading-snug text-muted-foreground">
                  {t('install.bannerDescription')}
                </p>
              </div>
              <button
                type="button"
                onClick={dismiss}
                aria-label={t('install.notNow')}
                className="-m-1 rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
              >
                <X aria-hidden="true" className="size-4" />
              </button>
            </div>
            <div className="mt-3 flex items-center justify-end gap-2">
              <Button variant="ghost" size="sm" className="h-11" onClick={dismiss}>
                {t('install.notNow')}
              </Button>
              <Button size="sm" className="h-11" onClick={handleInstall}>
                {t('install.install')}
              </Button>
            </div>
          </motion.aside>
        ) : null}
      </AnimatePresence>
      <InstallDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </>
  )
}
