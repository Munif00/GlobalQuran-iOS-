'use client'

/**
 * Native app delivery card - the Android APK download.
 *
 * The release APK is published as a static file at
 * /downloads/GlobalQuran-<version>-android.apk. This component:
 * - probes the file with a HEAD request (honest availability + real size,
 *   never a hardcoded size claim);
 * - offers the download as the primary action with the app version;
 * - explains the one-time "allow from this source" Android step;
 * - on iOS, points to the Add-to-Home-Screen flow instead (the honest iOS
 *   install path - Apple does not permit sideloading).
 *
 * Rendered on the Home screen and in the Settings mobile-app card; hidden
 * entirely when the app already runs standalone (PWA) or inside the native
 * Capacitor shell.
 */

import { useQuery } from '@tanstack/react-query'
import { CheckCircle2, Download, Smartphone } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useInstallPrompt } from '@/hooks/use-install-prompt'
import { APP_VERSION } from '@/lib/app-info'
import { formatBytes } from '@/utils/format'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { InfoRow } from '@/components/design-system/info-row'
import { cn } from '@/lib/utils'

export function apkDownloadUrl(): string {
  return `/downloads/GlobalQuran-${APP_VERSION}-android.apk`
}

export function useApkAvailability() {
  return useQuery({
    queryKey: ['native-apk', APP_VERSION],
    queryFn: async (): Promise<{ available: true; bytes: number } | { available: false }> => {
      try {
        const response = await fetch(apkDownloadUrl(), { method: 'HEAD' })
        if (!response.ok) return { available: false }
        const length = Number(response.headers.get('content-length'))
        return {
          available: true,
          bytes: Number.isFinite(length) && length > 0 ? length : 0,
        }
      } catch {
        return { available: false }
      }
    },
    staleTime: 10 * 60 * 1000,
    retry: false,
  })
}

export function NativeAppDownloadCard({ className }: { className?: string }) {
  const { t, locale } = useTranslation()
  const { platform } = useInstallPrompt()
  const availability = useApkAvailability()

  const data = availability.data
  const available = data?.available === true
  const sizeLabel =
    available && data.bytes > 0 ? formatBytes(locale, data.bytes) : t('common.loading')

  return (
    <Card className={cn('border-primary/25', className)}>
      <CardContent className="p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-3.5 min-w-0">
            <span
              aria-hidden="true"
              className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"
            >
              <Smartphone className="size-5" />
            </span>
            <div className="min-w-0">
              <h3 className="text-base font-semibold leading-snug">
                {t('install.getAppTitle')}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {t('install.getAppDescription')}
              </p>
            </div>
          </div>
          {available ? (
            <Button asChild className="shrink-0">
              <a href={apkDownloadUrl()} download>
                <Download aria-hidden="true" className="size-4" />
                {t('install.apkDownloadLabel')}
              </a>
            </Button>
          ) : (
            <Badge variant="outline" className="shrink-0 text-muted-foreground">
              {t('install.apkUnavailable')}
            </Badge>
          )}
        </div>

        {available ? (
          <dl className="mt-4 grid gap-x-6 gap-y-1 border-t pt-4 sm:grid-cols-2">
            <InfoRow label={t('install.apkVersionLabel')} value={`Global Quran ${APP_VERSION}`} />
            <InfoRow label={t('install.apkFilesize')} value={sizeLabel} />
          </dl>
        ) : null}

        <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
          <CheckCircle2 aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-primary" />
          <span>{t('install.apkInstallHint')}</span>
        </p>

        {platform === 'ios' ? (
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            {t('install.iosHint')}
          </p>
        ) : null}
      </CardContent>
    </Card>
  )
}
