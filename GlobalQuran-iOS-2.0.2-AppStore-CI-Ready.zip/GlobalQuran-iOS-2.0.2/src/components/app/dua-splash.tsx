'use client'

/**
 * Opening Dua splash screen.
 *
 * Shown once per application launch (one mount of the AppShell) before the
 * user enters the application. It presents the meaning of the supplication
 *
 *     لا تنسوني من صالح دعائكم
 *
 * ("remember me in your righteous prayers") in the user's interface
 * language, above a warm Quran-Mushaf illustration.
 *
 * Timing & lifecycle rules (implemented deliberately, not accidentally):
 * - Visible for exactly five seconds under normal operating conditions,
 *   then the application is revealed automatically. No button, no gesture.
 * - A single wall-clock anchor (`startedAt`) drives the schedule. When the
 *   page is backgrounded (mobile browsers throttle timers), the remaining
 *   time is recomputed on the `visibilitychange` foreground event, so the
 *   splash can never get stuck; if the full five seconds already elapsed
 *   while hidden, it dismisses immediately on return.
 * - Timers are cleared on unmount and a `dismissed` guard prevents both
 *   duplicate dismissal and duplicate scheduling.
 * - The splash is a passive overlay: the application underneath mounts and
 *   initializes normally (state restoration, deep-link hash routing,
 *   imported-file viewer). Nothing is delayed, nothing is lost - the user
 *   simply sees it after the splash fades.
 * - It never reappears on internal navigation (the AppShell does not
 *   remount); only a fresh page load / app launch shows it again.
 *
 * Language resolution happens synchronously on the first paint: a manually
 * selected language (persisted) always wins and is never overridden by the
 * device language; otherwise the device language is detected and, when
 * unsupported, English is used. The Arabic original is always rendered
 * verbatim from the translation resources - never paraphrased.
 */

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import { motion, useReducedMotion } from 'framer-motion'

import { createTranslator } from '@/i18n'
import { FALLBACK_LOCALE, detectDeviceLocale, getDirection, matchLocaleTag } from '@/i18n/config'
import { PREFERENCES_STORAGE_KEY } from '@/stores/preferences-store'

/** Exact display duration under normal conditions (milliseconds). */
const SPLASH_VISIBLE_MS = 5_000
/** When the Skip control becomes available (milliseconds). */
const SKIP_REVEAL_AFTER_MS = 1_200
/** Fade-out duration (milliseconds). */
const SPLASH_FADE_MS = 700
/** Small buffer after the fade before the overlay unmounts. */
const SPLASH_UNMOUNT_BUFFER_MS = 90

/** The Arabic UI locale - for it the meaning line equals the original, so
 * the calligraphic original alone is shown (no duplicated sentence). */
const ARABIC_LOCALE = 'ar'

/**
 * Resolve the splash language synchronously (before any effect runs):
 * 1. a manually chosen, still-supported language from persisted storage;
 * 2. otherwise the detected device language;
 * 3. English when the device language is unsupported.
 * Reading the raw persisted value (not the not-yet-rehydrated store) keeps
 * the very first paint in the correct language - no English flash.
 */
function resolveSplashLocale(): string {
  if (typeof window === 'undefined') return FALLBACK_LOCALE
  try {
    const raw = window.localStorage.getItem(PREFERENCES_STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as {
        state?: { languageMode?: string; manualLanguage?: string | null }
      }
      const state = parsed?.state
      if (state?.languageMode === 'manual' && typeof state.manualLanguage === 'string') {
        const match = matchLocaleTag(state.manualLanguage)
        if (match) return match
      }
    }
  } catch {
    // Corrupted or unreadable storage - fall through to device detection.
  }
  return detectDeviceLocale()
}

type SplashPhase = 'showing' | 'fading' | 'gone'

const emptySubscribe = () => () => {}

export function DuaSplash() {
  const [phase, setPhase] = useState<SplashPhase>('showing')
  /* PROMPT 14: a Skip control appears after the dua has had its moment (1.2 s);
   *  repeat users are never held captive for the full five seconds. */
  const [canSkip, setCanSkip] = useState(false)
  /* Set by the schedule effect so the Skip button can trigger the same
   * dismissal path as the natural timeout. */
  const finishRef = useRef<(() => void) | null>(null)
  /* The very first client render must match the server output (English
   * fallback) or React hydration fails and regenerates the whole tree -
   * which would "break application initialization", exactly what this
   * screen must never do. useSyncExternalStore provides the same
   * hydration-safe client-only value pattern the rest of the app uses
   * (see use-mounted.ts): the server snapshot is English, the client
   * snapshot resolves the real language, and React reconciles the two
   * before the browser paints - long before the 800 ms fade-in makes any
   * splash text visible, so users never see the English text flash. */
  const prefersReducedMotion = useReducedMotion()

  const splashLocale = useSyncExternalStore(
    emptySubscribe,
    resolveSplashLocale,
    () => FALLBACK_LOCALE,
  )
  const t = useMemo(() => createTranslator(splashLocale), [splashLocale])

  useEffect(() => {
    const startedAt = Date.now()
    let dismissTimer: ReturnType<typeof setTimeout> | null = null
    let unmountTimer: ReturnType<typeof setTimeout> | null = null
    let dismissed = false

    /* The five seconds start when the splash actually mounts; the language
     * resolution above re-renders but never restarts this schedule (the
     * effect runs once and anchors on `startedAt`). */

    const clearTimers = () => {
      if (dismissTimer !== null) {
        clearTimeout(dismissTimer)
        dismissTimer = null
      }
      if (unmountTimer !== null) {
        clearTimeout(unmountTimer)
        unmountTimer = null
      }
    }

    const finish = () => {
      if (dismissed) return
      dismissed = true
      clearTimers()
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      finishRef.current = null
      setPhase('fading')
      unmountTimer = setTimeout(() => setPhase('gone'), SPLASH_FADE_MS + SPLASH_UNMOUNT_BUFFER_MS)
    }
    finishRef.current = finish

    const skipRevealTimer = setTimeout(() => {
      if (!dismissed) setCanSkip(true)
    }, SKIP_REVEAL_AFTER_MS)

    const schedule = () => {
      if (dismissed) return
      if (dismissTimer !== null) {
        clearTimeout(dismissTimer)
        dismissTimer = null
      }
      const remaining = SPLASH_VISIBLE_MS - (Date.now() - startedAt)
      if (remaining <= 0) {
        finish()
      } else {
        dismissTimer = setTimeout(finish, remaining)
      }
    }

    const handleVisibilityChange = () => {
      // Foreground after backgrounding: recompute what is left of the five
      // seconds. Backgrounded timers are unreliable; the wall clock is not.
      if (document.visibilityState === 'visible') schedule()
    }

    document.addEventListener('visibilitychange', handleVisibilityChange)
    schedule()

    return () => {
      dismissed = true
      clearTimers()
      clearTimeout(skipRevealTimer)
      document.removeEventListener('visibilitychange', handleVisibilityChange)
    }
  }, [])

  if (phase === 'gone') return null

  const isArabicUI = splashLocale === ARABIC_LOCALE
  const meaningDirection = getDirection(splashLocale)
  const fadeDuration = prefersReducedMotion ? 0.01 : SPLASH_FADE_MS / 1000
  const entranceDuration = prefersReducedMotion ? 0.01 : 0.8

  return (
    <motion.div
      role="status"
      aria-label={t('splash.duaMeaning')}
      initial={{ opacity: 0 }}
      animate={{ opacity: phase === 'fading' ? 0 : 1 }}
      transition={{
        duration: phase === 'fading' ? fadeDuration : entranceDuration,
        ease: 'easeOut',
      }}
      className={
        'fixed inset-0 z-[100] flex flex-col items-center overflow-hidden select-none ' +
        (phase === 'fading' ? 'pointer-events-none' : 'pointer-events-auto')
      }
      style={{
        // Fixed warm identity (independent of app theme): a cream Mushaf-
        // cover palette that reads beautifully in any environment.
        background:
          'linear-gradient(180deg, #f8f1e0 0%, #f1e4c6 48%, #e9d5a7 100%)',
      }}
      data-splash={phase}
    >
      {/* Subtle Islamic geometric star pattern (pure ornament, no text) */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='128' height='128' viewBox='0 0 128 128'%3E%3Cg fill='none' stroke='%23a5842f' stroke-width='1'%3E%3Crect x='38' y='38' width='52' height='52'/%3E%3Crect x='38' y='38' width='52' height='52' transform='rotate(45 64 64)'/%3E%3C/g%3E%3C/svg%3E\")",
          backgroundSize: '128px 128px',
          opacity: 0.055,
        }}
      />
      {/* Soft radial vignette to focus the center */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 90% 70% at 50% 42%, transparent 40%, rgba(120, 90, 30, 0.10) 100%)',
        }}
      />

      <div className="relative flex h-full w-full max-w-xl flex-col items-center justify-center px-6 pb-24 sm:pb-20">
        {/* Central visual: the Quran Mushaf illustration, edges vignetted
            into the splash background. */}
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.96, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: entranceDuration, ease: 'easeOut', delay: 0.1 }}
          className="w-full flex justify-center"
        >
          {/* The artwork is a static public asset; next/image adds nothing
              for a fixed-size decorative splash illustration. */}
          <img
            src="/splash/mushaf.jpg"
            alt=""
            aria-hidden="true"
            width={512}
            height={512}
            className="h-[30vh] max-h-[300px] min-h-[180px] w-auto object-contain sm:h-[34vh]"
            style={{
              filter: 'drop-shadow(0 18px 28px rgba(97, 70, 15, 0.22))',
              maskImage:
                'radial-gradient(ellipse 78% 78% at 50% 50%, black 52%, transparent 98%)',
              WebkitMaskImage:
                'radial-gradient(ellipse 78% 78% at 50% 50%, black 52%, transparent 98%)',
            }}
            draggable={false}
          />
        </motion.div>

        {/* The supplication, in Arabic, verbatim */}
        <motion.p
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: entranceDuration, ease: 'easeOut', delay: 0.35 }}
          dir="rtl"
          lang="ar"
          className="text-quranic mt-7 max-w-md text-center text-3xl leading-[2] font-bold text-[#0b4a34] sm:text-4xl"
        >
          {t('splash.duaArabic')}
        </motion.p>

        {/* The meaning, in the user's application language */}
        {!isArabicUI && (
          <motion.p
            initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: entranceDuration, ease: 'easeOut', delay: 0.55 }}
            dir={meaningDirection}
            lang={splashLocale}
            className="mt-5 max-w-md text-center text-base leading-relaxed font-medium text-[#6b5233] sm:text-lg"
          >
            {t('splash.duaMeaning')}
          </motion.p>
        )}

        {/* App identity - small, quiet, last. Letter-spacing and small-caps
            are Latin-script devices; applying them to connected Arabic
            script would break its letterforms, so they are LTR-only. */}
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: entranceDuration, ease: 'easeOut', delay: 0.8 }}
          className="absolute inset-x-0 bottom-7 flex flex-col items-center gap-2.5"
          /* Clear the iOS home indicator in the installed app. */
          style={{ bottom: 'max(1.75rem, env(safe-area-inset-bottom, 0px))' }}
        >
          <span aria-hidden="true" className="h-px w-16 bg-[#b08d3f]/50" />
          <span
            className={
              meaningDirection === 'rtl'
                ? 'text-sm font-semibold text-[#5c4a2a]'
                : 'text-[11px] font-semibold tracking-[0.32em] text-[#5c4a2a] uppercase'
            }
          >
            {t('splash.appName')}
          </span>
          {/* PROMPT 14 (Nielsen #3): an escape hatch for repeat users - shown
              once the dua has had its moment, never competing with it. */}
          {phase === 'showing' && canSkip ? (
            <button
              type="button"
              onClick={() => finishRef.current?.()}
              className="mt-1 min-h-11 rounded-full bg-[#5c4a2a]/10 px-5 text-sm font-medium text-[#5c4a2a] outline-none transition-colors hover:bg-[#5c4a2a]/20 focus-visible:ring-[3px] focus-visible:ring-[#5c4a2a]/50"
            >
              {t('common.skip')}
            </button>
          ) : null}
        </motion.div>
      </div>
    </motion.div>
  )
}
