'use client'

/**
 * Surah-opening presentation (display only - NEVER part of the Quran data).
 *
 * Quran display rules implemented here, exactly as mandated:
 * - Surah Al-Fatihah (1): the Basmala IS its first ayah in the authentic
 *   text source (verified against the QuranEnc Hafs package), so NO separate
 *   opening is rendered - a second one would duplicate ayah 1.
 * - Surah At-Tawbah (9): the only surah that opens WITHOUT the Basmala.
 *   The Isti'adha is rendered instead, as a recitation preface: it carries
 *   NO ayah number, is never inserted into the text source/cache/API, and is
 *   visually distinct from the numbered ayat.
 * - Every other surah (2-8, 10-114): the Basmala is rendered above the first
 *   ayah, without an ayah number, as a display-only opening.
 * - Surah An-Naml's internal Basmala (27:30) lives INSIDE that authentic
 *   ayah and is never touched by this component (no ayah text is ever
 *   modified, joined, split or rewritten anywhere in the reader).
 *
 * Localization: the label and the explanatory meaning render in the
 * application interface language (a manual selection always wins; device
 * language is the fallback - the same resolution the whole app uses). The
 * meaning is hidden for the Arabic interface (it would duplicate the phrase
 * itself, exactly like the opening splash). The Arabic phrases themselves
 * are always the authentic originals - never translated, never replaced.
 */

import { useTranslation } from '@/i18n'
import { cn } from '@/lib/utils'

/**
 * The Basmala, verbatim as mandated for the opening display. Display-only
 * constant: it is never written into the Quran text source, the offline
 * cache, the API responses, or any export.
 */
const BASMALA_ARABIC = 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ'

/**
 * The Isti'adha (recitation preface for Surah At-Tawbah). Not a Quranic
 * ayah: rendered without an ayah number and never numbered as one.
 */
const ISTIADHA_ARABIC = 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ'

/** Surah Al-Fatihah: its first ayah already IS the Basmala in the source. */
const SURA_AL_FATIHAH = 1
/** Surah At-Tawbah: opens without a Basmala; the Isti'adha is its preface. */
const SURA_AT_TAWBAH = 9

/** Which opening presentation a surah receives. `null` = none. */
export type SuraOpeningKind = 'basmala' | 'istiadha'

/**
 * Pure rule function (exported for the surah-opening verification suite):
 * - 1 -> null (Basmala is ayah 1 - never duplicated)
 * - 9 -> 'istiadha' (never a Basmala)
 * - every other valid surah -> 'basmala'
 */
export function getSuraOpeningKind(sura: number): SuraOpeningKind | null {
  if (sura === SURA_AL_FATIHAH) return null
  return sura === SURA_AT_TAWBAH ? 'istiadha' : 'basmala'
}

/** The exact Arabic phrase rendered for a given opening kind. */
export function getSuraOpeningArabic(kind: SuraOpeningKind): string {
  return kind === 'basmala' ? BASMALA_ARABIC : ISTIADHA_ARABIC
}

export interface SuraOpeningProps {
  /** Surah number (1..114) of the sura being displayed. */
  sura: number
  /** Arabic font size, shared with the reader's ayah text scale. */
  arabicFontSize: string
}

export function SuraOpening({ sura, arabicFontSize }: SuraOpeningProps) {
  const { t, locale, direction } = useTranslation()

  const kind = getSuraOpeningKind(sura)
  /* Al-Fatihah renders no opening at all (its ayah 1 is the Basmala). */
  if (kind === null) return null

  const arabic = getSuraOpeningArabic(kind)
  const label = kind === 'basmala' ? t('reader.basmalaLabel') : t('reader.istiadhaLabel')
  const meaning = kind === 'basmala' ? t('reader.basmalaMeaning') : t('reader.istiadhaMeaning')

  /* The meaning line would just duplicate the Arabic phrase for the Arabic
   * interface - exactly the convention the opening splash established. */
  const showMeaning = locale !== 'ar'

  /* Letter-spacing and uppercase are Latin-script devices; applying them to
   * connected Arabic script would break its letterforms (RTL labels keep the
   * plain style). */
  const labelIsLatin = direction === 'ltr'

  return (
    <div
      data-sura-opening={kind}
      className="pt-1 text-center"
      aria-label={label}
    >
      <p dir="rtl" lang="ar" className="text-quranic" style={{ fontSize: arabicFontSize }}>
        {arabic}
      </p>
      <p
        dir={direction}
        lang={locale}
        className={cn(
          'reader-muted mt-3 text-xs font-medium',
          labelIsLatin && 'uppercase tracking-wide',
        )}
      >
        {label}
      </p>
      {showMeaning ? (
        <p
          dir={direction}
          lang={locale}
          className="reader-muted mt-2 text-sm italic leading-relaxed"
        >
          {meaning}
        </p>
      ) : null}
      {/* Quiet ornamental divider separating the opening from the first
       * numbered ayah (restrained, theme-aware, purely decorative). */}
      <div aria-hidden="true" className="mx-auto mt-6 flex items-center justify-center gap-2">
        <span className="h-px w-16 bg-current opacity-20" />
        <span className="size-1.5 rotate-45 bg-current opacity-25" />
        <span className="h-px w-16 bg-current opacity-20" />
      </div>
    </div>
  )
}
