'use client'

/**
 * Result card for one catalog translation - compact, non-technical, with
 * clear primary actions.
 *
 * Content policy (Prompt 3):
 * - The card shows what a browsing user needs: title, language in its
 *   native script, translator/publisher when the source documents one, a
 *   one-line description and the download status. Detailed metadata lives
 *   in the details dialog, not here.
 * - Trust is presented by naming the known source ("via QuranEnc") - never
 *   by scary "untrusted"/"not verified" labels.
 * - Actions: "Read now" opens the reader; "Download" opens the download
 *   page for this translation (offline pack, file formats with their exact
 *   sizes, exports and print); the info icon opens the regular details.
 *   A running pack download is reflected honestly by the inline progress.
 */

import { ArrowDownToLine, BookOpen, CheckCircle2, Info, RefreshCw } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useReaderStore } from '@/stores/reader-store'
import type { DownloadJobRecord, OfflinePackStatus, Translation } from '@/types'
import { formatDateTimeString } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'

/** Non-terminal pack-job statuses (progress / pause states). */
const ACTIVE_JOB_STATUSES = new Set(['queued', 'downloading', 'verifying', 'paused', 'interrupted'])

export interface TranslationCardProps {
  translation: Translation
  /** Real offline status from the pack index (null when nothing is cached). */
  packStatus: OfflinePackStatus | null
  /** Live pack job for this translation, when one is in flight. */
  activeJob: DownloadJobRecord | null
  /** True when this is the translation the user last read. */
  isLastRead: boolean
  onOpenDetails: (translation: Translation) => void
  onOpenDownloads: (translation: Translation) => void
}

export function TranslationCard({
  translation,
  packStatus,
  activeJob,
  isLastRead,
  onOpenDetails,
  onOpenDownloads,
}: TranslationCardProps) {
  const { t, locale } = useTranslation()
  const openReader = useReaderStore((s) => s.openReader)

  const jobActive = activeJob !== null && ACTIVE_JOB_STATUSES.has(activeJob.status)
  const jobDownloading = activeJob !== null && activeJob.status === 'downloading'
  const percent =
    jobDownloading && activeJob.totalBytes !== null && activeJob.totalBytes > 0
      ? Math.min(100, Math.max(0, (activeJob.bytesReceived / activeJob.totalBytes) * 100))
      : null

  const packComplete = packStatus?.complete === true
  // Update available: a complete pack whose stored version differs from the
  // source version (both known). Never guessed otherwise.
  const updateAvailable =
    packComplete &&
    packStatus.version !== null &&
    translation.version !== null &&
    packStatus.version !== translation.version

  return (
    <Card className="h-full transition-shadow hover:shadow-md">
      <CardContent className="flex h-full flex-col gap-2.5 p-4">
        {/* Title + offline status */}
        <div className="flex items-start justify-between gap-3">
          <h3 dir="auto" className="min-w-0 text-sm font-semibold leading-snug text-foreground">
            {translation.title}
          </h3>
          {packComplete ? (
            updateAvailable ? (
              <Badge
                variant="outline"
                className="shrink-0 border-gold/40 bg-gold/15 text-gold-foreground"
                title={t('quran.offline.updateNote')}
              >
                {t('quran.offline.updateAvailableBadge')}
              </Badge>
            ) : (
              <Badge
                variant="outline"
                className="shrink-0 border-success/40 bg-success/10 text-success"
              >
                <CheckCircle2 aria-hidden="true" className="size-3" />
                {t('quran.card.readyOffline')}
              </Badge>
            )
          ) : null}
        </div>

        {/* Language (native script first) + last-read marker */}
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant="secondary">
            <span dir="auto" className="truncate">
              {translation.languageNativeName ?? translation.languageName}
            </span>
          </Badge>
          {isLastRead ? (
            <Badge variant="outline" className="border-primary/30 text-primary">
              {t('quran.card.lastRead')}
            </Badge>
          ) : null}
        </div>

        {/* Translator / publisher - only when the source documents one */}
        {translation.translator ?? translation.publisher ? (
          <p dir="auto" className="truncate text-xs text-muted-foreground">
            {[translation.translator, translation.publisher].filter(Boolean).join(' · ')}
          </p>
        ) : null}

        {translation.description ? (
          <p dir="auto" className="line-clamp-1 text-xs leading-relaxed text-muted-foreground">
            {translation.description}
          </p>
        ) : null}

        {/* Source line + freshness - quiet, honest, never scary */}
        <p className="mt-auto flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground">
          <span>{t('quran.card.viaSource')}</span>
          {translation.lastUpdated ? (
            <>
              <span aria-hidden="true">·</span>
              <span>{formatDateTimeString(locale, translation.lastUpdated)}</span>
            </>
          ) : null}
        </p>

        {/* Inline progress while a pack download runs */}
        {jobActive && percent !== null ? (
          <Progress
            value={percent}
            aria-label={`${t('quran.card.downloadingAction')} ${translation.title}`}
          />
        ) : null}

        {/* Actions: read, download page, details */}
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            className="h-11"
            onClick={() => openReader({ translationKey: translation.key })}
          >
            <BookOpen aria-hidden="true" className="size-4" />
            {t('quran.readNow')}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-11"
            onClick={() => onOpenDownloads(translation)}
          >
            {updateAvailable ? (
              <RefreshCw aria-hidden="true" className="size-4" />
            ) : (
              <ArrowDownToLine aria-hidden="true" className="size-4" />
            )}
            {jobActive
              ? activeJob?.status === 'paused'
                ? t('downloads.paused')
                : t('quran.card.downloadingAction')
              : updateAvailable
                ? t('quran.offline.update')
                : t('quran.card.downloadAction')}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-11 w-11 px-0"
            aria-label={`${t('common.details')} — ${translation.title}`}
            title={t('common.details')}
            onClick={() => onOpenDetails(translation)}
          >
            <Info aria-hidden="true" className="size-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
