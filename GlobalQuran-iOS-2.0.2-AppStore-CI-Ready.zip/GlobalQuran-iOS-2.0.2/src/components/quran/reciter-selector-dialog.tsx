'use client'

/**
 * Reciter selector dialog.
 *
 * Shows the VERIFIED recitation catalog: one row per recitation style with
 * - reciter names (Latin + Arabic), style label and bitrate/format badges,
 * - the verification verdict: a style is selectable only when the server
 *   confirmed BOTH the seed inventory AND live availability - anything less
 *   is displayed honestly as "not verified right now" and cannot be picked,
 * - honest stats (complete suras, verified ayat, total size) and the source
 *   attribution of the recordings,
 * - a short preview action (Al-Fatiha 1:1 - the Basmalah) that plays the
 *   genuine recording of the highlighted style.
 *
 * Selecting a style never touches the reader state: the reading position,
 * translation and display settings stay exactly as they are.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  BadgeCheck,
  CircleAlert,
  Pause,
  Play,
  Radio,
  ShieldCheck,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getReciterCatalog } from '@/services/api/audio-api'
import { everyAyahFileUrl, formatAudioSize } from '@/lib/audio/urls'
import { getStyleDefinition } from '@/data/audio-styles'
import { useAudioStore } from '@/stores/audio-store'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'
import type { ReciterStyleDto } from '@/types'

export const RECITER_CATALOG_QUERY_KEY = ['audio-reciter-catalog'] as const

/** Shared query for the verified reciter catalog (reader toolbar uses it too). */
export function useReciterCatalog() {
  return useQuery({
    queryKey: RECITER_CATALOG_QUERY_KEY,
    queryFn: getReciterCatalog,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  })
}

function styleLabelKey(style: ReciterStyleDto): 'audio.styleMuallim' | 'audio.styleMurattal' | 'audio.styleMujawwad' {
  switch (style.style) {
    case 'muallim':
      return 'audio.styleMuallim'
    case 'mujawwad':
      return 'audio.styleMujawwad'
    default:
      return 'audio.styleMurattal'
  }
}

/** Locale-aware bio: Arabic users get the faithful Arabic rendering of the
 *  same verified facts (translation only, source unchanged). */
function localizedBio(style: ReciterStyleDto, locale: string): { note: string | null; source: string | null } {
  if (locale === 'ar') {
    const definition = getStyleDefinition(style.id)
    if (definition?.bioNoteArabic) {
      return { note: definition.bioNoteArabic, source: definition.bioNoteSourceArabic ?? style.bioNoteSource }
    }
  }
  return { note: style.bioNote, source: style.bioNoteSource }
}

export interface ReciterSelectorDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ReciterSelectorDialog({ open, onOpenChange }: ReciterSelectorDialogProps) {
  const { t, locale } = useTranslation()
  const selectedStyleId = useAudioStore((s) => s.selectedStyleId)
  const selectStyle = useAudioStore((s) => s.selectStyle)
  const catalogQuery = useReciterCatalog()
  const [previewStyleId, setPreviewStyleId] = useState<string | null>(null)
  const [previewPlaying, setPreviewPlaying] = useState(false)
  const previewRef = useRef<HTMLAudioElement | null>(null)

  /** A fresh preview audio element per dialog opening; removed on close.
   *  Listeners update React state from external events (allowed pattern);
   *  the effect body itself never calls setState. */
  useEffect(() => {
    if (!open) return
    const audio = new Audio()
    audio.preload = 'auto'
    audio.crossOrigin = 'anonymous'
    audio.addEventListener('playing', () => setPreviewPlaying(true))
    audio.addEventListener('pause', () => setPreviewPlaying(false))
    audio.addEventListener('ended', () => {
      setPreviewPlaying(false)
      setPreviewStyleId(null)
    })
    audio.addEventListener('error', () => {
      setPreviewPlaying(false)
      setPreviewStyleId(null)
    })
    previewRef.current = audio
    return () => {
      audio.pause()
      audio.removeAttribute('src')
      previewRef.current = null
    }
  }, [open])

  /** Closing the dialog also stops and forgets any running preview. */
  const handleDialogOpenChange = (next: boolean) => {
    if (!next) {
      previewRef.current?.pause()
      setPreviewStyleId(null)
      setPreviewPlaying(false)
    }
    onOpenChange(next)
  }

  /** Styles grouped per reciter (keeps Abdul Basit's two styles together). */
  const reciterGroups = useMemo(() => {
    const styles = catalogQuery.data?.styles ?? []
    const groups: { reciterName: string; reciterNameArabic: string; styles: ReciterStyleDto[] }[] = []
    for (const style of styles) {
      let group = groups.find((g) => g.reciterName === style.reciterName)
      if (!group) {
        group = { reciterName: style.reciterName, reciterNameArabic: style.reciterNameArabic, styles: [] }
        groups.push(group)
      }
      group.styles.push(style)
    }
    return groups
  }, [catalogQuery.data])

  const handlePreview = (style: ReciterStyleDto) => {
    const audio = previewRef.current
    if (!audio) return
    if (previewStyleId === style.id && previewPlaying) {
      audio.pause()
      return
    }
    const url = everyAyahFileUrl(style.folder, 1, 1)
    if (!url) return
    setPreviewStyleId(style.id)
    audio.src = url
    void audio.play().catch(() => {
      setPreviewPlaying(false)
      setPreviewStyleId(null)
    })
  }

  const handleSelect = (style: ReciterStyleDto) => {
    selectStyle(style.id)
    toast.success(t('audio.reciterSelected', { name: style.reciterName, style: t(styleLabelKey(style)) }))
    /* PROMPT 14 (Nielsen #3): close after the committed choice instead of
     *  forcing the user to find the dismiss control. */
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={handleDialogOpenChange}>
      <DialogContent className="gap-0 sm:max-w-lg">
        <DialogHeader className="pb-3 text-start">
          <DialogTitle className="flex items-center gap-2">
            <Radio aria-hidden="true" className="size-5 text-primary" />
            {t('audio.selectReciter')}
          </DialogTitle>
          <DialogDescription>
            {t('audio.selectReciterDescription')} {t('audio.positionKept')}
          </DialogDescription>
        </DialogHeader>

        <Separator />

        {catalogQuery.isPending ? (
          <div className="space-y-3 p-4">
            {Array.from({ length: 4 }).map((_, index) => (
              <Skeleton key={index} className="h-20 w-full" />
            ))}
          </div>
        ) : catalogQuery.isError ? (
          <div className="space-y-3 p-6 text-center">
            <CircleAlert aria-hidden="true" className="mx-auto size-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">{t('audio.catalogUnavailable')}</p>
            {/* PROMPT 14 (Nielsen #9): a recovery path, not a dead end. */}
            <Button
              type="button"
              variant="outline"
              className="h-11"
              onClick={() => void catalogQuery.refetch()}
              disabled={catalogQuery.isFetching}
            >
              {catalogQuery.isFetching ? t('common.loading') : t('common.retry')}
            </Button>
          </div>
        ) : (
          <ScrollArea className="max-h-[min(28rem,calc(100dvh-14rem))]">
            <div className="space-y-4 p-4">
              {reciterGroups.map((group) => (
                <section key={group.reciterName} aria-label={group.reciterName}>
                  <div className="flex items-baseline justify-between gap-2">
                    <h3 className="text-sm font-semibold text-foreground">{group.reciterName}</h3>
                    <span dir="rtl" lang="ar" className="text-quranic text-sm text-muted-foreground">
                      {group.reciterNameArabic}
                    </span>
                  </div>

                  <div className="mt-2 space-y-2">
                    {group.styles.map((style) => {
                      const isSelected = style.id === selectedStyleId
                      const isPreviewing = previewStyleId === style.id && previewPlaying
                      return (
                        <div
                          key={style.id}
                          className={cn(
                            'rounded-xl border p-3 transition-colors',
                            isSelected ? 'border-primary/60 bg-primary/5' : 'border-border',
                            style.available ? 'cursor-pointer hover:bg-accent/50' : 'opacity-70',
                          )}
                          onClick={() => style.available && handleSelect(style)}
                          role={style.available ? 'button' : undefined}
                          tabIndex={style.available ? 0 : undefined}
                          onKeyDown={(event) => {
                            if (style.available && (event.key === 'Enter' || event.key === ' ')) {
                              event.preventDefault()
                              handleSelect(style)
                            }
                          }}
                          aria-pressed={style.available ? isSelected : undefined}
                        >
                          <div className="flex items-center gap-2">
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium text-foreground">
                                {t(styleLabelKey(style))}
                              </p>
                              <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
                                <span>{style.bitrate}</span>
                                <span aria-hidden="true">·</span>
                                <span className="uppercase">{style.format}</span>
                                {style.forLearning ? (
                                  <>
                                    <span aria-hidden="true">·</span>
                                    <span className="font-medium text-primary">{t('audio.forLearning')}</span>
                                  </>
                                ) : null}
                              </p>
                            </div>

                            {style.available ? (
                              <Badge variant="outline" className="gap-1 border-emerald-600/30 text-emerald-700 dark:text-emerald-400">
                                <ShieldCheck aria-hidden="true" className="size-3" />
                                {t('audio.verified')}
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="gap-1 border-amber-600/30 text-amber-700 dark:text-amber-400">
                                <CircleAlert aria-hidden="true" className="size-3" />
                                {t('audio.notAvailableNow')}
                              </Badge>
                            )}
                          </div>

                          {/* Honest verified stats - exact numbers from the seed */}
                          <p className="mt-2 text-xs text-muted-foreground">
                            {t('audio.availableSuras', { count: style.completeSuras })} ·{' '}
                            {t('audio.verifiedAyat', { count: style.totalAyat })} ·{' '}
                            {t('audio.totalSize', { size: formatAudioSize(style.totalBytes, locale) })}
                          </p>

                          {(() => {
                            const bio = localizedBio(style, locale)
                            return bio.note ? (
                              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                                {bio.note}
                                <span className="block pt-0.5 text-[0.6875rem] opacity-75">
                                  {bio.source}
                                </span>
                              </p>
                            ) : null
                          })()}

                          <div className="mt-2 flex items-center justify-between gap-2">
                            <p className="text-[0.6875rem] text-muted-foreground">
                              {t('audio.sourceLine', { source: style.sourceName })}
                            </p>
                            <div className="flex items-center gap-1.5">
                              {isSelected ? (
                                <Badge variant="secondary" className="gap-1">
                                  <BadgeCheck aria-hidden="true" className="size-3" />
                                  {t('audio.selected')}
                                </Badge>
                              ) : null}
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                className="h-11 gap-1.5 px-3"
                                disabled={!style.available}
                                onClick={(event) => {
                                  event.stopPropagation()
                                  handlePreview(style)
                                }}
                                aria-label={isPreviewing ? t('audio.stopPreview') : t('audio.preview')}
                              >
                                {isPreviewing ? (
                                  <>
                                    <Pause aria-hidden="true" className="size-3.5" />
                                    <span className="text-xs">{t('audio.stopPreview')}</span>
                                  </>
                                ) : (
                                  <>
                                    <Play aria-hidden="true" className="size-3.5" />
                                    <span className="text-xs">{t('audio.preview')}</span>
                                  </>
                                )}
                              </Button>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </section>
              ))}

              <p className="pt-1 text-[0.6875rem] leading-relaxed text-muted-foreground">
                {t('audio.catalogVerificationNote')}
              </p>
            </div>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  )
}
