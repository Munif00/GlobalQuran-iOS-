'use client'

/**
 * Searchable language picker (combobox).
 *
 * The catalog offers translations in 80+ languages, so a plain dropdown makes
 * languages like Japanese or Korean hard to find. This combobox adds a search
 * field to the language list:
 * - matches the native name, the English name and the ISO code
 *   (e.g. "日本語", "japanese", "ja" all find Japanese),
 * - diacritic/Arabic-fold tolerant via the shared search normalizer,
 * - fully keyboard navigable (type, arrows, Enter, Escape),
 * - logical CSS properties so it lays out correctly in RTL and LTR.
 */

import { useId, useMemo, useState } from 'react'
import { Check, ChevronDown, Languages } from 'lucide-react'

import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { cn } from '@/lib/utils'
import { normalizeForSearch } from '@/utils/text-normalize'

export interface PickerLanguage {
  code: string
  /** English name (from the source ISO-code map). */
  name: string
  /** Native name when known - always shown in native form. */
  nativeName: string | null
  /** Number of translations in this language (optional, display only). */
  count?: number
}

export interface PickerSpecialOption {
  value: string
  label: string
}

interface LanguagePickerProps {
  /** Language list (already sorted by the caller). */
  languages: PickerLanguage[]
  /** Current value: a language code or one of the special option values. */
  value: string
  onChange: (value: string) => void
  /** Extra non-language choices rendered first (e.g. "All", "Automatic"). */
  specialOptions?: PickerSpecialOption[]
  /** Accessible name for the combobox trigger. */
  ariaLabel: string
  /** Placeholder of the search field. */
  searchPlaceholder: string
  /** Text shown when no language matches the query. */
  emptyLabel: string
  /** Formats the translation count for display. */
  formatCount?: (count: number) => string
  className?: string
}

/** cmdk filter over native name, English name and code (normalized). */
function languageFilter(value: string, search: string): number {
  const query = normalizeForSearch(search)
  if (!query) return 1
  const candidate = normalizeForSearch(value)
  if (!candidate) return 0
  if (candidate.includes(query)) return 1
  return 0
}

/**
 * Arabic names of the catalog languages - SEARCH-ONLY aliases so Arabic
 * interface users can find languages by their Arabic names (e.g. "كوري"
 * finds Korean). These are standard language names, not source data; the
 * visible label always remains the native + English name from the source.
 */
const ARABIC_SEARCH_ALIASES: Readonly<Record<string, string>> = {
  aa: 'العفارية',
  ak: 'الأكانية',
  am: 'الأمهرية',
  ar: 'العربية',
  as: 'الأسامية',
  az: 'الأذربيجانية',
  be: 'البيلاروسية',
  bg: 'البلغارية',
  bn: 'البنغالية',
  bs: 'البوسنية',
  ca: 'الكاتالونية',
  ceb: 'البيسايانية',
  dag: 'الداغبانية',
  de: 'الألمانية',
  el: 'اليونانية',
  en: 'الإنجليزية',
  es: 'الإسبانية',
  fa: 'الفارسية',
  ff: 'الفولانية',
  fil: 'الفلبينية',
  fr: 'الفرنسية',
  gu: 'الغوجاراتية',
  ha: 'الهوسا',
  he: 'العبرية',
  hi: 'الهندية',
  hr: 'الكرواتية',
  id: 'الإندونيسية',
  ilp: 'الإيرانونية',
  it: 'الإيطالية',
  ja: 'اليابانية',
  ka: 'الجورجية',
  kbd: 'الشركسية',
  kk: 'الكازاخية',
  km: 'الخميرية',
  kmr: 'الكردية الكرمانجية',
  kn: 'الكنادية',
  ko: 'الكورية',
  ku: 'الكردية',
  ky: 'القيرغيزية',
  lg: 'اللوغندية',
  ln: 'اللينغالية',
  lt: 'الليتوانية',
  luy: 'اللوهية',
  mdh: 'الماغويندناوية',
  mg: 'الملغاشية',
  mk: 'المقدونية',
  ml: 'المالايالامية',
  mos: 'المورية',
  mr: 'الماراثية',
  ms: 'الملايوية',
  ne: 'النيبالية',
  nl: 'الهولندية',
  nqo: 'النكوية',
  ny: 'التشيشيوية',
  om: 'الأورومية',
  pa: 'البنجابية',
  prs: 'الدرية',
  ps: 'البشتوية',
  pt: 'البرتغالية',
  rn: 'الكيروندية',
  ro: 'الرومانية',
  ru: 'الروسية',
  rw: 'الكينيارواندية',
  si: 'السنهالية',
  sn: 'الشونية',
  so: 'الصومالية',
  sq: 'الألبانية',
  sr: 'الصربية',
  sv: 'السويدية',
  sw: 'السواحيلية',
  ta: 'التاميلية',
  te: 'التيلوغوية',
  tg: 'الطاجيكية',
  th: 'التايلاندية',
  tl: 'التاغالوغية',
  tr: 'التركية',
  ug: 'الأويغورية',
  uk: 'الأوكرانية',
  ur: 'الأردية',
  uz: 'الأوزبكية',
  vi: 'الفيتنامية',
  yao: 'الياوية',
  yo: 'اليوروبية',
  zh: 'الصينية',
  zu: 'الزولوية',
}

export function LanguagePicker({
  languages,
  value,
  onChange,
  specialOptions = [],
  ariaLabel,
  searchPlaceholder,
  emptyLabel,
  formatCount,
  className,
}: LanguagePickerProps) {
  const [open, setOpen] = useState(false)
  const contentId = useId()

  const selected = useMemo(() => {
    const special = specialOptions.find((option) => option.value === value)
    if (special) return { label: special.label, count: null as number | null }
    const language = languages.find((entry) => entry.code === value)
    if (!language) return null
    return {
      label: language.nativeName
        ? `${language.nativeName} · ${language.name}`
        : language.name,
      count: typeof language.count === 'number' ? language.count : null,
    }
  }, [languages, specialOptions, value])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          role="combobox"
          aria-expanded={open}
          aria-controls={open ? contentId : undefined}
          aria-label={ariaLabel}
          className={cn(
            'flex h-11 w-full items-center justify-between gap-2 rounded-lg border border-input bg-background px-3 text-sm text-start outline-none transition-colors',
            'hover:bg-accent/50 focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50',
            'disabled:cursor-not-allowed disabled:opacity-50',
            className,
          )}
        >
          <span className="flex min-w-0 items-center gap-2">
            <Languages aria-hidden="true" className="size-4 shrink-0 text-muted-foreground" />
            {selected ? (
              <span className="min-w-0 truncate">
                <span dir="auto">{selected.label}</span>
                {selected.count !== null && formatCount ? (
                  <span className="ms-1.5 text-xs text-muted-foreground">
                    {formatCount(selected.count)}
                  </span>
                ) : null}
              </span>
            ) : (
              <span className="truncate text-muted-foreground">{specialOptions[0]?.label ?? ''}</span>
            )}
          </span>
          <ChevronDown
            aria-hidden="true"
            className={cn(
              'size-4 shrink-0 text-muted-foreground transition-transform',
              open && 'rotate-180',
            )}
          />
        </button>
      </PopoverTrigger>
      <PopoverContent
        id={contentId}
        align="start"
        className="w-[min(22rem,var(--radix-popover-trigger-width))] p-0"
      >
        <Command filter={languageFilter}>
          <CommandInput placeholder={searchPlaceholder} />
          <CommandList className="max-h-72">
            <CommandEmpty>{emptyLabel}</CommandEmpty>

            {specialOptions.length > 0 ? (
              <CommandGroup>
                {specialOptions.map((option) => (
                  <CommandItem
                    key={option.value}
                    value={option.label}
                    onSelect={() => {
                      onChange(option.value)
                      setOpen(false)
                    }}
                  >
                    <Check
                      aria-hidden="true"
                      className={cn(
                        'size-4 shrink-0',
                        value === option.value ? 'opacity-100' : 'opacity-0',
                      )}
                    />
                    <span className="truncate text-sm">{option.label}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            ) : null}

            <CommandGroup>
              {languages.map((language) => {
                const isActive = value === language.code
                return (
                  <CommandItem
                    key={language.code}
                    value={`${language.nativeName ?? ''} ${language.name} ${language.code} ${
                      ARABIC_SEARCH_ALIASES[language.code] ?? ''
                    }`}
                    onSelect={() => {
                      onChange(language.code)
                      setOpen(false)
                    }}
                  >
                    <Check
                      aria-hidden="true"
                      className={cn('size-4 shrink-0', isActive ? 'opacity-100' : 'opacity-0')}
                    />
                    <span className="flex min-w-0 flex-1 items-baseline justify-between gap-2">
                      <span dir="auto" className="min-w-0 truncate text-sm font-medium">
                        {language.nativeName ?? language.name}
                      </span>
                      <span className="ms-auto flex shrink-0 items-baseline gap-1.5 text-xs text-muted-foreground">
                        <span dir="auto" className="truncate">{language.name}</span>
                        {typeof language.count === 'number' && formatCount ? (
                          <span className="tabular-nums opacity-70">
                            {formatCount(language.count)}
                          </span>
                        ) : null}
                      </span>
                    </span>
                  </CommandItem>
                )
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
