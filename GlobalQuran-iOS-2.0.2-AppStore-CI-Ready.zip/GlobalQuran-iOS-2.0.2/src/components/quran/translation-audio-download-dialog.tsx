'use client'

/**
 * Translation narration audio download dialog (reader side, PROMPT 10).
 *
 * Offers the download options for the recorded narration of the SELECTED
 * translation at the current reading position:
 * - this ayah, a selected ayah range, the whole current surah, the juz
 *   that contains the current position, or the complete narration package
 *   - offered ONLY when the verified source manifest covers every ayah.
 *
 * Every option previews the VERIFIED plan before anything starts: the
 * exact file count, the total size (exact for ordinary batches; a clearly
 * labeled sampled estimate for the complete package), and an honest
 * notice for ayat the source does not have a verified file for.
 */

import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ArrowDownToLine, CircleAlert, Download, Loader2 } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getTranslationAudioBatchPlan } from '@/services/api/audio-api'
import {
  enqueueTranslationAudioBatch,
  type TranslationAudioBatchSpec,
} from '@/services/downloads/translation-audio-download-manager'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { getSuraMeta } from '@/data/sura-index'
import { getJuzForPosition } from '@/data/juz-index'
import { formatBytes, formatNumber } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

type BatchOption = 'ayah' | 'sura' | 'range' | 'juz' | 'complete'

export interface TranslationAudioDownloadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** The translation whose narration is downloaded. */
  translationKey: string
  /** Display name of the narration edition (from the verified catalog). */
  audioName: string
  /** The sura the reader currently shows. */
  sura: number
  /** The tracked reading line when the dialog was opened. */
  seedAyah: number
}

export function TranslationAudioDownloadDialog({
  open,
  onOpenChange,
  translationKey,
  audioName,
  sura,
  seedAyah,
}: TranslationAudioDownloadDialogProps) {
  const { t, locale } = useTranslation()

  const [option, setOption] = useState<BatchOption>('sura')
  const [rangeFrom, setRangeFrom] = useState('')
  const [rangeTo, setRangeTo] = useState('')

  const suraMeta = getSuraMeta(sura)
  const ayahCount = getSuraAyahCount(sura)
  const currentJuz = useMemo(() => getJuzForPosition(sura, seedAyah) ?? 1, [sura, seedAyah])

  const fromAyah = Number(rangeFrom)
  const toAyah = Number(rangeTo)

  // Reset the selection each time the dialog opens.
  const [wasOpen, setWasOpen] = useState(false)
  if (open !== wasOpen) {
    setWasOpen(open)
    if (open) {
      setOption('sura')
      setRangeFrom(String(Math.min(seedAyah, ayahCount)))
      setRangeTo(String(ayahCount))
    }
  }
  const rangeValid =
    Number.isInteger(fromAyah) &&
    Number.isInteger(toAyah) &&
    fromAyah >= 1 &&
    toAyah >= fromAyah &&
    toAyah <= ayahCount

  /** The batch spec of the selected option (null while invalid). */
  const spec: TranslationAudioBatchSpec | null = useMemo(() => {
    switch (option) {
      case 'ayah':
        return { translationKey, kind: 'ayah', sura, ayah: seedAyah }
      case 'sura':
        return { translationKey, kind: 'sura', sura }
      case 'range':
        return rangeValid
          ? { translationKey, kind: 'range', sura, from: fromAyah, to: toAyah }
          : null
      case 'juz':
        return { translationKey, kind: 'juz', juz: currentJuz }
      case 'complete':
        return { translationKey, kind: 'complete' }
    }
  }, [translationKey, option, sura, seedAyah, rangeValid, fromAyah, toAyah, currentJuz])

  /** Verified plan preview (exact sizes + honest missing report). */
  const planQuery = useQuery({
    queryKey: ['translation-audio-batch-plan', spec],
    queryFn: () => getTranslationAudioBatchPlan({ ...spec!, kind: spec!.kind }),
    enabled: open && spec !== null,
    staleTime: 60_000,
    retry: 1,
  })

  const plan = planQuery.data ?? null
  const completeOfferable = option !== 'complete' || plan?.completePackageOfferable === true

  const handleDownload = async () => {
    if (!spec) return
    const result = await enqueueTranslationAudioBatch(spec)
    if (result.ok) {
      toast(t('audio.download.started'), {
        description: t('audio.download.startedDescription'),
      })
      onOpenChange(false)
      return
    }
    switch (result.reason) {
      case 'already-downloaded':
        toast.info(t('audio.download.alreadyDownloadedTitle'), {
          description: t('audio.download.alreadyDownloadedDescription'),
        })
        break
      case 'duplicate-active':
        toast.info(t('audio.download.duplicateActiveTitle'), {
          description: t('audio.download.duplicateActiveDescription'),
        })
        break
      case 'incomplete-source':
        toast.info(t('audio.download.incompleteSourceTitle'), {
          description: t('audio.download.incompleteSourceDescription'),
        })
        break
      case 'plan-unavailable':
        toast.error(t('audio.download.planUnavailable'))
        break
      default:
        toast.error(t('common.error'), { description: t('common.errorDescription') })
    }
  }

  const optionItems: Array<{ value: BatchOption; label: string; hint?: string }> = [
    { value: 'ayah', label: t('audio.download.thisAyah'), hint: `${sura}:${seedAyah}` },
    { value: 'sura', label: t('audio.download.wholeSura'), hint: suraMeta?.nameEnglish },
    { value: 'range', label: t('audio.download.range') },
    {
      value: 'juz',
      label: t('audio.download.juzOption', { juz: currentJuz }),
      hint: t('audio.download.currentJuz'),
    },
    { value: 'complete', label: t('downloads.narrationBatchComplete') },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {/* Height cap: the dialog never exceeds the viewport (85dvh leaves room
          for the browser/OS chrome and gesture-nav insets); the content area
          scrolls internally and min-w-0 keeps long narration names from
          pushing the dialog wider than the screen. */}
      <DialogContent className="max-h-[85dvh] min-w-0 overflow-y-auto scrollbar-subtle sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowDownToLine aria-hidden="true" className="size-5 text-amber-600 dark:text-amber-400" />
            {t('narration.downloadTitle')}
          </DialogTitle>
          <DialogDescription className="text-left">
            {t('narration.downloadSubtitle')}
          </DialogDescription>
        </DialogHeader>

        <p className="text-sm text-muted-foreground">
          {t('narration.download.translationLabel')}:{' '}
          <span dir="auto" className="font-medium text-foreground">
            {audioName}
          </span>
        </p>

        <RadioGroup
          value={option}
          onValueChange={(value) => setOption(value as BatchOption)}
          className="gap-2"
        >
          {optionItems.map((item) => (
            <Label
              key={item.value}
              htmlFor={`narration-dl-${item.value}`}
              className={cn(
                'flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-input bg-background p-3 text-sm font-normal transition-colors',
                'hover:bg-accent has-[button[data-state=checked]]:border-amber-600/50 has-[button[data-state=checked]]:bg-amber-500/5',
                item.value === 'complete' && plan !== null && !completeOfferable && 'cursor-not-allowed opacity-50',
              )}
            >
              <span className="flex min-w-0 flex-1 items-center gap-3">
                <RadioGroupItem id={`narration-dl-${item.value}`} value={item.value} />
                <span className="min-w-0">
                  <span dir="auto" className="block truncate font-medium text-foreground">
                    {item.label}
                  </span>
                  {item.hint ? (
                    <span dir="auto" className="block truncate text-xs text-muted-foreground">
                      {item.hint}
                    </span>
                  ) : null}
                </span>
              </span>
            </Label>
          ))}
        </RadioGroup>

        {option === 'range' ? (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="narration-dl-from">{t('audio.download.rangeFrom')}</Label>
              <Input
                id="narration-dl-from"
                type="number"
                min={1}
                max={ayahCount}
                inputMode="numeric"
                value={rangeFrom}
                onChange={(event) => setRangeFrom(event.target.value)}
                className="h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="narration-dl-to">{t('audio.download.rangeTo')}</Label>
              <Input
                id="narration-dl-to"
                type="number"
                min={1}
                max={ayahCount}
                inputMode="numeric"
                value={rangeTo}
                onChange={(event) => setRangeTo(event.target.value)}
                className="h-11"
              />
            </div>
          </div>
        ) : null}

        {/* Verified plan preview */}
        <div className="space-y-2 rounded-lg border bg-card p-3" aria-live="polite">
          {planQuery.isPending ? (
            <div className="space-y-2">
              <p className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 aria-hidden="true" className="size-3.5 animate-spin" />
                {t('audio.download.planLoading')}
              </p>
              <Skeleton className="h-4 w-40" />
            </div>
          ) : plan === null ? (
            <p className="flex items-start gap-2 text-xs text-destructive">
              <CircleAlert aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
              {t('audio.download.planUnavailable')}
            </p>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="tabular-nums">
                  {t('audio.download.filesCount', {
                    count: formatNumber(locale, plan.totalFiles),
                  })}
                </Badge>
                {plan.sizeEstimated ? (
                  <Badge variant="outline" className="tabular-nums">
                    {t('narration.download.sizeEstimated', {
                      size: formatBytes(locale, plan.totalBytes),
                    })}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="tabular-nums">
                    {t('audio.download.sizeExact', { size: formatBytes(locale, plan.totalBytes) })}
                  </Badge>
                )}
                {option === 'complete' && !plan.completePackageOfferable ? (
                  <Badge variant="destructive">{t('audio.download.incompleteSourceTitle')}</Badge>
                ) : null}
              </div>
              {plan.sizeEstimated ? (
                <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
                  <CircleAlert aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
                  {t('narration.download.estimatedNote')}
                </p>
              ) : null}
              {plan.missing.length > 0 ? (
                <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
                  <CircleAlert aria-hidden="true" className="mt-0.5 size-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
                  {t('audio.download.missingHonest', {
                    count: formatNumber(locale, plan.missing.length),
                  })}
                </p>
              ) : null}
              <p className="text-xs text-muted-foreground">
                {t('audio.sourceLine', { source: plan.sourceName })}
              </p>
            </>
          )}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" className="h-11" onClick={() => onOpenChange(false)}>
            {t('common.close')}
          </Button>
          <Button
            className="h-11"
            disabled={spec === null || plan === null || !completeOfferable}
            onClick={() => void handleDownload()}
          >
            <Download aria-hidden="true" className="size-4" />
            {t('audio.download.downloadAction')}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
