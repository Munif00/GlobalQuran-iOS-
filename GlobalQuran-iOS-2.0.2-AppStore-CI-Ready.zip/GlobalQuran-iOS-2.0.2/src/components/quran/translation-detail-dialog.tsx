'use client'

/**
 * Dialog for one catalog translation, with two focused modes:
 *
 * - mode="details" (the info icon on a card): the regular details - source &
 *   trust plus the metadata list. Missing fields are labelled honestly
 *   (never inferred from titles or descriptions). Trust (§4): the source is
 *   named clearly and consistently; scholarly verification is shown only
 *   when documentary evidence exists, otherwise a neutral note explains that
 *   the absence of a separate certificate is not a warning.
 * - mode="download" (the Download button on a card): the download page -
 *   offline reading pack, the real documents the source publishes (PDF /
 *   EPUB / SQLite) and the generated exports (PDF print / DOCX / TXT /
 *   JSON), each option labelled with its exact size before anything starts.
 */

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import {
  ArrowDownToLine,
  BookOpen,
  Braces,
  CheckCircle2,
  Download,
  ExternalLink,
  FileText,
  FileType2,
  Loader2,
  Printer,
  RefreshCw,
  ShieldCheck,
  Trash2,
  type LucideIcon,
} from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { describeApiError } from '@/services/api/errors'
import { enqueueDownload } from '@/services/downloads/download-manager'
import { platformFetch } from '@/services/platform/fetch'
import {
  probeExportSizes,
  probeFileSize,
  probePackSize,
  type ExportSizeProbe,
} from '@/services/downloads/size-probe'
import {
  enqueueOfflinePack,
  getOfflinePackStatus,
  removeOfflinePack,
} from '@/services/downloads/offline-pack-manager'
import { getFileStorage, type StoredFileMetadata } from '@/services/storage/local-file-storage'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { useReaderStore } from '@/stores/reader-store'
import type { OfflinePackStatus, Translation, TranslationFile } from '@/types'
import { formatBytes, formatDateTimeString, formatNumber } from '@/utils/format'

import { InfoRow } from '@/components/design-system/info-row'
import { VerificationBadge } from '@/components/design-system/verification-badge'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'

/** Formats offered by the export section (`pdf` uses the print pipeline). */
type ExportFormat = 'pdf' | 'docx' | 'txt' | 'json'

/** Export requests aggregate 114 suras server-side; allow a long timeout. */
const EXPORT_FETCH_TIMEOUT_MS = 300_000

/**
 * Write a print-optimized HTML document into a hidden offscreen iframe and
 * open the browser print dialog on it. Removed after printing or on error.
 */
async function printHtmlInIframe(html: string): Promise<void> {
  const iframe = document.createElement('iframe')
  iframe.setAttribute('aria-hidden', 'true')
  iframe.title = 'Quran export print preview'
  // Sandbox without allow-scripts: the exported HTML is fully escaped by the
  // server, and the sandbox guarantees it can never become script-executing
  // even if an escaping regression appeared. allow-same-origin keeps the
  // print() callable from the parent; allow-modals permits the print dialog.
  iframe.setAttribute('sandbox', 'allow-same-origin allow-modals')
  iframe.style.cssText =
    'position:fixed;top:0;left:-10000px;width:8.27in;height:11.69in;border:0;background:#fff;'
  document.body.appendChild(iframe)

  let safetyTimer = 0
  const cleanup = () => {
    if (safetyTimer) window.clearTimeout(safetyTimer)
    iframe.remove()
  }

  try {
    await new Promise<void>((resolve, reject) => {
      const timer = window.setTimeout(
        () => reject(new Error('Print document did not load')),
        20_000,
      )
      iframe.addEventListener(
        'load',
        () => {
          window.clearTimeout(timer)
          resolve()
        },
        { once: true },
      )
      iframe.srcdoc = html
    })

    const contentWindow = iframe.contentWindow
    const contentDocument = iframe.contentDocument
    if (!contentWindow || !contentDocument) {
      throw new Error('Print frame unavailable')
    }

    const fontsReady = contentDocument.fonts?.ready ?? Promise.resolve()
    await Promise.race([
      fontsReady.catch(() => {}),
      new Promise((resolve) => window.setTimeout(resolve, 2500)),
    ])

    contentWindow.addEventListener('afterprint', cleanup, { once: true })
    safetyTimer = window.setTimeout(cleanup, 120_000)
    contentWindow.focus()
    contentWindow.print()
  } catch (error) {
    cleanup()
    throw error
  }
}

/** Read the clean `{ message }` body of a failed export response. */
async function readExportErrorMessage(response: Response): Promise<string> {
  try {
    const data: unknown = await response.json()
    if (data && typeof data === 'object' && 'message' in data) {
      const message = (data as { message?: unknown }).message
      if (typeof message === 'string' && message.length > 0) return message
    }
  } catch {
    // Body was not JSON - fall through to the empty fallback.
  }
  return ''
}

/** One downloadable file row: variant/format label, exact size, download. */
function DownloadFileRow({
  file,
  probedSize,
  isProbing,
  isQueued,
  onDownload,
}: {
  file: TranslationFile
  /** Size measured from the file host when the catalog does not publish one. */
  probedSize: number | null
  isProbing: boolean
  isQueued: boolean
  onDownload: (file: TranslationFile) => void
}) {
  const { t, locale } = useTranslation()

  const label =
    file.variant !== null
      ? t(`quran.variant.${file.variant}` as TranslationKey)
      : file.format.toUpperCase()

  // Size priority: the catalog-published size, then the measured size from
  // the file host, then an honest fallback - never a guess.
  const effectiveSize = file.size ?? probedSize

  return (
    <li className="flex items-center gap-3 rounded-lg border border-border/60 bg-muted/30 p-3">
      {file.coverUrl ? (
        <img
          src={file.coverUrl}
          alt=""
          loading="lazy"
          className="h-10 w-8 shrink-0 rounded object-cover"
        />
      ) : null}
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-foreground">{label}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {effectiveSize !== null ? (
            <span className="tabular-nums">{formatBytes(locale, effectiveSize)}</span>
          ) : isProbing ? (
            <span className="italic">{t('downloads.sizeMeasuring')}</span>
          ) : (
            t('quran.sizeNotPublished')
          )}
        </p>
      </div>
      <Button
        variant="outline"
        className="h-11 shrink-0"
        disabled={isQueued}
        onClick={() => onDownload(file)}
      >
        <Download aria-hidden="true" className="size-4" />
        {isQueued ? t('quran.downloadingFile') : t('common.download')}
      </Button>
    </li>
  )
}

/** One export format button; spinner while running, exact size on the side. */
function ExportFormatButton({
  label,
  icon: Icon,
  sizeLabel,
  sizePending,
  busy,
  disabled,
  onClick,
}: {
  label: string
  icon: LucideIcon
  /** Formatted exact size of the generated document (null when unknown). */
  sizeLabel: string | null
  /** True while the size is still being measured. */
  sizePending: boolean
  busy: boolean
  disabled: boolean
  onClick: () => void
}) {
  const { t } = useTranslation()

  return (
    <Button
      type="button"
      variant="outline"
      className="h-11 justify-start"
      disabled={disabled}
      aria-busy={busy}
      onClick={onClick}
    >
      {busy ? (
        <Loader2 aria-hidden="true" className="size-4 shrink-0 animate-spin" />
      ) : (
        <Icon aria-hidden="true" className="size-4 shrink-0" />
      )}
      <span className="min-w-0 flex-1 truncate text-start">
        {busy ? t('quran.export.preparing') : label}
      </span>
      {busy ? null : sizeLabel !== null ? (
        <span className="ms-auto shrink-0 text-xs font-normal tabular-nums text-muted-foreground">
          {sizeLabel}
        </span>
      ) : sizePending ? (
        <Loader2
          aria-label={t('downloads.sizeMeasuring')}
          className="ms-auto size-3 shrink-0 animate-spin text-muted-foreground"
        />
      ) : null}
    </Button>
  )
}

/** The measured download size of the offline pack, shown before download. */
function DownloadSizeBadge({
  locale,
  bytes,
  label,
  measuringLabel,
}: {
  locale: string
  bytes: number | null
  label: string
  measuringLabel: string
}) {
  return (
    <span className="text-xs tabular-nums text-muted-foreground">
      {label}:{' '}
      {bytes !== null ? (
        <span className="font-medium text-foreground">{formatBytes(locale, bytes)}</span>
      ) : (
        <span className="italic">{measuringLabel}</span>
      )}
    </span>
  )
}

/** Which page the dialog shows (see the component doc comment). */
export type TranslationDialogMode = 'details' | 'download'

export function TranslationDetailDialog({
  translation,
  mode,
  open,
  onOpenChange,
}: {
  translation: Translation | null
  mode: TranslationDialogMode
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const { t, locale } = useTranslation()
  const isDownloadMode = mode === 'download'
  const openReader = useReaderStore((s) => s.openReader)
  const managerJobs = useDownloadManagerStore((s) => s.jobs)
  const activeIds = useDownloadManagerStore((s) => s.activeIds)

  /** Format currently being generated (null when idle). */
  const [busyFormat, setBusyFormat] = useState<ExportFormat | null>(null)

  /** Latest document copy in the offline library for the open translation. */
  const [storedFor, setStoredFor] = useState<{ key: string; meta: StoredFileMetadata | null } | null>(null)
  /** Offline pack status of the open translation (refreshed when jobs end). */
  const [packStatusFor, setPackStatusFor] = useState<{ key: string; status: OfflinePackStatus } | null>(null)
  const [removingPack, setRemovingPack] = useState(false)

  /** Exact pack download size, measured before the user downloads (null = unknown). */
  const [packSizeFor, setPackSizeFor] = useState<{ key: string; bytes: number | null } | null>(null)
  /** Measured sizes of source files whose size the catalog does not publish. */
  const [probedFileSizes, setProbedFileSizes] = useState<Record<string, number | null>>({})
  /** File ids whose size measurement is still in flight. */
  const [probingFileIds, setProbingFileIds] = useState<Set<string>>(new Set())
  /** Exact sizes of the generated export formats (null = measuring/failed). */
  const [exportSizesFor, setExportSizesFor] = useState<
    { key: string; sizes: ExportSizeProbe | null; done: boolean } | null
  >(null)

  const translationKey = translation?.key ?? null
  const storedFile =
    storedFor && translationKey !== null && storedFor.key === translationKey ? storedFor.meta : null
  const packStatus =
    packStatusFor && translationKey !== null && packStatusFor.key === translationKey
      ? packStatusFor.status
      : null

  /** Derived probe results for the open translation (null while unknown). */
  const packSizeBytes =
    packSizeFor && translationKey !== null && packSizeFor.key === translationKey
      ? packSizeFor.bytes
      : null
  const exportSizes =
    exportSizesFor && translationKey !== null && exportSizesFor.key === translationKey
      ? exportSizesFor.sizes
      : null
  const exportSizesDone =
    exportSizesFor !== null &&
    translationKey !== null &&
    exportSizesFor.key === translationKey &&
    exportSizesFor.done

  /** Catalog file ids currently active in the document download engine. */
  const activeFileIds = new Set(
    Object.values(managerJobs)
      .filter(
        (job) =>
          job.kind !== 'offline-pack' &&
          job.translationKey === translation?.key &&
          !['completed', 'failed', 'canceled', 'corrupted'].includes(job.status),
      )
      .map((job) => job.fileId),
  )

  /** Live offline-pack job for this translation, when one is in flight. */
  const activePackJob =
    translationKey === null
      ? null
      : Object.values(managerJobs).find(
          (job) =>
            job.kind === 'offline-pack' &&
            job.translationKey === translationKey &&
            !['completed', 'failed', 'canceled', 'corrupted'].includes(job.status),
        ) ?? null

  // Load the downloaded document copy asynchronously - never blocks the dialog.
  // Only the details page shows the "downloaded version" metadata row.
  useEffect(() => {
    if (!open || !translationKey || mode === 'download') return
    let cancelled = false
    getFileStorage()
      .findLatestForTranslation(translationKey)
      .then((meta) => {
        if (!cancelled) setStoredFor({ key: translationKey, meta })
      })
      .catch(() => {
        if (!cancelled) setStoredFor({ key: translationKey, meta: null })
      })
    return () => {
      cancelled = true
    }
  }, [open, translationKey])

  // Load (and reload) the offline pack status - initially and whenever a
  // download job reaches a terminal state.
  const loadPackStatus = useCallback(async (key: string) => {
    const status = await getOfflinePackStatus(key)
    setPackStatusFor({ key, status })
  }, [])

  // The offline-pack status feeds the offline section of the DOWNLOAD page.
  useEffect(() => {
    if (!open || !translationKey || mode !== 'download') return
    void loadPackStatus(translationKey)
  }, [open, translationKey, mode, loadPackStatus, activeIds.length])

  /**
   * Measure the exact download sizes as soon as the DOWNLOAD page opens, so
   * every download option shows its real size BEFORE anything is downloaded:
   * - the offline pack (the payload the primary action would stream),
   * - source files whose size the catalog does not publish,
   * - every generated export format.
   * All probes are session-cached in the size-probe service; failures are
   * retried on the next open. The details page shows no sizes, so it skips
   * every probe.
   */
  useEffect(() => {
    if (!open || !translationKey || mode !== 'download') return
    let cancelled = false

    // Pack size - the exact payload size of the offline-reading download.
    setPackSizeFor({ key: translationKey, bytes: null })
    void probePackSize(translationKey).then((bytes) => {
      if (!cancelled) setPackSizeFor({ key: translationKey, bytes })
    })

    // Source file sizes - only for formats without a published size.
    const unpublished = (translation?.downloadFiles ?? []).filter((file) => file.size === null)
    if (unpublished.length > 0) {
      setProbingFileIds(new Set(unpublished.map((file) => file.id)))
      setProbedFileSizes((previous) => {
        const next = { ...previous }
        for (const file of unpublished) delete next[file.id]
        return next
      })
      for (const file of unpublished) {
        void probeFileSize(translationKey, file.id).then((bytes) => {
          if (cancelled) return
          setProbedFileSizes((previous) => ({ ...previous, [file.id]: bytes }))
          setProbingFileIds((previous) => {
            if (!previous.has(file.id)) return previous
            const next = new Set(previous)
            next.delete(file.id)
            return next
          })
        })
      }
    } else {
      setProbingFileIds(new Set())
    }

    // Export sizes - one request measures every generated format.
    setExportSizesFor({ key: translationKey, sizes: null, done: false })
    void probeExportSizes(translationKey, locale).then((sizes) => {
      if (!cancelled) setExportSizesFor({ key: translationKey, sizes, done: true })
    })

    return () => {
      cancelled = true
    }
  }, [open, translationKey, locale, translation, mode])

  /**
   * Export the full translation as a generated file (docx / txt / json).
   */
  const handleFileExport = async (format: 'docx' | 'txt' | 'json') => {
    if (!translation || busyFormat) return
    setBusyFormat(format)
    try {
      const response = await platformFetch(
        `/api/quran/export/${translation.key}?format=${format}&localization=${encodeURIComponent(locale)}`,
        { signal: AbortSignal.timeout(EXPORT_FETCH_TIMEOUT_MS) },
      )
      if (!response.ok) {
        const message = await readExportErrorMessage(response)
        toast.error(t('quran.export.failed'), {
          description: message || t('quran.export.failedDescription'),
        })
        return
      }
      const disposition = response.headers.get('Content-Disposition') ?? ''
      const filenameMatch = /filename="([^"]+)"/.exec(disposition)
      const filename =
        filenameMatch?.[1] ?? `quran-${translation.key.replace(/_/g, '-')}.${format}`

      const blob = await response.blob()
      const objectUrl = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = objectUrl
      anchor.download = filename
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 30_000)

      toast.success(t('quran.export.success'), {
        description: t('quran.export.successDescriptionWithSize', {
          name: filename,
          size: formatBytes(locale, blob.size),
        }),
      })
    } catch {
      toast.error(t('quran.export.failed'), { description: t('quran.export.failedDescription') })
    } finally {
      setBusyFormat(null)
    }
  }

  /**
   * Honest PDF path: fetch the print-optimized HTML and print it via a hidden
   * iframe - the browser dialog produces the PDF ("Save as PDF").
   */
  const handlePrintExport = async () => {
    if (!translation || busyFormat) return
    setBusyFormat('pdf')
    try {
      const response = await platformFetch(
        `/api/quran/export/${translation.key}?format=html&localization=${encodeURIComponent(locale)}`,
        { signal: AbortSignal.timeout(EXPORT_FETCH_TIMEOUT_MS) },
      )
      if (!response.ok) {
        const message = await readExportErrorMessage(response)
        toast.error(t('quran.export.failed'), {
          description: message || t('quran.export.failedDescription'),
        })
        return
      }
      const html = await response.text()
      await printHtmlInIframe(html)
      toast.success(t('quran.export.printOpened'))
    } catch {
      toast.error(t('quran.export.failed'), { description: t('quran.export.failedDescription') })
    } finally {
      setBusyFormat(null)
    }
  }

  /** Enqueue a document-file download through the engine. */
  const handleDownload = async (file: TranslationFile) => {
    if (!translation) return
    const result = await enqueueDownload(translation, file)
    if (result.ok) return
    if (result.reason === 'already-downloaded') {
      toast.info(t('downloads.alreadyDownloadedTitle'), {
        description: t('downloads.alreadyDownloadedDescription'),
      })
      return
    }
    if (result.reason === 'duplicate-active') {
      toast.info(t('downloads.duplicateActiveTitle'), {
        description: t('downloads.duplicateActiveDescription'),
      })
      return
    }
    toast.error(t('quran.downloadFailed'), {
      description: t('quran.downloadFailedDescription'),
    })
  }

  /** The one obvious action: store the complete translation for offline use. */
  const handleDownloadPack = async () => {
    if (!translation) return
    const result = await enqueueOfflinePack(translation)
    if (result.ok) {
      toast(t('quran.offline.downloadStarted'), {
        description: t('quran.offline.downloadStartedDescription', { title: translation.title }),
      })
      return
    }
    if (result.reason === 'already-downloaded') {
      toast.info(t('quran.offline.alreadyTitle'), {
        description: t('quran.offline.alreadyDescription'),
      })
      return
    }
    toast.info(t('downloads.duplicateActiveTitle'), {
      description: t('downloads.duplicateActiveDescription'),
    })
  }

  /** Remove the offline copy after the explicit confirmation. */
  const handleRemovePack = async () => {
    if (!translation) return
    setRemovingPack(true)
    try {
      await removeOfflinePack(translation.key)
      await loadPackStatus(translation.key)
      toast(t('quran.offline.removed'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setRemovingPack(false)
    }
  }

  /** Open the reader with this translation and close the dialog. */
  const handleRead = () => {
    if (!translation) return
    openReader({ translationKey: translation.key })
    onOpenChange(false)
  }

  /** Present a value, or an honest muted fallback when the source omits it. */
  const valueOr = (value: string | null, fallbackKey: TranslationKey) =>
    value ? (
      <span dir="auto">{value}</span>
    ) : (
      <span className="italic text-muted-foreground">{t(fallbackKey)}</span>
    )

  const updateAvailable =
    packStatus?.complete === true &&
    packStatus.version !== null &&
    translation?.version !== null &&
    translation != null &&
    packStatus.version !== translation.version

  const packJobDownloading = activePackJob?.status === 'downloading'
  const packPercent =
    packJobDownloading && activePackJob.totalBytes !== null && activePackJob.totalBytes > 0
      ? Math.min(100, Math.max(0, (activePackJob.bytesReceived / activePackJob.totalBytes) * 100))
      : null

  const hasScholarlyEvidence =
    translation !== null && translation.approvalStatus !== 'not_verified'

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {translation ? (
        <DialogContent className="max-h-[85vh] overflow-y-auto scrollbar-subtle sm:max-w-lg">
          <DialogHeader>
            <DialogTitle dir="auto">{translation.title}</DialogTitle>
            <DialogDescription>
              {isDownloadMode ? (
                t('quran.downloadDialog.description')
              ) : (
                <span dir="auto">
                  {translation.languageNativeName
                    ? `${translation.languageNativeName} · ${translation.languageName}`
                    : translation.languageName}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>

          {/* Download page: offline reading - the primary action (Prompt 3 §6/§7) */}
          {isDownloadMode ? (
          <section aria-labelledby="translation-offline-heading" className="space-y-3">
            <h3
              id="translation-offline-heading"
              className="text-sm font-semibold text-foreground"
            >
              {t('quran.offline.sectionTitle')}
            </h3>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('quran.offline.sectionDescription')}
            </p>

            {packStatus !== null ? (
              <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border/60 bg-muted/30 p-3">
                {packStatus.complete ? (
                  <>
                    <Badge
                      variant="outline"
                      className="border-success/40 bg-success/10 text-success"
                    >
                      <CheckCircle2 aria-hidden="true" className="size-3" />
                      {t('quran.offline.statusReady')}
                    </Badge>
                    {packStatus.approxBytes > 0 ? (
                      <span className="text-xs tabular-nums text-muted-foreground">
                        {t('quran.offline.sizeLabel')}: {formatBytes(locale, packStatus.approxBytes)}
                      </span>
                    ) : null}
                    {packStatus.version ? (
                      <span className="text-xs text-muted-foreground">
                        {t('quran.offline.versionLabel')}: <span dir="auto">{packStatus.version}</span>
                      </span>
                    ) : null}
                  </>
                ) : packStatus.cachedSuras > 0 ? (
                  <>
                    <span className="text-xs text-muted-foreground">
                      {t('quran.offline.statusPartial', {
                        cached: formatNumber(locale, packStatus.cachedSuras),
                        total: formatNumber(locale, packStatus.totalSuras),
                      })}
                    </span>
                    <DownloadSizeBadge
                      locale={locale}
                      bytes={packSizeBytes}
                      label={t('downloads.downloadSizeLabel')}
                      measuringLabel={t('downloads.sizeMeasuring')}
                    />
                  </>
                ) : (
                  <>
                    <span className="text-xs text-muted-foreground">
                      {t('quran.offline.statusNone')}
                    </span>
                    <DownloadSizeBadge
                      locale={locale}
                      bytes={packSizeBytes}
                      label={t('downloads.downloadSizeLabel')}
                      measuringLabel={t('downloads.sizeMeasuring')}
                    />
                  </>
                )}
              </div>
            ) : null}

            {packPercent !== null ? (
              <Progress
                value={packPercent}
                aria-label={`${t('quran.card.downloadingAction')} ${translation.title}`}
              />
            ) : null}

            {updateAvailable ? (
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('quran.offline.updateNote')}
              </p>
            ) : null}

            <div className="flex flex-wrap gap-2">
              {packStatus?.complete && !updateAvailable ? (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" className="h-11 text-destructive hover:bg-destructive/10 hover:text-destructive" disabled={removingPack}>
                      <Trash2 aria-hidden="true" className="size-4" />
                      {removingPack ? t('common.loading') : t('quran.offline.remove')}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>{t('quran.offline.removeConfirmTitle')}</AlertDialogTitle>
                      <AlertDialogDescription>
                        {t('quran.offline.removeConfirmDescription')}
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
                      <AlertDialogAction
                        className="h-11"
                        onClick={() => void handleRemovePack()}
                      >
                        {t('common.remove')}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              ) : (
                <Button
                  className="h-11"
                  disabled={activePackJob !== null}
                  onClick={() => void handleDownloadPack()}
                >
                  {updateAvailable ? (
                    <RefreshCw aria-hidden="true" className="size-4" />
                  ) : (
                    <ArrowDownToLine aria-hidden="true" className="size-4" />
                  )}
                  {activePackJob !== null
                    ? activePackJob.status === 'paused'
                      ? t('downloads.paused')
                      : t('quran.card.downloadingAction')
                    : updateAvailable
                      ? t('quran.offline.update')
                      : t('quran.offline.download')}
                </Button>
              )}
            </div>
          </section>
          ) : null}

          {!isDownloadMode ? (
            <>
          <Separator />

          {/* Source & trust (Prompt 3 §4) - details page */}
          <section aria-labelledby="translation-source-heading" className="space-y-3">
            <h3 id="translation-source-heading" className="text-sm font-semibold text-foreground">
              {t('quran.sourceUrl')}
            </h3>
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/30 p-3">
              <p className="min-w-0 text-sm font-medium text-foreground">{t('quran.sourceName')}</p>
              {translation.sourceUrl ? (
                <Button variant="outline" className="h-11" asChild>
                  <a href={translation.sourceUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink aria-hidden="true" className="size-4" />
                    {t('quran.openSourcePage')}
                  </a>
                </Button>
              ) : null}
            </div>
            {/* Scholarly verification - shown only with documented evidence;
                otherwise a neutral note (absence of a certificate is not a
                warning and never labeled "untrusted"). */}
            {hasScholarlyEvidence ? (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border/60 bg-muted/30 p-3">
                <VerificationBadge status={translation.approvalStatus} />
                {translation.reviewingAuthority ? (
                  <p dir="auto" className="text-xs text-muted-foreground">
                    {translation.reviewingAuthority}
                  </p>
                ) : null}
              </div>
            ) : (
              <p className="text-xs leading-relaxed text-muted-foreground">
                {t('quran.trust.noCertificate')}
              </p>
            )}
          </section>

          <Separator />

          {/* Metadata */}
          <dl>
            <InfoRow
              label={t('common.language')}
              value={
                <span dir="auto">
                  {translation.languageNativeName
                    ? `${translation.languageNativeName} (${translation.languageName})`
                    : translation.languageName}
                </span>
              }
            />
            <InfoRow
              label={t('quran.description')}
              value={valueOr(translation.description, 'quran.informationNotProvided')}
            />
            <InfoRow
              label={t('quran.translator')}
              value={valueOr(translation.translator, 'quran.informationNotProvided')}
            />
            <InfoRow
              label={t('quran.publisher')}
              value={valueOr(translation.publisher, 'quran.publisherNotSpecified')}
            />
            <InfoRow
              label={t('quran.edition')}
              value={valueOr(translation.edition, 'quran.informationNotProvided')}
            />
            <InfoRow
              label={t('quran.publicationYear')}
              value={
                translation.publicationYear !== null ? (
                  <span>{formatNumber(locale, translation.publicationYear)}</span>
                ) : (
                  <span className="italic text-muted-foreground">
                    {t('quran.informationNotProvided')}
                  </span>
                )
              }
            />
            <InfoRow
              label={t('common.version')}
              value={valueOr(translation.version, 'common.notAvailable')}
            />
            <InfoRow
              label={t('quran.lastUpdated')}
              value={
                translation.lastUpdated ? (
                  <span>{formatDateTimeString(locale, translation.lastUpdated)}</span>
                ) : (
                  <span className="italic text-muted-foreground">{t('common.notAvailable')}</span>
                )
              }
            />
            <InfoRow
              label={t('quran.lastChecked')}
              value={
                translation.lastChecked ? (
                  <span>{formatDateTimeString(locale, translation.lastChecked)}</span>
                ) : (
                  <span className="italic text-muted-foreground">{t('common.notAvailable')}</span>
                )
              }
            />
            <InfoRow
              label={t('quran.rightsStatus')}
              value={valueOr(translation.rightsStatus, 'quran.rightsNotDocumented')}
            />

            {/* Latest downloaded document copy (offline library) */}
            {storedFile ? (
              <InfoRow
                label={t('quran.downloadedVersion')}
                value={
                  <span className="flex flex-wrap items-center justify-end gap-2">
                    <span dir="auto">{storedFile.version ?? '—'}</span>
                    <span className="text-xs font-normal text-muted-foreground">
                      {formatDateTimeString(locale, storedFile.storedAt)}
                    </span>
                    {storedFile.version !== null &&
                    translation.version !== null &&
                    storedFile.version !== translation.version ? (
                      <Badge variant="outline" className="border-gold/40 bg-gold/15 text-gold-foreground">
                        {t('quran.updateAvailable')}
                      </Badge>
                    ) : null}
                  </span>
                }
              />
            ) : null}
          </dl>
            </>
          ) : null}

          {isDownloadMode ? (
            <>
          <Separator />

          {/* Download page: document files published by the source */}
          <section aria-labelledby="translation-downloads-heading" className="space-y-3">
            <h3
              id="translation-downloads-heading"
              className="text-sm font-semibold text-foreground"
            >
              {t('quran.availableFormats')}
            </h3>
            {translation.downloadFiles.length > 0 ? (
              <ul className="space-y-2">
                {translation.downloadFiles.map((file) => (
                  <DownloadFileRow
                    key={file.id}
                    file={file}
                    probedSize={probedFileSizes[file.id] ?? null}
                    isProbing={probingFileIds.has(file.id)}
                    isQueued={activeFileIds.has(file.id)}
                    onDownload={(target) => void handleDownload(target)}
                  />
                ))}
              </ul>
            ) : (
              <p className="text-sm italic text-muted-foreground">{t('common.notAvailable')}</p>
            )}
            {/* Technical integrity - explicitly not an endorsement (§4 D) */}
            <p className="flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
              <ShieldCheck aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
              {t('quran.trust.technicalNote')}
            </p>
          </section>

          <Separator />

          {/* Export full translation (generated on the fly, exact sizes shown) */}
          <section aria-labelledby="translation-export-heading" className="space-y-3">
            <h3
              id="translation-export-heading"
              className="text-sm font-semibold text-foreground"
            >
              {t('quran.export.title')}
            </h3>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('quran.export.description')}
            </p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <ExportFormatButton
                label={t('quran.export.pdf')}
                icon={Printer}
                sizeLabel={
                  exportSizes !== null
                    ? `≈ ${formatBytes(locale, exportSizes.html)}`
                    : null
                }
                sizePending={!exportSizesDone}
                busy={busyFormat === 'pdf'}
                disabled={busyFormat !== null}
                onClick={() => void handlePrintExport()}
              />
              <ExportFormatButton
                label={t('quran.export.docx')}
                icon={FileType2}
                sizeLabel={
                  exportSizes !== null ? formatBytes(locale, exportSizes.docx) : null
                }
                sizePending={!exportSizesDone}
                busy={busyFormat === 'docx'}
                disabled={busyFormat !== null}
                onClick={() => void handleFileExport('docx')}
              />
              <ExportFormatButton
                label={t('quran.export.txt')}
                icon={FileText}
                sizeLabel={
                  exportSizes !== null ? formatBytes(locale, exportSizes.txt) : null
                }
                sizePending={!exportSizesDone}
                busy={busyFormat === 'txt'}
                disabled={busyFormat !== null}
                onClick={() => void handleFileExport('txt')}
              />
              <ExportFormatButton
                label={t('quran.export.json')}
                icon={Braces}
                sizeLabel={
                  exportSizes !== null ? formatBytes(locale, exportSizes.json) : null
                }
                sizePending={!exportSizesDone}
                busy={busyFormat === 'json'}
                disabled={busyFormat !== null}
                onClick={() => void handleFileExport('json')}
              />
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('quran.export.sizeNote')}
            </p>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('quran.export.printNote')}
            </p>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('quran.export.fullQuranNote')}
            </p>
            {/* Rights notice - mirrors the notice embedded in every generated file */}
            <p className="flex items-start gap-1.5 rounded-lg border border-gold/40 bg-gold/10 p-3 text-xs leading-relaxed text-gold-foreground">
              <ShieldCheck aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
              {t('quran.export.rightsNotice')}
            </p>
          </section>
            </>
          ) : null}

          <DialogFooter>
            <Button variant="outline" className="h-11" onClick={() => onOpenChange(false)}>
              {t('common.close')}
            </Button>
            <Button className="h-11" onClick={handleRead}>
              <BookOpen aria-hidden="true" className="size-4" />
              {t('quran.readNow')}
            </Button>
          </DialogFooter>
        </DialogContent>
      ) : null}
    </Dialog>
  )
}
