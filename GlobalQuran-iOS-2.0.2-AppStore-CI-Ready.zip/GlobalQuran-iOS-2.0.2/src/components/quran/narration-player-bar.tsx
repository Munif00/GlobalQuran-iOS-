'use client'

/**
 * Translation narration player bar (app-wide, stacked above the recitation
 * player bar on mobile).
 *
 * Renders only while a narration session exists (an ayah's translation
 * narration was started). Narration is a COMPLETELY separate concern from
 * Arabic recitation, and the bar makes that separation visible:
 *
 * - an amber accent and a "Translation narration" title,
 * - an always-visible MODE badge: "Recorded narration" (human-recorded
 *   QuranEnc audio) or "Device voice (TTS)" (synthesized - never presented
 *   as a human recording, and never a reciter's voice) plus, inside the
 *   native app, a "Device speech engine" badge (the real Android TTS
 *   bridge, not the WebView's unusable Web Speech surface),
 * - an offline badge when a downloaded local file plays,
 * - honest errors, including the mandated explanations when no recording
 *   AND no device voice exists for the translation's language - with a
 *   direct entry into the system text-to-speech settings when the failure
 *   is engine/voice/data related on native.
 *
 * Controls (PROMPT 10 #4): play/pause/resume, stop, previous ayah, next
 * ayah, single/sequential narration, repeat current ayah (with count),
 * playback speed, and voice selection when multiple voices exist. On the
 * native speech backend pause does not exist (Android's TextToSpeech has
 * no pause) - the pause affordance becomes an honest Stop there.
 */

import { useCallback, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  AudioLines,
  ChevronsRight,
  Crosshair,
  Download,
  Pause,
  Play,
  Repeat,
  Settings,
  SkipBack,
  SkipForward,
  Square,
  X,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { narrationEngine, type NarrationVoice } from '@/services/audio/narration-engine'
import { ttsOpenTtsSettings } from '@/services/native/tts-bridge'
import { isRealNativePlatform } from '@/services/platform/native-mode'
import { getTranslationAudioCatalog } from '@/services/api/audio-api'
import { getSuraMeta } from '@/data/sura-index'
import { formatClock, getSuraAyahCount } from '@/lib/audio/urls'
import { formatNumber } from '@/utils/format'
import { useReaderStore } from '@/stores/reader-store'
import { TranslationAudioDownloadDialog } from '@/components/quran/translation-audio-download-dialog'
import {
  FINITE_NARRATION_REPEAT_OPTIONS,
  useNarrationStore,
  type NarrationSpeed,
} from '@/stores/narration-store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'

const SPEED_STEPS: NarrationSpeed[] = [0.75, 1, 1.25, 1.5]

/**
 * The translation narration player bar. Self-contained: the download
 * entry appears only while the narrated translation has a VERIFIED
 * recorded narration (catalog match), and the dialog it opens is owned
 * here so narration stays usable on every screen.
 */
export function NarrationPlayerBar() {
  const { t, locale } = useTranslation()
  const mode = useNarrationStore((s) => s.mode)
  const narratingSura = useNarrationStore((s) => s.narratingSura)
  const narratingAyah = useNarrationStore((s) => s.narratingAyah)
  const narrationTranslationKey = useNarrationStore((s) => s.narrationTranslationKey)
  const languageIso = useNarrationStore((s) => s.languageIso)
  const languageName = useNarrationStore((s) => s.languageName)
  const isPlaying = useNarrationStore((s) => s.isPlaying)
  const isBuffering = useNarrationStore((s) => s.isBuffering)
  const isSpeaking = useNarrationStore((s) => s.isSpeaking)
  const error = useNarrationStore((s) => s.error)
  const currentTime = useNarrationStore((s) => s.currentTime)
  const duration = useNarrationStore((s) => s.duration)
  const sourceMode = useNarrationStore((s) => s.sourceMode)
  const activeVoiceName = useNarrationStore((s) => s.activeVoiceName)
  const ttsBackend = useNarrationStore((s) => s.ttsBackend)
  const speed = useNarrationStore((s) => s.speed)
  const advanceMode = useNarrationStore((s) => s.advanceMode)
  const repeatEnabled = useNarrationStore((s) => s.repeatEnabled)
  const repeatCount = useNarrationStore((s) => s.repeatCount)
  const session = useNarrationStore((s) => s.session)
  const narrationFollowAyah = useNarrationStore((s) => s.followAyah)
  const toggleFollowAyah = useNarrationStore((s) => s.toggleFollowAyah)
  const setSpeed = useNarrationStore((s) => s.setSpeed)
  const setAdvanceMode = useNarrationStore((s) => s.setAdvanceMode)
  const setRepeatEnabled = useNarrationStore((s) => s.setRepeatEnabled)
  const setRepeatCount = useNarrationStore((s) => s.setRepeatCount)

  const [voicePopoverOpen, setVoicePopoverOpen] = useState(false)
  const [downloadOpen, setDownloadOpen] = useState(false)

  /** The sura the reader currently shows (download seed context). */
  const readerSura = useReaderStore((s) => s.sura)

  /** Verified narration catalog - the download entry appears only when the
   *  NARRATED translation actually has recorded narration at the source. */
  const catalogQuery = useQuery({
    queryKey: ['translation-audio-catalog'],
    queryFn: getTranslationAudioCatalog,
    staleTime: 24 * 60 * 60_000,
    retry: 1,
  })
  const narratedCatalogEntry = useMemo(
    () =>
      narrationTranslationKey !== null
        ? (catalogQuery.data?.translations ?? []).find(
            (entry) => entry.translationKey === narrationTranslationKey,
          ) ?? null
        : null,
    [catalogQuery.data, narrationTranslationKey],
  )

  const suraMeta = narratingSura !== null ? getSuraMeta(narratingSura) : undefined

  const handleSeek = useCallback((values: number[]) => {
    if (values.length > 0) narrationEngine.seek(values[0])
  }, [])

  const cycleSpeed = useCallback(() => {
    const index = SPEED_STEPS.indexOf(speed)
    const next = SPEED_STEPS[(index + 1) % SPEED_STEPS.length]
    setSpeed(next)
    narrationEngine.applySpeed(next)
  }, [speed, setSpeed])

  const repeatCountLabel = repeatCount === 'infinite' ? '∞' : `×${repeatCount}`

  const errorText = useMemo(() => {
    if (error === null) return null
    const languageLabel = languageName || languageIso || ''
    switch (error) {
      case 'file-missing':
        return t('narration.errorFileMissing')
      case 'network':
        return t('narration.errorNetwork')
      case 'voice-missing':
        return t('narration.errorVoiceMissing', { language: languageLabel })
      case 'no-audio':
        return t('narration.errorNoAudio')
      case 'unsupported':
        return t('narration.errorUnsupported')
      // Native TTS bridge failures - the REAL reasons, with the translation
      // language's display name (the same value the web path uses).
      case 'tts-engine-missing':
        return t('narration.tts.engineUnavailable')
      case 'tts-voice-missing':
        return t('narration.tts.voiceUnavailable', { language: languageLabel })
      case 'tts-voice-data':
        return t('narration.tts.voiceInstallRequired', { language: languageLabel })
      case 'tts-synthesis-failed':
        return t('narration.tts.synthesisFailed')
      default:
        return t('narration.errorUnknown')
    }
  }, [error, t, languageName, languageIso])

  /** Engine/voice/data failures on the native backend can be fixed in the
   *  system text-to-speech settings - offer the direct entry there. */
  const showTtsSettingsAction =
    error !== null &&
    ttsBackend === 'native' &&
    (error === 'tts-engine-missing' ||
      error === 'tts-voice-missing' ||
      error === 'tts-voice-data')

  /** Native TTS has no pause: while it speaks, the round control is an
   *  honest Stop (the web pause/resume stays untouched). */
  const nativeTtsSpeaking =
    mode === 'tts' && ttsBackend === 'native' && (isPlaying || isSpeaking)

  if (narratingSura === null || narratingAyah === null) return null

  const positionLabel = t('narration.suraAyah', {
    sura: formatNumber(locale, narratingSura),
    ayah: formatNumber(locale, narratingAyah),
  })

  return (
    <div
      role="region"
      aria-label={t('narration.playerLabel')}
      className="border-t border-amber-500/30 bg-amber-50/95 shadow-lg backdrop-blur dark:border-amber-400/25 dark:bg-amber-950/80"
    >
      <div className="mx-auto max-w-6xl px-3 py-2 sm:px-6">
        {/* Row 1: identity + mode + primary controls */}
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 truncate text-sm font-medium text-foreground">
              <AudioLines aria-hidden="true" className="size-4 shrink-0 text-amber-700 dark:text-amber-300" />
              <span className="truncate">{positionLabel}</span>
              {suraMeta ? (
                <span dir="rtl" lang="ar" className="text-quranic ms-1 hidden text-muted-foreground sm:inline">
                  {suraMeta.nameArabic}
                </span>
              ) : null}
              {sourceMode === 'local' ? (
                <Badge
                  variant="outline"
                  title={t('narration.offlinePlaying')}
                  className="border-emerald-600/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
                >
                  {t('narration.offlineBadge')}
                </Badge>
              ) : null}
            </p>
            <p className="flex items-center gap-1.5 truncate text-xs text-muted-foreground">
              {mode === 'recording' ? (
                <span
                  title={t('narration.modeRecordingHint')}
                  className="font-medium text-amber-800 dark:text-amber-200"
                >
                  {t('narration.title')} · {t('narration.modeRecording')}
                </span>
              ) : mode === 'tts' ? (
                <span
                  title={t('narration.modeTtsHint')}
                  className="flex items-center gap-1.5 font-medium text-amber-800 dark:text-amber-200"
                >
                  <span className="truncate">
                    {t('narration.title')} · {t('narration.modeTts')}
                    {activeVoiceName ? ` — ${activeVoiceName}` : ''}
                  </span>
                  {ttsBackend === 'native' ? (
                    <Badge
                      variant="outline"
                      title={t('narration.tts.nativeBadge')}
                      className="border-amber-600/40 bg-amber-500/10 text-amber-800 dark:border-amber-400/30 dark:text-amber-200"
                    >
                      {t('narration.tts.nativeBadge')}
                    </Badge>
                  ) : null}
                </span>
              ) : (
                <span>{t('narration.title')}</span>
              )}
            </p>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-11"
              onClick={() => void narrationEngine.prevAyah()}
              aria-label={t('narration.prevAyah')}
              disabled={narratingSura <= 1 && narratingAyah <= 1}
            >
              <SkipBack aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>

            <Button
              type="button"
              size="icon"
              className="size-11 rounded-full bg-amber-600 text-white hover:bg-amber-700 dark:bg-amber-500 dark:text-amber-950 dark:hover:bg-amber-400"
              onClick={() => {
                // Native TTS has no pause: the round control Stops while
                // speech is running (replay restarts the ayah honestly).
                if (nativeTtsSpeaking) {
                  narrationEngine.stop()
                } else {
                  narrationEngine.togglePlayPause()
                }
              }}
              aria-label={
                nativeTtsSpeaking
                  ? t('narration.stop')
                  : isPlaying || isSpeaking
                    ? t('narration.pause')
                    : t('narration.play')
              }
            >
              {isBuffering && error === null && mode !== 'tts' ? (
                <span
                  aria-hidden="true"
                  className="size-4 animate-spin rounded-full border-2 border-current border-t-transparent"
                />
              ) : nativeTtsSpeaking ? (
                <Square aria-hidden="true" className="size-5" />
              ) : isPlaying || isSpeaking ? (
                <Pause aria-hidden="true" className="size-5" />
              ) : (
                <Play aria-hidden="true" className="size-5 rtl:-scale-x-100" />
              )}
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-11"
              onClick={() => void narrationEngine.nextAyah()}
              aria-label={t('narration.nextAyah')}
              disabled={narratingSura >= 114 && narratingAyah >= (getSuraMeta(narratingSura)?.ayahCount ?? 1)}
            >
              <SkipForward aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-11"
              onClick={() => narrationEngine.stop()}
              aria-label={t('narration.stop')}
            >
              <X aria-hidden="true" className="size-4" />
            </Button>
          </div>
        </div>

        {/* Row 2: progress (recordings) / speaking indicator (TTS) */}
        {mode === 'recording' ? (
          <div className="mt-1.5 flex items-center gap-2">
            <span className="w-10 shrink-0 text-end text-[0.6875rem] tabular-nums text-muted-foreground">
              {formatClock(currentTime)}
            </span>
            <Slider
              className="flex-1"
              value={[
                Number.isFinite(duration) && duration > 0 ? Math.min(currentTime, duration) : 0,
              ]}
              max={Number.isFinite(duration) && duration > 0 ? duration : 1}
              step={0.5}
              onValueChange={handleSeek}
              disabled={!(Number.isFinite(duration) && duration > 0)}
              aria-label={t('narration.seek')}
            />
            <span className="w-10 shrink-0 text-[0.6875rem] tabular-nums text-muted-foreground">
              {Number.isFinite(duration) && duration > 0 ? formatClock(duration) : '–:––'}
            </span>
          </div>
        ) : mode === 'tts' && (isPlaying || isSpeaking) ? (
          <p className="mt-1.5 flex flex-wrap items-center gap-1.5 truncate text-[0.6875rem] font-medium text-amber-800 dark:text-amber-200">
            <span>{t('narration.speaking')}</span>
            {ttsBackend === 'native' ? (
              <span className="font-normal text-muted-foreground">
                · {t('narration.tts.pauseUnsupported')}
              </span>
            ) : null}
          </p>
        ) : null}

        {/* Row 3: honest error (+ the native TTS settings entry), or the
            narration configuration */}
        {errorText !== null ? (
          <div className="mt-1.5 flex flex-wrap items-start gap-2">
            <p className="flex min-w-0 flex-1 items-start gap-1.5 text-xs font-medium text-destructive">
              <Square aria-hidden="true" className="mt-0.5 size-3 shrink-0" />
              <span>{errorText}</span>
            </p>
            {showTtsSettingsAction ? (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 shrink-0 gap-1.5 px-2.5 text-xs"
                onClick={() => {
                  void ttsOpenTtsSettings()
                }}
              >
                <Settings aria-hidden="true" className="size-3.5" />
                <span className="whitespace-nowrap">{t('narration.tts.openSettings')}</span>
              </Button>
            ) : null}
          </div>
        ) : (
          <div className="mt-1.5 flex items-center gap-1.5 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden [mask-image:linear-gradient(to_right,transparent_0,black_12px,black_calc(100%-12px),transparent_100%)]">
            {/* Advance mode: single ayah or sequential */}
            <div
              role="group"
              aria-label={t('narration.advanceLabel')}
              className="flex h-11 shrink-0 items-center rounded-md border bg-background/70 p-0.5"
            >
              <button
                type="button"
                aria-pressed={advanceMode === 'single'}
                onClick={() => setAdvanceMode('single')}
                className={cn(
                  'flex h-10 items-center gap-1 rounded-[0.25rem] px-2.5 text-xs transition-colors outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                  advanceMode === 'single'
                    ? 'bg-amber-600 text-white dark:bg-amber-500 dark:text-amber-950'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <Square aria-hidden="true" className="size-3" />
                {t('narration.advanceSingle')}
              </button>
              <button
                type="button"
                aria-pressed={advanceMode === 'sequential'}
                onClick={() => setAdvanceMode('sequential')}
                className={cn(
                  'flex h-10 items-center gap-1 rounded-[0.25rem] px-2.5 text-xs transition-colors outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                  advanceMode === 'sequential'
                    ? 'bg-amber-600 text-white dark:bg-amber-500 dark:text-amber-950'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <ChevronsRight aria-hidden="true" className="size-3 rtl:-scale-x-100" />
                {t('narration.advanceSequential')}
              </button>
            </div>

            {/* Repeat current ayah */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              aria-pressed={repeatEnabled}
              className={cn(
                'h-11 shrink-0 gap-1.5 bg-background/70 px-2.5 text-xs',
                repeatEnabled && 'border-amber-600/50 text-amber-800 dark:text-amber-200',
              )}
              onClick={() => setRepeatEnabled(!repeatEnabled)}
            >
              <Repeat aria-hidden="true" className="size-3.5" />
              <span className="whitespace-nowrap">
                {t('narration.repeatLabel')} · {t('narration.repeatCurrent')}
              </span>
            </Button>

            {repeatEnabled ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-11 min-w-14 shrink-0 bg-background/70 px-2.5 text-xs tabular-nums"
                    aria-label={`${t('narration.repeatLabel')} ${repeatCountLabel}`}
                  >
                    {repeatCountLabel}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="min-w-32">
                  <DropdownMenuRadioGroup
                    value={String(repeatCount)}
                    onValueChange={(value) =>
                      setRepeatCount(
                        value === 'infinite' ? 'infinite' : (Number(value) as typeof repeatCount),
                      )
                    }
                  >
                    {FINITE_NARRATION_REPEAT_OPTIONS.map((count) => (
                      <DropdownMenuRadioItem key={count} value={String(count)}>
                        ×{formatNumber(locale, count)}
                      </DropdownMenuRadioItem>
                    ))}
                    <DropdownMenuRadioItem value="infinite">
                      {t('narration.countEndless')}
                    </DropdownMenuRadioItem>
                  </DropdownMenuRadioGroup>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : null}

            {/* Live session status */}
            {session && session.ayahPlayCount !== 1 ? (
              <span className="shrink-0 text-[0.6875rem] tabular-nums text-muted-foreground">
                {t('audio.statusRep', {
                  current: formatNumber(locale, session.ayahPlay),
                  total:
                    session.ayahPlayCount === 'infinite'
                      ? '∞'
                      : formatNumber(locale, session.ayahPlayCount),
                })}
              </span>
            ) : null}

            {/* Follow translation: keep the narrated ayah's highlight in view */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              aria-pressed={narrationFollowAyah}
              className={cn(
                'h-11 shrink-0 gap-1.5 px-2.5 text-xs',
                narrationFollowAyah && 'border-primary/40 text-primary',
              )}
              onClick={toggleFollowAyah}
            >
              <Crosshair aria-hidden="true" className="size-3.5" />
              <span className="whitespace-nowrap">{t('narration.followTranslation')}</span>
            </Button>

            <div className="shrink-0 flex-1" />

            {/* Download the recorded narration (when it exists) */}
            {narratedCatalogEntry !== null ? (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-11 shrink-0 gap-1.5 bg-background/70 px-2.5 text-xs"
                onClick={() => setDownloadOpen(true)}
              >
                <Download aria-hidden="true" className="size-3.5" />
                <span className="whitespace-nowrap">{t('narration.downloadEntry')}</span>
              </Button>
            ) : null}

            {/* Playback speed */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-11 min-w-14 shrink-0 bg-background/70 px-2.5 text-xs tabular-nums"
              onClick={cycleSpeed}
              aria-label={`${t('narration.speed')}: ${formatNumber(locale, speed)}×`}
            >
              {formatNumber(locale, speed)}×
            </Button>

            {/* Voice selection (opens the reader's voice picker) */}
            <NarrationVoiceButton open={voicePopoverOpen} onOpenChange={setVoicePopoverOpen} />
          </div>
        )}
      </div>

      {/* The download dialog of the narrated translation's recordings. */}
      {narratedCatalogEntry !== null ? (
        <TranslationAudioDownloadDialog
          open={downloadOpen}
          onOpenChange={setDownloadOpen}
          translationKey={narratedCatalogEntry.translationKey}
          audioName={narratedCatalogEntry.audioName}
          sura={narratingSura ?? readerSura}
          seedAyah={narratingAyah ?? 1}
        />
      ) : null}
    </div>
  )
}

/**
 * The voice picker entry. Voice detection is ASYNC (the platform loads the
 * voice list lazily) - the popover reports exactly what was detected on
 * THIS device, never an assumption.
 */
function NarrationVoiceButton({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const { t } = useTranslation()
  const [voices, setVoices] = useState<NarrationVoice[] | null>(null)
  const [engineAvailable, setEngineAvailable] = useState<boolean | null>(null)
  const [languageName, setLanguageName] = useState('')
  const voiceChoice = useNarrationStore((s) => s.voiceChoice)
  const setVoiceChoice = useNarrationStore((s) => s.setVoiceChoice)
  const languageIso = useNarrationStore((s) => s.languageIso)

  const handleOpen = useCallback(
    (next: boolean) => {
      onOpenChange(next)
      if (next) {
        setVoices(null)
        setEngineAvailable(null)
        // Detection is ASYNC on both backends (the web voice list loads
        // lazily; the native bridge probes the real engine) - the popover
        // reports exactly what was detected on THIS device, never an
        // assumption.
        void narrationEngine
          .listDetectedVoices(languageIso ?? 'en')
          .then((result) => {
            setEngineAvailable(result.engine)
            setVoices(result.voices)
          })
      }
    },
    [languageIso, onOpenChange],
  )

  const chosen = languageIso ? voiceChoice[languageIso] : undefined

  return (
    <Popover open={open} onOpenChange={handleOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-11 shrink-0 gap-1.5 bg-background/70 px-2.5 text-xs"
          aria-label={t('narration.voicePicker')}
        >
          <AudioLines aria-hidden="true" className="size-3.5" />
          <span className="whitespace-nowrap">{t('narration.voicePicker')}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80">
        <div className="space-y-3">
          <p className="text-sm font-semibold text-foreground">
            {t('narration.voicePickerTitle', { language: languageName || languageIso || '' })}
          </p>

          {engineAvailable === false ? (
            <p className="text-xs leading-relaxed text-muted-foreground">
              {/* Native: the device's TTS engine itself is missing; web: the
                  browser exposes no speech synthesis engine. */}
              {isRealNativePlatform()
                ? t('narration.tts.engineUnavailable')
                : t('narration.voiceEngineMissing')}
            </p>
          ) : voices === null ? (
            <p className="text-xs text-muted-foreground">{t('audio.download.planLoading')}</p>
          ) : voices.length === 0 ? (
            <p className="text-xs leading-relaxed text-muted-foreground">
              {t('narration.voiceNone')}
            </p>
          ) : (
            <>
              <p className="text-xs text-muted-foreground">
                {t('narration.voiceDetected', { count: voices.length })}
              </p>
              <ul className="max-h-48 space-y-1 overflow-y-auto scrollbar-subtle">
                {voices.map((voice) => (
                  <li key={voice.id}>
                    <button
                      type="button"
                      onClick={() => {
                        if (languageIso) setVoiceChoice(languageIso, voice.id)
                      }}
                      className={cn(
                        'flex min-h-11 w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-start text-sm outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50',
                        chosen === voice.id && 'bg-accent/60',
                      )}
                    >
                      <span className="min-w-0 flex-1">
                        <span dir="auto" className="block truncate font-medium">
                          {voice.name}
                        </span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {voice.lang}
                          {voice.localService ? ` · ${t('narration.voiceDefault')}` : ''}
                        </span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
              {chosen ? (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-11 w-full"
                  onClick={() => {
                    if (languageIso) setVoiceChoice(languageIso, null)
                  }}
                >
                  {t('narration.voiceDefault')}
                </Button>
              ) : null}
            </>
          )}
          <p className="border-t pt-2 text-[0.6875rem] leading-relaxed text-muted-foreground">
            {t('narration.ttsOfflineNote')}
          </p>
        </div>
      </PopoverContent>
    </Popover>
  )
}
