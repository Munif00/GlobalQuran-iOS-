'use client'

/**
 * Imported personal files - listed in the library's "Imported files"
 * category.
 *
 * Import policy (Prompt 3 §8): imported files are clearly distinguished from
 * provider translations - each row states that this is a personal file from
 * the user's device whose origin the app cannot identify. No provider,
 * certificate or endorsement is ever claimed for an import. Files open in
 * the built-in viewers (never executed); management (rename/delete) lives in
 * Downloads.
 */

import { BookOpen, FileAudio, FileJson, FileText, Archive, Database, HardDriveUpload, type LucideIcon } from 'lucide-react'

import { useTranslation } from '@/i18n'
import type { StoredFileMetadata } from '@/services/storage/local-file-storage'
import type { DownloadFormat } from '@/types'
import { isViewableFormat } from '@/utils/file-validation'
import { formatBytes, formatDateTimeString } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

/** Icons per stored format (imports may be validated zip archives too). */
const FORMAT_ICONS: Record<DownloadFormat | 'zip', LucideIcon> = {
  pdf: FileText,
  epub: BookOpen,
  sql: Database,
  json: FileJson,
  txt: FileText,
  mp3: FileAudio,
  zip: Archive,
}

export function ImportedFileList({
  files,
  onOpen,
}: {
  files: StoredFileMetadata[]
  onOpen: (fileId: string) => void
}) {
  const { t, locale } = useTranslation()

  return (
    <ul className="space-y-3">
      {files.map((file) => {
        const FormatIcon = FORMAT_ICONS[file.format] ?? FileText
        const viewable = isViewableFormat(file.format)
        return (
          <li key={file.id}>
            <Card>
              <CardContent className="flex flex-wrap items-center gap-3 p-4">
                <span
                  aria-hidden="true"
                  className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground"
                >
                  <FormatIcon className="size-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p dir="auto" className="truncate text-sm font-medium text-foreground">
                    {file.fileName}
                  </p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
                    <span className="uppercase">{file.format}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{formatBytes(locale, file.fileSize)}</span>
                    <span aria-hidden="true">·</span>
                    <span>{formatDateTimeString(locale, file.storedAt)}</span>
                  </p>
                  <p className="mt-1 flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
                    <HardDriveUpload aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
                    {t('quran.imported.personalNote')}
                  </p>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <Badge variant="outline" className="border-border bg-muted text-muted-foreground">
                    {t('downloads.originImported')}
                  </Badge>
                  {viewable ? (
                    <Button variant="outline" className="h-11" onClick={() => onOpen(file.id)}>
                      {t('common.open')}
                    </Button>
                  ) : null}
                </div>
              </CardContent>
            </Card>
          </li>
        )
      })}
    </ul>
  )
}
