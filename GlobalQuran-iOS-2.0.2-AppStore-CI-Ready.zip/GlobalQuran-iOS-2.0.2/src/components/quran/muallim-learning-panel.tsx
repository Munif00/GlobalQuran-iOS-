'use client'

/**
 * Muallim learning mode panel - the dedicated Al-Husary Muallim experience.
 *
 * Opens from the reader toolbar (and stays available on every sura). The
 * learning surface offers:
 *
 * - Playing an ayah (from the current reading line, or wherever playback
 *   already is), with the SAME single/sequential and repeat model as the
 *   player bar - both surfaces bind to one store, so they can never disagree.
 * - Repeating the current ayah (xN or endless), moving to the next ayah, and
 *   repeating a selected range or the whole surah, with visible repetition
 *   and pass progress.
 * - Reading synchronization: the currently playing ayah is highlighted in the
 *   reader and kept in view; this panel shows the same live position.
 *
 * Honesty guarantees (unchanged): the ORIGINAL Al-Husary Muallim recording is
 * played exactly as published - its teaching pauses and natural silences are
 * never trimmed, shortened or altered, and the recitation is never generated.
 * The panel states this explicitly so learners know the rhythm is authentic.
 *
 * Switching to the Muallim recitation (when another style is selected) never
 * touches the reader store - the reading position stays exactly where it is.
 */

import { useMemo, useState } from 'react'
import {
  ChevronsRight,
  GraduationCap,
  Pause,
  Play,
  ShieldCheck,
  SkipForward,
  Square,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { playbackEngine } from '@/services/audio/playback-engine'
import { getStyleDefinition, RECITATION_STYLES } from '@/data/audio-styles'
import { getSuraMeta } from '@/data/sura-index'
import { formatNumber } from '@/utils/format'
import {
  FINITE_REPEAT_OPTIONS,
  useAudioStore,
  type RepeatCount,
  type RepeatMode,
} from '@/stores/audio-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { cn } from '@/lib/utils'

export const MUALLIM_STYLE_ID = 'husary-muallim'

export interface MuallimLearningPanelProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Sura currently open in the reader. */
  sura: number
  /** Authentic ayah count of that sura (end-boundary validation). */
  suraAyahCount: number
  /** Ayah currently at the reading line (where "play from here" starts). */
  readingLineAyah: number
}

export function MuallimLearningPanel({
  open,
  onOpenChange,
  sura,
  suraAyahCount,
  readingLineAyah,
}: MuallimLearningPanelProps) {
  const { t, locale } = useTranslation()
  const selectedStyleId = useAudioStore((s) => s.selectedStyleId)
  const selectStyle = useAudioStore((s) => s.selectStyle)
  const playingSura = useAudioStore((s) => s.playingSura)
  const playingAyah = useAudioStore((s) => s.playingAyah)
  const isPlaying = useAudioStore((s) => s.isPlaying)
  const isBuffering = useAudioStore((s) => s.isBuffering)
  const error = useAudioStore((s) => s.error)
  const session = useAudioStore((s) => s.session)
  const playbackMode = useAudioStore((s) => s.playbackMode)
  const repeatMode = useAudioStore((s) => s.repeatMode)
  const repeatCount = useAudioStore((s) => s.repeatCount)
  const sequenceEndAyah = useAudioStore((s) => s.sequenceEndAyah)
  const setPlaybackMode = useAudioStore((s) => s.setPlaybackMode)
  const setRepeatMode = useAudioStore((s) => s.setRepeatMode)
  const setRepeatCount = useAudioStore((s) => s.setRepeatCount)
  const setSequenceEndAyah = useAudioStore((s) => s.setSequenceEndAyah)

  const [endDraft, setEndDraft] = useState('')

  const muallimStyle = useMemo(
    () => RECITATION_STYLES.find((style) => style.id === MUALLIM_STYLE_ID),
    [],
  )
  const isMuallimSelected = selectedStyleId === MUALLIM_STYLE_ID
  const suraMeta = getSuraMeta(sura)
  const endMaxAyah = Math.max(1, suraAyahCount)
  const endControlRelevant =
    playbackMode === 'sequential' || repeatMode === 'range' || repeatMode === 'sura'

  const playingHere = playingSura === sura
  const statusText = useMemo(() => {
    if (session) {
      const parts: string[] = [
        session.mode === 'sequential' ? t('audio.statusSequential') : t('audio.statusSingle'),
      ]
      if (session.ayahPlayCount !== 1) {
        parts.push(
          t('audio.statusRep', {
            current: formatNumber(locale, session.ayahPlay),
            total:
              session.ayahPlayCount === 'infinite'
                ? '∞'
                : formatNumber(locale, session.ayahPlayCount),
          }),
        )
      }
      if (session.mode === 'sequential' && session.passCount !== 1) {
        parts.push(
          t('audio.statusPass', {
            current: formatNumber(locale, session.pass),
            total:
              session.passCount === 'infinite' ? '∞' : formatNumber(locale, session.passCount),
          }),
        )
      }
      return parts.join(' · ')
    }
    return null
  }, [session, t, locale])

  const applyEndDraft = () => {
    const parsed = Number(endDraft)
    if (endDraft.trim() !== '' && Number.isInteger(parsed) && parsed >= 1 && parsed <= endMaxAyah) {
      setSequenceEndAyah(parsed)
    }
  }

  const playFromReadingLine = () => {
    const target = Math.min(Math.max(1, readingLineAyah), endMaxAyah)
    void playbackEngine.playAyah(sura, target)
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="bottom"
        className="mx-auto max-h-[85dvh] max-w-2xl overflow-y-auto scrollbar-subtle rounded-t-2xl px-4 pb-6 pt-3 sm:px-6"
      >
        <SheetHeader className="text-start">
          <SheetTitle className="flex items-center gap-2">
            <GraduationCap aria-hidden="true" className="size-5 text-primary" />
            {t('audio.learning.title')}
          </SheetTitle>
          <SheetDescription>
            {t('audio.learning.subtitle')}
          </SheetDescription>
        </SheetHeader>

        {isMuallimSelected ? (
          <div className="mt-4 space-y-5">
            {/* Live learning status */}
            <div className="rounded-lg border bg-muted/40 p-4">
              <p className="text-sm font-medium text-foreground">
                {playingSura !== null && playingAyah !== null ? (
                  <>
                    {t('audio.suraAyah', {
                      sura: formatNumber(locale, playingSura),
                      ayah: formatNumber(locale, playingAyah),
                    })}
                    {getSuraMeta(playingSura) ? (
                      <span dir="rtl" lang="ar" className="text-quranic ms-2 text-muted-foreground">
                        {getSuraMeta(playingSura)?.nameArabic}
                      </span>
                    ) : null}
                    {playingHere ? null : (
                      <span className="ms-2 text-xs font-normal text-muted-foreground">
                        {t('audio.learning.otherSura')}
                      </span>
                    )}
                  </>
                ) : (
                  t('audio.learning.notPlaying')
                )}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {statusText ?? t('audio.learning.readLine', { ayah: formatNumber(locale, readingLineAyah) })}
              </p>
              {error !== null ? (
                <p className="mt-2 text-xs font-medium text-destructive">
                  {error === 'file-missing'
                    ? t('audio.errorFileMissing')
                    : error === 'network'
                      ? t('audio.errorNetwork')
                      : error === 'style-unavailable'
                        ? t('audio.errorStyleUnavailable')
                        : t('audio.errorUnknown')}
                </p>
              ) : null}
            </div>

            {/* Learning actions */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Button
                type="button"
                className="h-11"
                onClick={playFromReadingLine}
                disabled={isBuffering && error === null}
              >
                <Play aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                {t('audio.learning.playFromLine', { ayah: formatNumber(locale, readingLineAyah) })}
              </Button>
              <Button
                type="button"
                variant="outline"
                className="h-11"
                onClick={() => playbackEngine.togglePlayPause()}
                disabled={playingSura === null || playingAyah === null}
              >
                {isPlaying ? (
                  <>
                    <Pause aria-hidden="true" className="size-4" />
                    {t('audio.pause')}
                  </>
                ) : (
                  <>
                    <Play aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                    {t('audio.play')}
                  </>
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                className="h-11"
                onClick={() => void playbackEngine.nextAyah()}
                disabled={playingSura === null || playingAyah === null}
              >
                <SkipForward aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                {t('audio.nextAyah')}
              </Button>
              <Button
                type="button"
                variant="outline"
                className="h-11"
                onClick={() => playbackEngine.stop()}
                disabled={playingSura === null}
              >
                <Square aria-hidden="true" className="size-4" />
                {t('audio.learning.stopAndClose')}
              </Button>
            </div>

            <Separator />

            {/* Playback configuration (same store as the player bar) */}
            <div className="space-y-4">
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">{t('audio.modeLabel')}</p>
                <div className="flex h-11 items-center rounded-md border bg-background p-0.5">
                  <button
                    type="button"
                    aria-pressed={playbackMode === 'single'}
                    onClick={() => setPlaybackMode('single')}
                    className={cn(
                      'flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[0.25rem] px-3 text-sm transition-colors outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                      playbackMode === 'single'
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    <Square aria-hidden="true" className="size-3.5" />
                    {t('audio.modeSingle')}
                  </button>
                  <button
                    type="button"
                    aria-pressed={playbackMode === 'sequential'}
                    onClick={() => setPlaybackMode('sequential')}
                    className={cn(
                      'flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[0.25rem] px-3 text-sm transition-colors outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                      playbackMode === 'sequential'
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    <ChevronsRight aria-hidden="true" className="size-3.5 rtl:-scale-x-100" />
                    {t('audio.modeSequential')}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground">{t('audio.modeHint')}</p>
              </div>

              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">{t('audio.repeatLabel')}</p>
                <ToggleGroup
                  type="single"
                  variant="outline"
                  className="flex h-11 w-full"
                  value={repeatMode}
                  onValueChange={(value) => {
                    if (value) setRepeatMode(value as RepeatMode)
                  }}
                >
                  <ToggleGroupItem value="off" className="flex-1 gap-1.5 text-xs">
                    {t('audio.repeatOff')}
                  </ToggleGroupItem>
                  <ToggleGroupItem value="ayah" className="flex-1 gap-1.5 text-xs">
                    {t('audio.repeatAyahMode')}
                  </ToggleGroupItem>
                  <ToggleGroupItem value="range" className="flex-1 gap-1.5 text-xs">
                    {t('audio.repeatRangeMode')}
                  </ToggleGroupItem>
                  <ToggleGroupItem value="sura" className="flex-1 gap-1.5 text-xs">
                    {t('audio.repeatSuraMode')}
                  </ToggleGroupItem>
                </ToggleGroup>
              </div>

              {repeatMode !== 'off' ? (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">
                    {t('audio.repeatCountLabel')}
                  </p>
                  <ToggleGroup
                    type="single"
                    variant="outline"
                    className="flex h-11 w-full"
                    value={String(repeatCount)}
                    onValueChange={(value) => {
                      if (value)
                        setRepeatCount(value === 'infinite' ? 'infinite' : (Number(value) as RepeatCount))
                    }}
                  >
                    {FINITE_REPEAT_OPTIONS.map((count) => (
                      <ToggleGroupItem key={count} value={String(count)} className="flex-1 gap-1.5 text-xs">
                        ×{formatNumber(locale, count)}
                      </ToggleGroupItem>
                    ))}
                    <ToggleGroupItem value="infinite" className="flex-1 gap-1.5 text-xs">
                      {t('audio.countEndless')}
                    </ToggleGroupItem>
                  </ToggleGroup>
                </div>
              ) : null}

              {endControlRelevant ? (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">{t('audio.endTitle')}</p>
                  <p className="text-xs text-muted-foreground">
                    {t('audio.endAyahHint', { max: formatNumber(locale, endMaxAyah) })}
                  </p>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={1}
                      max={endMaxAyah}
                      step={1}
                      inputMode="numeric"
                      value={endDraft}
                      onChange={(event) => setEndDraft(event.target.value)}
                      placeholder={
                        sequenceEndAyah === null ? `1–${endMaxAyah}` : String(sequenceEndAyah)
                      }
                      aria-label={t('audio.endAyahInput')}
                      className="h-11 w-24"
                    />
                    <Button type="button" variant="outline" className="h-11" onClick={applyEndDraft}>
                      {t('audio.endApply')}
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      className="h-11"
                      onClick={() => setSequenceEndAyah(null)}
                    >
                      {t('audio.endUseSuraEnd')}
                    </Button>
                  </div>
                  {endDraft.trim() !== '' &&
                  !(Number.isInteger(Number(endDraft)) && Number(endDraft) >= 1 && Number(endDraft) <= endMaxAyah) ? (
                    <p className="text-xs font-medium text-destructive">
                      {t('audio.endAyahInvalid', { max: formatNumber(locale, endMaxAyah) })}
                    </p>
                  ) : null}
                </div>
              ) : null}
            </div>

            <Separator />

            {/* Authentic teaching rhythm - stated, never altered */}
            <div className="flex gap-3 rounded-lg border border-primary/25 bg-primary/5 p-4">
              <ShieldCheck aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-primary" />
              <div className="min-w-0 space-y-1">
                <p className="text-sm font-medium text-foreground">
                  {t('audio.learning.rhythmTitle')}
                </p>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {t('audio.learning.rhythmBody')}
                </p>
                {muallimStyle ? (
                  <p className="text-xs text-muted-foreground">
                    {t('audio.sourceLine', { source: muallimStyle.sourceName })} ·{' '}
                    {muallimStyle.bitrate} {muallimStyle.format.toUpperCase()}
                  </p>
                ) : null}
              </div>
            </div>
          </div>
        ) : (
          /* Another style (or none) is selected: offer the one-tap switch. */
          <div className="mt-4 space-y-4">
            <div className="flex gap-3 rounded-lg border bg-muted/40 p-4">
              <GraduationCap aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-primary" />
              <div className="min-w-0 space-y-1">
                <p className="text-sm font-medium text-foreground">
                  {t('audio.learning.needsMuallimTitle')}
                </p>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {t('audio.learning.needsMuallimBody')}
                </p>
                {muallimStyle ? (
                  <p className="text-xs text-muted-foreground">
                    {muallimStyle.reciterName} · {muallimStyle.styleLabel}
                  </p>
                ) : null}
              </div>
            </div>
            <div className="space-y-2">
              <Button
                type="button"
                className="h-11 w-full"
                onClick={() => selectStyle(MUALLIM_STYLE_ID)}
              >
                <GraduationCap aria-hidden="true" className="size-4" />
                {t('audio.learning.useMuallim')}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                {t('audio.positionKept')}
              </p>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  )
}

/** Style definition of the Muallim learning recitation (display helper). */
export function getMuallimStyleDefinition() {
  return getStyleDefinition(MUALLIM_STYLE_ID)
}
