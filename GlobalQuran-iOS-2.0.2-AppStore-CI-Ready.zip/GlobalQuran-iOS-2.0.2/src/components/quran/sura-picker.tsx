'use client'

/**
 * Sura picker dialog for the Quran reader.
 *
 * - Searchable list of all 114 suras from the structural index (instant and
 *   offline-capable - no API dependency for the list itself).
 * - Matching is case/diacritic-insensitive (normalizeForSearch) across the
 *   Arabic name, the English name and the localized name actually shown to
 *   the user; an exact sura-number query jumps straight to that sura.
 * - The current sura is marked with aria-current; selecting a row reports the
 *   sura number via onSelect and closes the dialog.
 */

import { useMemo, useState } from 'react'
import { Search } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { SURA_INDEX, type SuraMeta } from '@/data/sura-index'
import { formatNumber } from '@/utils/format'
import { normalizeForSearch } from '@/utils/text-normalize'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'

export interface SuraPickerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentSura: number
  onSelect: (sura: number) => void
  /** Localized sura names (from the QuranEnc sowar-names endpoint), when loaded. */
  localizedNames?: Record<string, string>
}

export function SuraPicker({
  open,
  onOpenChange,
  currentSura,
  onSelect,
  localizedNames,
}: SuraPickerProps) {
  const { t, locale } = useTranslation()
  const [query, setQuery] = useState('')

  const trimmedQuery = query.trim()
  const normalizedQuery = useMemo(() => normalizeForSearch(trimmedQuery), [trimmedQuery])

  /** Name shown in the interface language: Arabic for the Arabic UI, localized
   *  source name when available, English transliteration otherwise. */
  const primaryName = (sura: SuraMeta): string => {
    if (locale === 'ar') return sura.nameArabic
    return localizedNames?.[String(sura.number)] ?? sura.nameEnglish
  }

  const visibleSuras = useMemo(() => {
    if (!trimmedQuery) return SURA_INDEX
    return SURA_INDEX.filter((sura) => {
      // Exact sura-number match ("2" -> Al-Baqarah).
      if (trimmedQuery === String(sura.number)) return true
      if (!normalizedQuery) return false
      return (
        normalizeForSearch(sura.nameEnglish).includes(normalizedQuery) ||
        normalizeForSearch(sura.nameArabic).includes(normalizedQuery) ||
        normalizeForSearch(localizedNames?.[String(sura.number)]).includes(normalizedQuery)
      )
    })
  }, [trimmedQuery, normalizedQuery, localizedNames])

  /** Close (and reset the search) through any path - dialog chrome or a row. */
  const handleOpenChange = (nextOpen: boolean) => {
    if (!nextOpen) setQuery('')
    onOpenChange(nextOpen)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t('reader.selectSura')}</DialogTitle>
          <DialogDescription>{t('reader.selectSuraDescription')}</DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search
            aria-hidden="true"
            className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          />
          <Input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t('reader.searchSura')}
            aria-label={t('reader.searchSura')}
            className="h-11 ps-9"
          />
        </div>

        <ScrollArea className="max-h-96 -me-1.5 scrollbar-subtle">
          <div className="space-y-0.5 pe-1.5">
            {visibleSuras.map((sura) => {
              const isCurrent = currentSura === sura.number
              return (
                <button
                  key={sura.number}
                  type="button"
                  aria-current={isCurrent ? 'true' : undefined}
                  onClick={() => {
                    onSelect(sura.number)
                    handleOpenChange(false)
                  }}
                  className={cn(
                    'flex h-14 w-full items-center gap-3 rounded-lg px-3 text-start outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50',
                    isCurrent && 'bg-accent/60',
                  )}
                >
                  <span className="w-8 shrink-0 text-end text-sm tabular-nums text-muted-foreground">
                    {formatNumber(locale, sura.number)}
                  </span>
                  <span
                    dir="auto"
                    className="min-w-0 flex-1 truncate text-sm font-medium text-foreground"
                  >
                    {primaryName(sura)}
                  </span>
                  {locale === 'ar' ? null : (
                    <span
                      dir="rtl"
                      lang="ar"
                      className="shrink-0 font-arabic text-lg text-foreground"
                    >
                      {sura.nameArabic}
                    </span>
                  )}
                  <span className="w-20 shrink-0 truncate text-end text-xs text-muted-foreground">
                    {t('reader.ayahCount', { count: formatNumber(locale, sura.ayahCount) })}
                  </span>
                </button>
              )
            })}
            {visibleSuras.length === 0 ? (
              <p className="px-3 py-8 text-center text-sm text-muted-foreground">
                {t('common.none')}
              </p>
            ) : null}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
