'use client'

/**
 * One ayah block of the reading surface.
 *
 * - The Arabic text renders VERBATIM as a React text node (never transformed,
 *   joined or split); the numbered marker is a restrained bordered medallion.
 * - The translation also renders verbatim. When the source has no translation
 *   text for this ayah, an honest "not available" notice is shown - never a
 *   fabricated placeholder.
 * - Per-ayah actions (bookmark, note, copy, share) are hidden while the
 *   distraction-free focus mode is active.
 */

import { memo } from 'react'
import { AudioLines, Bookmark, BookmarkCheck, Copy, NotebookPen, Pause, Play, Share2 } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { formatNumber } from '@/utils/format'
import { cn } from '@/lib/utils'
import type { QuranAya } from '@/types'

export interface AyahBlockProps {
  aya: QuranAya
  /** Text direction of the active translation ('ltr' | 'rtl'). */
  direction: 'ltr' | 'rtl'
  /** Effective translation visibility (already accounts for focus mode). */
  showTranslation: boolean
  arabicFontSize: string
  translationFontSize: string
  isBookmarked: boolean
  /** The user's personal note for this bookmark, when any. */
  bookmarkNote: string | null
  /** This is the ayah a resume/"Continue reading"/bookmark navigation just
   *  revealed - briefly highlighted so the user recognizes it (PROMPT 12). */
  isResumeTarget: boolean
  focusMode: boolean
  /** Verified audio playback is active for this sura (style selected + verified inventory). */
  audioAvailable: boolean
  /** This exact ayah is the one currently playing. */
  isPlayingAyah: boolean
  /** Translation narration is offered at all (recorded audio verified for
   *  the selected translation, or a device voice was detected - otherwise
   *  the narrate control is not shown for this translation). */
  narrationAvailable: boolean
  /** This exact ayah is the one currently being narrated. */
  isNarratingAyah: boolean
  onToggleBookmark: (aya: QuranAya) => void
  onEditNote: (aya: QuranAya) => void
  onCopy: (aya: QuranAya) => void
  onShare: (aya: QuranAya) => void
  /** Start (or pause) the verified recitation of this ayah. */
  onPlayAyah: (aya: QuranAya) => void
  /** Start (or pause) the translation narration of this ayah. */
  onNarrateAyah: (aya: QuranAya) => void
}

/**
 * Memoized: a 286-ayah sura mounts 286 of these, and the reader re-renders
 * for unrelated reasons (display popover, translation search) - the memo
 * plus stable handler identities from the reader keep those re-renders from
 * reconciling every block. The Quranic/translation text inside is always
 * rendered verbatim.
 */
export const AyahBlock = memo(function AyahBlock({
  aya,
  direction,
  showTranslation,
  arabicFontSize,
  translationFontSize,
  isBookmarked,
  bookmarkNote,
  isResumeTarget,
  focusMode,
  audioAvailable,
  isPlayingAyah,
  narrationAvailable,
  isNarratingAyah,
  onToggleBookmark,
  onEditNote,
  onCopy,
  onShare,
  onPlayAyah,
  onNarrateAyah,
}: AyahBlockProps) {
  const { t } = useTranslation()

  const hasFootnotes = typeof aya.footnotes === 'string' && aya.footnotes.trim().length > 0
  const hasTranslation = typeof aya.translation === 'string' && aya.translation.trim().length > 0

  return (
    <article
      id={`ayah-${aya.sura}-${aya.aya}`}
      className={cn(
        'scroll-mt-48',
        isPlayingAyah && 'playing-ayah',
        isNarratingAyah && 'narrating-ayah',
        isResumeTarget && 'ayah-resume-highlight',
      )}
    >
      <p dir="rtl" lang="ar" className="text-quranic" style={{ fontSize: arabicFontSize }}>
        {aya.arabicText}{' '}
        {/* Marker digits follow the Mushaf convention (Arabic-Indic numerals);
            the extension is explicit so constrained ICU builds that would
            otherwise resolve 'ar' to latin digits still render ١٢٣. */}
        <span className="ayah-marker" aria-label={`${t('reader.ayah')} ${aya.aya}`}>
          {formatNumber('ar-u-nu-arab', aya.aya)}
        </span>
      </p>

      {showTranslation ? (
        hasTranslation ? (
          <p dir={direction} className="mt-3 leading-relaxed" style={{ fontSize: translationFontSize }}>
            {aya.translation}
          </p>
        ) : (
          <p
            dir={direction}
            className="reader-muted mt-3 rounded-md border border-dashed border-current/45 px-3 py-2 text-sm italic"
            style={{ fontSize: translationFontSize }}
          >
            {t('reader.translationUnavailable')}
          </p>
        )
      ) : null}

      {hasFootnotes ? (
        <p className="reader-muted mt-2 text-xs leading-relaxed">
          <span className="font-medium">{t('reader.footnotes')}:</span> {aya.footnotes}
        </p>
      ) : null}

      {isBookmarked && bookmarkNote ? (
        <p className="reader-muted mt-3 border-s-2 border-current/40 ps-3 text-sm leading-relaxed">
          <span className="font-medium">{t('reader.noteTitle')}:</span> {bookmarkNote}
        </p>
      ) : null}

      {/* PROMPT 14: full opacity + 8px gaps on touch screens (no hover state
          exists there); the subdued look is kept only on pointer devices. */}
      {focusMode ? null : (
        <div className="reader-muted mt-2 flex items-center gap-2 opacity-100 transition-opacity sm:opacity-70 sm:hover:opacity-100 sm:focus-within:opacity-100">
          {/* Verified recitation: offered only while the sura's audio
              inventory is verified; a missing file never shows a play
              control (handled by the reader before mounting this button). */}
          {audioAvailable ? (
            <button
              type="button"
              onClick={() => onPlayAyah(aya)}
              aria-label={isPlayingAyah ? t('audio.pauseAyah') : t('audio.playAyah')}
              aria-pressed={isPlayingAyah}
              className={cn(
                'flex size-11 items-center justify-center rounded-md outline-none transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50',
                isPlayingAyah && 'text-primary',
              )}
            >
              {isPlayingAyah ? (
                <Pause aria-hidden="true" className="size-4" />
              ) : (
                <Play aria-hidden="true" className="size-4 rtl:-scale-x-100" />
              )}
            </button>
          ) : null}
          {/* Translation narration (PROMPT 10): a SEPARATE control with a
              distinct icon - the amber accent keeps narration visually
              distinct from the primary recitation button. Offered only when
              narration is actually possible for the selected translation. */}
          {narrationAvailable ? (
            <button
              type="button"
              onClick={() => onNarrateAyah(aya)}
              aria-label={isNarratingAyah ? t('narration.pauseAyah') : t('narration.playAyah')}
              aria-pressed={isNarratingAyah}
              className={cn(
                'flex size-11 items-center justify-center rounded-md outline-none transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50',
                isNarratingAyah && 'text-amber-700 dark:text-amber-300',
              )}
            >
              {isNarratingAyah ? (
                <Pause aria-hidden="true" className="size-4" />
              ) : (
                <AudioLines aria-hidden="true" className="size-4" />
              )}
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => onToggleBookmark(aya)}
            aria-label={isBookmarked ? t('reader.bookmarked') : t('reader.bookmarkAyah')}
            aria-pressed={isBookmarked}
            className="flex size-11 items-center justify-center rounded-md outline-none transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
          >
            {isBookmarked ? (
              <BookmarkCheck aria-hidden="true" className="size-4 text-gold" fill="currentColor" />
            ) : (
              <Bookmark aria-hidden="true" className="size-4" />
            )}
          </button>
          {isBookmarked ? (
            <button
              type="button"
              onClick={() => onEditNote(aya)}
              aria-label={bookmarkNote ? t('reader.editNote') : t('reader.addNote')}
              className="flex size-11 items-center justify-center rounded-md outline-none transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
            >
              <NotebookPen aria-hidden="true" className="size-4" />
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => onCopy(aya)}
            aria-label={t('reader.copyAyah')}
            className="flex size-11 items-center justify-center rounded-md outline-none transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
          >
            <Copy aria-hidden="true" className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => onShare(aya)}
            aria-label={t('reader.shareAyah')}
            className="flex size-11 items-center justify-center rounded-md outline-none transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
          >
            <Share2 aria-hidden="true" className="size-4" />
          </button>
        </div>
      )}
    </article>
  )
})
