'use client'

/**
 * Quran reader view - the reading experience inside the Quran screen.
 *
 * Reading model: Surah-based with per-ayah blocks (the Arabic text of one
 * sura renders as a continuous flow of numbered ayat, exactly as supplied by
 * the source - never joined, split or rewritten).
 *
 * - Persistent Surah navigation: a compact toolbar (sticky below the app
 *   header) with Previous Surah / Surah selector / Next Surah controls that
 *   are ALWAYS reachable - the user never has to scroll to the end of a
 *   surah to move on. Optional horizontal swipe navigation (reliable
 *   thresholds, RTL-aware, never the only method).
 * - Jump to a specific ayah through a validated dialog (checked against the
 *   authentic structural index, never accepting invalid numbers).
 * - Reading controls: text sizes with reset, translation visibility,
 *   distraction-free focus reading, reading themes, bookmarks with optional
 *   personal notes - all persisted between sessions.
 * - Reading progress: the topmost visible ayah is tracked with an
 *   IntersectionObserver and persisted (debounced) as the reading position,
 *   so "Continue reading" reopens the exact saved ayah. The saved position is
 *   never overwritten with a default: only the actually tracked ayah is
 *   saved (plus an honest fallback only when IntersectionObserver is
 *   unavailable).
 * - Sura content loads from the live API through React Query; every
 *   successful load is written to the IndexedDB offline cache. On
 *   connectivity failures the last cached copy is rendered with an honest
 *   "cached for offline" chip.
 * - Arabic text and translations render VERBATIM as React text nodes - they
 *   are never transformed, joined or split. A missing translation renders an
 *   honest unavailable notice, never fabricated text.
 */

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode, type TouchEvent as ReactTouchEvent } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  ArrowDownToLine,
  ArrowLeft,
  BookX,
  Bookmark,
  Check,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  GraduationCap,
  Hash,
  Languages,
  NotebookPen,
  Radio,
  RotateCcw,
  Search,
  Settings2,
  Trash2,
  X,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getSuraContent, getSuraNames, getTranslationsCatalog } from '@/services/api/catalog-api'
import { getSuraAudio, getTranslationAudioCatalog } from '@/services/api/audio-api'
import { playbackEngine } from '@/services/audio/playback-engine'
import { narrationEngine } from '@/services/audio/narration-engine'
import { getStyleDefinition } from '@/data/audio-styles'
import { useAudioStore } from '@/stores/audio-store'
import { useNarrationStore } from '@/stores/narration-store'
import { ApiError } from '@/services/api/client'
import { getCachedSura, putCachedSura } from '@/services/storage/quran-cache'
import {
  DEFAULT_TRANSLATION_KEY,
  useReaderStore,
  type ReaderBookmark,
  type ReadingTheme,
  type TextScale,
} from '@/stores/reader-store'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useOnlineStatus } from '@/hooks/use-online-status'
import { SURA_COUNT, getSuraMeta } from '@/data/sura-index'
import type { QuranAya, Translation } from '@/types'
import { normalizeForSearch } from '@/utils/text-normalize'
import { formatDateTimeString, formatNumber } from '@/utils/format'

import { EmptyState } from '@/components/design-system/empty-state'
import { StatusBanner } from '@/components/design-system/status-banner'
import { AyahBlock } from '@/components/quran/ayah-block'
import { SuraOpening } from '@/components/quran/sura-opening'
import { BookmarkNoteDialog } from '@/components/quran/bookmark-note-dialog'
import { JumpToAyahDialog } from '@/components/quran/jump-to-ayah-dialog'
import { MuallimLearningPanel } from '@/components/quran/muallim-learning-panel'
import { ReciterSelectorDialog, useReciterCatalog } from '@/components/quran/reciter-selector-dialog'
import { AudioDownloadDialog } from '@/components/quran/audio-download-dialog'
import { TranslationAudioDownloadDialog } from '@/components/quran/translation-audio-download-dialog'
import { SuraPicker } from '@/components/quran/sura-picker'
import { Badge } from '@/components/ui/badge'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------------ */
/* Reader constants                                                    */
/* ------------------------------------------------------------------ */

/** Arabic text sizes for the five display steps (inline, so .text-quranic line-height applies). */
const ARABIC_SIZES: Record<TextScale, string> = {
  1: '1.5rem',
  2: '1.75rem',
  3: '2rem',
  4: '2.35rem',
  5: '2.75rem',
}

/** Translation text sizes for the five display steps. */
const TRANS_SIZES: Record<TextScale, string> = {
  1: '0.875rem',
  2: '0.9375rem',
  3: '1rem',
  4: '1.125rem',
  5: '1.25rem',
}

/** Growing "A" labels for the text-scale step buttons. */
const STEP_LABEL_SIZES: Record<TextScale, string> = {
  1: '0.7rem',
  2: '0.8rem',
  3: '0.9rem',
  4: '1.02rem',
  5: '1.15rem',
}

const TEXT_STEPS: readonly TextScale[] = [1, 2, 3, 4, 5]

/** Default scale both text groups reset to. */
const DEFAULT_SCALE: TextScale = 3

/** Reading-surface styling per theme (tokens from globals.css). */
const READER_SURFACES: Record<ReadingTheme, string> = {
  'match-app': 'border border-border bg-card',
  sepia: 'reader-surface-sepia border border-border/50',
  night: 'reader-surface-night border border-border/50',
}

const READING_THEMES: ReadonlyArray<{
  value: ReadingTheme
  labelKey: 'reader.themeMatchApp' | 'reader.themeSepia' | 'reader.themeNight'
}> = [
  { value: 'match-app', labelKey: 'reader.themeMatchApp' },
  { value: 'sepia', labelKey: 'reader.themeSepia' },
  { value: 'night', labelKey: 'reader.themeNight' },
]

/* Swipe navigation thresholds: a deliberate horizontal flick, not a scroll
 * or a tap. The gesture must dominate vertically by 1.4x. */
const SWIPE_MIN_DISTANCE = 64
const SWIPE_MAX_VERTICAL = 48
const SWIPE_MAX_DURATION = 800

/** PROMPT 14 (WCAG 2.3.3): an explicit `behavior: 'smooth'` would override the
 *  global `scroll-behavior: auto !important` reduced-motion guard, so every
 *  programmatic scroll resolves the behavior first. */
function scrollBehavior(): ScrollBehavior {
  if (
    typeof window !== 'undefined' &&
    typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  ) {
    return 'auto'
  }
  return 'smooth'
}

/* ------------------------------------------------------------------ */
/* Default translation resolution                                      */
/* ------------------------------------------------------------------ */

/** True when a catalog language code matches a locale (exact or base language). */
function languageMatches(languageCode: string, locale: string): boolean {
  const code = languageCode.toLowerCase()
  const target = locale.toLowerCase()
  if (code === target) return true
  const base = target.split('-')[0]
  return base.length > 0 && code === base
}

/** The freshest item of a list (lastUpdated desc), or null when empty. */
function latestItem(items: Translation[]): Translation | null {
  if (items.length === 0) return null
  const sorted = [...items].sort((a, b) =>
    (b.lastUpdated ?? '').localeCompare(a.lastUpdated ?? ''),
  )
  return sorted[0] ?? null
}

/**
 * Resolve the default translation key:
 * 1. the user's preferred Quran translation language (preferences store),
 * 2. the interface language,
 * 3. the well-known default key - or the freshest catalog item when even
 *    that is absent, so the reader never ends up without a translation.
 */
function resolveDefaultTranslationKey(
  items: Translation[],
  preferredLanguage: string | null,
  interfaceLocale: string,
): string | null {
  if (preferredLanguage) {
    const preferred = latestItem(
      items.filter((item) => languageMatches(item.languageCode, preferredLanguage)),
    )
    if (preferred) return preferred.key
  }
  const inInterfaceLanguage = latestItem(
    items.filter((item) => languageMatches(item.languageCode, interfaceLocale)),
  )
  if (inInterfaceLanguage) return inInterfaceLanguage.key
  if (items.some((item) => item.key === DEFAULT_TRANSLATION_KEY)) return DEFAULT_TRANSLATION_KEY
  return latestItem(items)?.key ?? null
}

/* ------------------------------------------------------------------ */
/* Reader view types & subcomponents                                   */
/* ------------------------------------------------------------------ */

/** Normalized shape the reading surface renders (live response or cached copy). */
interface ReaderContent {
  translationKey: string
  translationTitle: string | null
  direction: 'ltr' | 'rtl'
  sura: number
  ayahCount: number
  version: string | null
  ayat: QuranAya[]
  fromCache: boolean
}

/** Sura header + ayah skeletons while the content resolves. */
function ReaderLoadingSkeleton({
  readingTheme,
  showTranslation,
  label,
}: {
  readingTheme: ReadingTheme
  showTranslation: boolean
  label: string
}) {
  return (
    <div role="status" className="space-y-6">
      <span className="sr-only">{label}</span>
      <div className="space-y-3 text-center">
        <Skeleton className="mx-auto h-4 w-24" />
        <Skeleton className="mx-auto h-8 w-56" />
        <Skeleton className="mx-auto h-4 max-w-full w-72" />
      </div>
      <div className={cn('space-y-8 rounded-xl p-4 sm:p-6', READER_SURFACES[readingTheme])}>
        {[0, 1, 2, 3].map((index) => (
          <div key={index} className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-11/12" />
            {showTranslation ? <Skeleton className="h-4 w-2/3" /> : null}
          </div>
        ))}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Reader view                                                         */
/* ------------------------------------------------------------------ */

export function ReaderView() {
  const { t, locale } = useTranslation()
  const { isOnline } = useOnlineStatus()

  /* Reader store */
  const readerOpen = useReaderStore((s) => s.readerOpen)
  const selectedTranslationKey = useReaderStore((s) => s.selectedTranslationKey)
  const sura = useReaderStore((s) => s.sura)
  const showTranslation = useReaderStore((s) => s.showTranslation)
  const arabicScale = useReaderStore((s) => s.arabicScale)
  const translationScale = useReaderStore((s) => s.translationScale)
  const readingTheme = useReaderStore((s) => s.readingTheme)
  const focusMode = useReaderStore((s) => s.focusMode)
  const bookmarks = useReaderStore((s) => s.bookmarks)
  const recentTranslationKeys = useReaderStore((s) => s.recentTranslations)
  const closeReader = useReaderStore((s) => s.closeReader)
  const setSelectedTranslationKey = useReaderStore((s) => s.setSelectedTranslationKey)
  const setSura = useReaderStore((s) => s.setSura)
  const nextSura = useReaderStore((s) => s.nextSura)
  const prevSura = useReaderStore((s) => s.prevSura)
  const toggleTranslation = useReaderStore((s) => s.toggleTranslation)
  const setArabicScale = useReaderStore((s) => s.setArabicScale)
  const setTranslationScale = useReaderStore((s) => s.setTranslationScale)
  const setReadingTheme = useReaderStore((s) => s.setReadingTheme)
  const setFocusMode = useReaderStore((s) => s.setFocusMode)
  const addBookmark = useReaderStore((s) => s.addBookmark)
  const removeBookmark = useReaderStore((s) => s.removeBookmark)
  const restoreBookmark = useReaderStore((s) => s.restoreBookmark)
  const updateBookmarkNote = useReaderStore((s) => s.updateBookmarkNote)
  const bookmarksPanelRequested = useReaderStore((s) => s.bookmarksPanelRequested)
  const clearBookmarksPanelRequest = useReaderStore((s) => s.clearBookmarksPanelRequest)
  const pendingAyahTarget = useReaderStore((s) => s.pendingAyahTarget)
  const consumePendingAyahTarget = useReaderStore((s) => s.consumePendingAyahTarget)

  /* Audio store: the selected recitation style + live playback state.
   * Reading state (sura, translation, scales, theme) is intentionally NOT
   * part of this - switching reciters never moves the reading position. */
  const selectedStyleId = useAudioStore((s) => s.selectedStyleId)
  const playingSura = useAudioStore((s) => s.playingSura)
  const playingAyah = useAudioStore((s) => s.playingAyah)
  const audioError = useAudioStore((s) => s.error)
  const followAyah = useAudioStore((s) => s.followAyah)

  /* Preferences */
  const lastReadingPosition = usePreferencesStore((s) => s.lastReadingPosition)
  const setLastReadingPosition = usePreferencesStore((s) => s.setLastReadingPosition)
  const preferredQuranTranslationLanguage = usePreferencesStore(
    (s) => s.preferredQuranTranslationLanguage,
  )

  /* Local UI state */
  const [suraPickerOpen, setSuraPickerOpen] = useState(false)
  const [translationDialogOpen, setTranslationDialogOpen] = useState(false)
  const [translationSearch, setTranslationSearch] = useState('')
  const [displayOpen, setDisplayOpen] = useState(false)
  const [bookmarksOpen, setBookmarksOpen] = useState(false)
  const [jumpDialogOpen, setJumpDialogOpen] = useState(false)
  /** Reading-line ayah captured when the jump dialog was opened (the dialog
   *  seeds its input from it). */
  const [jumpSeedAyah, setJumpSeedAyah] = useState<number | null>(null)
  /** Ayah briefly highlighted after a resume / bookmark / jump navigation,
   *  so the user recognizes exactly where they stopped (PROMPT 12 §3). */
  const [highlightedAyah, setHighlightedAyah] = useState<{ sura: number; aya: number } | null>(null)
  const [noteDialogOpen, setNoteDialogOpen] = useState(false)
  /** Bookmark whose note dialog is open (kept mounted for the exit animation). */
  const [noteTarget, setNoteTarget] = useState<ReaderBookmark | null>(null)
  /** Bookmark pending its removal confirmation (list trash button, PROMPT 14). */
  const [bookmarkRemovalTarget, setBookmarkRemovalTarget] = useState<ReaderBookmark | null>(null)
  const [fontState, setFontState] = useState<'loading' | 'active' | 'fallback'>('loading')
  const [reciterDialogOpen, setReciterDialogOpen] = useState(false)
  const [audioDownloadOpen, setAudioDownloadOpen] = useState(false)
  /** Muallim learning mode panel (dedicated Al-Husary experience). */
  const [learningPanelOpen, setLearningPanelOpen] = useState(false)
  /** Last reading line captured by the observer ({sura, aya}). Stale by
   *  design while another sura is open - see readingLineAyah below. */
  const [readingLine, setReadingLine] = useState<{ sura: number; aya: number } | null>(null)
  /** Reading line of the CURRENT sura: the last captured line when it belongs
   *  to this sura, otherwise ayah 1 (fresh content, not yet observed). */
  const readingLineAyah = readingLine !== null && readingLine.sura === sura ? readingLine.aya : 1

  /** Reading-position scroll already performed for this sura load. */
  const scrolledLoadRef = useRef<string | null>(null)
  /** Navigation (bookmark or ayah jump) waiting for its sura content to render. */
  const pendingScrollRef = useRef<{ sura: number; aya: number } | null>(null)
  /** Sura of the last rendered content - detects next/prev sura transitions
   *  so the view always starts from the first ayah of the new sura. */
  const lastLoadedSuraRef = useRef<number | null>(null)
  /** Reading surface element (the ayat list) for position tracking. */
  const readingSurfaceRef = useRef<HTMLDivElement | null>(null)
  /** Ayah currently at the reading line (updated by the observer). */
  const trackedAyahRef = useRef<number>(1)
  /** Debounce timer for reading-position persistence. */
  const positionSaveTimerRef = useRef<number | null>(null)
  /** Last reading line captured by the observer but not yet written to the
   *  store (the debounced value) - flushed when the user leaves the reader. */
  const pendingPositionRef = useRef<{ surah: number; ayah: number } | null>(null)
  /** Until this timestamp, an explicit resume/target scroll is still settling;
   *  position flushes are held back so the saved position is not clobbered
   *  with an intermediate line the user merely passed through. */
  const resumeGuardUntilRef = useRef(0)
  /** Timer that clears the brief resume highlight. */
  const highlightTimerRef = useRef<number | null>(null)
  /** Start point of an in-progress touch gesture (swipe navigation). */
  const swipeStartRef = useRef<{ x: number; y: number; at: number } | null>(null)

  /* ---------------------------------------------------------------- */
  /* Data                                                              */
  /* ---------------------------------------------------------------- */

  const catalogQuery = useQuery({
    queryKey: ['translations-catalog', locale],
    queryFn: () => getTranslationsCatalog(locale),
    staleTime: 300_000,
    retry: 1,
    // Fetch even while offline so failures surface as honest errors
    // (instead of paused queries that look like eternal loading).
    networkMode: 'always',
  })

  const suraNamesQuery = useQuery({
    queryKey: ['sura-names', locale],
    queryFn: () => getSuraNames(locale),
    staleTime: 24 * 3600_000,
    retry: 1,
    networkMode: 'always',
  })

  /* Verified per-ayah audio inventory of the current sura. Fetched only
   * after the user picked a recitation style, so nothing is claimed or
   * loaded before it is needed. The response is the SERVER-VERIFIED file
   * list - the reader renders play controls exactly from it. */
  const suraAudioQuery = useQuery({
    queryKey: ['sura-audio', selectedStyleId, sura],
    queryFn: () => getSuraAudio(selectedStyleId as string, sura),
    staleTime: 10 * 60_000,
    retry: 1,
    enabled: readerOpen && selectedStyleId !== null,
  })

  /** Style summaries (shared with the selector dialog through one query). */
  const reciterCatalogQuery = useReciterCatalog()

  const suraQuery = useQuery({
    queryKey: ['sura-content', selectedTranslationKey, sura],
    queryFn: () => {
      if (selectedTranslationKey === null) {
        throw new ApiError('No translation selected', 0)
      }
      return getSuraContent(selectedTranslationKey, sura)
    },
    staleTime: Infinity,
    retry: 0,
    enabled: readerOpen && selectedTranslationKey !== null,
    // Attempt the request even while offline: the failure (ApiError 0) then
    // drives the offline-cache fallback instead of a paused, endless loading.
    networkMode: 'always',
  })

  const localizedSuraNames = suraNamesQuery.data?.names ?? null

  const translationMeta = useMemo(
    () => catalogQuery.data?.items.find((item) => item.key === selectedTranslationKey) ?? null,
    [catalogQuery.data, selectedTranslationKey],
  )

  const catalogItems = catalogQuery.data?.items ?? []

  const filteredTranslations = useMemo(() => {
    const query = normalizeForSearch(translationSearch)
    if (!query) return catalogItems
    return catalogItems.filter(
      (item) =>
        normalizeForSearch(item.title).includes(query) ||
        normalizeForSearch(item.languageName).includes(query) ||
        normalizeForSearch(item.languageNativeName).includes(query),
    )
  }, [catalogItems, translationSearch])

  /** PROMPT 14 (Nielsen #6/#7): recently used translations surfaced as quick
   *  chips (newest first, max 3, current selection excluded) - the store has
   *  persisted them all along, they were just never shown. */
  const recentTranslationItems = useMemo(() => {
    const items: Translation[] = []
    for (const key of recentTranslationKeys) {
      if (key === selectedTranslationKey) continue
      const item = catalogItems.find((candidate) => candidate.key === key)
      if (item) items.push(item)
      if (items.length >= 3) break
    }
    return items
  }, [recentTranslationKeys, selectedTranslationKey, catalogItems])

  /** Bookmarks indexed by "sura:aya" for per-ayah lookups (note included). */
  const bookmarksByKey = useMemo(
    () =>
      new Map<string, ReaderBookmark>(
        bookmarks.map((bookmark) => [`${bookmark.sura}:${bookmark.aya}`, bookmark]),
      ),
    [bookmarks],
  )

  /** Interface-language sura name: Arabic names for the Arabic UI, localized
   *  source names when available, English transliteration otherwise.
   *  PROMPT 14: useCallback keeps this identity stable - it feeds the memoized
   *  ayah text builders, so an unstable identity defeated the AyahBlock memo
   *  and re-rendered every block of a long sura on unrelated state changes. */
  const getSuraName = useCallback(
    (suraNumber: number): string => {
      const meta = getSuraMeta(suraNumber)
      if (!meta) return String(suraNumber)
      if (locale === 'ar') return meta.nameArabic
      return localizedSuraNames?.[String(suraNumber)] ?? meta.nameEnglish
    },
    [locale, localizedSuraNames],
  )

  const suraError = suraQuery.error
  const suraErrorStatus = suraError instanceof ApiError ? suraError.status : null
  const isSuraUnavailable = suraQuery.isError && suraErrorStatus === 404
  /** Connectivity-style failure (offline / upstream 502 / network error):
   *  the last cached copy may still be readable. */
  const isConnectivityFailure =
    suraQuery.isError &&
    !isSuraUnavailable &&
    (!isOnline || suraErrorStatus === 502 || suraErrorStatus === 0)

  /** Offline fallback lookup in the IndexedDB cache (IndexedDB keeps working
   *  while offline, hence networkMode: 'always'). */
  const cacheQuery = useQuery({
    queryKey: ['sura-cache', selectedTranslationKey, sura],
    queryFn: () => {
      if (selectedTranslationKey === null) return Promise.resolve(null)
      return getCachedSura(selectedTranslationKey, sura)
    },
    staleTime: Infinity,
    retry: 0,
    networkMode: 'always',
    enabled: readerOpen && isConnectivityFailure,
  })

  const cachedSura = isConnectivityFailure ? (cacheQuery.data ?? null) : null
  /** True while the offline fallback lookup is in flight (avoids a banner flash). */
  const isCheckingCache = isConnectivityFailure && cacheQuery.isPending

  /** What the reading surface renders: the live response, or the offline
   *  cached copy when the request failed for connectivity reasons. */
  const content: ReaderContent | null = useMemo(() => {
    const data = suraQuery.data
    if (data) {
      return {
        translationKey: data.translationKey,
        translationTitle: data.translationTitle,
        direction: data.direction,
        sura: data.sura,
        ayahCount: data.ayahCount,
        version: data.version,
        ayat: data.ayat,
        fromCache: false,
      }
    }
    if (
      suraQuery.isError &&
      cachedSura !== null &&
      cachedSura.translationKey === selectedTranslationKey &&
      cachedSura.sura === sura
    ) {
      return {
        translationKey: cachedSura.translationKey,
        translationTitle: translationMeta?.title ?? null,
        direction: translationMeta?.direction ?? 'ltr',
        sura: cachedSura.sura,
        ayahCount: cachedSura.ayahCount,
        version: cachedSura.version,
        ayat: cachedSura.ayat,
        fromCache: true,
      }
    }
    return null
  }, [suraQuery.data, suraQuery.isError, cachedSura, selectedTranslationKey, sura, translationMeta])

  /* ---------------------------------------------------------------- */
  /* Verified audio recitation                                         */
  /* ---------------------------------------------------------------- */

  /** Set of ayat with a VERIFIED audio file for the current sura + style.
   *  Only these ayat ever show a play control - a file that was not verified
   *  is never offered as playable. */
  const playableAyat = useMemo(() => {
    const data = suraAudioQuery.data
    if (!data || data.live.status !== 'available') return null
    if (data.files.length === 0) return null
    return new Set(data.files.map((file) => file.ayah))
  }, [suraAudioQuery.data])

  /** Verified audio is offered at all (style chosen + live-confirmed files). */
  const audioAvailable = selectedStyleId !== null && playableAyat !== null

  /** Live availability verdict of the currently selected style (honest
   *  warning when the source cannot be confirmed right now). */
  const selectedStyleLive = useMemo(() => {
    if (!selectedStyleId) return null
    return (
      reciterCatalogQuery.data?.styles.find((style) => style.id === selectedStyleId)?.available ??
      null
    )
  }, [reciterCatalogQuery.data, selectedStyleId])

  const selectedStyleDef = useMemo(
    () => (selectedStyleId ? getStyleDefinition(selectedStyleId) : undefined),
    [selectedStyleId],
  )

  /** Stable play/pause handler for the per-ayah buttons. Toggling the SAME
   *  ayah pauses; another ayah starts it (reading position untouched). */
  const handlePlayAyah = useCallback(
    (aya: QuranAya) => {
      if (playingSura === aya.sura && playingAyah === aya.aya) {
        playbackEngine.togglePlayPause()
        return
      }
      void playbackEngine.playAyah(aya.sura, aya.aya)
    },
    [playingSura, playingAyah],
  )

  /* ---------------------------------------------------------------- */
  /* Translation narration (PROMPT 10) - completely separate from      */
  /* the Arabic recitation above.                                      */
  /* ---------------------------------------------------------------- */

  const narratingSura = useNarrationStore((s) => s.narratingSura)
  const narratingAyah = useNarrationStore((s) => s.narratingAyah)
  const narrationTranslationKey = useNarrationStore((s) => s.narrationTranslationKey)
  const narrationMode = useNarrationStore((s) => s.mode)
  const narrationFollowAyah = useNarrationStore((s) => s.followAyah)

  /** The verified catalog of translations with recorded narration. */
  const translationAudioCatalogQuery = useQuery({
    queryKey: ['translation-audio-catalog'],
    queryFn: getTranslationAudioCatalog,
    staleTime: 24 * 60 * 60_000,
    retry: 1,
    enabled: readerOpen,
  })

  /** The catalog entry of the SELECTED translation (exact key match only -
   *  a recording of a DIFFERENT translation is never substituted). */
  const narrationCatalogEntry = useMemo(
    () =>
      selectedTranslationKey !== null
        ? (translationAudioCatalogQuery.data?.translations ?? []).find(
            (entry) => entry.translationKey === selectedTranslationKey,
          ) ?? null
        : null,
    [translationAudioCatalogQuery.data, selectedTranslationKey],
  )

  /**
   * Voice detection is performed ON DEMAND by the narration engine (at the
   * moment of a narrate press) and by the voice picker (when opened) - a
   * voice is only ever offered after it was actually detected on THIS
   * device, so no eager detection is kept here.
   */

  /** Keep the engine's language context in sync (voice matching follows the
   *  SELECTED TRANSLATION's language - never the interface language). */
  useEffect(() => {
    narrationEngine.setLanguageContext(
      translationMeta?.languageCode ?? null,
      translationMeta?.languageName ?? null,
    )
  }, [translationMeta?.languageCode, translationMeta?.languageName])

  /** Register the displayed ayat as the engine's TTS text source (the
   *  selected translation's OWN text - nothing else is ever spoken). */
  useEffect(() => {
    if (!content) return
    narrationEngine.registerTextSource(
      content.translationKey,
      sura,
      content.ayat.map((aya) => ({ ayah: aya.aya, translation: aya.translation ?? '' })),
    )
  }, [content, sura])

  /**
   * Narration control availability for the per-ayah buttons: the narrate
   * control is offered whenever a translation is selected - the PLAYBACK
   * PRIORITY LADDER then resolves each press honestly:
   * 1. exact verified recording of the selected translation,
   * 2. a device voice for the translation's language (actually detected),
   * 3. an honest explanation that narration is unavailable for the
   *    language (shown in the narration bar - never a silent dead button).
   */
  const narrationAvailable = selectedTranslationKey !== null || content !== null

  /** Stable narrate/pause handler for the per-ayah buttons. Toggling the
   *  SAME ayah pauses; another ayah starts its narration (the reading
   *  position is untouched, and any recitation is paused by the session
   *  coordinator - the two never overlap). */
  const handleNarrateAyah = useCallback(
    (aya: QuranAya) => {
      const key = selectedTranslationKey ?? content?.translationKey ?? null
      if (key === null) return
      if (
        narrationTranslationKey === key &&
        narratingSura === aya.sura &&
        narratingAyah === aya.aya
      ) {
        narrationEngine.togglePlayPause()
        return
      }
      void narrationEngine.playAyah(key, aya.sura, aya.aya)
    },
    [selectedTranslationKey, content?.translationKey, narrationTranslationKey, narratingSura, narratingAyah],
  )

  /** Follow-along for narration: keep the narrated ayah in view (a visually
   *  distinct amber highlight - never confused with recitation playback). */
  useEffect(() => {
    if (!narrationFollowAyah) return
    if (narratingSura !== sura || narratingAyah === null) return
    const element = document.getElementById(`ayah-${narratingSura}-${narratingAyah}`)
    if (element) {
      element.scrollIntoView({ behavior: scrollBehavior(), block: 'center' })
    }
  }, [narrationFollowAyah, narratingSura, narratingAyah, sura])

  /** Narration download dialog state (the recorded narration of the
   *  selected translation - offered only when the catalog verified it). */
  const [narrationDownloadOpen, setNarrationDownloadOpen] = useState(false)


  /** Follow-along: keep the playing (or loading) ayah in view. The scroll
   *  follows the playback position the moment it is set - including while
   *  the file buffers - but never follows an errored attempt, so the view
   *  never jumps to an ayah that is not actually playing. */
  useEffect(() => {
    if (!followAyah) return
    if (playingSura !== sura || playingAyah === null || audioError !== null) return
    const element = document.getElementById(`ayah-${playingSura}-${playingAyah}`)
    if (element) {
      element.scrollIntoView({ behavior: scrollBehavior(), block: 'center' })
    }
  }, [followAyah, playingSura, playingAyah, sura, audioError])

  /* ---------------------------------------------------------------- */
  /* Effects                                                           */
  /* ---------------------------------------------------------------- */

  /** Arabic font detection: the Uthmanic Hafs (v20) webfont is loaded
   *  locally; report whether it is active or a fallback stack is in use. */
  useEffect(() => {
    if (typeof document === 'undefined' || !document.fonts) return
    let cancelled = false
    document.fonts.ready
      .then(() => {
        if (cancelled) return
        setFontState(document.fonts.check('1rem Hafs20') ? 'active' : 'fallback')
      })
      .catch(() => {
        if (!cancelled) setFontState('fallback')
      })
    return () => {
      cancelled = true
    }
  }, [])

  /**
   * Default translation resolution - runs while the reader is open and no
   * valid key is held: preferred translation language, then the interface
   * language, then the well-known default. A persisted key that is no longer
   * in the catalog is re-resolved.
   */
  useEffect(() => {
    if (!readerOpen) return
    const items = catalogQuery.data?.items
    if (!items || items.length === 0) return
    if (
      selectedTranslationKey !== null &&
      items.some((item) => item.key === selectedTranslationKey)
    ) {
      return
    }
    const key = resolveDefaultTranslationKey(
      items,
      preferredQuranTranslationLanguage,
      locale,
    )
    if (key !== null && key !== selectedTranslationKey) {
      setSelectedTranslationKey(key)
    }
  }, [
    readerOpen,
    catalogQuery.data,
    selectedTranslationKey,
    preferredQuranTranslationLanguage,
    locale,
    setSelectedTranslationKey,
  ])

  /**
   * Successful load: cache the sura for offline reading (best effort).
   *
   * The reading position is NOT written here: only the IntersectionObserver
   * persists the ayah actually at the reading line, so a saved position is
   * never overwritten with a default. The sole fallback (ayah 1) applies
   * only when IntersectionObserver is unavailable in this browser.
   */
  useEffect(() => {
    const data = suraQuery.data
    if (!data) return
    void putCachedSura({
      translationKey: data.translationKey,
      sura: data.sura,
      version: data.version,
      ayahCount: data.ayahCount,
      ayat: data.ayat,
    })
    if (typeof IntersectionObserver === 'undefined') {
      setLastReadingPosition({ surah: data.sura, ayah: 1, savedAt: new Date().toISOString() })
    }
  }, [suraQuery.data, setLastReadingPosition])

  /** Persist the reading position after a short debounce (never on every
   *  intersection tick, and never synchronously during rendering). The last
   *  captured line is also remembered in a ref so leaving the reader (or the
   *  app being backgrounded) can flush it immediately (PROMPT 12 §2). */
  const saveReadingPositionSoon = useCallback(
    (surah: number, ayah: number) => {
      pendingPositionRef.current = { surah, ayah }
      if (positionSaveTimerRef.current !== null) {
        window.clearTimeout(positionSaveTimerRef.current)
      }
      positionSaveTimerRef.current = window.setTimeout(() => {
        positionSaveTimerRef.current = null
        const pending = pendingPositionRef.current
        pendingPositionRef.current = null
        if (pending !== null) {
          setLastReadingPosition({ ...pending, savedAt: new Date().toISOString() })
        }
      }, 500)
    },
    [setLastReadingPosition],
  )

  /** Write the not-yet-persisted reading line immediately. Called when the
   *  user leaves the reader, hides the page, or the app is being closed - so
   *  the saved position never lags behind the last line actually read.
   *  Skipped while an explicit resume scroll is still settling (the previous
   *  saved position is then more accurate than an intermediate line). */
  const flushReadingPosition = useCallback(() => {
    if (Date.now() < resumeGuardUntilRef.current) return
    if (positionSaveTimerRef.current !== null) {
      window.clearTimeout(positionSaveTimerRef.current)
      positionSaveTimerRef.current = null
    }
    const pending = pendingPositionRef.current
    pendingPositionRef.current = null
    if (pending !== null) {
      setLastReadingPosition({ ...pending, savedAt: new Date().toISOString() })
    }
  }, [setLastReadingPosition])

  /* Persist the pending reading line when the reader unmounts (the user
   * leaves the Quran reader) and when the page is hidden or closed (the app
   * is backgrounded or quit) - never depending on the debounce having fired. */
  useEffect(() => {
    const flushIfHidden = () => {
      if (document.visibilityState === 'hidden') flushReadingPosition()
    }
    window.addEventListener('pagehide', flushReadingPosition)
    document.addEventListener('visibilitychange', flushIfHidden)
    return () => {
      window.removeEventListener('pagehide', flushReadingPosition)
      document.removeEventListener('visibilitychange', flushIfHidden)
      flushReadingPosition()
      if (highlightTimerRef.current !== null) {
        window.clearTimeout(highlightTimerRef.current)
        highlightTimerRef.current = null
      }
    }
  }, [flushReadingPosition])

  /**
   * Track the topmost ayah at the reading line (upper half of the viewport)
   * and persist it as the real reading position. The tracked value starts
   * "unset" (0) whenever a DIFFERENT sura than the saved position renders,
   * so the first observed line of a newly opened sura is saved immediately -
   * navigating to another sura updates the position (PROMPT 12 §2). For the
   * same sura (resume case) it starts at 1, so the initial view of ayah 1
   * never clobbers a deeper saved position while the resume scroll settles.
   */
  useEffect(() => {
    if (content === null) return
    const savedPosition = usePreferencesStore.getState().lastReadingPosition
    trackedAyahRef.current =
      savedPosition !== null && savedPosition.surah === content.sura ? 1 : 0
    const surface = readingSurfaceRef.current
    if (surface === null || typeof IntersectionObserver === 'undefined') return

    const parseAya = (element: Element): number => {
      const parts = element.id.split('-')
      const aya = Number(parts[parts.length - 1])
      return Number.isInteger(aya) && aya > 0 ? aya : 0
    }

    const intersecting = new Set<Element>()
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) intersecting.add(entry.target)
          else intersecting.delete(entry.target)
        }
        let topAya = 0
        let topBound = Number.POSITIVE_INFINITY
        for (const element of intersecting) {
          const aya = parseAya(element)
          if (aya === 0) continue
          const rect = element.getBoundingClientRect()
          if (rect.top < topBound) {
            topBound = rect.top
            topAya = aya
          }
        }
        if (topAya > 0 && topAya !== trackedAyahRef.current) {
          trackedAyahRef.current = topAya
          setReadingLine({ sura: content.sura, aya: topAya })
          saveReadingPositionSoon(content.sura, topAya)
        }
      },
      // The reading line: only the upper ~55% of the viewport counts as
      // "currently being read".
      { root: null, rootMargin: '0px 0px -45% 0px', threshold: 0 },
    )

    for (const element of surface.querySelectorAll('article[id^="ayah-"]')) {
      observer.observe(element)
    }
    return () => {
      observer.disconnect()
    }
  }, [content, saveReadingPositionSoon])

  /* The bookmarks panel shows while a one-shot request (Home quick access)
   * is pending; closing it consumes the request. The request is also
   * dropped when the reader closes without the panel being dismissed. */
  useEffect(() => {
    if (!readerOpen && bookmarksPanelRequested) {
      clearBookmarksPanelRequest()
    }
  }, [readerOpen, bookmarksPanelRequested, clearBookmarksPanelRequest])

  /** Allow one resume-scroll per sura load, and one set per reader open. */
  useEffect(() => {
    if (!readerOpen) scrolledLoadRef.current = null
  }, [readerOpen])

  /** Smooth-scroll to one ayah of the rendered content (small delay lets
   *  the browser lay out the freshly mounted surface). */
  const scrollToAyah = useCallback((suraNumber: number, aya: number, block: ScrollLogicalPosition = 'center') => {
    window.setTimeout(() => {
      document
        .getElementById(`ayah-${suraNumber}-${aya}`)
        ?.scrollIntoView({ behavior: scrollBehavior(), block })
    }, 120)
  }, [])

  /** Scroll to one ayah AND briefly highlight it, so the user recognizes
   *  exactly where they stopped ("Continue reading", bookmark taps, jumps).
   *  Also opens the resume guard window so position flushes do not overwrite
   *  the saved position with lines the auto-scroll merely passes through.
   *  The highlight is applied on the scroll's timer tick (not synchronously
   *  in a render effect) and fades out by itself after ~3s. */
  const revealAyah = useCallback(
    (suraNumber: number, aya: number, block: ScrollLogicalPosition = 'center') => {
      resumeGuardUntilRef.current = Date.now() + 1800
      scrollToAyah(suraNumber, aya, block)
      if (highlightTimerRef.current !== null) {
        window.clearTimeout(highlightTimerRef.current)
      }
      highlightTimerRef.current = window.setTimeout(() => {
        setHighlightedAyah({ sura: suraNumber, aya })
        highlightTimerRef.current = window.setTimeout(() => {
          highlightTimerRef.current = null
          setHighlightedAyah(null)
        }, 3000)
      }, 120)
    },
    [scrollToAyah],
  )

  /**
   * Once a sura load renders, scroll exactly once:
   * 1. to an explicit ayah target ("Continue reading" / bookmark tapped
   *    outside the reader) - always wins, once per target;
   * 2. to a pending in-reader navigation (bookmarks panel / ayah jump);
   * 3. otherwise resume the saved reading position (same sura, deeper ayah).
   * Moving to another sura always starts from its first ayah.
   */
  useEffect(() => {
    if (content === null) return
    const loadKey = `${content.translationKey}:${content.sura}`

    /* 1. Explicit exact-ayah target from outside the reader. */
    if (pendingAyahTarget !== null && pendingAyahTarget.sura === content.sura) {
      const target = pendingAyahTarget
      consumePendingAyahTarget()
      scrolledLoadRef.current = loadKey
      lastLoadedSuraRef.current = content.sura
      revealAyah(target.sura, target.aya)
      return
    }

    /* 2. In-reader navigation waiting for this content. */
    const pending = pendingScrollRef.current
    if (pending !== null && pending.sura === content.sura) {
      pendingScrollRef.current = null
      scrolledLoadRef.current = loadKey
      lastLoadedSuraRef.current = content.sura
      revealAyah(pending.sura, pending.aya)
      return
    }

    if (scrolledLoadRef.current === loadKey) return
    scrolledLoadRef.current = loadKey

    // Moving to another sura (next/previous/picker/swipe): always start from
    // the FIRST ayah of the new sura - never stay wherever the reader was.
    const isSuraTransition =
      lastLoadedSuraRef.current !== null && lastLoadedSuraRef.current !== content.sura
    lastLoadedSuraRef.current = content.sura
    if (isSuraTransition) {
      scrollToAyah(content.sura, 1, 'start')
      return
    }

    /* 3. Reopen of the same sura: resume the saved reading position. */
    const position = lastReadingPosition
    if (position !== null && position.surah === content.sura && position.ayah > 1) {
      scrollToAyah(position.surah, position.ayah)
    }
  }, [content, pendingAyahTarget, lastReadingPosition, scrollToAyah, revealAyah, consumePendingAyahTarget])

  /* ---------------------------------------------------------------- */
  /* Handlers                                                          */
  /* ---------------------------------------------------------------- */

  /* Handlers below are wrapped in useCallback with stable dependencies so
   * the memoized AyahBlock instances do not re-render for unrelated state
   * changes (display popover, translation search, ...). Bookmark lookups
   * read the live store instead of the render-scope map, keeping the
   * identities stable across bookmark mutations. */
  const handleToggleBookmark = useCallback(
    (aya: QuranAya) => {
      const existing = useReaderStore
        .getState()
        .bookmarks.find((bookmark) => bookmark.sura === aya.sura && bookmark.aya === aya.aya)
      if (existing) {
        /* PROMPT 14 (Nielsen #3): one accidental tap must not silently destroy
         *  a bookmark that may carry a long personal note - the removal is
         *  immediately reversible from the toast. */
        removeBookmark(existing.id)
        toast(t('reader.bookmarkRemoved'), {
          action: {
            label: t('common.undo'),
            onClick: () => restoreBookmark(existing),
          },
        })
      } else {
        /* Capture a short verbatim excerpt of the ayah as it is on screen
         * (translation first, Arabic otherwise) - shown in the bookmarks
         * lists with zero network access, never fabricated. */
        const translationText =
          typeof aya.translation === 'string' ? aya.translation.trim() : ''
        const arabicText = typeof aya.arabicText === 'string' ? aya.arabicText.trim() : ''
        const source = translationText.length > 0 ? translationText : arabicText
        const preview = source.length > 0 ? source.slice(0, 140) : null
        addBookmark(aya.sura, aya.aya, preview)
        toast.success(t('reader.bookmarkSaved'))
      }
    },
    [addBookmark, removeBookmark, restoreBookmark, t],
  )

  /** The text shared/copied for one ayah: verbatim Arabic, then the source
   *  translation (when it exists), then the reference. */
  const buildAyahText = useCallback(
    (aya: QuranAya): string => {
      const suraName = getSuraName(aya.sura)
      const parts = [aya.arabicText]
      const translationText = typeof aya.translation === 'string' ? aya.translation.trim() : ''
      if (translationText.length > 0) parts.push(translationText)
      parts.push(`(${suraName} · ${t('reader.ayah')} ${aya.aya})`)
      return parts.join('\n\n')
    },
    [getSuraName, t],
  )

  const handleShareAyah = useCallback(
    async (aya: QuranAya) => {
      const suraName = getSuraName(aya.sura)
      const text = buildAyahText(aya)
      try {
        if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
          await navigator.share({ title: suraName, text })
          return
        }
        if (typeof navigator !== 'undefined' && navigator.clipboard) {
          await navigator.clipboard.writeText(text)
          toast.success(t('reader.shareCopied'))
          return
        }
        toast.error(t('reader.shareUnavailable'))
      } catch (error) {
        // Cancelling the native share sheet is not a failure.
        if (error instanceof DOMException && error.name === 'AbortError') return
        toast.error(t('reader.shareUnavailable'))
      }
    },
    [buildAyahText, getSuraName, t],
  )

  const handleCopyAyah = useCallback(
    async (aya: QuranAya) => {
      const text = buildAyahText(aya)
      try {
        if (typeof navigator === 'undefined' || !navigator.clipboard) {
          toast.error(t('reader.copyUnavailable'))
          return
        }
        await navigator.clipboard.writeText(text)
        toast.success(t('reader.ayahCopied'))
      } catch {
        toast.error(t('reader.copyUnavailable'))
      }
    },
    [buildAyahText, t],
  )

  const handleSelectTranslation = (key: string) => {
    setSelectedTranslationKey(key)
    setTranslationDialogOpen(false)
    setTranslationSearch('')
  }

  const handleTranslationDialogOpenChange = (open: boolean) => {
    setTranslationDialogOpen(open)
    if (!open) setTranslationSearch('')
  }

  /** Navigate to a bookmark: straight scroll when the sura is rendered,
   *  otherwise remember the target and scroll when its content arrives. */
  const handleBookmarkNavigate = (bookmark: ReaderBookmark) => {
    setBookmarksOpen(false)
    if (bookmark.sura === sura && content !== null) {
      revealAyah(bookmark.sura, bookmark.aya)
      return
    }
    pendingScrollRef.current = { sura: bookmark.sura, aya: bookmark.aya }
    if (bookmark.sura !== sura) setSura(bookmark.sura)
  }

  /** Jump to a specific ayah of the current sura (already validated by the
   *  dialog against the authentic structural index). */
  const handleJumpToAyah = (ayah: number) => {
    if (content !== null && content.sura === sura) {
      revealAyah(sura, ayah)
      return
    }
    pendingScrollRef.current = { sura, aya: ayah }
  }

  /** Open the note dialog for the bookmark attached to one ayah. */
  const handleEditNote = useCallback(
    (aya: QuranAya) => {
      const bookmark = useReaderStore
        .getState()
        .bookmarks.find((entry) => entry.sura === aya.sura && entry.aya === aya.aya)
      if (!bookmark) return
      setNoteTarget(bookmark)
      setNoteDialogOpen(true)
    },
    [],
  )

  const handleSaveNote = (id: string, note: string) => {
    updateBookmarkNote(id, note)
    toast(note.trim().length > 0 ? t('reader.noteSaved') : t('reader.noteCleared'))
  }

  /* Optional swipe navigation between suras: a deliberate horizontal flick.
   * Direction follows the interface direction (forward is leftward in LTR
   * and rightward in RTL). Buttons and the sura index always remain the
   * primary navigation - this is only an additional convenience. */
  const handleTouchStart = (event: ReactTouchEvent<HTMLElement>) => {
    if (event.touches.length !== 1) {
      swipeStartRef.current = null
      return
    }
    const touch = event.touches[0]
    swipeStartRef.current = { x: touch.clientX, y: touch.clientY, at: Date.now() }
  }

  const handleTouchEnd = (event: ReactTouchEvent<HTMLElement>) => {
    const start = swipeStartRef.current
    swipeStartRef.current = null
    if (!start || event.changedTouches.length !== 1) return
    const touch = event.changedTouches[0]
    const dx = touch.clientX - start.x
    const dy = touch.clientY - start.y
    if (Date.now() - start.at > SWIPE_MAX_DURATION) return
    if (Math.abs(dx) < SWIPE_MIN_DISTANCE) return
    if (Math.abs(dy) > SWIPE_MAX_VERTICAL) return
    if (Math.abs(dx) < Math.abs(dy) * 1.4) return
    // A gesture that ends on an interactive control was a control touch, not
    // a navigation swipe.
    const target = event.target as HTMLElement | null
    if (target?.closest('button, a, input, textarea, select, [role="button"]')) return
    // Swiping while selecting text must not navigate.
    if (typeof window !== 'undefined') {
      const selection = window.getSelection()
      if (selection && selection.toString().trim().length > 0) return
    }
    const rtl = typeof document !== 'undefined' && document.documentElement.dir === 'rtl'
    const forward = rtl ? dx > 0 : dx < 0
    if (forward) {
      if (sura < SURA_COUNT) nextSura()
    } else if (sura > 1) {
      prevSura()
    }
  }

  /* ---------------------------------------------------------------- */
  /* Derived render values                                             */
  /* ---------------------------------------------------------------- */

  const suraMeta = getSuraMeta(sura)
  const contentSuraMeta = content !== null ? getSuraMeta(content.sura) : undefined
  const currentSuraName = getSuraName(sura)
  const currentTranslationTitle =
    content?.translationTitle ?? translationMeta?.title ?? t('reader.selectTranslation')

  /** Source line with the publisher when the catalog knows one. */
  const headerTitle = content?.translationTitle ?? translationMeta?.title ?? null
  const headerPublisher = translationMeta?.publisher ?? null
  const sourceLineText = headerTitle
    ? headerPublisher
      ? t('reader.publisherLine', { title: headerTitle, publisher: headerPublisher })
      : t('reader.sourceLine', { title: headerTitle })
    : null

  const fontChipLabel =
    fontState === 'active'
      ? t('reader.fontActive')
      : fontState === 'loading'
        ? t('reader.fontLoading')
        : t('reader.fontFallback')
  const fontChipClass =
    fontState === 'active'
      ? 'border-success/40 bg-success/10 text-success'
      : 'border-border bg-muted text-muted-foreground'

  /** True while the default translation is still being resolved (catalog
   *  loading, or loaded with items and the key not yet picked). */
  const isResolvingTranslation = selectedTranslationKey === null && !catalogQuery.isError

  const retryCatalogButton = (
    <Button variant="outline" className="h-11" onClick={() => void catalogQuery.refetch()}>
      {t('common.retry')}
    </Button>
  )

  /** Translation visibility on the surface (focus reading forces Arabic-only). */
  const effectiveShowTranslation = showTranslation && !focusMode

  let readingBody: ReactNode
  if (content !== null) {
    readingBody = (
      <>
        {/* Sura header */}
        <header className="space-y-3 text-center">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {t('reader.sura')} {formatNumber(locale, content.sura)}
          </p>
          <h2 className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            <span dir="auto">{getSuraName(content.sura)}</span>
            {/* Arabic name shown as a second script only when it differs
                from the localized name (avoids duplication in Arabic UI). */}
            {contentSuraMeta && contentSuraMeta.nameArabic !== getSuraName(content.sura) ? (
              <span dir="rtl" lang="ar" className="font-arabic text-gold">
                {contentSuraMeta.nameArabic}
              </span>
            ) : null}
          </h2>
          <p className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1.5 text-xs text-muted-foreground">
            <span>{t('reader.ayahCount', { count: formatNumber(locale, content.ayahCount) })}</span>
            {content.fromCache ? (
              <>
                <span aria-hidden="true">·</span>
                <Badge variant="outline" className="border-gold/40 bg-gold/10 text-gold-foreground">
                  {t('reader.offlineCached')}
                </Badge>
              </>
            ) : null}
            {focusMode ? null : (
              <>
                {sourceLineText ? (
                  <>
                    <span aria-hidden="true">·</span>
                    <span dir="auto">{sourceLineText}</span>
                  </>
                ) : null}
                {content.version ? (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>
                      {t('common.version')}: {content.version}
                    </span>
                  </>
                ) : null}
                <span aria-hidden="true">·</span>
                <Badge variant="outline" className={fontChipClass}>
                  {fontChipLabel}
                </Badge>
              </>
            )}
          </p>
        </header>

        {/* Ayat - the reading surface */}
        <div
          ref={readingSurfaceRef}
          className={cn('space-y-8 rounded-xl p-4 sm:p-6', READER_SURFACES[readingTheme])}
        >
          {/* Surah-opening presentation (Basmala / Isti'adha) - display
           * only, derived purely from the sura number, so EVERY navigation
           * path into a sura (index, prev/next, search, bookmarks, recently
           * read, deep links) renders the same correct opening exactly once
           * above the first ayah. It is never part of the ayat data: nothing
           * is inserted into the source text, cache, API, or exports, and
           * ayah navigation inside a sura never re-renders or duplicates it. */}
          <SuraOpening sura={content.sura} arabicFontSize={ARABIC_SIZES[arabicScale]} />
          {content.ayat.map((aya) => {
            const key = `${aya.sura}:${aya.aya}`
            const bookmark = bookmarksByKey.get(key)
            return (
              <AyahBlock
                key={`${aya.sura}-${aya.aya}`}
                aya={aya}
                direction={content.direction}
                showTranslation={effectiveShowTranslation}
                arabicFontSize={ARABIC_SIZES[arabicScale]}
                translationFontSize={TRANS_SIZES[translationScale]}
                isBookmarked={bookmark !== undefined}
                bookmarkNote={bookmark?.note ?? null}
                isResumeTarget={
                  highlightedAyah !== null &&
                  highlightedAyah.sura === aya.sura &&
                  highlightedAyah.aya === aya.aya
                }
                focusMode={focusMode}
                audioAvailable={audioAvailable && (playableAyat?.has(aya.aya) ?? false)}
                isPlayingAyah={audioError === null && playingSura === aya.sura && playingAyah === aya.aya}
                narrationAvailable={narrationAvailable}
                isNarratingAyah={narratingSura === aya.sura && narratingAyah === aya.aya}
                onToggleBookmark={handleToggleBookmark}
                onEditNote={handleEditNote}
                onCopy={handleCopyAyah}
                onShare={handleShareAyah}
                onPlayAyah={handlePlayAyah}
                onNarrateAyah={handleNarrateAyah}
              />
            )
          })}
        </div>
      </>
    )
  } else if (
    selectedTranslationKey === null &&
    (catalogQuery.isError || (catalogQuery.isSuccess && catalogItems.length === 0))
  ) {
    // The catalog could not be loaded (or resolved empty) and no translation is held.
    readingBody = (
      <StatusBanner
        variant="error"
        title={t('common.error')}
        description={t('common.errorDescription')}
        action={retryCatalogButton}
      />
    )
  } else if (isResolvingTranslation || suraQuery.isPending || isCheckingCache) {
    readingBody = (
      <ReaderLoadingSkeleton
        readingTheme={readingTheme}
        showTranslation={effectiveShowTranslation}
        label={t('common.loading')}
      />
    )
  } else if (isSuraUnavailable) {
    readingBody = (
      <EmptyState
        icon={BookX}
        title={t('reader.suraUnavailable')}
        action={
          <Button variant="outline" className="h-11" onClick={() => setTranslationDialogOpen(true)}>
            <Languages aria-hidden="true" className="size-4" />
            {t('reader.changeTranslation')}
          </Button>
        }
      />
    )
  } else {
    readingBody = (
      <StatusBanner
        variant="error"
        title={t('common.error')}
        description={t('common.errorDescription')}
        action={
          <Button variant="outline" className="h-11" onClick={() => void suraQuery.refetch()}>
            {t('common.retry')}
          </Button>
        }
      />
    )
  }

  /* ---------------------------------------------------------------- */
  /* Render                                                            */
  /* ---------------------------------------------------------------- */

  if (!readerOpen) return null

  return (
    <section aria-label={t('quran.quranTextTitle')} className="mx-auto w-full max-w-3xl">
      {/* Sticky reader chrome: always-reachable controls below the app header.
       * Focus reading collapses it to a single slim bar. */}
      <div className="sticky top-16 z-30 border-b bg-background/95 backdrop-blur">
        {focusMode ? (
          <div className="flex items-center gap-2 px-4 py-1.5 sm:px-6">
            <Button
              variant="ghost"
              className="h-11 shrink-0 gap-2 px-3"
              onClick={() => setFocusMode(false)}
              aria-label={t('reader.exitFocusMode')}
            >
              <X aria-hidden="true" className="size-4" />
              <span className="hidden whitespace-nowrap sm:inline">{t('reader.exitFocusMode')}</span>
            </Button>
            <div className="min-w-0 flex-1 text-center">
              <p className="truncate text-sm font-medium text-foreground">
                {t('reader.sura')} {formatNumber(locale, sura)} · {currentSuraName}
              </p>
              <p className="truncate text-xs text-muted-foreground">
                {t('reader.ayahCount', { count: formatNumber(locale, suraMeta?.ayahCount ?? 0) })}
              </p>
            </div>
            <span aria-hidden="true" className="w-1 shrink-0" />
          </div>
        ) : (
          <>
            {/* Toolbar row. PROMPT 14: on <=375px screens the controls would
                otherwise clip off-screen with no affordance - the row scrolls
                horizontally (hidden scrollbar) with soft edge fades, so every
                control stays reachable without scrolling the reading surface. */}
            <div className="flex items-center gap-1 overflow-x-auto px-2 py-2 sm:px-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden [mask-image:linear-gradient(to_right,transparent_0,black_12px,black_calc(100%-12px),transparent_100%)]">
              <Button
                variant="ghost"
                className="h-11 shrink-0 gap-1.5 px-2.5"
                onClick={closeReader}
                aria-label={t('reader.backToLibrary')}
              >
                <ArrowLeft aria-hidden="true" className="size-4 rtl:-scale-x-100" />
                <span className="hidden whitespace-nowrap sm:inline">{t('reader.backToLibrary')}</span>
              </Button>

              <div className="flex-1" />

              {/* Jump to ayah: captures the reading-line ayah in the event
                  handler (refs are read here, never during render). */}
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                onClick={() => {
                  setJumpSeedAyah(trackedAyahRef.current)
                  setJumpDialogOpen(true)
                }}
                aria-label={t('reader.jumpToAyah')}
              >
                <Hash aria-hidden="true" className="size-4" />
              </Button>

              {/* Recitation (verified EveryAyah audio): selector + active
                  style display. Changing the style never moves the reading
                  position - only the audio follows. */}
              <Button
                variant="ghost"
                className="h-11 min-w-0 shrink-0 gap-2 px-2.5"
                onClick={() => setReciterDialogOpen(true)}
                aria-haspopup="dialog"
                aria-label={t('audio.selectReciter')}
                title={
                  selectedStyleDef
                    ? `${selectedStyleDef.reciterName} · ${selectedStyleDef.styleLabel}`
                    : t('audio.selectReciter')
                }
              >
                <Radio
                  aria-hidden="true"
                  className={cn(
                    'size-4 shrink-0',
                    selectedStyleLive === false ? 'text-amber-600 dark:text-amber-400' : 'text-primary',
                  )}
                />
                <span
                  dir="auto"
                  className="hidden max-w-28 truncate text-sm text-muted-foreground sm:inline sm:max-w-36"
                >
                  {selectedStyleDef
                    ? selectedStyleLive === false
                      ? t('audio.notAvailableNow')
                      : selectedStyleDef.reciterName
                    : t('audio.recitation')}
                </span>
              </Button>

              {/* Recitation audio download (PROMPT 9): store verified
                  recitation files on this device for offline playback. Opens
                  with the current reading line as the seed - the reading
                  position never moves. */}
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                onClick={() => {
                  setJumpSeedAyah(trackedAyahRef.current)
                  setAudioDownloadOpen(true)
                }}
                aria-haspopup="dialog"
                aria-label={t('audio.download.title')}
                title={t('audio.download.title')}
              >
                <ArrowDownToLine aria-hidden="true" className="size-4 text-primary" />
              </Button>

              {/* Translation narration download (PROMPT 10): store the
                  RECORDED narration of the selected translation (verified
                  catalog match) for offline playback. Shown only when the
                  selected translation actually has recorded narration -
                  device-voice narration needs no download. */}
              {narrationCatalogEntry !== null ? (
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-11 shrink-0"
                  onClick={() => {
                    setJumpSeedAyah(trackedAyahRef.current)
                    setNarrationDownloadOpen(true)
                  }}
                  aria-haspopup="dialog"
                  aria-label={t('narration.downloadTitle')}
                  title={`${t('narration.downloadTitle')} — ${narrationCatalogEntry.audioName}`}
                >
                  <ArrowDownToLine
                    aria-hidden="true"
                    className="size-4 text-amber-600 dark:text-amber-400"
                  />
                </Button>
              ) : null}

              {/* Muallim learning mode: the dedicated Al-Husary teaching
                  experience. Opening it never moves the reading position. */}
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                onClick={() => setLearningPanelOpen(true)}
                aria-haspopup="dialog"
                aria-label={t('audio.learning.title')}
                title={t('audio.learning.title')}
              >
                <GraduationCap aria-hidden="true" className="size-4 shrink-0 text-primary" />
              </Button>

              {/* Translation chooser */}
              <Button
                variant="ghost"
                className="h-11 min-w-0 shrink-0 gap-2 px-2.5"
                onClick={() => setTranslationDialogOpen(true)}
                aria-haspopup="dialog"
              >
                <Languages aria-hidden="true" className="size-4 shrink-0 text-primary" />
                <span
                  dir="auto"
                  className="hidden max-w-32 truncate text-sm text-muted-foreground sm:inline sm:max-w-40"
                >
                  {currentTranslationTitle}
                </span>
              </Button>

              {/* Display settings */}
              <Popover open={displayOpen} onOpenChange={setDisplayOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-11 shrink-0"
                    aria-label={t('reader.display')}
                  >
                    <Settings2 aria-hidden="true" className="size-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="max-h-[min(32rem,calc(100dvh-9rem))] w-80 overflow-y-auto scrollbar-subtle">
                  <div className="space-y-4">
                    <p className="text-sm font-semibold text-foreground">{t('reader.display')}</p>

                    {/* Arabic text size */}
                    <div className="space-y-2">
                      <span className="text-xs font-medium text-muted-foreground">
                        {t('reader.arabicSize')}
                      </span>
                      <ToggleGroup
                        type="single"
                        variant="outline"
                        size="sm"
                        className="w-full"
                        value={String(arabicScale)}
                        onValueChange={(value) => {
                          const step = Number(value)
                          if (Number.isInteger(step) && step >= 1 && step <= 5) {
                            setArabicScale(step as TextScale)
                          }
                        }}
                      >
                        {TEXT_STEPS.map((step) => (
                          <ToggleGroupItem
                            key={step}
                            value={String(step)}
                            className="flex-1"
                            aria-label={`${t('reader.arabicSize')} ${formatNumber(locale, step)}`}
                          >
                            <span style={{ fontSize: STEP_LABEL_SIZES[step] }}>A</span>
                          </ToggleGroupItem>
                        ))}
                      </ToggleGroup>
                    </div>

                    {/* Translation text size */}
                    <div className="space-y-2">
                      <span className="text-xs font-medium text-muted-foreground">
                        {t('reader.translationSize')}
                      </span>
                      <ToggleGroup
                        type="single"
                        variant="outline"
                        size="sm"
                        className="w-full"
                        value={String(translationScale)}
                        onValueChange={(value) => {
                          const step = Number(value)
                          if (Number.isInteger(step) && step >= 1 && step <= 5) {
                            setTranslationScale(step as TextScale)
                          }
                        }}
                      >
                        {TEXT_STEPS.map((step) => (
                          <ToggleGroupItem
                            key={step}
                            value={String(step)}
                            className="flex-1"
                            aria-label={`${t('reader.translationSize')} ${formatNumber(locale, step)}`}
                          >
                            <span style={{ fontSize: STEP_LABEL_SIZES[step] }}>A</span>
                          </ToggleGroupItem>
                        ))}
                      </ToggleGroup>
                    </div>

                    {/* Reset reading size */}
                    <Button
                      variant="outline"
                      className="h-11 w-full justify-start gap-2 text-sm"
                      onClick={() => {
                        setArabicScale(DEFAULT_SCALE)
                        setTranslationScale(DEFAULT_SCALE)
                      }}
                    >
                      <RotateCcw aria-hidden="true" className="size-4" />
                      {t('reader.resetSizes')}
                    </Button>

                    {/* Translation visibility */}
                    <div className="flex items-center justify-between gap-3">
                      <label
                        htmlFor="reader-translation-switch"
                        className="cursor-pointer text-sm text-foreground"
                      >
                        {showTranslation ? t('reader.showTranslation') : t('reader.hideTranslation')}
                      </label>
                      <Switch
                        id="reader-translation-switch"
                        checked={showTranslation}
                        onCheckedChange={() => toggleTranslation()}
                      />
                    </div>

                    {/* Focus (distraction-free) reading */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-3">
                        <label
                          htmlFor="reader-focus-switch"
                          className="cursor-pointer text-sm text-foreground"
                          title={t('reader.focusModeHint')}
                        >
                          {t('reader.focusMode')}
                        </label>
                        <Switch
                          id="reader-focus-switch"
                          checked={focusMode}
                          onCheckedChange={(checked) => setFocusMode(checked)}
                        />
                      </div>
                      {/* PROMPT 14: the explanation was title-only (invisible on
                          touch) - now a visible helper line. */}
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        {t('reader.focusModeHint')}
                      </p>
                    </div>

                    {/* Reading theme */}
                    <div className="space-y-2">
                      <span className="text-xs font-medium text-muted-foreground">
                        {t('reader.readingTheme')}
                      </span>
                      <ToggleGroup
                        type="single"
                        variant="outline"
                        size="sm"
                        className="w-full"
                        value={readingTheme}
                        onValueChange={(value) => {
                          if (value === 'match-app' || value === 'sepia' || value === 'night') {
                            setReadingTheme(value)
                          }
                        }}
                      >
                        {READING_THEMES.map((theme) => (
                          <ToggleGroupItem key={theme.value} value={theme.value} className="flex-1">
                            {t(theme.labelKey)}
                          </ToggleGroupItem>
                        ))}
                      </ToggleGroup>
                    </div>

                    <Separator />

                    {/* Arabic font status */}
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-medium text-muted-foreground">
                          {t('reader.arabicFont')}
                        </span>
                        <Badge variant="outline" className={fontChipClass}>
                          {fontChipLabel}
                        </Badge>
                      </div>
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        {t('reader.arabicSource')}
                      </p>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Bookmarks */}
              <Popover
                open={bookmarksOpen || bookmarksPanelRequested}
                onOpenChange={(open) => {
                  if (!open) clearBookmarksPanelRequest()
                  setBookmarksOpen(open)
                }}
              >
                <PopoverTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative size-11 shrink-0"
                    aria-label={
                      bookmarks.length > 0
                        ? `${t('reader.bookmarks')} (${formatNumber(locale, bookmarks.length)})`
                        : t('reader.bookmarks')
                    }
                  >
                    <Bookmark aria-hidden="true" className="size-4" />
                    {bookmarks.length > 0 ? (
                      <span className="absolute end-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[0.6875rem] font-semibold leading-none text-primary-foreground">
                        {formatNumber(locale, bookmarks.length)}
                      </span>
                    ) : null}
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80">
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-foreground">{t('reader.bookmarks')}</p>
                    {bookmarks.length === 0 ? (
                      <p className="py-6 text-center text-sm text-muted-foreground">
                        {t('reader.bookmarksEmpty')}
                      </p>
                    ) : (
                      <ScrollArea className="max-h-72 -me-2 scrollbar-subtle">
                        <ul className="space-y-1 pe-2">
                          {bookmarks.map((bookmark) => (
                            <li
                              key={bookmark.id}
                              className="flex items-center gap-1 rounded-lg hover:bg-accent"
                            >
                              <button
                                type="button"
                                className="flex min-w-0 flex-1 flex-col items-start gap-0.5 rounded-lg px-2.5 py-2 text-start outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                                onClick={() => handleBookmarkNavigate(bookmark)}
                              >
                                <span className="w-full truncate text-sm font-medium text-foreground">
                                  {getSuraName(bookmark.sura)}:{formatNumber(locale, bookmark.aya)}
                                </span>
                                {bookmark.preview ? (
                                  <span
                                    dir="auto"
                                    className="w-full line-clamp-2 text-xs leading-snug text-muted-foreground"
                                  >
                                    {bookmark.preview}
                                  </span>
                                ) : null}
                                <span className="w-full truncate text-xs text-muted-foreground">
                                  {formatDateTimeString(locale, bookmark.createdAt)}
                                </span>
                                {bookmark.note ? (
                                  <span
                                    dir="auto"
                                    className="w-full truncate text-xs italic text-muted-foreground"
                                  >
                                    {bookmark.note}
                                  </span>
                                ) : null}
                              </button>
                              <button
                                type="button"
                                aria-label={
                                  bookmark.note ? t('reader.editNote') : t('reader.addNote')
                                }
                                onClick={() => {
                                  setNoteTarget(bookmark)
                                  setNoteDialogOpen(true)
                                }}
                                className="flex size-11 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
                              >
                                <NotebookPen aria-hidden="true" className="size-4" />
                              </button>
                              <button
                                type="button"
                                aria-label={t('reader.removeBookmark')}
                                onClick={() => setBookmarkRemovalTarget(bookmark)}
                                className="flex size-11 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:ring-[3px] focus-visible:ring-ring/50"
                              >
                                <Trash2 aria-hidden="true" className="size-4" />
                              </button>
                            </li>
                          ))}
                        </ul>
                      </ScrollArea>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {/* Persistent sura navigation strip: always reachable without
                scrolling to the end of the surah. */}
            <nav
              aria-label={t('quran.quranTextTitle')}
              className="flex items-center gap-1 border-t border-border/60 px-2 py-1.5 sm:px-4"
            >
              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                disabled={sura <= 1}
                onClick={prevSura}
                aria-label={t('reader.prevSura')}
                title={sura > 1 ? `${t('reader.prevSura')}: ${getSuraName(sura - 1)}` : t('reader.prevSura')}
              >
                <ChevronLeft aria-hidden="true" className="size-5 rtl:-scale-x-100" />
              </Button>

              <Button
                variant="ghost"
                className="h-11 min-w-0 flex-1 gap-2.5 px-2.5"
                onClick={() => setSuraPickerOpen(true)}
                aria-haspopup="dialog"
                aria-label={t('reader.selectSura')}
              >
                <ChevronsUpDown aria-hidden="true" className="size-4 shrink-0 text-muted-foreground" />
                <span className="flex min-w-0 flex-1 flex-col items-start leading-tight">
                  <span className="w-full truncate text-sm font-medium">
                    {t('reader.sura')} {formatNumber(locale, sura)} · {currentSuraName}
                  </span>
                  <span className="w-full truncate text-xs text-muted-foreground">
                    {t('reader.ayahCount', {
                      count: formatNumber(locale, suraMeta?.ayahCount ?? 0),
                    })}
                  </span>
                </span>
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="size-11 shrink-0"
                disabled={sura >= SURA_COUNT}
                onClick={nextSura}
                aria-label={t('reader.nextSura')}
                title={
                  sura < SURA_COUNT
                    ? `${t('reader.nextSura')}: ${getSuraName(sura + 1)}`
                    : t('reader.nextSura')
                }
              >
                <ChevronRight aria-hidden="true" className="size-5 rtl:-scale-x-100" />
              </Button>
            </nav>
          </>
        )}
      </div>

      {/* Reading column (swipe navigation lives here) */}
      <div
        className="space-y-6 px-4 pt-6 pb-4 sm:px-6"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {readingBody}

        {/* Sura footer navigation (kept: a natural continuation at the end
            of a surah; the sticky strip above is the primary control). */}
        <div className="flex items-stretch gap-3">
          <Button
            variant="outline"
            className="h-11 min-w-0 flex-1 justify-start gap-2 px-3"
            disabled={sura <= 1}
            onClick={prevSura}
            aria-label={t('reader.prevSura')}
          >
            <ChevronLeft aria-hidden="true" className="size-4 shrink-0 rtl:-scale-x-100" />
            <span className="flex min-w-0 flex-col items-start leading-tight">
              <span className="text-xs font-normal text-muted-foreground">
                {t('reader.prevSura')}
              </span>
              {sura > 1 ? (
                <span className="w-full truncate text-sm font-medium">{getSuraName(sura - 1)}</span>
              ) : null}
            </span>
          </Button>
          <Button
            variant="outline"
            className="h-11 min-w-0 flex-1 justify-end gap-2 px-3"
            disabled={sura >= SURA_COUNT}
            onClick={nextSura}
            aria-label={t('reader.nextSura')}
          >
            <span className="flex min-w-0 flex-col items-end leading-tight">
              <span className="text-xs font-normal text-muted-foreground">
                {t('reader.nextSura')}
              </span>
              {sura < SURA_COUNT ? (
                <span className="w-full truncate text-sm font-medium">{getSuraName(sura + 1)}</span>
              ) : null}
            </span>
            <ChevronRight aria-hidden="true" className="size-4 shrink-0 rtl:-scale-x-100" />
          </Button>
        </div>
      </div>

      {/* Sura picker */}
      <SuraPicker
        open={suraPickerOpen}
        onOpenChange={setSuraPickerOpen}
        currentSura={sura}
        onSelect={setSura}
        localizedNames={localizedSuraNames ?? undefined}
      />

      {/* Reciter selector (verified EveryAyah recitation catalog) */}
      <ReciterSelectorDialog open={reciterDialogOpen} onOpenChange={setReciterDialogOpen} />

      {/* Recitation audio download (verified files, offline playback) */}
      <AudioDownloadDialog
        open={audioDownloadOpen}
        onOpenChange={setAudioDownloadOpen}
        seedAyah={jumpSeedAyah ?? readingLineAyah ?? 1}
      />

      {/* Translation narration download (verified QuranEnc recordings) */}
      {narrationCatalogEntry !== null ? (
        <TranslationAudioDownloadDialog
          open={narrationDownloadOpen}
          onOpenChange={setNarrationDownloadOpen}
          translationKey={narrationCatalogEntry.translationKey}
          audioName={narrationCatalogEntry.audioName}
          sura={sura}
          seedAyah={jumpSeedAyah ?? readingLineAyah ?? 1}
        />
      ) : null}

      {/* Muallim learning mode (dedicated Al-Husary teaching experience).
          Reads the live reading line; never moves the reading position. */}
      <MuallimLearningPanel
        open={learningPanelOpen}
        onOpenChange={setLearningPanelOpen}
        sura={sura}
        suraAyahCount={suraMeta?.ayahCount ?? 0}
        readingLineAyah={readingLineAyah}
      />

      {/* Jump to ayah */}
      <JumpToAyahDialog
        open={jumpDialogOpen}
        onOpenChange={setJumpDialogOpen}
        sura={sura}
        currentAyah={jumpSeedAyah}
        onJump={handleJumpToAyah}
      />

      {/* Bookmark note */}
      <BookmarkNoteDialog
        open={noteDialogOpen}
        onOpenChange={(open) => {
          setNoteDialogOpen(open)
          if (!open) setNoteTarget(null)
        }}
        bookmark={noteTarget}
        onSave={handleSaveNote}
      />

      {/* Bookmark removal confirmation (PROMPT 14: destructive action gated,
          still reversible afterwards via the toast's Undo). */}
      <AlertDialog
        open={bookmarkRemovalTarget !== null}
        onOpenChange={(open) => {
          if (!open) setBookmarkRemovalTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('reader.removeBookmarkTitle')}</AlertDialogTitle>
            <AlertDialogDescription>{t('reader.removeBookmarkDescription')}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (bookmarkRemovalTarget === null) return
                const removed = bookmarkRemovalTarget
                removeBookmark(removed.id)
                setBookmarkRemovalTarget(null)
                toast(t('reader.bookmarkRemoved'), {
                  action: { label: t('common.undo'), onClick: () => restoreBookmark(removed) },
                })
              }}
            >
              {t('common.remove')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Translation chooser */}
      <Dialog open={translationDialogOpen} onOpenChange={handleTranslationDialogOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t('reader.changeTranslation')}</DialogTitle>
            <DialogDescription>{t('reader.selectTranslation')}</DialogDescription>
          </DialogHeader>

          <div className="relative">
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              type="search"
              value={translationSearch}
              onChange={(event) => setTranslationSearch(event.target.value)}
              placeholder={t('common.search')}
              aria-label={t('common.search')}
              className="h-11 ps-9"
            />
          </div>

          {/* PROMPT 14: recent translations as one-tap chips (no search needed). */}
          {translationSearch.trim() === '' && recentTranslationItems.length > 0 ? (
            <div className="space-y-1.5">
              <span className="text-xs font-medium text-muted-foreground">
                {t('reader.recentTranslations')}
              </span>
              <div className="flex flex-wrap gap-2">
                {recentTranslationItems.map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => handleSelectTranslation(item.key)}
                    className="min-h-10 rounded-full border border-input bg-background px-3.5 text-sm text-foreground outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
                  >
                    <span dir="auto" className="truncate">
                      {item.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          <ScrollArea className="max-h-96 -me-2 scrollbar-subtle">
            <div className="space-y-1 pe-2">
              {filteredTranslations.map((item) => {
                const isCurrent = item.key === selectedTranslationKey
                return (
                  <button
                    key={item.key}
                    type="button"
                    aria-current={isCurrent ? 'true' : undefined}
                    onClick={() => handleSelectTranslation(item.key)}
                    className={cn(
                      'flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-start outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50',
                      isCurrent && 'bg-accent/60',
                    )}
                  >
                    <span className="flex min-w-0 flex-1 flex-col gap-0.5">
                      <span dir="auto" className="truncate text-sm font-medium text-foreground">
                        {item.title}
                      </span>
                      <span dir="auto" className="truncate text-xs text-muted-foreground">
                        {item.languageNativeName ?? item.languageName}
                      </span>
                      {item.publisher ? (
                        <span dir="auto" className="truncate text-xs text-muted-foreground">
                          {item.publisher}
                        </span>
                      ) : null}
                    </span>
                    {isCurrent ? (
                      <Check aria-hidden="true" className="size-4 shrink-0 text-primary" />
                    ) : null}
                  </button>
                )
              })}
              {filteredTranslations.length === 0 ? (
                <p className="px-3 py-8 text-center text-sm text-muted-foreground">
                  {t('common.none')}
                </p>
              ) : null}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </section>
  )
}
