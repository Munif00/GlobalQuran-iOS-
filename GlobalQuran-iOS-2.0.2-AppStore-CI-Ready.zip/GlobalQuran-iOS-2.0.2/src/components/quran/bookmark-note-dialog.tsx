'use client'

/**
 * Bookmark note dialog - an optional personal note for one bookmark.
 *
 * - The form mounts fresh each time the dialog opens and seeds itself from
 *   the bookmark's existing note; saving an empty value clears the note
 *   (honest "note cleared" feedback).
 * - The note is the user's own text: it is stored verbatim and never altered.
 */

import { useState } from 'react'

import type { ReaderBookmark } from '@/stores/reader-store'

import { useTranslation } from '@/i18n'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'

export interface BookmarkNoteDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** The bookmark being edited (kept mounted for the exit animation). */
  bookmark: ReaderBookmark | null
  onSave: (id: string, note: string) => void
}

/** The interactive form - mounts when the dialog opens, seeds from props. */
function BookmarkNoteForm({
  initialNote,
  onCancel,
  onSave,
}: {
  initialNote: string
  onCancel: () => void
  onSave: (note: string) => void
}) {
  const { t } = useTranslation()
  const [value, setValue] = useState(initialNote)

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault()
        onSave(value)
      }}
    >
      <div className="space-y-1.5">
        <Textarea
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder={t('reader.notePlaceholder')}
          rows={4}
          maxLength={500}
          aria-label={t('reader.noteTitle')}
          className="min-h-28"
        />
        {/* PROMPT 14 (Nielsen #1): visible character budget - the input would
            otherwise stop accepting text silently at the 500-character cap. */}
        <p aria-live="polite" className="text-end text-xs tabular-nums text-muted-foreground">
          {value.length}/500
        </p>
      </div>
      <DialogFooter className="gap-2">
        <Button type="button" variant="ghost" className="h-11" onClick={onCancel}>
          {t('common.cancel')}
        </Button>
        <Button type="submit" className="h-11">
          {t('common.save')}
        </Button>
      </DialogFooter>
    </form>
  )
}

export function BookmarkNoteDialog({
  open,
  onOpenChange,
  bookmark,
  onSave,
}: BookmarkNoteDialogProps) {
  const { t } = useTranslation()

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t('reader.noteTitle')}</DialogTitle>
          <DialogDescription>{t('reader.noteDescription')}</DialogDescription>
        </DialogHeader>

        {/* Mounts when the dialog opens (content unmounts while closed), so
            the textarea seeds itself from the bookmark's existing note. */}
        <BookmarkNoteForm
          initialNote={bookmark?.note ?? ''}
          onCancel={() => onOpenChange(false)}
          onSave={(note) => {
            if (bookmark) onSave(bookmark.id, note)
            onOpenChange(false)
          }}
        />
      </DialogContent>
    </Dialog>
  )
}
