'use client'

/**
 * Audio player bar (app-wide, fixed above the bottom navigation on mobile).
 *
 * Renders only while a playback session exists (an ayah was started). The
 * bar is mounted from the app shell, so recitation continues when the user
 * moves between screens - matching how a dedicated recitation app behaves.
 *
 * PROMPT 8 surface: the playback MODE (single-ayah / sequential), the REPEAT
 * controls (off / this ayah / range / surah, with a repeat count), the
 * sequential END boundary (surah end or a configured ending ayah) and the
 * playback speed are all visible and adjustable here. The active session's
 * live status (mode, range, current repetition, current pass) is shown as a
 * compact strip so the selected mode is always visually clear.
 *
 * Everything shown is real: the progress clock uses the audio element's
 * actual duration once loaded; errors are stated honestly (file missing at
 * the source / network / not verified) and pressing play retries the load;
 * the reciter and style always show the active selection.
 */

import { useCallback, useMemo, useState } from 'react'
import {
  ChevronsRight,
  Crosshair,
  Flag,
  Pause,
  Play,
  Repeat,
  SkipBack,
  SkipForward,
  Square,
  X,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { playbackEngine } from '@/services/audio/playback-engine'
import { getStyleDefinition } from '@/data/audio-styles'
import { getSuraMeta } from '@/data/sura-index'
import { formatClock, getSuraAyahCount } from '@/lib/audio/urls'
import { formatNumber } from '@/utils/format'
import {
  FINITE_REPEAT_OPTIONS,
  useAudioStore,
  type PlaybackSpeed,
  type RepeatCount,
  type RepeatMode,
} from '@/stores/audio-store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Slider } from '@/components/ui/slider'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'

const SPEED_STEPS: PlaybackSpeed[] = [0.75, 1, 1.25, 1.5]

function repeatCountLabel(count: RepeatCount): string {
  return count === 'infinite' ? '∞' : `×${count}`
}

export function AudioPlayerBar() {
  const { t, locale } = useTranslation()
  const playingSura = useAudioStore((s) => s.playingSura)
  const playingAyah = useAudioStore((s) => s.playingAyah)
  const isPlaying = useAudioStore((s) => s.isPlaying)
  const isBuffering = useAudioStore((s) => s.isBuffering)
  const error = useAudioStore((s) => s.error)
  const currentTime = useAudioStore((s) => s.currentTime)
  const duration = useAudioStore((s) => s.duration)
  const selectedStyleId = useAudioStore((s) => s.selectedStyleId)
  const sourceMode = useAudioStore((s) => s.sourceMode)
  const speed = useAudioStore((s) => s.speed)
  const playbackMode = useAudioStore((s) => s.playbackMode)
  const repeatMode = useAudioStore((s) => s.repeatMode)
  const repeatCount = useAudioStore((s) => s.repeatCount)
  const sequenceEndAyah = useAudioStore((s) => s.sequenceEndAyah)
  const session = useAudioStore((s) => s.session)
  const followAyah = useAudioStore((s) => s.followAyah)
  const toggleFollowAyah = useAudioStore((s) => s.toggleFollowAyah)
  const setSpeed = useAudioStore((s) => s.setSpeed)
  const setPlaybackMode = useAudioStore((s) => s.setPlaybackMode)
  const setRepeatMode = useAudioStore((s) => s.setRepeatMode)
  const setRepeatCount = useAudioStore((s) => s.setRepeatCount)
  const setSequenceEndAyah = useAudioStore((s) => s.setSequenceEndAyah)

  const [endPopoverOpen, setEndPopoverOpen] = useState(false)
  const [endDraft, setEndDraft] = useState('')

  const style = useMemo(
    () => (selectedStyleId ? getStyleDefinition(selectedStyleId) : undefined),
    [selectedStyleId],
  )
  const suraMeta = playingSura !== null ? getSuraMeta(playingSura) : undefined

  /** Sura the end boundary applies to (the session's sura while active). */
  const endReferenceSura = session?.pressSurah ?? playingSura ?? 1
  const endMaxAyah = Math.max(1, getSuraAyahCount(endReferenceSura))

  /** The end control is only meaningful when playback can advance. */
  const endControlRelevant =
    playbackMode === 'sequential' || repeatMode === 'range' || repeatMode === 'sura'

  const handleSeek = useCallback((values: number[]) => {
    if (values.length > 0) playbackEngine.seek(values[0])
  }, [])

  const cycleSpeed = useCallback(() => {
    const index = SPEED_STEPS.indexOf(speed)
    const next = SPEED_STEPS[(index + 1) % SPEED_STEPS.length]
    setSpeed(next)
    playbackEngine.applySpeed(next)
  }, [speed, setSpeed])

  const openEndPopover = useCallback(
    (open: boolean) => {
      if (open) setEndDraft(sequenceEndAyah !== null ? String(sequenceEndAyah) : '')
      setEndPopoverOpen(open)
    },
    [sequenceEndAyah],
  )

  const applyEndDraft = useCallback(() => {
    const parsed = Number(endDraft)
    if (endDraft.trim() !== '' && Number.isInteger(parsed) && parsed >= 1 && parsed <= endMaxAyah) {
      setSequenceEndAyah(parsed)
      setEndPopoverOpen(false)
    }
  }, [endDraft, endMaxAyah, setSequenceEndAyah])

  if (playingSura === null || playingAyah === null) return null

  const positionLabel = t('audio.suraAyah', {
    sura: formatNumber(locale, playingSura),
    ayah: formatNumber(locale, playingAyah),
  })

  /* Live session status strip - only when it carries real information. */
  const statusParts: string[] = []
  if (session) {
    statusParts.push(
      session.mode === 'sequential' ? t('audio.statusSequential') : t('audio.statusSingle'),
    )
    if (session.mode === 'sequential') {
      statusParts.push(
        t('audio.statusRange', {
          from: `${formatNumber(locale, session.startSurah)}:${formatNumber(locale, session.startAyah)}`,
          to: `${formatNumber(locale, session.endSurah)}:${formatNumber(locale, session.endAyah)}`,
        }),
      )
    }
    if (session.ayahPlayCount !== 1) {
      statusParts.push(
        t('audio.statusRep', {
          current: formatNumber(locale, session.ayahPlay),
          total: session.ayahPlayCount === 'infinite' ? '∞' : formatNumber(locale, session.ayahPlayCount),
        }),
      )
    }
    if (session.mode === 'sequential' && session.passCount !== 1) {
      statusParts.push(
        t('audio.statusPass', {
          current: formatNumber(locale, session.pass),
          total: session.passCount === 'infinite' ? '∞' : formatNumber(locale, session.passCount),
        }),
      )
    }
  }

  const repeatModeLabel: Record<RepeatMode, string> = {
    off: t('audio.repeatOff'),
    ayah: t('audio.repeatAyahMode'),
    range: t('audio.repeatRangeMode'),
    sura: t('audio.repeatSuraMode'),
  }

  return (
    <div
      role="region"
      aria-label={t('audio.playerLabel')}
      className="border-t bg-background/95 shadow-lg backdrop-blur"
    >
      <div className="mx-auto max-w-6xl px-3 py-2 sm:px-6">
        {/* Row 1: identity + primary controls */}
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 truncate text-sm font-medium text-foreground">
              <span className="truncate">
                {positionLabel}
                {suraMeta ? (
                  <span dir="rtl" lang="ar" className="text-quranic ms-2 text-muted-foreground">
                    {suraMeta.nameArabic}
                  </span>
                ) : null}
              </span>
              {sourceMode === 'local' ? (
                <Badge
                  variant="outline"
                  title={t('audio.offlinePlaying')}
                  className="border-success/40 bg-success/10 text-success"
                >
                  {t('audio.offlineBadge')}
                </Badge>
              ) : null}
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {style ? `${style.reciterName} · ${style.styleLabel}` : t('audio.noReciterSelected')}
            </p>
          </div>

          {/* PROMPT 14: 8px spacing between the 44px transport controls. */}
          <div className="flex shrink-0 items-center gap-2">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-11"
              onClick={() => void playbackEngine.prevAyah()}
              aria-label={t('audio.prevAyah')}
              disabled={playingSura <= 1 && playingAyah <= 1}
            >
              <SkipBack aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>

            <Button
              type="button"
              size="icon"
              className="size-11 rounded-full"
              onClick={() => playbackEngine.togglePlayPause()}
              aria-label={isPlaying ? t('audio.pause') : t('audio.play')}
            >
              {isBuffering && error === null ? (
                <span
                  aria-hidden="true"
                  className="size-4 animate-spin rounded-full border-2 border-current border-t-transparent"
                />
              ) : isPlaying ? (
                <Pause aria-hidden="true" className="size-5" />
              ) : (
                <Play aria-hidden="true" className="size-5 rtl:-scale-x-100" />
              )}
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-11"
              onClick={() => void playbackEngine.nextAyah()}
              aria-label={t('audio.nextAyah')}
              disabled={playingSura >= 114 && playingAyah >= (getSuraMeta(playingSura)?.ayahCount ?? 1)}
            >
              <SkipForward aria-hidden="true" className="size-4 rtl:-scale-x-100" />
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-11"
              onClick={() => playbackEngine.stop()}
              aria-label={t('audio.stop')}
            >
              <X aria-hidden="true" className="size-4" />
            </Button>
          </div>
        </div>

        {/* Live session status: mode · range · repetition · pass */}
        {statusParts.length > 0 ? (
          <p className="mt-1 truncate text-[0.6875rem] text-muted-foreground">
            {statusParts.join(' · ')}
          </p>
        ) : null}

        {/* Row 2: progress */}
        <div className="mt-1.5 flex items-center gap-2">
          <span className="w-10 shrink-0 text-end text-[0.6875rem] tabular-nums text-muted-foreground">
            {formatClock(currentTime)}
          </span>
          <Slider
            className="flex-1"
            value={[Number.isFinite(duration) && duration > 0 ? Math.min(currentTime, duration) : 0]}
            max={Number.isFinite(duration) && duration > 0 ? duration : 1}
            step={0.5}
            onValueChange={handleSeek}
            disabled={!(Number.isFinite(duration) && duration > 0)}
            aria-label={t('audio.seek')}
          />
          <span className="w-10 shrink-0 text-[0.6875rem] tabular-nums text-muted-foreground">
            {Number.isFinite(duration) && duration > 0 ? formatClock(duration) : '–:––'}
          </span>
        </div>

        {/* Row 3: honest error, or the playback configuration */}
        {error !== null ? (
          <p className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-destructive">
            <Square aria-hidden="true" className="size-3" />
            {error === 'file-missing'
              ? t('audio.errorFileMissing')
              : error === 'network'
                ? t('audio.errorNetwork')
                : error === 'style-unavailable'
                  ? t('audio.errorStyleUnavailable')
                  : t('audio.errorUnknown')}
          </p>
        ) : (
          /* PROMPT 14: hidden scrollbar + soft edge fades so the off-screen
             controls on the right are discoverable, with every control at a
             comfortable target size. */
          <div className="mt-1.5 flex items-center gap-1.5 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden [mask-image:linear-gradient(to_right,transparent_0,black_12px,black_calc(100%-12px),transparent_100%)]">
            {/* Playback mode: single-ayah (default) or sequential advance. */}
            <div
              role="group"
              aria-label={t('audio.modeLabel')}
              className="flex h-11 shrink-0 items-center rounded-md border bg-background p-0.5"
            >
              <button
                type="button"
                aria-pressed={playbackMode === 'single'}
                onClick={() => setPlaybackMode('single')}
                className={cn(
                  'flex h-10 items-center gap-1 rounded-[0.25rem] px-2.5 text-xs transition-colors outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                  playbackMode === 'single'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <Square aria-hidden="true" className="size-3" />
                {t('audio.modeSingle')}
              </button>
              <button
                type="button"
                aria-pressed={playbackMode === 'sequential'}
                onClick={() => setPlaybackMode('sequential')}
                className={cn(
                  'flex h-10 items-center gap-1 rounded-[0.25rem] px-2.5 text-xs transition-colors outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                  playbackMode === 'sequential'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <ChevronsRight aria-hidden="true" className="size-3 rtl:-scale-x-100" />
                {t('audio.modeSequential')}
              </button>
            </div>

            {/* Repeat mode: off / this ayah / range / surah. */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  aria-pressed={repeatMode !== 'off'}
                  className={cn(
                    'h-11 shrink-0 gap-1.5 px-2.5 text-xs',
                    repeatMode !== 'off' && 'border-primary/40 text-primary',
                  )}
                >
                  <Repeat aria-hidden="true" className="size-3.5" />
                  <span className="whitespace-nowrap">
                    {t('audio.repeatLabel')} · {repeatModeLabel[repeatMode]}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="min-w-44">
                <DropdownMenuRadioGroup
                  value={repeatMode}
                  onValueChange={(value) => setRepeatMode(value as RepeatMode)}
                >
                  <DropdownMenuRadioItem value="off">{t('audio.repeatOff')}</DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="ayah">
                    {t('audio.repeatAyahMode')}
                  </DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="range">
                    {t('audio.repeatRangeMode')}
                  </DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="sura">
                    {t('audio.repeatSuraMode')}
                  </DropdownMenuRadioItem>
                </DropdownMenuRadioGroup>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Repeat count (only while a repetition mode is active). */}
            {repeatMode !== 'off' ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-11 min-w-14 shrink-0 px-2.5 text-xs tabular-nums"
                    aria-label={`${t('audio.repeatCountLabel')} ${repeatCountLabel(repeatCount)}`}
                  >
                    {repeatCountLabel(repeatCount)}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="min-w-32">
                  <DropdownMenuRadioGroup
                    value={String(repeatCount)}
                    onValueChange={(value) =>
                      setRepeatCount(value === 'infinite' ? 'infinite' : (Number(value) as RepeatCount))
                    }
                  >
                    {FINITE_REPEAT_OPTIONS.map((count) => (
                      <DropdownMenuRadioItem key={count} value={String(count)}>
                        ×{formatNumber(locale, count)}
                      </DropdownMenuRadioItem>
                    ))}
                    <DropdownMenuRadioItem value="infinite">
                      {t('audio.countEndless')}
                    </DropdownMenuRadioItem>
                  </DropdownMenuRadioGroup>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : null}

            {/* Sequential end boundary: surah end or a configured ending ayah. */}
            {endControlRelevant ? (
              <Popover open={endPopoverOpen} onOpenChange={openEndPopover}>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-11 shrink-0 gap-1.5 px-2.5 text-xs"
                    aria-label={t('audio.endLabel')}
                  >
                    <Flag aria-hidden="true" className="size-3.5" />
                    <span className="whitespace-nowrap">
                      {t('audio.endLabel')} ·{' '}
                      {sequenceEndAyah === null
                        ? t('audio.endAtSuraEnd')
                        : t('audio.endAtAyah', { ayah: formatNumber(locale, sequenceEndAyah) })}
                    </span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="start" className="w-72">
                  <div className="space-y-3">
                    <p className="text-sm font-semibold text-foreground">{t('audio.endTitle')}</p>
                    <p className="text-xs text-muted-foreground">
                      {t('audio.endAyahHint', { max: formatNumber(locale, endMaxAyah) })}
                    </p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={1}
                        max={endMaxAyah}
                        step={1}
                        inputMode="numeric"
                        value={endDraft}
                        onChange={(event) => setEndDraft(event.target.value)}
                        placeholder={`1–${endMaxAyah}`}
                        aria-label={t('audio.endAyahInput')}
                        aria-invalid={
                          endDraft.trim() !== '' &&
                          !(Number.isInteger(Number(endDraft)) && Number(endDraft) >= 1 && Number(endDraft) <= endMaxAyah)
                        }
                        className="h-11 w-24"
                      />
                      <Button type="button" size="sm" className="h-11" onClick={applyEndDraft}>
                        {t('audio.endApply')}
                      </Button>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="h-11 w-full"
                      onClick={() => {
                        setSequenceEndAyah(null)
                        setEndPopoverOpen(false)
                      }}
                    >
                      {t('audio.endUseSuraEnd')}
                    </Button>
                    {endDraft.trim() !== '' &&
                    !(Number.isInteger(Number(endDraft)) && Number(endDraft) >= 1 && Number(endDraft) <= endMaxAyah) ? (
                      <p className="text-xs font-medium text-destructive">
                        {t('audio.endAyahInvalid', { max: formatNumber(locale, endMaxAyah) })}
                      </p>
                    ) : null}
                  </div>
                </PopoverContent>
              </Popover>
            ) : null}

            <div className="shrink-0 flex-1" />

            {/* PROMPT 14: follow-along auto-scroll toggle - the store supported
                it all along, it just had no visible control. */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              aria-pressed={followAyah}
              className={cn(
                'h-11 shrink-0 gap-1.5 px-2.5 text-xs',
                followAyah && 'border-primary/40 text-primary',
              )}
              onClick={toggleFollowAyah}
            >
              <Crosshair aria-hidden="true" className="size-3.5" />
              <span className="whitespace-nowrap">{t('reader.followRecitation')}</span>
            </Button>

            {/* Playback speed */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-11 min-w-14 shrink-0 px-2.5 text-xs tabular-nums"
              onClick={cycleSpeed}
              aria-label={`${t('audio.speed')}: ${formatNumber(locale, speed)}×`}
            >
              {formatNumber(locale, speed)}×
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
