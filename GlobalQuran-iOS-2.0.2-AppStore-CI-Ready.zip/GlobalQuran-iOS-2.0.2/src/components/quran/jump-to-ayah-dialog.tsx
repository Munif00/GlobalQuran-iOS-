'use client'

/**
 * Jump-to-ayah dialog.
 *
 * - Lets the user open a specific ayah of the current surah by number.
 * - The input is validated against the structural sura index (the authentic
 *   dataset derived from the official QuranEnc Hafs v20 package) - invalid
 *   numbers are rejected with a clear message, never silently clamped and
 *   never accepted beyond the real ayah count.
 * - The form mounts fresh each time the dialog opens and seeds itself with
 *   the ayah currently at the reading line, so the dialog also answers
 *   "where am I?" and makes returning to the position trivial.
 */

import { useMemo, useState } from 'react'
import { Hash } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getSuraMeta } from '@/data/sura-index'
import { formatNumber } from '@/utils/format'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export interface JumpToAyahDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Current sura (validated 1..114 by the caller). */
  sura: number
  /** Ayah currently at the reading line, when known (seeded into the input). */
  currentAyah: number | null
  onJump: (ayah: number) => void
}

/** The interactive form - mounts when the dialog opens, seeds from props. */
function JumpToAyahForm({
  initialAyah,
  ayahCount,
  onCancel,
  onJump,
}: {
  initialAyah: number | null
  ayahCount: number | null
  onCancel: () => void
  onJump: (ayah: number) => void
}) {
  const { t, locale } = useTranslation()
  const [value, setValue] = useState(
    initialAyah !== null && initialAyah > 0 ? String(initialAyah) : '',
  )
  const [error, setError] = useState<string | null>(null)

  /** Validate the raw input against the real dataset; returns the number or null. */
  const validate = (raw: string): number | null => {
    const trimmed = raw.trim()
    if (trimmed.length === 0) return null
    if (!/^\d{1,3}$/.test(trimmed)) return null
    const parsed = Number(trimmed)
    if (!Number.isInteger(parsed) || parsed < 1) return null
    if (ayahCount === null || parsed > ayahCount) return null
    return parsed
  }

  const handleSubmit = () => {
    const parsed = validate(value)
    if (parsed === null) {
      setError(t('reader.ayahInvalid', { max: formatNumber(locale, ayahCount ?? 0) }))
      return
    }
    onJump(parsed)
  }

  return (
    <form
      className="space-y-3"
      /* Native constraint validation is disabled so the explicit, localized
       * error message below always shows instead of a browser tooltip. */
      noValidate
      onSubmit={(event) => {
        event.preventDefault()
        handleSubmit()
      }}
    >
      <div className="space-y-2">
        <label htmlFor="jump-ayah-input" className="block text-sm font-medium text-foreground">
          {t('reader.ayahNumber')}
        </label>
        <Input
          id="jump-ayah-input"
          type="number"
          inputMode="numeric"
          min={1}
          max={ayahCount ?? undefined}
          step={1}
          value={value}
          onChange={(event) => {
            setValue(event.target.value)
            if (error !== null) setError(null)
          }}
          aria-invalid={error !== null}
          aria-describedby={error !== null ? 'jump-ayah-error' : 'jump-ayah-hint'}
          className="h-11"
          autoComplete="off"
        />
        <p
          id={error !== null ? undefined : 'jump-ayah-hint'}
          className="text-xs text-muted-foreground"
        >
          {t('reader.ayahRangeHint', { max: formatNumber(locale, ayahCount ?? 0) })}
          {initialAyah !== null && initialAyah > 0 ? (
            <>
              {' · '}
              {t('reader.currentPosition', { ayah: formatNumber(locale, initialAyah) })}
            </>
          ) : null}
        </p>
        {error !== null ? (
          <p id="jump-ayah-error" role="alert" className="text-sm text-destructive">
            {error}
          </p>
        ) : null}
      </div>

      <DialogFooter className="gap-2">
        <Button type="button" variant="ghost" className="h-11" onClick={onCancel}>
          {t('common.cancel')}
        </Button>
        <Button type="submit" className="h-11" disabled={value.trim().length === 0}>
          {t('reader.goToAyah')}
        </Button>
      </DialogFooter>
    </form>
  )
}

export function JumpToAyahDialog({
  open,
  onOpenChange,
  sura,
  currentAyah,
  onJump,
}: JumpToAyahDialogProps) {
  const { t } = useTranslation()

  /** Authentic ayah count of the current sura from the structural index. */
  const ayahCount = useMemo(() => getSuraMeta(sura)?.ayahCount ?? null, [sura])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Hash aria-hidden="true" className="size-4 text-primary" />
            {t('reader.jumpToAyah')}
          </DialogTitle>
          <DialogDescription>{t('reader.jumpToAyahDescription')}</DialogDescription>
        </DialogHeader>

        {/* Mounts when the dialog opens (content unmounts while closed), so
            the input seeds itself from the current reading position. */}
        <JumpToAyahForm
          initialAyah={currentAyah}
          ayahCount={ayahCount}
          onCancel={() => onOpenChange(false)}
          onJump={(ayah) => {
            onOpenChange(false)
            onJump(ayah)
          }}
        />
      </DialogContent>
    </Dialog>
  )
}
