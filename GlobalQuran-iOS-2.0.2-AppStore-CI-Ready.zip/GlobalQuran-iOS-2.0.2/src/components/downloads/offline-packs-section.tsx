'use client'

/**
 * Offline translations section (Downloads screen).
 *
 * Lists every translation with a locally stored offline pack - real data
 * from the quran-cache pack indexes, joined with the live catalog for
 * titles and languages. "Read" opens the in-app reader (works without a
 * connection); "Remove" deletes the stored suras behind an explicit
 * confirmation.
 */

import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { BookOpen, Trash2, WifiOff } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getTranslationsCatalog } from '@/services/api/catalog-api'
import { describeApiError } from '@/services/api/errors'
import { removeOfflinePack } from '@/services/downloads/offline-pack-manager'
import { useOfflinePacks } from '@/hooks/use-offline-packs'
import { useReaderStore } from '@/stores/reader-store'
import { useNavigationStore } from '@/stores/navigation-store'
import { formatBytes, formatDateTimeString, formatNumber } from '@/utils/format'

import { EmptyState } from '@/components/design-system/empty-state'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'

export function OfflinePacksSection() {
  const { t, locale } = useTranslation()
  const openReader = useReaderStore((s) => s.openReader)
  const navigate = useNavigationStore((s) => s.navigate)
  const { statuses, refresh } = useOfflinePacks()
  const [removingKey, setRemovingKey] = useState<string | null>(null)

  // Catalog join for titles/languages (falls back to the offline cache copy).
  const catalogQuery = useQuery({
    queryKey: ['translations-catalog', locale],
    queryFn: () => getTranslationsCatalog(locale),
    staleTime: 300_000,
    retry: 1,
    networkMode: 'always',
  })

  const catalogByKey = useMemo(() => {
    const map = new Map<string, { title: string; language: string | null }>()
    for (const item of catalogQuery.data?.items ?? []) {
      map.set(item.key, {
        title: item.title,
        language: item.languageNativeName ?? item.languageName,
      })
    }
    return map
  }, [catalogQuery.data])

  const packs = useMemo(
    () =>
      Object.values(statuses ?? {})
        .filter((status) => status.cachedSuras > 0)
        .sort((a, b) => (b.updatedAt ?? '').localeCompare(a.updatedAt ?? '')),
    [statuses],
  )

  const handleRemove = async (translationKey: string) => {
    setRemovingKey(translationKey)
    try {
      await removeOfflinePack(translationKey)
      await refresh()
      toast(t('quran.offline.removed'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setRemovingKey(null)
    }
  }

  if (statuses === null) return null

  return (
    <section aria-labelledby="offline-packs-heading" className="space-y-3">
      <h2
        id="offline-packs-heading"
        className="text-sm font-semibold uppercase tracking-wide text-muted-foreground"
      >
        {t('downloads.offlinePacksSection')}
      </h2>

      {packs.length === 0 ? (
        <EmptyState
          icon={WifiOff}
          title={t('downloads.offlinePacksEmpty')}
          description={t('downloads.offlinePacksEmptyDescription')}
        />
      ) : (
        <ul className="space-y-3">
          {packs.map((pack) => {
            const meta = catalogByKey.get(pack.translationKey) ?? null
            return (
              <li key={pack.translationKey}>
                <Card>
                  <CardContent className="flex flex-wrap items-center gap-3 p-4">
                    <span
                      aria-hidden="true"
                      className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-success/10 text-success"
                    >
                      <BookOpen className="size-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p dir="auto" className="truncate text-sm font-medium text-foreground">
                        {meta?.title ?? pack.translationKey}
                      </p>
                      <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
                        {meta?.language ? (
                          <span dir="auto">{meta.language}</span>
                        ) : null}
                        <span aria-hidden="true">·</span>
                        <span>
                          {pack.complete
                            ? t('quran.offline.statusReady')
                            : t('quran.offline.statusPartial', {
                                cached: formatNumber(locale, pack.cachedSuras),
                                total: formatNumber(locale, pack.totalSuras),
                              })}
                        </span>
                        {pack.approxBytes > 0 ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="tabular-nums">
                              {formatBytes(locale, pack.approxBytes)}
                            </span>
                          </>
                        ) : null}
                        {pack.updatedAt ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{formatDateTimeString(locale, pack.updatedAt)}</span>
                          </>
                        ) : null}
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-wrap items-center gap-2">
                      <Button
                        variant="outline"
                        className="h-11"
                        onClick={() => {
                          openReader({ translationKey: pack.translationKey })
                          // The reader lives on the Quran screen - follow the
                          // same explicit navigation pattern as Home/Profile.
                          navigate('quran')
                        }}
                      >
                        <BookOpen aria-hidden="true" className="size-4" />
                        {t('downloads.offlinePacksRead')}
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            className="h-11 text-destructive hover:bg-destructive/10 hover:text-destructive"
                            disabled={removingKey === pack.translationKey}
                          >
                            <Trash2 aria-hidden="true" className="size-4" />
                            {t('downloads.offlinePacksRemove')}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              {t('downloads.offlinePacksRemoveConfirmTitle')}
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              {t('downloads.offlinePacksRemoveConfirmDescription')}
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
                            <AlertDialogAction
                              className="h-11"
                              onClick={() => void handleRemove(pack.translationKey)}
                            >
                              {t('common.remove')}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              </li>
            )
          })}
        </ul>
      )}
    </section>
  )
}
