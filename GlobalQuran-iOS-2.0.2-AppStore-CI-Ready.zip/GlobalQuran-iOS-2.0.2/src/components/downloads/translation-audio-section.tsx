'use client'

/**
 * Translation narration audio section (Downloads screen, PROMPT 10).
 *
 * The offline manager for downloaded recorded translation narration:
 * - pick one of the VERIFIED narration translations (only editions the
 *   QuranEnc audio catalog actually confirmed are offered),
 * - download a surah, a juz, or the complete narration package - each
 *   option shows the size from the verified plan before it starts (exact
 *   for surah/juz; a clearly-labeled estimate for the complete package);
 *   the complete package is only offered when the source manifest covers
 *   every ayah,
 * - see the honest per-sura offline status (a sura is "complete" only when
 *   every ayah is stored AND verified - never merely because a download
 *   once ran),
 * - re-verify stored files (recorded sizes are checked against the real
 *   payloads; failures are marked for re-download),
 * - delete a surah's narration or the whole translation's narration -
 *   narration lives in its OWN storage, so Quran text, translations and
 *   recitation audio are never touched,
 * - the source attribution of every recording is preserved and shown.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  CheckCircle2,
  CircleAlert,
  HardDriveDownload,
  Languages,
  ShieldCheck,
  Trash2,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getTranslationAudioBatchPlan, getTranslationAudioCatalog } from '@/services/api/audio-api'
import { describeApiError } from '@/services/api/errors'
import {
  enqueueTranslationAudioBatch,
  type TranslationAudioBatchSpec,
} from '@/services/downloads/translation-audio-download-manager'
import { getTranslationAudioLibrary } from '@/services/storage/translation-audio-library'
import { useReaderStore } from '@/stores/reader-store'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { SURA_INDEX } from '@/data/sura-index'
import { JUZ_COUNT } from '@/data/juz-index'
import type { TranslationAudioOfflineStatus } from '@/types'
import { formatBytes, formatNumber } from '@/utils/format'

import { EmptyState } from '@/components/design-system/empty-state'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { cn } from '@/lib/utils'

/** Total numbered ayat - the complete package requirement. */
const TOTAL_QURAN_AYAT = 6236

export function TranslationAudioSection() {
  const { t, locale } = useTranslation()
  const selectedTranslationKey = useReaderStore((s) => s.selectedTranslationKey)
  const activeIds = useDownloadManagerStore((s) => s.activeIds)

  /** The verified narration catalog (dynamic - no hardcoded language list). */
  const catalogQuery = useQuery({
    queryKey: ['translation-audio-catalog'],
    queryFn: getTranslationAudioCatalog,
    staleTime: 24 * 60 * 60_000,
    retry: 1,
  })

  const catalog = useMemo(
    () => catalogQuery.data?.translations ?? [],
    [catalogQuery.data],
  )

  /** The translation this section manages (defaults to the reader's). */
  const [translationKey, setTranslationKey] = useState<string | null>(null)
  const [status, setStatus] = useState<TranslationAudioOfflineStatus | null>(null)
  const [suraPick, setSuraPick] = useState('1')
  const [juzPick, setJuzPick] = useState('1')
  const [busySura, setBusySura] = useState<number | null>(null)
  const [verifyingSura, setVerifyingSura] = useState<number | null>(null)

  useEffect(() => {
    if (translationKey === null && catalog.length > 0) {
      setTranslationKey(
        catalog.some((entry) => entry.translationKey === selectedTranslationKey)
          ? selectedTranslationKey
          : catalog[0].translationKey,
      )
    }
  }, [translationKey, catalog, selectedTranslationKey])

  const entry = useMemo(
    () => catalog.find((item) => item.translationKey === translationKey) ?? null,
    [catalog, translationKey],
  )

  const refreshStatus = useCallback(async () => {
    if (translationKey === null) {
      setStatus(null)
      return
    }
    try {
      setStatus(await getTranslationAudioLibrary().getStatus(translationKey))
    } catch {
      setStatus(null)
    }
  }, [translationKey])

  useEffect(() => {
    void refreshStatus()
  }, [refreshStatus])

  // Refresh whenever a batch finishes (activeIds shrinks) or changes.
  const activeCount = activeIds.length
  useEffect(() => {
    if (activeCount === 0) void refreshStatus()
  }, [activeCount, refreshStatus])

  /** The complete package may only be offered when the source covers all. */
  const completeOfferable = entry !== null && entry.availableFiles >= TOTAL_QURAN_AYAT

  /* Sura + juz plan previews - fetched for the picked sura/juz only. */
  const [suraPlan, setSuraPlan] = useState<{ bytes: number; files: number } | null>(null)
  const [juzPlan, setJuzPlan] = useState<{ bytes: number; files: number } | null>(null)
  const [completePlan, setCompletePlan] = useState<{ bytes: number; estimated: boolean } | null>(
    null,
  )
  useEffect(() => {
    let cancelled = false
    setSuraPlan(null)
    if (translationKey === null) return
    getTranslationAudioBatchPlan({
      translationKey,
      kind: 'sura',
      sura: Number(suraPick),
    })
      .then((plan) => {
        if (!cancelled) setSuraPlan({ bytes: plan.totalBytes, files: plan.totalFiles })
      })
      .catch(() => undefined)
    return () => {
      cancelled = true
    }
  }, [translationKey, suraPick])

  useEffect(() => {
    let cancelled = false
    setJuzPlan(null)
    if (translationKey === null) return
    getTranslationAudioBatchPlan({ translationKey, kind: 'juz', juz: Number(juzPick) })
      .then((plan) => {
        if (!cancelled) setJuzPlan({ bytes: plan.totalBytes, files: plan.totalFiles })
      })
      .catch(() => undefined)
    return () => {
      cancelled = true
    }
  }, [translationKey, juzPick])

  useEffect(() => {
    let cancelled = false
    setCompletePlan(null)
    if (translationKey === null || !completeOfferable) return
    getTranslationAudioBatchPlan({ translationKey, kind: 'complete' })
      .then((plan) => {
        if (!cancelled) setCompletePlan({ bytes: plan.totalBytes, estimated: plan.sizeEstimated })
      })
      .catch(() => undefined)
    return () => {
      cancelled = true
    }
  }, [translationKey, completeOfferable])

  /** Shared enqueue handling with honest toasts. */
  const startBatch = useCallback(
    async (spec: TranslationAudioBatchSpec) => {
      const result = await enqueueTranslationAudioBatch(spec)
      if (result.ok) {
        toast(t('audio.download.started'), {
          description: t('audio.download.startedDescription'),
        })
        return
      }
      if (result.reason === 'already-downloaded') {
        toast.info(t('audio.download.alreadyDownloadedTitle'), {
          description: t('audio.download.alreadyDownloadedDescription'),
        })
        return
      }
      if (result.reason === 'duplicate-active') {
        toast.info(t('audio.download.duplicateActiveTitle'), {
          description: t('audio.download.duplicateActiveDescription'),
        })
        return
      }
      if (result.reason === 'incomplete-source') {
        toast.info(t('audio.download.incompleteSourceTitle'), {
          description: t('audio.download.incompleteSourceDescription'),
        })
        return
      }
      toast.error(t('audio.download.planUnavailable'))
    },
    [t],
  )

  const handleDownloadSura = () => {
    if (translationKey === null) return
    void startBatch({ translationKey, kind: 'sura', sura: Number(suraPick) })
  }

  const handleDownloadJuz = () => {
    if (translationKey === null) return
    void startBatch({ translationKey, kind: 'juz', juz: Number(juzPick) })
  }

  const handleDownloadComplete = () => {
    if (translationKey === null || !completeOfferable) return
    void startBatch({ translationKey, kind: 'complete' })
  }

  const handleDeleteSura = async (sura: number) => {
    if (translationKey === null) return
    setBusySura(sura)
    try {
      await getTranslationAudioLibrary().deleteSura(translationKey, sura)
      await refreshStatus()
      toast(t('common.updated'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setBusySura(null)
    }
  }

  const handleVerifySura = async (sura: number) => {
    if (translationKey === null) return
    setVerifyingSura(sura)
    try {
      const result = await getTranslationAudioLibrary().verifySura(translationKey, sura)
      await refreshStatus()
      if (result.failed > 0) {
        toast.warning(
          t('narration.lib.verifyFailed', { count: formatNumber(locale, result.failed) }),
        )
      } else {
        toast(t('narration.lib.verifyOk'))
      }
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setVerifyingSura(null)
    }
  }

  const handleDeleteAll = async () => {
    if (translationKey === null) return
    try {
      await getTranslationAudioLibrary().deleteTranslation(translationKey)
      await refreshStatus()
      toast(t('common.updated'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    }
  }

  return (
    <section aria-labelledby="narration-offline-heading" className="space-y-3">
      <h2
        id="narration-offline-heading"
        className="text-sm font-semibold uppercase tracking-wide text-muted-foreground"
      >
        {t('narration.lib.sectionTitle')}
      </h2>

      <Card>
        <CardContent className="space-y-4 p-4">
          <p className="text-xs leading-relaxed text-muted-foreground">
            {t('narration.lib.sectionDescription')}
          </p>

          {catalogQuery.isPending ? (
            <p className="text-xs text-muted-foreground">{t('audio.download.planLoading')}</p>
          ) : catalog.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              {t('narration.lib.pickTranslation')}
            </p>
          ) : (
            <>
              {/* Translation picker + delete-all */}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
                <div className="flex w-full min-w-0 flex-col gap-1.5 sm:max-w-72">
                  <Label htmlFor="narration-lib-translation">
                    {t('narration.lib.translationLabel')}
                  </Label>
                  <Select
                    value={translationKey ?? ''}
                    onValueChange={(value) => setTranslationKey(value)}
                  >
                    <SelectTrigger id="narration-lib-translation" className="h-11 w-full">
                      <SelectValue placeholder={t('narration.lib.pickTranslation')} />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                      {catalog.map((item) => (
                        <SelectItem key={item.translationKey} value={item.translationKey}>
                          <span dir="auto" className="truncate">
                            {item.audioName}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1" />
                {status !== null && status.storedFiles > 0 ? (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="h-11 text-destructive hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 aria-hidden="true" className="size-4" />
                        {t('narration.lib.deleteAll')}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          {t('narration.lib.deleteAllConfirmTitle')}
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          {t('narration.lib.deleteAllConfirmDescription')}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="h-11">
                          {t('common.cancel')}
                        </AlertDialogCancel>
                        <AlertDialogAction className="h-11" onClick={() => void handleDeleteAll()}>
                          {t('common.delete')}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                ) : null}
              </div>

              {/* Source attribution + completeness */}
              {entry !== null ? (
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="outline" className="gap-1">
                    <Languages aria-hidden="true" className="size-3" />
                    <span dir="auto">{entry.languageName ?? entry.languageIso ?? ''}</span>
                  </Badge>
                  <Badge
                    variant="outline"
                    className={cn(
                      entry.complete
                        ? 'border-success/40 bg-success/10 text-success'
                        : 'border-amber-600/40 text-amber-700 dark:text-amber-300',
                    )}
                  >
                    {formatNumber(locale, entry.availableFiles)} / {formatNumber(locale, entry.totalFiles)}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {t('narration.lib.sourceNote', { source: entry.sourceName })}
                  </span>
                </div>
              ) : null}

              {/* Honest offline summary */}
              {translationKey !== null ? (
                status === null || (status.storedFiles === 0 && status.corruptedFiles === 0) ? (
                  <p className="text-xs text-muted-foreground">{t('narration.lib.storedNone')}</p>
                ) : (
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className="tabular-nums">
                      {t('narration.lib.storedSummary', {
                        files: formatNumber(locale, status.storedFiles),
                        size: formatBytes(locale, status.totalBytes),
                      })}
                    </Badge>
                    <Badge
                      variant="outline"
                      className={cn(
                        status.completeSuras > 0
                          ? 'border-success/40 bg-success/10 text-success'
                          : undefined,
                      )}
                    >
                      {t('narration.lib.completeSuras', {
                        count: formatNumber(locale, status.completeSuras),
                      })}
                    </Badge>
                    {status.corruptedFiles > 0 ? (
                      <Badge variant="destructive" className="tabular-nums">
                        {t('narration.lib.corruptCount', {
                          count: formatNumber(locale, status.corruptedFiles),
                        })}
                      </Badge>
                    ) : null}
                  </div>
                )
              ) : null}

              {/* Download controls: sura / juz / complete */}
              <Separator />
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-1.5">
                  <Label htmlFor="narration-lib-sura">{t('audio.lib.downloadSura')}</Label>
                  <div className="flex gap-2">
                    <Select value={suraPick} onValueChange={setSuraPick}>
                      <SelectTrigger id="narration-lib-sura" className="h-11 w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="max-h-72">
                        {SURA_INDEX.map((meta) => (
                          <SelectItem key={meta.number} value={String(meta.number)}>
                            <span dir="auto" className="truncate">
                              {meta.number}. {meta.nameEnglish}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      variant="outline"
                      className="h-11 shrink-0"
                      onClick={handleDownloadSura}
                      disabled={suraPlan === null}
                    >
                      <HardDriveDownload aria-hidden="true" className="size-4" />
                      <span className="sr-only">{t('narration.lib.downloadSura')}</span>
                    </Button>
                  </div>
                  {suraPlan !== null ? (
                    <p className="text-xs tabular-nums text-muted-foreground">
                      {formatNumber(locale, suraPlan.files)} · {formatBytes(locale, suraPlan.bytes)}
                    </p>
                  ) : null}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="narration-lib-juz">{t('audio.download.juzLabel')}</Label>
                  <div className="flex gap-2">
                    <Select value={juzPick} onValueChange={setJuzPick}>
                      <SelectTrigger id="narration-lib-juz" className="h-11 w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="max-h-72">
                        {Array.from({ length: JUZ_COUNT }, (_, index) => index + 1).map((juz) => (
                          <SelectItem key={juz} value={String(juz)}>
                            {t('audio.download.juzOption', { juz: formatNumber(locale, juz) })}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      variant="outline"
                      className="h-11 shrink-0"
                      onClick={handleDownloadJuz}
                      disabled={juzPlan === null}
                    >
                      <HardDriveDownload aria-hidden="true" className="size-4" />
                      <span className="sr-only">{t('downloads.batchJuz', { juz: juzPick })}</span>
                    </Button>
                  </div>
                  {juzPlan !== null ? (
                    <p className="text-xs tabular-nums text-muted-foreground">
                      {t('audio.download.sizeExact', { size: formatBytes(locale, juzPlan.bytes) })}
                    </p>
                  ) : null}
                </div>

                <div className="space-y-1.5">
                  <Label>{t('downloads.narrationBatchComplete')}</Label>
                  {completeOfferable ? (
                    <>
                      <Button
                        variant="outline"
                        className="h-11 w-full"
                        onClick={handleDownloadComplete}
                        disabled={completePlan === null}
                      >
                        <HardDriveDownload aria-hidden="true" className="size-4" />
                        {completePlan === null
                          ? t('audio.download.planLoading')
                          : completePlan.estimated
                            ? t('narration.download.sizeEstimated', {
                                size: formatBytes(locale, completePlan.bytes),
                              })
                            : formatBytes(locale, completePlan.bytes)}
                      </Button>
                      {completePlan !== null && completePlan.estimated ? (
                        <p className="text-xs leading-relaxed text-muted-foreground">
                          {t('narration.download.estimatedNote')}
                        </p>
                      ) : null}
                    </>
                  ) : (
                    <p className="flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
                      <CircleAlert
                        aria-hidden="true"
                        className="mt-0.5 size-3.5 shrink-0 text-amber-600 dark:text-amber-400"
                      />
                      {t('audio.download.incompleteSourceTitle')}
                    </p>
                  )}
                </div>
              </div>

              {/* Per-sura stored files */}
              {status !== null && status.suras.length > 0 ? (
                <>
                  <Separator />
                  {/* Natural page flow (no nested max-height scroller): the
                      full sura list is part of the page scroll, nothing
                      clipped, and no second scrollbar shifts content. */}
                  <ul className="space-y-2">
                    {status.suras.map((sura) => {
                      const meta = SURA_INDEX[sura.sura - 1]
                      return (
                        <li
                          key={sura.sura}
                          className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border bg-card p-3"
                        >
                          {sura.complete ? (
                            <CheckCircle2
                              aria-hidden="true"
                              className="size-5 shrink-0 text-success"
                            />
                          ) : (
                            <CircleAlert
                              aria-hidden="true"
                              className="size-5 shrink-0 text-amber-600 dark:text-amber-400"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <p dir="auto" className="truncate text-sm font-medium text-foreground">
                              {sura.sura}. {meta?.nameEnglish} · {meta?.nameArabic}
                            </p>
                            <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
                              {sura.complete ? (
                                <span className="text-success">{t('quran.offline.statusReady')}</span>
                              ) : (
                                <span>
                                  {t('narration.lib.incompleteSura', {
                                    stored: formatNumber(locale, sura.storedAyat),
                                    total: formatNumber(locale, sura.ayahCount),
                                  })}
                                </span>
                              )}
                              <span aria-hidden="true">·</span>
                              <span className="tabular-nums">
                                {formatBytes(locale, sura.totalBytes)}
                              </span>
                              {sura.corruptedAyat > 0 ? (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="text-destructive">
                                    {t('narration.lib.corruptCount', {
                                      count: formatNumber(locale, sura.corruptedAyat),
                                    })}
                                  </span>
                                </>
                              ) : null}
                            </p>
                          </div>
                          <div className="flex shrink-0 items-center gap-1.5">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-11"
                              disabled={verifyingSura === sura.sura}
                              onClick={() => void handleVerifySura(sura.sura)}
                              aria-label={t('narration.lib.verify')}
                              title={t('narration.lib.verify')}
                            >
                              <ShieldCheck
                                aria-hidden="true"
                                className={cn(
                                  'size-4',
                                  verifyingSura === sura.sura && 'animate-pulse',
                                )}
                              />
                            </Button>
                            {/* Destructive: always behind an explicit confirmation.
                                Deleting narration never deletes Quran text,
                                translations or recitation audio (separate storage). */}
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-11 text-destructive hover:bg-destructive/10 hover:text-destructive"
                                  disabled={busySura === sura.sura}
                                  aria-label={t('narration.lib.deleteSura')}
                                  title={t('narration.lib.deleteSura')}
                                >
                                  <Trash2 aria-hidden="true" className="size-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>
                                    {t('narration.lib.deleteSuraConfirmTitle')}
                                  </AlertDialogTitle>
                                  <AlertDialogDescription>
                                    {t('narration.lib.deleteSuraConfirmDescription')}
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel className="h-11">
                                    {t('common.cancel')}
                                  </AlertDialogCancel>
                                  <AlertDialogAction
                                    className="h-11"
                                    onClick={() => void handleDeleteSura(sura.sura)}
                                  >
                                    {t('common.delete')}
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </li>
                      )
                    })}
                  </ul>
                </>
              ) : null}
            </>
          )}
        </CardContent>
      </Card>

      {status !== null && status.suras.length === 0 ? (
        <EmptyState
          icon={Languages}
          title={t('narration.lib.emptyTitle')}
          description={t('narration.lib.emptyDescription')}
        />
      ) : null}
    </section>
  )
}
