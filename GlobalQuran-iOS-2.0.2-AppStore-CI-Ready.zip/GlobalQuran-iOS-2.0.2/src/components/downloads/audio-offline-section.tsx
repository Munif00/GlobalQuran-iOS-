'use client'

/**
 * Recitation audio section (Downloads screen, PROMPT 9).
 *
 * The offline manager for downloaded recitation audio:
 * - pick one of the VERIFIED recitations (only styles the server confirmed
 *   are fully available are offered for downloading),
 * - download a surah, a juz, or the complete package - each option shows
 *   the EXACT size from the verified plan before it starts; the complete
 *   package is only offered when the source inventory covers every ayah,
 * - see the honest per-sura offline status (a sura is "complete" only when
 *   every ayah is stored AND verified - never merely because a download
 *   once ran),
 * - re-verify stored files (recorded sizes are checked against the real
 *   payloads; failures are marked for re-download),
 * - delete a surah's audio or the whole recitation - audio lives in its
 *   own storage, so Quran text and translations are never touched,
 * - the source attribution of every recording is preserved and shown.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import {
  ArrowDownToLine,
  CheckCircle2,
  CircleAlert,
  HardDriveDownload,
  Music,
  ShieldCheck,
  Trash2,
} from 'lucide-react'

import { useTranslation } from '@/i18n'
import { getAudioBatchPlan } from '@/services/api/audio-api'
import { describeApiError } from '@/services/api/errors'
import { enqueueAudioBatch } from '@/services/downloads/audio-download-manager'
import { getAudioLibrary } from '@/services/storage/audio-library'
import { getStyleDefinition } from '@/data/audio-styles'
import { SURA_INDEX } from '@/data/sura-index'
import { JUZ_COUNT } from '@/data/juz-index'
import { useAudioStore } from '@/stores/audio-store'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import type { AudioStyleOfflineStatus, ReciterStyleDto } from '@/types'
import { formatBytes, formatNumber } from '@/utils/format'

import { EmptyState } from '@/components/design-system/empty-state'
import { useReciterCatalog } from '@/components/quran/reciter-selector-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { cn } from '@/lib/utils'

/** Total numbered ayat - the complete package requirement. */
const TOTAL_QURAN_AYAT = 6236

export function AudioOfflineSection() {
  const { t, locale } = useTranslation()
  const catalogQuery = useReciterCatalog()
  const selectedStyleId = useAudioStore((s) => s.selectedStyleId)
  const activeIds = useDownloadManagerStore((s) => s.activeIds)

  /** The style this section manages (defaults to the reader's selection). */
  const [styleId, setStyleId] = useState<string | null>(selectedStyleId)
  const [status, setStatus] = useState<AudioStyleOfflineStatus | null>(null)
  const [suraPick, setSuraPick] = useState('1')
  const [juzPick, setJuzPick] = useState('1')
  const [busySura, setBusySura] = useState<number | null>(null)
  const [verifyingSura, setVerifyingSura] = useState<number | null>(null)

  useEffect(() => {
    if (styleId === null && selectedStyleId !== null) setStyleId(selectedStyleId)
  }, [styleId, selectedStyleId])

  /** Styles offered for download: seed-verified AND live-confirmed. */
  const downloadableStyles = useMemo(
    () => (catalogQuery.data?.styles ?? []).filter((style) => style.available && style.seedVerified),
    [catalogQuery.data],
  )

  /** Default to the first downloadable style when nothing is selected. */
  useEffect(() => {
    if (styleId === null && downloadableStyles.length > 0) {
      setStyleId(
        downloadableStyles.some((style) => style.id === selectedStyleId)
          ? selectedStyleId
          : downloadableStyles[0].id,
      )
    }
  }, [styleId, downloadableStyles, selectedStyleId])

  const refreshStatus = useCallback(async () => {
    if (styleId === null) {
      setStatus(null)
      return
    }
    try {
      setStatus(await getAudioLibrary().getStyleStatus(styleId))
    } catch {
      setStatus(null)
    }
  }, [styleId])

  useEffect(() => {
    void refreshStatus()
  }, [refreshStatus])

  // Refresh whenever a batch finishes (activeIds shrinks) or changes.
  const activeCount = activeIds.length
  useEffect(() => {
    if (activeCount === 0) void refreshStatus()
  }, [activeCount, refreshStatus])

  const style = styleId ? getStyleDefinition(styleId) : undefined
  const catalogStyle = downloadableStyles.find((entry) => entry.id === styleId) ?? null

  /** The complete package may only be offered when the source has all files. */
  const completeOfferable =
    catalogStyle !== null &&
    catalogStyle.completeSuras >= 114 &&
    catalogStyle.totalAyat >= TOTAL_QURAN_AYAT

  /* Sura plan preview (exact size) - only fetched for the picked sura. */
  const [suraPlanSize, setSuraPlanSize] = useState<number | null>(null)
  useEffect(() => {
    let cancelled = false
    setSuraPlanSize(null)
    if (styleId === null) return
    const sura = Number(suraPick)
    getAudioBatchPlan({ styleId, kind: 'sura', sura })
      .then((plan) => {
        if (!cancelled) setSuraPlanSize(plan.totalBytes)
      })
      .catch(() => undefined)
    return () => {
      cancelled = true
    }
  }, [styleId, suraPick])

  /** Shared enqueue handling with honest toasts. */
  const startBatch = useCallback(
    async (spec: Parameters<typeof enqueueAudioBatch>[0]) => {
      const result = await enqueueAudioBatch(spec)
      if (result.ok) {
        toast(t('audio.download.started'), { description: t('audio.download.startedDescription') })
        return
      }
      if (result.reason === 'already-downloaded') {
        toast.info(t('audio.download.alreadyDownloadedTitle'), {
          description: t('audio.download.alreadyDownloadedDescription'),
        })
        return
      }
      if (result.reason === 'duplicate-active') {
        toast.info(t('audio.download.duplicateActiveTitle'), {
          description: t('audio.download.duplicateActiveDescription'),
        })
        return
      }
      if (result.reason === 'incomplete-source') {
        toast.info(t('audio.download.incompleteSourceTitle'), {
          description: t('audio.download.incompleteSourceDescription'),
        })
        return
      }
      toast.error(t('audio.download.planUnavailable'))
    },
    [t],
  )

  const handleDownloadSura = () => {
    if (styleId === null) return
    void startBatch({ styleId, kind: 'sura', sura: Number(suraPick) })
  }

  const handleDownloadJuz = () => {
    if (styleId === null) return
    void startBatch({ styleId, kind: 'juz', juz: Number(juzPick) })
  }

  const handleDownloadComplete = () => {
    if (styleId === null || !completeOfferable) return
    void startBatch({ styleId, kind: 'complete' })
  }

  const handleDeleteSura = async (sura: number) => {
    if (styleId === null) return
    setBusySura(sura)
    try {
      await getAudioLibrary().deleteSura(styleId, sura)
      await refreshStatus()
      toast(t('common.updated'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setBusySura(null)
    }
  }

  const handleVerifySura = async (sura: number) => {
    if (styleId === null) return
    setVerifyingSura(sura)
    try {
      const result = await getAudioLibrary().verifySura(styleId, sura)
      await refreshStatus()
      if (result.failed > 0) {
        toast.warning(t('audio.lib.verifyFailed', { count: formatNumber(locale, result.failed) }))
      } else {
        toast(t('audio.lib.verifyOk'))
      }
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setVerifyingSura(null)
    }
  }

  const handleDeleteAll = async () => {
    if (styleId === null) return
    try {
      await getAudioLibrary().deleteStyle(styleId)
      await refreshStatus()
      toast(t('common.updated'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    }
  }

  return (
    <section aria-labelledby="audio-offline-heading" className="space-y-3">
      <h2
        id="audio-offline-heading"
        className="text-sm font-semibold uppercase tracking-wide text-muted-foreground"
      >
        {t('audio.lib.sectionTitle')}
      </h2>

      <Card>
        <CardContent className="space-y-4 p-4">
          {/* Reciter picker + summary */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="flex w-full min-w-0 flex-col gap-1.5 sm:max-w-72">
              <Label htmlFor="audio-lib-style">{t('audio.lib.reciterLabel')}</Label>
              <Select
                value={styleId ?? ''}
                onValueChange={(value) => setStyleId(value)}
                disabled={downloadableStyles.length === 0}
              >
                <SelectTrigger id="audio-lib-style" className="h-11 w-full">
                  <SelectValue placeholder={t('audio.download.pickReciter')} />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {downloadableStyles.map((entry: ReciterStyleDto) => (
                    <SelectItem key={entry.id} value={entry.id}>
                      <span dir="auto" className="truncate">
                        {entry.reciterName} — {entry.styleLabel}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1" />
            {status !== null && status.storedFiles > 0 ? (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="h-11 text-destructive hover:bg-destructive/10 hover:text-destructive">
                    <Trash2 aria-hidden="true" className="size-4" />
                    {t('audio.lib.deleteAll')}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>{t('audio.lib.deleteAllConfirmTitle')}</AlertDialogTitle>
                    <AlertDialogDescription>
                      {t('audio.lib.deleteAllConfirmDescription')}
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
                    <AlertDialogAction
                      className="h-11"
                      onClick={() => void handleDeleteAll()}
                    >
                      {t('common.delete')}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            ) : null}
          </div>

          {/* Honest offline summary */}
          {styleId !== null ? (
            status === null ? (
              <p className="text-xs text-muted-foreground">{t('audio.lib.storedNone')}</p>
            ) : status.storedFiles === 0 && status.corruptedFiles === 0 ? (
              <p className="text-xs text-muted-foreground">{t('audio.lib.storedNone')}</p>
            ) : (
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="tabular-nums">
                  {t('audio.lib.storedSummary', {
                    files: formatNumber(locale, status.storedFiles),
                    size: formatBytes(locale, status.totalBytes),
                  })}
                </Badge>
                <Badge
                  variant="outline"
                  className={cn(
                    status.completeSuras > 0
                      ? 'border-success/40 bg-success/10 text-success'
                      : undefined,
                  )}
                >
                  {t('audio.lib.completeSuras', { count: formatNumber(locale, status.completeSuras) })}
                </Badge>
                {status.corruptedFiles > 0 ? (
                  <Badge variant="destructive" className="tabular-nums">
                    {t('audio.lib.corruptCount', { count: formatNumber(locale, status.corruptedFiles) })}
                  </Badge>
                ) : null}
              </div>
            )
          ) : null}

          {/* Download options */}
          <div className="grid gap-3 md:grid-cols-3">
            {/* Surah */}
            <div className="space-y-1.5">
              <Label htmlFor="audio-lib-sura">{t('audio.lib.downloadSura')}</Label>
              <div className="flex gap-2">
                <Select value={suraPick} onValueChange={setSuraPick} disabled={styleId === null}>
                  <SelectTrigger id="audio-lib-sura" className="h-11 w-full min-w-0">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {SURA_INDEX.map((meta) => (
                      <SelectItem key={meta.number} value={String(meta.number)}>
                        <span dir="auto" className="truncate">
                          {meta.number}. {meta.nameEnglish}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  className="h-11 shrink-0"
                  disabled={styleId === null}
                  onClick={handleDownloadSura}
                >
                  <ArrowDownToLine aria-hidden="true" className="size-4" />
                  <span className="sr-only">{t('audio.lib.downloadSura')}</span>
                </Button>
              </div>
              {suraPlanSize !== null ? (
                <p className="text-xs tabular-nums text-muted-foreground">
                  {t('audio.download.sizeExact', { size: formatBytes(locale, suraPlanSize) })}
                </p>
              ) : null}
            </div>

            {/* Juz */}
            <div className="space-y-1.5">
              <Label htmlFor="audio-lib-juz">{t('audio.download.juzLabel')}</Label>
              <div className="flex gap-2">
                <Select value={juzPick} onValueChange={setJuzPick} disabled={styleId === null}>
                  <SelectTrigger id="audio-lib-juz" className="h-11 w-full min-w-0">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {Array.from({ length: JUZ_COUNT }, (_, index) => index + 1).map((juz) => (
                      <SelectItem key={juz} value={String(juz)}>
                        {t('audio.download.juzOption', { juz: formatNumber(locale, juz) })}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  className="h-11 shrink-0"
                  disabled={styleId === null}
                  onClick={handleDownloadJuz}
                >
                  <ArrowDownToLine aria-hidden="true" className="size-4" />
                  <span className="sr-only">{t('downloads.batchJuz', { juz: juzPick })}</span>
                </Button>
              </div>
            </div>

            {/* Complete package */}
            <div className="space-y-1.5">
              <Label>{t('downloads.batchComplete')}</Label>
              <Button
                variant="outline"
                className="h-11 w-full justify-start gap-2"
                disabled={styleId === null || !completeOfferable}
                onClick={handleDownloadComplete}
                title={
                  completeOfferable || styleId === null
                    ? undefined
                    : t('audio.download.incompleteSourceDescription')
                }
              >
                <HardDriveDownload aria-hidden="true" className="size-4 shrink-0" />
                <span className="min-w-0 flex-1 truncate text-start">
                  {completeOfferable && catalogStyle
                    ? formatBytes(locale, catalogStyle.totalBytes)
                    : t('audio.download.incompleteSourceTitle')}
                </span>
              </Button>
            </div>
          </div>

          <p className="text-xs leading-relaxed text-muted-foreground">
            {t('audio.lib.sectionDescription')}
          </p>

          {/* Stored suras */}
          {status !== null && status.suras.length > 0 ? (
            <>
              <Separator />
              {/* Natural page flow (no nested max-height scroller): the full
                  sura list is part of the page scroll, nothing clipped, and no
                  second scrollbar appears/disappears to shift content. */}
              <ul className="space-y-2">
                {status.suras.map((sura) => {
                  const meta = SURA_INDEX[sura.sura - 1]
                  return (
                    <li
                      key={sura.sura}
                      className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border bg-card p-3"
                    >
                      {sura.complete ? (
                        <CheckCircle2
                          aria-hidden="true"
                          className="size-5 shrink-0 text-success"
                        />
                      ) : (
                        <CircleAlert
                          aria-hidden="true"
                          className="size-5 shrink-0 text-amber-600 dark:text-amber-400"
                        />
                      )}
                      <div className="min-w-0 flex-1">
                        <p dir="auto" className="truncate text-sm font-medium text-foreground">
                          {sura.sura}. {meta?.nameEnglish} · {meta?.nameArabic}
                        </p>
                        <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
                          {sura.complete ? (
                            <span className="text-success">{t('quran.offline.statusReady')}</span>
                          ) : (
                            <span>
                              {t('audio.lib.incompleteSura', {
                                stored: formatNumber(locale, sura.storedAyat),
                                total: formatNumber(locale, sura.ayahCount),
                              })}
                            </span>
                          )}
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">
                            {formatBytes(locale, sura.totalBytes)}
                          </span>
                          {sura.corruptedAyat > 0 ? (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-destructive">
                                {t('audio.lib.corruptCount', {
                                  count: formatNumber(locale, sura.corruptedAyat),
                                })}
                              </span>
                            </>
                          ) : null}
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-1.5">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-11"
                          disabled={verifyingSura === sura.sura}
                          onClick={() => void handleVerifySura(sura.sura)}
                          aria-label={t('audio.lib.verify')}
                          title={t('audio.lib.verify')}
                        >
                          {verifyingSura === sura.sura ? (
                            <ShieldCheck aria-hidden="true" className="size-4 animate-pulse" />
                          ) : (
                            <ShieldCheck aria-hidden="true" className="size-4" />
                          )}
                        </Button>
                        {/* Destructive: always behind an explicit confirmation.
                            Deleting audio never deletes Quran text or
                            translations (separate storage). */}
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-11 text-destructive hover:bg-destructive/10 hover:text-destructive"
                              disabled={busySura === sura.sura}
                              aria-label={t('audio.lib.deleteSura')}
                              title={t('audio.lib.deleteSura')}
                            >
                              <Trash2 aria-hidden="true" className="size-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                {t('audio.lib.deleteSuraConfirmTitle')}
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                {t('audio.lib.deleteSuraConfirmDescription')}
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="h-11">
                                {t('common.cancel')}
                              </AlertDialogCancel>
                              <AlertDialogAction
                                className="h-11"
                                onClick={() => void handleDeleteSura(sura.sura)}
                              >
                                {t('common.delete')}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </li>
                  )
                })}
              </ul>
            </>
          ) : null}

          {/* Source attribution */}
          {style ? (
            <p className="text-xs leading-relaxed text-muted-foreground">
              <Music aria-hidden="true" className="me-1 inline size-3.5 align-[-2px]" />
              {t('audio.lib.sourceNote', {
                reciter: style.reciterName,
                style: style.styleLabel,
                source: style.sourceName,
              })}
            </p>
          ) : null}
        </CardContent>
      </Card>

      {status !== null && status.suras.length === 0 ? (
        <EmptyState
          icon={Music}
          title={t('audio.lib.emptyTitle')}
          description={t('audio.lib.emptyDescription')}
        />
      ) : null}
    </section>
  )
}
