'use client'

/**
 * One stored file of the offline library (downloaded from the catalog or
 * imported from the device).
 *
 * - Shows only real stored metadata: name, format, size, date, origin,
 *   version, translation key and the locally computed SHA-256 checksum.
 * - Version comparison joins the file's translationId/fileId with the live
 *   catalog: when the catalog publishes a different version, a gold update
 *   strip offers a one-tap update (the engine keeps the old file until the
 *   new one validates). While the catalog is unavailable, nothing is guessed.
 * - "Open" uses the built-in viewer through the viewer store; ZIP archives
 *   are kept offline but have no in-app reader, so they show no Open button.
 */

import { BookOpen, Database, FileAudio, FileJson, FileText, Archive, RefreshCw, Trash2, type LucideIcon } from 'lucide-react'

import { useTranslation } from '@/i18n'
import type { StoredFileMetadata } from '@/services/storage/local-file-storage'
import type { DownloadFormat, Translation, TranslationFile } from '@/types'
import { shortChecksum } from '@/utils/checksum'
import { isViewableFormat } from '@/utils/file-validation'
import { formatBytes, formatDateTimeString } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { cn } from '@/lib/utils'

/**
 * Icons per stored format. Validated ZIP archives are stored as-is, so the
 * union is wider than the catalog-driven `DownloadFormat`.
 */
export const FORMAT_ICONS: Record<DownloadFormat | 'zip', LucideIcon> = {
  pdf: FileText,
  epub: BookOpen,
  sql: Database,
  json: FileJson,
  txt: FileText,
  mp3: FileAudio,
  zip: Archive,
}

/** Outcome of joining one stored file with the live catalog. */
type VersionStatus = 'update' | 'current' | 'unknown'

export interface LibraryFileCardProps {
  file: StoredFileMetadata
  /** Catalog translation matching file.translationId (null when no match). */
  catalogItem: Translation | null
  /** True once the catalog has data - version comparison is skipped otherwise. */
  catalogReady: boolean
  isDeleting: boolean
  onOpen: (fileId: string) => void
  onDelete: (fileId: string) => void
  onUpdate: (file: StoredFileMetadata, catalogItem: Translation, catalogFile: TranslationFile) => void
}

export function LibraryFileCard({
  file,
  catalogItem,
  catalogReady,
  isDeleting,
  onOpen,
  onDelete,
  onUpdate,
}: LibraryFileCardProps) {
  const { t, locale } = useTranslation()
  const FormatIcon = FORMAT_ICONS[file.format] ?? FileText
  const viewable = isViewableFormat(file.format)

  // The catalog file that corresponds to this stored copy (matched by the
  // catalog file id recorded at download time).
  const catalogFile =
    file.fileId !== null && catalogItem !== null
      ? catalogItem.downloadFiles.find((candidate) => candidate.id === file.fileId) ?? null
      : null

  // Version comparison - only when the catalog actually loaded and both the
  // stored copy and the catalog carry a version. Never guessed.
  let versionStatus: VersionStatus = 'unknown'
  if (catalogReady && catalogItem !== null && file.translationId !== null && file.fileId !== null) {
    if (file.version === null && catalogItem.version === null) {
      versionStatus = 'current'
    } else if (file.version !== null && catalogItem.version !== null) {
      versionStatus = file.version === catalogItem.version ? 'current' : 'update'
    }
  }

  // An update needs the catalog file to still be published; without it there
  // is nothing to enqueue, so no update strip is rendered.
  const updateTarget =
    versionStatus === 'update' && catalogItem !== null && catalogFile !== null
      ? { catalogItem, catalogFile }
      : null

  return (
    <li
      className={cn(
        'rounded-xl border border-border bg-card p-4 shadow-sm transition-opacity',
        isDeleting && 'opacity-60',
      )}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <span
            aria-hidden="true"
            className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"
          >
            <FormatIcon className="size-5" />
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <p dir="auto" title={file.fileName} className="min-w-0 truncate text-sm font-semibold text-foreground">
                {file.fileName}
              </p>
              <Badge variant="secondary" className="uppercase">
                {file.format}
              </Badge>
            </div>

            <dl className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
              <div className="flex items-baseline gap-1.5">
                <dt>{t('common.size')}</dt>
                <dd className="font-medium text-foreground">{formatBytes(locale, file.fileSize)}</dd>
              </div>
              <div className="flex items-baseline gap-1.5">
                <dt>{t('downloads.downloadedAt')}</dt>
                <dd className="font-medium text-foreground">
                  {formatDateTimeString(locale, file.storedAt)}
                </dd>
              </div>
              <div className="flex items-baseline gap-1.5">
                <dt>{t('common.status')}</dt>
                <dd>
                  <Badge
                    variant="outline"
                    className={
                      file.origin === 'downloaded'
                        ? 'border-primary/40 bg-primary/10 text-primary'
                        : 'border-border bg-muted text-muted-foreground'
                    }
                  >
                    {file.origin === 'downloaded'
                      ? t('downloads.originDownloaded')
                      : t('downloads.originImported')}
                  </Badge>
                </dd>
              </div>
              {file.version ? (
                <div className="flex items-baseline gap-1.5">
                  <dt>{t('common.version')}</dt>
                  <dd className="flex flex-wrap items-center gap-1.5">
                    <span dir="auto" className="font-medium text-foreground">
                      {file.version}
                    </span>
                    {versionStatus === 'current' ? (
                      <Badge variant="outline" className="border-border bg-muted text-muted-foreground">
                        {t('downloads.upToDate')}
                      </Badge>
                    ) : null}
                  </dd>
                </div>
              ) : null}
              {file.translationId ? (
                <div className="flex items-baseline gap-1.5">
                  <dt>{t('downloads.translationKey')}</dt>
                  <dd dir="auto" className="font-mono text-[11px] font-medium text-foreground">
                    {file.translationId}
                  </dd>
                </div>
              ) : null}
              {file.checksum ? (
                <div className="flex items-baseline gap-1.5">
                  <dt>{t('downloads.checksumLabel')}</dt>
                  <dd>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          type="button"
                          aria-label={file.checksum}
                          className="rounded-sm font-mono font-medium text-foreground underline decoration-dotted underline-offset-4 outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                        >
                          {shortChecksum(file.checksum)}
                        </button>
                      </TooltipTrigger>
                      <TooltipContent className="max-w-72 text-start">
                        <span className="block font-semibold">{t('downloads.checksumLabel')}</span>
                        <span className="mt-0.5 block break-all font-mono">{file.checksum}</span>
                      </TooltipContent>
                    </Tooltip>
                  </dd>
                </div>
              ) : null}
              <div className="flex items-baseline gap-1.5">
                <dt>{t('downloads.integrity')}</dt>
                <dd>
                  {file.checksum ? (
                    <Badge variant="outline" className="border-success/40 bg-success/10 text-success">
                      {t('downloads.integrityVerified')}
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="border-border bg-muted text-muted-foreground">
                      {t('downloads.integrityUnverified')}
                    </Badge>
                  )}
                </dd>
              </div>
            </dl>

            {updateTarget ? (
              <div className="mt-3 flex flex-wrap items-center gap-2 rounded-lg border border-gold/40 bg-gold/10 p-2.5">
                <Badge variant="outline" className="border-gold/40 bg-gold/15 text-gold-foreground">
                  {t('downloads.updateNow')}
                </Badge>
                <span dir="auto" className="text-xs tabular-nums text-muted-foreground">
                  {t('downloads.versionTransition', {
                    old: file.version ?? '—',
                    new: updateTarget.catalogItem.version ?? '—',
                  })}
                </span>
                <Button
                  variant="outline"
                  className="ms-auto h-11"
                  disabled={isDeleting}
                  onClick={() => onUpdate(file, updateTarget.catalogItem, updateTarget.catalogFile)}
                >
                  <RefreshCw aria-hidden="true" className="size-4" />
                  {t('downloads.updateNow')}
                </Button>
              </div>
            ) : null}
          </div>
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {viewable ? (
            <Button variant="outline" className="h-11" disabled={isDeleting} onClick={() => onOpen(file.id)}>
              <BookOpen aria-hidden="true" className="size-4" />
              {t('downloads.openFile')}
            </Button>
          ) : null}

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                className="h-11 text-destructive hover:bg-destructive/10 hover:text-destructive"
                disabled={isDeleting}
              >
                <Trash2 aria-hidden="true" className="size-4" />
                {t('downloads.deleteFile')}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t('downloads.deleteConfirmTitle')}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t('downloads.deleteConfirmDescription')}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
                <AlertDialogAction
                  className="h-11 bg-destructive text-white shadow-xs hover:bg-destructive/90"
                  onClick={() => onDelete(file.id)}
                >
                  {t('common.confirm')}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </li>
  )
}
