'use client'

/**
 * Storage management for the offline library.
 *
 * - Shows the real browser storage quota (when the platform reports one) and
 *   the persistence state; requesting persistent storage is a real call with
 *   an honest result toast.
 * - By-format breakdown and the largest stored files are computed from the
 *   actual IndexedDB metadata; every deletion goes through a confirmation
 *   dialog.
 * - "Delete all" clears every stored file and resets the download-manager
 *   job records, so no orphaned job references remain in the UI.
 * - The two honesty notes (source relay policy, checksum policy) live here
 *   as quiet footnote paragraphs.
 */

import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { HardDrive, Loader2, ShieldCheck, Trash2 } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { describeApiError } from '@/services/api/errors'
import {
  getFileStorage,
  requestPersistentStorage,
  type StoredFileMetadata,
} from '@/services/storage/local-file-storage'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import type { DownloadFormat, StorageEstimateInfo } from '@/types'
import { formatBytes, formatNumber } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { cn } from '@/lib/utils'
import { FORMAT_ICONS } from '@/components/downloads/library-file-card'

export interface StorageManagementProps {
  /** Current stored files (null while loading). */
  files: StoredFileMetadata[] | null
  /** Latest storage estimate (null while loading). */
  estimate: StorageEstimateInfo | null
  /** Stored-file id currently being deleted (for row dimming). */
  deletingFileId: string | null
  onDeleteFile: (fileId: string) => void
  /** Reloads the file list and the estimate after any mutation. */
  onRefresh: () => Promise<void> | void
}

export function StorageManagement({
  files,
  estimate,
  deletingFileId,
  onDeleteFile,
  onRefresh,
}: StorageManagementProps) {
  const { t, locale } = useTranslation()

  const [isRequestingPersist, setIsRequestingPersist] = useState(false)
  const [isDeletingAll, setIsDeletingAll] = useState(false)

  const quotaKnown =
    estimate !== null && estimate.usage !== null && estimate.quota !== null && estimate.quota > 0
  const usageRatio =
    quotaKnown && estimate !== null && estimate.usage !== null && estimate.quota !== null
      ? Math.min(100, Math.max(0, (estimate.usage / estimate.quota) * 100))
      : 0

  /** Per-format count and byte totals from the real metadata. */
  const formatBreakdown = useMemo(() => {
    if (files === null) return []
    const byFormat = new Map<DownloadFormat | 'zip', { count: number; bytes: number }>()
    for (const file of files) {
      const entry = byFormat.get(file.format) ?? { count: 0, bytes: 0 }
      entry.count += 1
      entry.bytes += file.fileSize
      byFormat.set(file.format, entry)
    }
    return [...byFormat.entries()]
      .map(([format, stats]) => ({ format, ...stats }))
      .sort((a, b) => a.format.localeCompare(b.format))
  }, [files])

  /** The three largest stored files. */
  const largestFiles = useMemo(() => {
    if (files === null) return []
    return [...files].sort((a, b) => b.fileSize - a.fileSize).slice(0, 3)
  }, [files])

  const handlePersistRequest = async () => {
    setIsRequestingPersist(true)
    try {
      const granted = await requestPersistentStorage()
      if (granted) {
        toast.success(t('downloads.persistGranted'))
      } else {
        toast.error(t('common.error'))
      }
      await onRefresh()
    } finally {
      setIsRequestingPersist(false)
    }
  }

  const handleDeleteAll = async () => {
    setIsDeletingAll(true)
    try {
      await getFileStorage().deleteAllFiles()
      // No stored files remain - drop the (now orphaned) job records too.
      useDownloadManagerStore.setState({ jobs: {}, activeIds: [] })
      toast(t('downloads.deletedAll'))
      await onRefresh()
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setIsDeletingAll(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <HardDrive aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('downloads.storageSection')}</CardTitle>
        </div>
        {files !== null ? (
          <CardDescription>
            {t('downloads.itemsCount', { count: formatNumber(locale, files.length) })}
          </CardDescription>
        ) : null}
      </CardHeader>

      <CardContent className="space-y-5">
        {/* Quota */}
        {estimate === null ? (
          <div role="status" className="space-y-2">
            <span className="sr-only">{t('common.loading')}</span>
            <Skeleton className="h-2 w-full" />
            <Skeleton className="h-4 w-48" />
          </div>
        ) : quotaKnown && estimate.usage !== null && estimate.quota !== null ? (
          <div className="space-y-2">
            <Progress value={usageRatio} aria-label={t('downloads.storageUsed')} />
            <p className="text-xs text-muted-foreground">
              {t('downloads.storageUsedOf', {
                used: formatBytes(locale, estimate.usage),
                total: formatBytes(locale, estimate.quota),
              })}
            </p>
          </div>
        ) : (
          <p className="text-xs leading-relaxed text-muted-foreground">
            {t('downloads.storageUnavailable')}
          </p>
        )}

        {/* Persistence */}
        {estimate !== null ? (
          <div className="flex flex-wrap items-center gap-3">
            {estimate.persisted ? (
              <Badge variant="outline" className="border-success/40 bg-success/10 text-success">
                {t('downloads.persistGranted')}
              </Badge>
            ) : (
              <Button
                variant="outline"
                className="h-11 w-fit"
                disabled={isRequestingPersist}
                onClick={() => void handlePersistRequest()}
              >
                {isRequestingPersist ? (
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                ) : (
                  <ShieldCheck aria-hidden="true" className="size-4" />
                )}
                {t('downloads.persistRequest')}
              </Button>
            )}
          </div>
        ) : null}

        <p className="text-xs leading-relaxed text-muted-foreground">{t('downloads.persistNote')}</p>

        {/* By format + largest files (only meaningful with stored files) */}
        {files !== null && files.length > 0 ? (
          <>
            <Separator />

            <div className="space-y-2.5">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {t('downloads.byFormat')}
              </h3>
              <ul className="flex flex-wrap gap-2">
                {formatBreakdown.map((entry) => {
                  const FormatIcon = FORMAT_ICONS[entry.format] ?? HardDrive
                  return (
                    <li
                      key={entry.format}
                      className="flex items-center gap-2 rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground"
                    >
                      <FormatIcon aria-hidden="true" className="size-3.5 text-primary" />
                      <span className="font-semibold uppercase text-foreground">{entry.format}</span>
                      <span className="tabular-nums">
                        {formatNumber(locale, entry.count)} · {formatBytes(locale, entry.bytes)}
                      </span>
                    </li>
                  )
                })}
              </ul>
            </div>

            <div className="space-y-2.5">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {t('downloads.largestFiles')}
              </h3>
              <ul className="space-y-2">
                {largestFiles.map((file) => (
                  <li
                    key={file.id}
                    className={cn(
                      'flex min-h-11 items-center gap-3 rounded-lg border border-border/60 bg-muted/30 px-3 py-1.5 transition-opacity',
                      deletingFileId === file.id && 'opacity-60',
                    )}
                  >
                    <p dir="auto" title={file.fileName} className="min-w-0 flex-1 truncate text-xs font-medium text-foreground">
                      {file.fileName}
                    </p>
                    <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                      {formatBytes(locale, file.fileSize)}
                    </span>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          className="size-11 shrink-0 text-destructive hover:bg-destructive/10 hover:text-destructive"
                          aria-label={`${t('downloads.deleteFile')} · ${file.fileName}`}
                          disabled={deletingFileId === file.id}
                        >
                          <Trash2 aria-hidden="true" className="size-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>{t('downloads.deleteConfirmTitle')}</AlertDialogTitle>
                          <AlertDialogDescription>
                            {t('downloads.deleteConfirmDescription')}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
                          <AlertDialogAction
                            className="h-11 bg-destructive text-white shadow-xs hover:bg-destructive/90"
                            onClick={() => onDeleteFile(file.id)}
                          >
                            {t('common.confirm')}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </li>
                ))}
              </ul>
            </div>
          </>
        ) : null}

        <Separator />

        {/* Delete all */}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="outline"
              className="h-11 w-fit border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
              disabled={isDeletingAll || (files !== null && files.length === 0)}
            >
              {isDeletingAll ? (
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
              ) : (
                <Trash2 aria-hidden="true" className="size-4" />
              )}
              {t('downloads.deleteAll')}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t('downloads.deleteAllConfirmTitle')}</AlertDialogTitle>
              <AlertDialogDescription>
                {t('downloads.deleteAllConfirmDescription')}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
              <AlertDialogAction
                className="h-11 bg-destructive text-white shadow-xs hover:bg-destructive/90"
                onClick={() => void handleDeleteAll()}
              >
                {t('common.confirm')}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Honesty notes */}
        <div className="space-y-2">
          <p className="text-xs leading-relaxed text-muted-foreground">{t('downloads.directNote')}</p>
          <p className="flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
            <ShieldCheck aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
            {t('downloads.integrityNote')}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
