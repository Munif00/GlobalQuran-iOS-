'use client'

/**
 * Import from device - a real, fully local import flow.
 *
 * - Two entry points: the classic hidden file input, and (when the browser
 *   supports it) the File System Access picker with typed accept filters.
 * - Every picked file is treated as untrusted input: validateImportFile
 *   checks the extension allow-list, sniffs the real content (magic bytes),
 *   cross-checks the MIME type and enforces the size limit before anything
 *   is stored. Rejections map to honest, specific messages.
 * - Accepted files are hashed with SHA-256 on the device and stored in the
 *   IndexedDB offline library; nothing ever leaves the device.
 */

import { useEffect, useRef, useState, type ChangeEvent } from 'react'
import { toast } from 'sonner'
import { FolderInput, Loader2, ShieldCheck, Sparkles, Upload } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { getFileStorage, type StoredFileMetadata } from '@/services/storage/local-file-storage'
import { sha256Hex } from '@/utils/checksum'
import { sanitizeFileName, validateImportFile } from '@/utils/file-validation'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

/** Import rejection codes mapped to their user-facing messages. */
const IMPORT_ERROR_KEYS: Record<string, TranslationKey> = {
  'unsupported-extension': 'downloads.importUnsupported',
  'too-large': 'downloads.importTooLarge',
  'content-extension-mismatch': 'downloads.importMismatch',
  'unknown-content': 'downloads.importUnknownContent',
  unreadable: 'downloads.importReadError',
  'empty-file': 'downloads.importEmpty',
}

/**
 * window.showOpenFilePicker is not in the TS DOM lib - access it through a
 * narrow, documented shape.
 */
type AdvancedFileHandle = { getFile: () => Promise<File> }
type ShowOpenFilePickerFn = (options?: {
  multiple?: boolean
  types?: Array<{ description?: string; accept: Record<string, string[]> }>
}) => Promise<AdvancedFileHandle[]>

function getAdvancedPicker(): ShowOpenFilePickerFn | null {
  if (typeof window === 'undefined') return null
  const picker = (window as unknown as { showOpenFilePicker?: ShowOpenFilePickerFn })
    .showOpenFilePicker
  return typeof picker === 'function' ? picker : null
}

export interface ImportCardProps {
  /** Called after a file was stored, so the library and quota can refresh. */
  onImported: () => Promise<void> | void
}

export function ImportCard({ onImported }: ImportCardProps) {
  const { t } = useTranslation()
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  const [isImporting, setIsImporting] = useState(false)
  const [advancedAvailable, setAdvancedAvailable] = useState(false)

  // Feature detection must run on the client only (the component is also
  // server-rendered, where window does not exist).
  useEffect(() => {
    setAdvancedAvailable(getAdvancedPicker() !== null)
  }, [])

  /** Validate, hash and store one picked file - entirely on-device. */
  const importPickedFile = async (picked: File) => {
    setIsImporting(true)
    try {
      const validation = await validateImportFile({
        name: picked.name,
        size: picked.size,
        type: picked.type,
        blob: picked,
      })

      if (!validation.ok) {
        const errorKey =
          validation.errorCode !== null ? IMPORT_ERROR_KEYS[validation.errorCode] : undefined
        toast.error(t('downloads.importRejected'), {
          description: errorKey ? t(errorKey) : t('downloads.importFailedDescription'),
        })
        return
      }
      if (validation.format === null) {
        toast.error(t('downloads.importFailedTitle'), {
          description: t('downloads.importFailedDescription'),
        })
        return
      }

      const checksum = await sha256Hex(picked)
      const fileName = sanitizeFileName(picked.name)

      // Validated ZIP archives are persisted as-is with format 'zip', which
      // widens the format union beyond the catalog-driven DownloadFormat of
      // the current storage types - hence this single documented cast at the
      // storage boundary.
      await getFileStorage().saveFile(
        {
          fileName,
          format: validation.format,
          fileSize: validation.fileSize,
          storedAt: new Date().toISOString(),
          checksum,
          origin: 'imported',
          translationId: null,
          version: null,
          fileId: null,
        } as Omit<StoredFileMetadata, 'id'>,
        picked,
      )

      toast.success(t('downloads.importSuccessTitle'), {
        description: t('downloads.importSuccessDescription', { name: fileName }),
      })
      await onImported()
    } catch {
      toast.error(t('downloads.importFailedTitle'), {
        description: t('downloads.importFailedDescription'),
      })
    } finally {
      setIsImporting(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    const picked = event.target.files?.[0]
    if (!picked) return
    void importPickedFile(picked)
  }

  /** File System Access picker: typed filters, silent on user cancel. */
  const handleAdvancedPick = async () => {
    const picker = getAdvancedPicker()
    if (picker === null || isImporting) return
    try {
      const handles = await picker({
        multiple: false,
        types: [
          {
            description: 'Documents',
            accept: {
              'application/pdf': ['.pdf'],
              'application/epub+zip': ['.epub'],
              'application/zip': ['.zip'],
              'application/json': ['.json'],
              'text/plain': ['.txt'],
              'application/octet-stream': ['.sql', '.sqlite', '.db'],
            },
          },
        ],
      })
      const handle = handles[0]
      if (!handle) return
      const picked = await handle.getFile()
      await importPickedFile(picked)
    } catch (error) {
      // The user closing the picker is not an error - stay silent.
      if (error instanceof Error && error.name === 'AbortError') return
      toast.error(t('downloads.importFailedTitle'), {
        description: t('downloads.importFailedDescription'),
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <Upload aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('downloads.importFile')}</CardTitle>
        </div>
        <CardDescription>{t('downloads.importFileDescription')}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.epub,.sql,.sqlite,.db,.json,.txt,.zip"
          onChange={handleInputChange}
          className="hidden"
        />

        <div className="flex flex-wrap items-center gap-2">
          <Button
            className="h-11 w-fit"
            disabled={isImporting}
            onClick={() => fileInputRef.current?.click()}
          >
            {isImporting ? (
              <Loader2 aria-hidden="true" className="size-4 animate-spin" />
            ) : (
              <FolderInput aria-hidden="true" className="size-4" />
            )}
            {isImporting
              ? t('common.loading')
              : advancedAvailable
                ? t('downloads.importSimple')
                : t('downloads.importPickFile')}
          </Button>

          {advancedAvailable ? (
            <Button
              variant="outline"
              className="h-11 w-fit"
              disabled={isImporting}
              onClick={() => void handleAdvancedPick()}
            >
              <Sparkles aria-hidden="true" className="size-4" />
              {t('downloads.importAdvanced')}
            </Button>
          ) : null}
        </div>

        <p className="flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
          <ShieldCheck aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
          {t('downloads.checksumComputed')}
        </p>
        <p className="flex items-start gap-1.5 text-xs leading-relaxed text-muted-foreground">
          <ShieldCheck aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
          {t('downloads.offlineNote')}
        </p>
      </CardContent>
    </Card>
  )
}
