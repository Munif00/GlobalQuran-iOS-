'use client'

/**
 * Active downloads - a live view over the download-manager engine.
 *
 * - Renders every job that is still in flight or needs a decision
 *   (queued / downloading / verifying / paused / interrupted / failed /
 *   corrupted). Completed and canceled jobs never appear here.
 * - Progress, byte counts and statuses come straight from the reactive
 *   download-manager store - no polling, the engine pushes every update.
 * - Pause / resume / retry / cancel / dismiss call the engine directly; the
 *   engine owns the state machine and persists everything.
 * - The section stays quiet when idle (a small muted card) and only renders
 *   once the engine has restored persisted jobs after startup.
 */

import { useMemo } from 'react'
import { Check, Loader2, Pause, Play, RotateCcw, X } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import {
  cancelDownload,
  dismissJob,
  pauseDownload,
  resumeDownload,
  retryDownload,
} from '@/services/downloads/download-manager'
import {
  cancelOfflinePack,
  dismissPackJob,
  pauseOfflinePack,
  resumeOfflinePack,
} from '@/services/downloads/offline-pack-manager'
import {
  cancelAudioBatch,
  dismissAudioBatch,
  pauseAudioBatch,
  resumeAudioBatch,
} from '@/services/downloads/audio-download-manager'
import {
  cancelTranslationAudioBatch,
  dismissTranslationAudioBatch,
  pauseTranslationAudioBatch,
  resumeTranslationAudioBatch,
} from '@/services/downloads/translation-audio-download-manager'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import type {
  AudioBatchDescriptor,
  DownloadJobRecord,
  DownloadStatus,
  TranslationAudioBatchDescriptor,
} from '@/types'
import { formatBytes, formatNumber } from '@/utils/format'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'

/** Job statuses that belong in this section. */
const ACTIVE_JOB_STATUSES = [
  'queued',
  'downloading',
  'verifying',
  'paused',
  'interrupted',
  'failed',
  'corrupted',
] as const

type ActiveJobStatus = (typeof ACTIVE_JOB_STATUSES)[number]

/** A job record narrowed to one of the active statuses. */
type ActiveJob = DownloadJobRecord & { status: ActiveJobStatus }

function isActiveJobStatus(status: DownloadStatus): status is ActiveJobStatus {
  return (ACTIVE_JOB_STATUSES as readonly DownloadStatus[]).includes(status)
}

const STATUS_LABEL_KEYS: Record<ActiveJobStatus, TranslationKey> = {
  queued: 'downloads.waiting',
  downloading: 'downloads.downloading',
  verifying: 'downloads.verifying',
  paused: 'downloads.paused',
  interrupted: 'downloads.interrupted',
  failed: 'downloads.failed',
  corrupted: 'downloads.corrupted',
}

const STATUS_BADGE_CLASS: Record<ActiveJobStatus, string> = {
  queued: 'border-primary/40 bg-primary/10 text-primary',
  downloading: 'border-primary/40 bg-primary/10 text-primary',
  verifying: 'border-gold/40 bg-gold/10 text-gold-foreground',
  paused: 'border-gold/40 bg-muted text-muted-foreground',
  interrupted: 'border-destructive/70 bg-destructive/10 text-destructive',
  failed: 'border-destructive/70 bg-destructive/10 text-destructive',
  corrupted: 'border-destructive/40 bg-destructive/15 text-destructive',
}

/** Every stable error code the engines can report. */
const KNOWN_ERROR_CODES: ReadonlySet<string> = new Set([
  'insufficient-storage',
  'network-error',
  'source-unreachable',
  'not-available',
  'size-mismatch',
  'storage-error',
  'interrupted',
  'interrupted-while-verifying',
  'aborted',
  'http-error',
  'rate-limited',
  'no-stream',
  'invalid-pack',
  'some-files-failed',
  'incomplete-batch',
  'plan-unavailable',
  'unknown-error',
])

/** Honest label of what an audio batch covers (PROMPT 9 options). */
function audioBatchLabel(
  batch: AudioBatchDescriptor,
  t: (key: TranslationKey, params?: Record<string, string | number>) => string,
  locale: string,
): string {
  const n = (value: number | null): number => value ?? 0
  switch (batch.batchKind) {
    case 'ayah':
      return t('downloads.batchThisAyah', { sura: n(batch.sura), ayah: n(batch.ayahFrom) })
    case 'sura':
      return t('downloads.batchSura', { sura: n(batch.sura) })
    case 'range':
      return t('downloads.batchRange', {
        sura: n(batch.sura),
        from: n(batch.ayahFrom),
        to: n(batch.ayahTo),
      })
    case 'juz':
      return t('downloads.batchJuz', { juz: n(batch.juz) })
    case 'complete':
      return t('downloads.batchComplete')
  }
  void locale
  return ''
}

/** Honest label of what a translation narration batch covers (PROMPT 10). */
function translationAudioBatchLabel(
  batch: TranslationAudioBatchDescriptor,
  t: (key: TranslationKey, params?: Record<string, string | number>) => string,
): string {
  const n = (value: number | null): number => value ?? 0
  switch (batch.batchKind) {
    case 'ayah':
      return t('downloads.batchThisAyah', { sura: n(batch.sura), ayah: n(batch.ayahFrom) })
    case 'sura':
      return t('downloads.batchSura', { sura: n(batch.sura) })
    case 'range':
      return t('downloads.batchRange', {
        sura: n(batch.sura),
        from: n(batch.ayahFrom),
        to: n(batch.ayahTo),
      })
    case 'juz':
      return t('downloads.batchJuz', { juz: n(batch.juz) })
    case 'complete':
      return t('downloads.narrationBatchComplete')
  }
  return ''
}

function JobRow({ job }: { job: ActiveJob }) {
  const { t, locale } = useTranslation()
  const isPack = job.kind === 'offline-pack'
  const isAudioBatch = job.kind === 'audio-batch'
  const isNarrationBatch = job.kind === 'translation-audio-batch'

  const pause = () =>
    isNarrationBatch
      ? void pauseTranslationAudioBatch(job.id)
      : isAudioBatch
        ? void pauseAudioBatch(job.id)
        : isPack
          ? void pauseOfflinePack(job.id)
          : void pauseDownload(job.id)
  const resume = () =>
    isNarrationBatch
      ? void resumeTranslationAudioBatch(job.id)
      : isAudioBatch
        ? void resumeAudioBatch(job.id)
        : isPack
          ? void resumeOfflinePack(job.id)
          : void resumeDownload(job.id)
  const retry = () =>
    isNarrationBatch
      ? void resumeTranslationAudioBatch(job.id)
      : isAudioBatch
        ? void resumeAudioBatch(job.id)
        : isPack
          ? void resumeOfflinePack(job.id)
          : void retryDownload(job.id)
  const cancel = () =>
    isNarrationBatch
      ? void cancelTranslationAudioBatch(job.id)
      : isAudioBatch
        ? void cancelAudioBatch(job.id)
        : isPack
          ? void cancelOfflinePack(job.id)
          : void cancelDownload(job.id)
  const dismiss = () =>
    isNarrationBatch
      ? void dismissTranslationAudioBatch(job.id)
      : isAudioBatch
        ? void dismissAudioBatch(job.id)
        : isPack
          ? void dismissPackJob(job.id)
          : void dismissJob(job.id)

  const statusLabel = t(STATUS_LABEL_KEYS[job.status])
  const percent =
    job.totalBytes !== null && job.totalBytes > 0
      ? Math.min(100, Math.max(0, (job.bytesReceived / job.totalBytes) * 100))
      : null

  // Human-safe error message - only for statuses that carry one, and only
  // for codes that actually have a translation.
  let errorKey: TranslationKey | null = null
  if (
    job.errorCode !== null &&
    (job.status === 'interrupted' || job.status === 'failed' || job.status === 'corrupted') &&
    KNOWN_ERROR_CODES.has(job.errorCode)
  ) {
    errorKey = `download.error.${job.errorCode}` as TranslationKey
  }

  let note: { text: string; destructive: boolean } | null = null
  if (job.status === 'queued') {
    note = { text: t('downloads.queuedNote'), destructive: false }
  } else if (job.status === 'paused') {
    note = { text: t('downloads.resumableNote'), destructive: false }
  } else if (errorKey !== null) {
    note = {
      text: t(errorKey),
      destructive: job.status === 'failed' || job.status === 'corrupted',
    }
  }

  const cancelClass = 'h-11 text-destructive hover:bg-destructive/10 hover:text-destructive'

  return (
    <li>
      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <p dir="auto" title={job.translationTitle} className="min-w-0 truncate text-sm font-semibold text-foreground">
              {job.translationTitle}
            </p>
            {job.languageName ? (
              <Badge variant="secondary" dir="auto">
                {job.languageName}
              </Badge>
            ) : null}
            {isNarrationBatch ? (
              <>
                <Badge variant="outline" className="border-amber-600/40 text-amber-700 dark:text-amber-300">
                  {t('downloads.narrationBadge')}
                </Badge>
                {job.translationAudioBatch ? (
                  <Badge variant="outline" dir="auto">
                    {translationAudioBatchLabel(job.translationAudioBatch, t)}
                  </Badge>
                ) : null}
              </>
            ) : isAudioBatch ? (
              <>
                <Badge variant="outline" className="border-primary/30 text-primary">
                  {t('downloads.audioBadge')}
                </Badge>
                {job.audioBatch ? (
                  <Badge variant="outline" dir="auto">
                    {audioBatchLabel(job.audioBatch, t, locale)}
                  </Badge>
                ) : null}
              </>
            ) : isPack ? (
              <Badge variant="outline" className="border-primary/30 text-primary">
                {t('downloads.packBadge')}
              </Badge>
            ) : (
              <Badge variant="outline" className="uppercase">
                {job.format}
              </Badge>
            )}
            {job.status === 'corrupted' ? (
              <Badge variant="destructive">{statusLabel}</Badge>
            ) : (
              <Badge variant="outline" className={STATUS_BADGE_CLASS[job.status]}>
                {job.status === 'verifying' ? (
                  <Loader2 aria-hidden="true" className="size-3 animate-spin" />
                ) : null}
                {statusLabel}
              </Badge>
            )}
          </div>

          {percent !== null ? (
            <Progress value={percent} aria-label={`${statusLabel} · ${job.translationTitle}`} />
          ) : (
            /* PROMPT 14 (Nielsen #1): an indeterminate bar alone cannot be
               distinguished from a stuck one - the state is labeled. */
            <div className="space-y-1">
              <div aria-hidden="true" className="h-2 w-full animate-pulse rounded-full bg-primary/20" />
              <p className="text-xs text-muted-foreground">{t('downloads.measuring')}</p>
            </div>
          )}

          <p className="text-xs tabular-nums text-muted-foreground">
            {formatBytes(locale, job.bytesReceived)}
            {job.totalBytes !== null ? ` / ${formatBytes(locale, job.totalBytes)}` : ''}
            {percent !== null
              ? ` · ${formatNumber(locale, percent, { maximumFractionDigits: 0 })}%`
              : ''}
            {(isAudioBatch || isNarrationBatch) &&
            (job.audioBatch ?? job.translationAudioBatch) ? (
              (() => {
                const batch = (job.audioBatch ?? job.translationAudioBatch)!
                return ` · ${t('downloads.batchProgress', {
                  done: formatNumber(locale, batch.filesCompleted),
                  total: formatNumber(locale, batch.filesTotal),
                })}`
              })()
            ) : (
              ''
            )}
          </p>

          {note ? (
            <p
              className={cn(
                'text-xs leading-relaxed',
                note.destructive ? 'text-destructive' : 'text-muted-foreground',
              )}
            >
              {note.text}
            </p>
          ) : null}

          {job.status !== 'verifying' ? (
            <div className="flex flex-wrap items-center gap-2">
              {job.status === 'downloading' ? (
                <Button variant="outline" className="h-11" onClick={pause}>
                  <Pause aria-hidden="true" className="size-4" />
                  {t('downloads.pause')}
                </Button>
              ) : null}

              {job.status === 'queued' ? (
                <Button variant="ghost" className={cancelClass} onClick={cancel}>
                  <X aria-hidden="true" className="size-4" />
                  {t('downloads.cancel')}
                </Button>
              ) : null}

              {job.status === 'paused' || job.status === 'interrupted' || job.status === 'failed' ? (
                <>
                  <Button variant="outline" className="h-11" onClick={resume}>
                    <Play aria-hidden="true" className="size-4" />
                    {t('downloads.resume')}
                  </Button>
                  <Button variant="ghost" className={cancelClass} onClick={cancel}>
                    <X aria-hidden="true" className="size-4" />
                    {t('downloads.cancel')}
                  </Button>
                </>
              ) : null}

              {job.status === 'corrupted' ? (
                <>
                  <Button variant="outline" className="h-11" onClick={retry}>
                    <RotateCcw aria-hidden="true" className="size-4" />
                    {t('downloads.retryAction')}
                  </Button>
                  <Button variant="ghost" className="h-11" onClick={dismiss}>
                    <Check aria-hidden="true" className="size-4" />
                    {t('downloads.dismiss')}
                  </Button>
                </>
              ) : null}
            </div>
          ) : null}
        </CardContent>
      </Card>
    </li>
  )
}

export function ActiveDownloads() {
  const { t } = useTranslation()
  const jobs = useDownloadManagerStore((s) => s.jobs)
  const restored = useDownloadManagerStore((s) => s.restored)

  const activeJobs = useMemo(
    () =>
      Object.values(jobs)
        .filter((job): job is ActiveJob => isActiveJobStatus(job.status))
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
    [jobs],
  )

  // Stay completely quiet until the engine has restored persisted jobs -
  // otherwise a flash of "no active downloads" would appear on every start.
  if (!restored) return null

  return (
    <section aria-labelledby="active-downloads-heading" className="space-y-3">
      <h2
        id="active-downloads-heading"
        className="text-sm font-semibold uppercase tracking-wide text-muted-foreground"
      >
        {t('downloads.activeSection')}
      </h2>

      {activeJobs.length === 0 ? (
        <Card className="border-dashed bg-card/50 shadow-none">
          <CardContent className="p-4">
            <p className="text-sm font-medium text-foreground">{t('downloads.noActiveDownloads')}</p>
            <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
              {t('downloads.noActiveDownloadsDescription')}
            </p>
          </CardContent>
        </Card>
      ) : (
        <ul className="space-y-3">
          {activeJobs.map((job) => (
            <JobRow key={job.id} job={job} />
          ))}
        </ul>
      )}
    </section>
  )
}
