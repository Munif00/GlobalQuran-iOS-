'use client'

/**
 * Capability matrix card (Settings > About, PROMPT 11 §4).
 *
 * Shows the five language/audio categories, each with its own real count
 * and source - never merged, never implying equal availability:
 *  A. interface languages (80 configured locales),
 *  B. Quran translation languages (live catalog),
 *  C. human-recorded translation narration (verified audio keys),
 *  D. device/browser TTS voices (detected live on THIS device),
 *  E. Quran recitation (verified EveryAyah inventory).
 */

import { useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { AudioLines, Globe, Languages, Mic, Speech } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { platformFetch } from '@/services/platform/fetch'
import type { CapabilitySnapshotDto } from '@/data/capability-matrix'

import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'

interface DetectedVoices {
  status: 'detecting' | 'ready' | 'none' | 'unsupported'
  count: number
  languageSample: string[]
}

/** Detect the REAL device/browser voices (never assumed, never cached). */
function useDetectedVoices(): DetectedVoices {
  const [state, setState] = useState<DetectedVoices>({
    status: 'detecting',
    count: 0,
    languageSample: [],
  })

  useEffect(() => {
    let cancelled = false
    let settled = false
    const detect = () => {
      if (cancelled || settled) return
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        settled = true
        setState({ status: 'unsupported', count: 0, languageSample: [] })
        return
      }
      const voices = window.speechSynthesis.getVoices()
      if (voices.length > 0) {
        settled = true
        const languages = [...new Set(voices.map((voice) => voice.lang))]
        setState({ status: 'ready', count: voices.length, languageSample: languages.slice(0, 8) })
      }
    }
    // Voice lists populate asynchronously in most engines; poll briefly,
    // then settle honestly on whatever was (or was not) detected.
    let polls = 0
    const timer = setInterval(() => {
      polls += 1
      detect()
      if (settled || polls >= 12) {
        clearInterval(timer)
        if (!settled) {
          settled = true
          setState({ status: 'none', count: 0, languageSample: [] })
        }
      }
    }, 250)
    return () => {
      cancelled = true
      clearInterval(timer)
    }
  }, [])

  return state
}

function CategoryRow({
  icon,
  title,
  detail,
  badge,
}: {
  icon: React.ReactNode
  title: string
  detail: string
  badge: string | null
}) {
  return (
    <li className="flex items-start justify-between gap-3 rounded-lg border border-border/60 px-3 py-2.5">
      <div className="flex min-w-0 items-start gap-2.5">
        <span aria-hidden="true" className="mt-0.5 text-primary">
          {icon}
        </span>
        <div className="min-w-0">
          <p className="text-sm font-medium text-foreground">{title}</p>
          <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{detail}</p>
        </div>
      </div>
      {badge !== null && (
        <Badge variant="outline" className="shrink-0 whitespace-nowrap">
          {badge}
        </Badge>
      )}
    </li>
  )
}

export function CapabilityMatrixCard() {
  const { t } = useTranslation()
  const voices = useDetectedVoices()

  const capabilitiesQuery = useQuery({
    queryKey: ['capabilities-matrix'],
    queryFn: async (): Promise<CapabilitySnapshotDto> => {
      /* platformFetch: in the native app this dispatches to the client-side
       * adapter instead of a server that does not exist (the raw fetch
       * would hit the WebView origin and fail). */
      const response = await platformFetch('/api/capabilities', { headers: { Accept: 'application/json' } })
      if (!response.ok) throw new Error('capabilities unavailable')
      return (await response.json()) as CapabilitySnapshotDto
    },
    staleTime: 10 * 60 * 1000,
    retry: 1,
  })

  const ttsBadge = useMemo(() => {
    if (voices.status === 'detecting') return null
    if (voices.status === 'none' || voices.status === 'unsupported') return '0'
    return String(voices.count)
  }, [voices])

  const data = capabilitiesQuery.data

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <Languages aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('capability.title')}</CardTitle>
        </div>
        <CardDescription>{t('capability.description')}</CardDescription>
      </CardHeader>
      <CardContent>
        {capabilitiesQuery.isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-2/3" />
          </div>
        ) : capabilitiesQuery.isError || !data ? (
          <p className="text-sm text-muted-foreground">{t('capability.unavailableNow')}</p>
        ) : (
          <ul className="space-y-2" aria-label={t('capability.title')}>
            <CategoryRow
              icon={<Globe className="size-4" />}
              title={t('capability.interfaceLanguages.title')}
              detail={t('capability.interfaceLanguages.description', {
                count: data.interfaceLanguages.count,
              })}
              badge={`${data.interfaceLanguages.count}`}
            />
            <CategoryRow
              icon={<Languages className="size-4" />}
              title={t('capability.translationLanguages.title')}
              detail={
                data.translationLanguages
                  ? t('capability.translationLanguages.description', {
                      datasets: data.translationLanguages.datasetCount,
                      languages: data.translationLanguages.languageCount,
                    })
                  : t('capability.unavailableNow')
              }
              badge={data.translationLanguages ? `${data.translationLanguages.languageCount}` : '—'}
            />
            <CategoryRow
              icon={<AudioLines className="size-4" />}
              title={t('capability.recordedAudio.title')}
              detail={
                data.recordedTranslationAudio
                  ? t('capability.recordedAudio.description', {
                      count: data.recordedTranslationAudio.translationCount,
                    })
                  : t('capability.unavailableNow')
              }
              badge={data.recordedTranslationAudio ? `${data.recordedTranslationAudio.translationCount}` : '—'}
            />
            <CategoryRow
              icon={<Speech className="size-4" />}
              title={t('capability.deviceTts.title')}
              detail={
                voices.status === 'detecting'
                  ? t('capability.deviceTts.detecting')
                  : voices.status === 'none' || voices.status === 'unsupported'
                    ? t('capability.deviceTts.none')
                    : t('capability.deviceTts.description', {
                        count: voices.count,
                        languages: voices.languageSample.join(' · '),
                      })
              }
              badge={ttsBadge}
            />
            <CategoryRow
              icon={<Mic className="size-4" />}
              title={t('capability.recitation.title')}
              detail={t('capability.recitation.description', {
                styles: data.recitation.styleCount,
                ayat: data.recitation.ayatPerStyle,
              })}
              badge={`${data.recitation.styleCount}`}
            />
          </ul>
        )}
      </CardContent>
    </Card>
  )
}
