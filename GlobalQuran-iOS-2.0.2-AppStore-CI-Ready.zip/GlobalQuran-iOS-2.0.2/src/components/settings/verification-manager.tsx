'use client'

/**
 * Verification management (administrator tool).
 *
 * Lists the administrator-attached institutional verification records,
 * lets the admin attach evidence (reviewing authority, official source,
 * document reference, verification date, reviewer notes, status) to any
 * real QuranEnc translation, and remove records again.
 *
 * Honesty rules enforced by the UI:
 * - Only translations that actually exist in the live catalog can be selected.
 * - The four statuses are the app-wide verification states.
 * - A visible note reminds the admin that "Officially verified" requires
 *   documentary evidence; listing on QuranEnc is not institutional approval.
 */

import { useEffect, useMemo, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { BadgeCheck, Loader2, Pencil, Plus, ShieldCheck, Trash2 } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import {
  deleteVerificationRecord,
  getAdminToken,
  getTranslationsCatalog,
  listVerificationRecords,
  setAdminToken,
  upsertVerificationRecord,
} from '@/services/api/catalog-api'
import { describeApiError } from '@/services/api/errors'
import { normalizeForSearch } from '@/utils/text-normalize'
import type { VerificationRecordDto, VerificationStatus } from '@/types'

import { VerificationBadge } from '@/components/design-system/verification-badge'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'

const VERIFICATION_STATUSES: VerificationStatus[] = [
  'official_verified',
  'awaiting_verification',
  'not_verified',
  'rejected',
]

interface FormState {
  translationKey: string
  status: VerificationStatus
  reviewingAuthority: string
  officialSource: string
  documentReference: string
  verifiedAt: string
  reviewerNotes: string
}

const EMPTY_FORM: FormState = {
  translationKey: '',
  status: 'awaiting_verification',
  reviewingAuthority: '',
  officialSource: '',
  documentReference: '',
  verifiedAt: '',
  reviewerNotes: '',
}

export function VerificationManager() {
  const { t, locale } = useTranslation()
  const queryClient = useQueryClient()

  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingRecord, setEditingRecord] = useState<VerificationRecordDto | null>(null)
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [translationSearch, setTranslationSearch] = useState('')
  const [isSaving, setIsSaving] = useState(false)
  const [adminToken, setAdminTokenState] = useState('')

  useEffect(() => {
    setAdminTokenState(getAdminToken())
  }, [])

  const saveAdminToken = (value: string) => {
    setAdminTokenState(value)
    setAdminToken(value)
  }

  const recordsQuery = useQuery({
    queryKey: ['verification-records'],
    queryFn: listVerificationRecords,
    staleTime: 30_000,
    retry: 1,
  })

  const catalogQuery = useQuery({
    queryKey: ['translations-catalog', locale],
    queryFn: () => getTranslationsCatalog(locale),
    staleTime: 300_000,
    retry: 1,
  })

  const catalogItems = useMemo(() => catalogQuery.data?.items ?? [], [catalogQuery.data])

  const filteredTranslations = useMemo(() => {
    const query = normalizeForSearch(translationSearch)
    if (!query) return catalogItems.slice(0, 60)
    return catalogItems
      .filter((item) =>
        // Admin tool: matching the technical key is appropriate here.
        [item.title, item.languageName, item.languageNativeName ?? '', item.key]
          .some((field) => normalizeForSearch(field).includes(query)),
      )
      .slice(0, 60)
  }, [catalogItems, translationSearch])

  useEffect(() => {
    if (!dialogOpen) {
      setTranslationSearch('')
    }
  }, [dialogOpen])

  const openCreate = () => {
    setEditingRecord(null)
    setForm(EMPTY_FORM)
    setDialogOpen(true)
  }

  const openEdit = (record: VerificationRecordDto) => {
    setEditingRecord(record)
    setForm({
      translationKey: record.translationKey,
      status: record.status,
      reviewingAuthority: record.reviewingAuthority ?? '',
      officialSource: record.officialSource ?? '',
      documentReference: record.documentReference ?? '',
      verifiedAt: record.verifiedAt ? record.verifiedAt.slice(0, 10) : '',
      reviewerNotes: record.reviewerNotes ?? '',
    })
    setDialogOpen(true)
  }

  const selectedTranslation = catalogItems.find((item) => item.key === form.translationKey)

  const handleSave = async () => {
    if (!form.translationKey) {
      toast.error(t('common.error'), { description: t('settings.verificationSelectTranslation') })
      return
    }
    setIsSaving(true)
    try {
      await upsertVerificationRecord({
        translationKey: form.translationKey,
        status: form.status,
        reviewingAuthority: form.reviewingAuthority.trim() || null,
        officialSource: form.officialSource.trim() || null,
        documentReference: form.documentReference.trim() || null,
        verifiedAt: form.verifiedAt ? new Date(form.verifiedAt).toISOString() : null,
        reviewerNotes: form.reviewerNotes.trim() || null,
      })
      await queryClient.invalidateQueries({ queryKey: ['verification-records'] })
      await queryClient.invalidateQueries({ queryKey: ['translations-catalog'] })
      toast.success(t('settings.verificationSaved'))
      setDialogOpen(false)
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async (key: string) => {
    try {
      await deleteVerificationRecord(key)
      await queryClient.invalidateQueries({ queryKey: ['verification-records'] })
      await queryClient.invalidateQueries({ queryKey: ['translations-catalog'] })
      toast(t('settings.verificationRemoved'))
    } catch (error) {
      toast.error(t('common.error'), { description: describeApiError(error, t) })
    }
  }

  const records = recordsQuery.data?.records ?? []

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <BadgeCheck aria-hidden="true" className="size-5 text-primary" />
            <CardTitle className="text-base">{t('settings.verificationManagement')}</CardTitle>
          </div>
          <Button size="sm" className="h-11" onClick={openCreate}>
            <Plus aria-hidden="true" className="size-4" />
            {t('settings.verificationAdd')}
          </Button>
        </div>
        <CardDescription>{t('settings.verificationManagementDescription')}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="flex items-start gap-1.5 rounded-lg border border-gold/40 bg-gold/10 p-3 text-xs leading-relaxed text-gold-foreground">
          <ShieldCheck aria-hidden="true" className="mt-0.5 size-3.5 shrink-0" />
          {t('settings.verificationHonestyNote')}
        </p>

        {/* Administrator access token (sent only as a request header, kept in
            sessionStorage, never written to disk). */}
        <div className="space-y-1.5">
          <Label htmlFor="admin-token-input" className="text-xs">
            {t('settings.verificationAdminToken')}
          </Label>
          <Input
            id="admin-token-input"
            type="password"
            autoComplete="off"
            spellCheck={false}
            value={adminToken}
            onChange={(event) => saveAdminToken(event.target.value)}
            placeholder={t('settings.verificationAdminTokenPlaceholder')}
            className="max-w-md"
          />
          <p className="text-xs leading-relaxed text-muted-foreground">
            {t('settings.verificationAdminTokenNote')}
          </p>
        </div>

        {recordsQuery.isPending ? (
          <p className="text-sm text-muted-foreground" role="status">
            {t('common.loading')}
          </p>
        ) : recordsQuery.isError ? (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">{t('common.errorDescription')}</p>
            <Button
              variant="outline"
              size="sm"
              className="h-11"
              onClick={() => void recordsQuery.refetch()}
            >
              {t('common.retry')}
            </Button>
          </div>
        ) : records.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t('settings.verificationEmpty')}</p>
        ) : (
          <ul className="space-y-2">
            {records.map((record) => {
              const translation = catalogItems.find((item) => item.key === record.translationKey)
              return (
                <li
                  key={record.translationKey}
                  className="flex flex-wrap items-start justify-between gap-3 rounded-lg border border-border/70 p-3"
                >
                  <div className="min-w-0">
                    <p dir="auto" className="truncate text-sm font-medium text-foreground">
                      {translation?.title ?? record.translationKey}
                    </p>
                    <p className="mt-0.5 font-mono text-xs text-muted-foreground">
                      {record.translationKey}
                    </p>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <VerificationBadge status={record.status} />
                      {record.reviewingAuthority ? (
                        <Badge variant="secondary">
                          <span dir="auto" className="max-w-48 truncate">
                            {record.reviewingAuthority}
                          </span>
                        </Badge>
                      ) : null}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-11"
                      onClick={() => openEdit(record)}
                    >
                      <Pencil aria-hidden="true" className="size-4" />
                      {t('common.edit')}
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-11 text-destructive hover:bg-destructive/10 hover:text-destructive"
                        >
                          <Trash2 aria-hidden="true" className="size-4" />
                          {t('settings.verificationRemove')}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            {t('settings.verificationRemoveConfirmTitle')}
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            {t('settings.verificationRemoveConfirmDescription')}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="h-11">{t('common.cancel')}</AlertDialogCancel>
                          <AlertDialogAction
                            className="h-11 bg-destructive text-white hover:bg-destructive/90"
                            onClick={() => void handleDelete(record.translationKey)}
                          >
                            {t('common.confirm')}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </li>
              )
            })}
          </ul>
        )}

        {/* Create / edit dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg scrollbar-subtle">
            <DialogHeader>
              <DialogTitle>
                {editingRecord ? t('settings.verificationEdit') : t('settings.verificationAdd')}
              </DialogTitle>
              <DialogDescription>{t('settings.verificationHonestyNote')}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* Translation selector */}
              <div className="space-y-2">
                <Label htmlFor="verification-translation-search">
                  {t('settings.verificationSelectTranslation')}
                </Label>
                {!editingRecord ? (
                  <>
                    <Input
                      id="verification-translation-search"
                      type="search"
                      value={translationSearch}
                      onChange={(event) => setTranslationSearch(event.target.value)}
                      placeholder={t('settings.verificationSearchTranslation')}
                      className="h-11"
                    />
                    <div
                      role="listbox"
                      aria-label={t('settings.verificationSelectTranslation')}
                      className="max-h-48 overflow-y-auto rounded-lg border border-border/70 scrollbar-subtle"
                    >
                      {catalogQuery.isPending ? (
                        <p className="p-3 text-sm text-muted-foreground">{t('common.loading')}</p>
                      ) : filteredTranslations.length === 0 ? (
                        <p className="p-3 text-sm text-muted-foreground">{t('quran.noResultsTitle')}</p>
                      ) : (
                        filteredTranslations.map((item) => (
                          <button
                            key={item.key}
                            type="button"
                            role="option"
                            aria-selected={form.translationKey === item.key}
                            onClick={() => setForm((prev) => ({ ...prev, translationKey: item.key }))}
                            className={
                              form.translationKey === item.key
                                ? 'block w-full border-b border-border/50 bg-primary/[0.08] px-3 py-2.5 text-start last:border-b-0'
                                : 'block w-full border-b border-border/50 px-3 py-2.5 text-start transition-colors last:border-b-0 hover:bg-accent/60'
                            }
                          >
                            <span dir="auto" className="block truncate text-sm font-medium text-foreground">
                              {item.title}
                            </span>
                            <span className="mt-0.5 block text-xs text-muted-foreground">
                              {item.languageNativeName ?? item.languageName} · {item.key}
                            </span>
                          </button>
                        ))
                      )}
                    </div>
                  </>
                ) : (
                  <p dir="auto" className="rounded-lg border border-border/70 bg-muted/40 p-3 text-sm text-foreground">
                    {selectedTranslation?.title ?? editingRecord.translationKey}
                    <span className="ms-2 font-mono text-xs text-muted-foreground">
                      {editingRecord.translationKey}
                    </span>
                  </p>
                )}
              </div>

              {/* Status */}
              <div className="space-y-2">
                <span className="text-sm font-medium text-foreground">
                  {t('settings.verificationStatusField')}
                </span>
                <Select
                  value={form.status}
                  onValueChange={(value) =>
                    setForm((prev) => ({ ...prev, status: value as VerificationStatus }))
                  }
                >
                  <SelectTrigger className="h-11 w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {VERIFICATION_STATUSES.map((status) => (
                      <SelectItem key={status} value={status}>
                        {t(`quran.verification.${status}` as TranslationKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Evidence fields */}
              {(
                [
                  ['reviewingAuthority', 'settings.verificationAuthority'],
                  ['officialSource', 'settings.verificationOfficialSource'],
                  ['documentReference', 'settings.verificationDocument'],
                ] as const
              ).map(([field, labelKey]) => (
                <div key={field} className="space-y-2">
                  <Label htmlFor={`verification-${field}`}>
                    {t(labelKey)}{' '}
                    <span className="font-normal text-muted-foreground">({t('common.optional')})</span>
                  </Label>
                  <Input
                    id={`verification-${field}`}
                    value={form[field]}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, [field]: event.target.value }))
                    }
                    className="h-11"
                    maxLength={300}
                  />
                </div>
              ))}

              <div className="space-y-2">
                <Label htmlFor="verification-date">
                  {t('settings.verificationDate')}{' '}
                  <span className="font-normal text-muted-foreground">({t('common.optional')})</span>
                </Label>
                <Input
                  id="verification-date"
                  type="date"
                  value={form.verifiedAt}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, verifiedAt: event.target.value }))
                  }
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="verification-notes">
                  {t('settings.verificationNotes')}{' '}
                  <span className="font-normal text-muted-foreground">({t('common.optional')})</span>
                </Label>
                <textarea
                  id="verification-notes"
                  value={form.reviewerNotes}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, reviewerNotes: event.target.value }))
                  }
                  rows={3}
                  maxLength={2000}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" className="h-11" onClick={() => setDialogOpen(false)}>
                {t('common.cancel')}
              </Button>
              <Button className="h-11" onClick={() => void handleSave()} disabled={isSaving}>
                {isSaving ? (
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                ) : null}
                {t('common.save')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}
