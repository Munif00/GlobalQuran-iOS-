'use client'

/**
 * Settings card: the mobile application.
 *
 * An always-available, honest install surface:
 * - shows whether the app currently runs as an installed application;
 * - when not installed, offers the install action with the right flow per
 *   platform (native prompt / guided steps);
 * - when running standalone, confirms the installed state and version.
 */

import { useState } from 'react'
import { Check, Smartphone, SwatchBook } from 'lucide-react'

import { useTranslation } from '@/i18n'
import { useInstallPrompt } from '@/hooks/use-install-prompt'
import { APP_VERSION } from '@/lib/app-info'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { InfoRow } from '@/components/design-system/info-row'
import { InstallDialog } from '@/components/app/install-dialog'
import { NativeAppDownloadCard } from '@/components/app/native-app-download'
import { cn } from '@/lib/utils'

export function InstallCard() {
  const { t } = useTranslation()
  const { mounted, platform, isStandalone, canInstall, install, isPrompting } = useInstallPrompt()
  const [dialogOpen, setDialogOpen] = useState(false)

  const handleInstall = () => {
    if (platform !== 'ios') {
      void install().then((outcome) => {
        if (outcome === 'unavailable') setDialogOpen(true)
      })
    } else {
      setDialogOpen(true)
    }
  }

  const statusValue = mounted
    ? isStandalone
      ? t('install.settingsStatusInstalled')
      : canInstall
        ? t('install.settingsStatusNotInstalled')
        : t('install.settingsStatusBrowserOnly')
    : t('common.loading')

  return (
    <Card id="mobile-app">
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <Smartphone aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('install.settingsTitle')}</CardTitle>
        </div>
        <CardDescription>{t('install.settingsDescription')}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap items-center justify-between gap-3">
        <dl className="min-w-0 flex-1">
          <InfoRow
            label={t('install.settingsStatus')}
            value={
              <span
                className={cn(
                  'inline-flex items-center gap-1.5 font-medium',
                  mounted && isStandalone ? 'text-success' : 'text-foreground',
                )}
              >
                {mounted && isStandalone ? (
                  <Check aria-hidden="true" className="size-3.5" />
                ) : (
                  <SwatchBook aria-hidden="true" className="size-3.5 text-muted-foreground" />
                )}
                {statusValue}
              </span>
            }
          />
          {mounted && isStandalone ? (
            <InfoRow label={t('settings.aboutVersion')} value={APP_VERSION} />
          ) : null}
        </dl>
        {mounted && !isStandalone ? (
          <Button variant="outline" size="sm" onClick={handleInstall} disabled={isPrompting}>
            {isPrompting ? t('common.loading') : t('install.openSettingsLabel')}
          </Button>
        ) : null}
      </CardContent>
      {mounted && !isStandalone ? (
        <CardContent className="border-t pt-4">
          <NativeAppDownloadCard className="border-0 shadow-none" />
        </CardContent>
      ) : null}
      <InstallDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </Card>
  )
}
