'use client'

/**
 * Integration status card (Settings > About).
 *
 * Moved from the Home screen: it is honest, useful information, but too
 * technical for the daily starting point. Advanced details live here in the
 * secondary information screen, using only user-facing labels (no API names).
 */

import { ShieldCheck } from 'lucide-react'

import { useTranslation, type TranslationKey } from '@/i18n'
import { useAppConfig } from '@/hooks/use-app-config'
import type { AppConfigDto, IntegrationState } from '@/types'

import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

const INTEGRATION_LABELS: Array<{
  key: keyof AppConfigDto['integrations']
  labelKey: TranslationKey
}> = [
  { key: 'quranText', labelKey: 'quran.quranTextTitle' },
  { key: 'translationsCatalog', labelKey: 'home.translationLibrary' },
  { key: 'prayerTimes', labelKey: 'prayer.title' },
  { key: 'qibla', labelKey: 'qibla.title' },
  { key: 'offlineDownloads', labelKey: 'downloads.title' },
]

function integrationBadgeClass(status: IntegrationState): string {
  switch (status) {
    case 'live':
      return 'border-success/40 bg-success/10 text-success'
    case 'partial':
    case 'in_progress':
      return 'border-gold/40 bg-gold/10 text-gold-foreground'
    case 'planned':
    default:
      return 'border-border bg-muted text-muted-foreground'
  }
}

export function IntegrationStatusCard() {
  const { t } = useTranslation()
  const configQuery = useAppConfig()

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2.5">
          <ShieldCheck aria-hidden="true" className="size-5 text-primary" />
          <CardTitle className="text-base">{t('home.integrationStatus')}</CardTitle>
        </div>
        <CardDescription>{t('home.integrationStatusDescription')}</CardDescription>
      </CardHeader>
      <CardContent>
        {configQuery.isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-2/3" />
          </div>
        ) : configQuery.isError ? (
          <p className="text-sm text-muted-foreground">{t('common.notAvailableYet')}</p>
        ) : configQuery.data ? (
          <ul className="space-y-2">
            {INTEGRATION_LABELS.map(({ key, labelKey }) => {
              const integration = configQuery.data.integrations[key]
              return (
                <li
                  key={key}
                  className="flex items-center justify-between gap-3 rounded-lg border border-border/60 px-3 py-2.5"
                >
                  <span className="min-w-0 truncate text-sm font-medium text-foreground">
                    {t(labelKey)}
                  </span>
                  <Badge
                    variant="outline"
                    className={cn('shrink-0', integrationBadgeClass(integration.status))}
                  >
                    {t(`integration.${integration.status}` as TranslationKey)}
                  </Badge>
                </li>
              )
            })}
          </ul>
        ) : null}
      </CardContent>
    </Card>
  )
}
