/**
 * Recitation style definitions - the verified reciter catalog.
 *
 * SINGLE SOURCE OF TRUTH shared by the client UI and the server API.
 *
 * Honesty rules (project-wide): reciter metadata is NEVER invented.
 * - `folder` identifiers, bitrate labels and the official source name come
 *   from EveryAyah's own published metadata (data/recitations.js).
 * - `bioNote` facts were verified against independent encyclopedic sources
 *   (Wikipedia REST summaries, retrieved at release verification time) and
 *   are attributed in `bioNoteSource`. A style only carries a bio/mosque
 *   association line when that association was verified; unverified
 *   descriptions are simply absent, never guessed.
 * - `styleDescription` describes what the STYLE means (a well-established
 *   recitation term), not unverifiable biographical claims.
 * - Per-ayah availability and file sizes come exclusively from the verified
 *   seed catalog (src/data/audio-catalog-seed.json) and the live checks in
 *   src/server/audio/everyayah.ts - never from this file.
 */

export type RecitationStyleKind = 'muallim' | 'murattal' | 'mujawwad'

export interface RecitationStyleDefinition {
  /** Stable catalog id (used in APIs, storage and URLs). */
  id: string
  /** EveryAyah folder identifier (verified against everyayah.com). */
  folder: string
  /** Reciter display name (verified form). */
  reciterName: string
  /** Reciter name in Arabic script. */
  reciterNameArabic: string
  /** Recitation style kind. */
  style: RecitationStyleKind
  /** Style label shown to users. */
  styleLabel: string
  /** Nominal bitrate from the EveryAyah folder metadata. */
  bitrate: '128kbps' | '192kbps'
  /** Audio file format (all EveryAyah files are MP3). */
  format: 'mp3'
  /** Source attribution line for the recording itself. */
  sourceName: string
  /** Recording host that serves the files. */
  sourceSite: string
  /** Verified encyclopedic note (only where independently verified). */
  bioNote: string | null
  /** Faithful Arabic rendering of the verified bioNote (translation only -
   *  the facts and their verification source are unchanged). */
  bioNoteArabic: string | null
  /** Where the bioNote facts were verified. */
  bioNoteSource: string | null
  /** Arabic rendering of the verification source line. */
  bioNoteSourceArabic: string | null
  /** Whether this style is intended for learning and repetition. */
  forLearning: boolean
}

export const RECITATION_STYLES: readonly RecitationStyleDefinition[] = [
  {
    id: 'husary-muallim',
    folder: 'Husary_Muallim_128kbps',
    reciterName: 'Mahmoud Khalil Al-Husary',
    reciterNameArabic: 'محمود خليل الحصري',
    style: 'muallim',
    styleLabel: "Muallim (teacher's recitation)",
    bitrate: '128kbps',
    format: 'mp3',
    sourceName: 'EveryAyah',
    sourceSite: 'https://everyayah.com',
    bioNote:
      'Egyptian Quran reciter and scholar of Quranic readings (1917-1980). His Muallim recording follows a measured, teaching-paced recitation.',
    bioNoteArabic:
      'قارئ قرآن مصري وعالم بالقراءات (1917-1980). تسجيله «المعلّم» على قراءة متأنية بإيقاع تعليمي.',
    bioNoteSource: 'Verified via Wikipedia (Mahmoud Khalil Al-Hussary)',
    bioNoteSourceArabic: 'موثّق عبر ويكيبيديا (محمود خليل الحصري)',
    forLearning: true,
  },
  {
    id: 'abdulbasit-murattal',
    folder: 'Abdul_Basit_Murattal_192kbps',
    reciterName: 'Abdul Basit Abdus-Samad',
    reciterNameArabic: 'عبد الباسط عبد الصمد',
    style: 'murattal',
    styleLabel: 'Murattal (measured)',
    bitrate: '192kbps',
    format: 'mp3',
    sourceName: 'EveryAyah',
    sourceSite: 'https://everyayah.com',
    bioNote:
      'Egyptian Quran reciter (1927-1988), renowned for his recitation in both murattal and melodic mujawwad styles.',
    bioNoteArabic:
      'قارئ قرآن مصري (1927-1988)، اشتهر بتلاوته بالأسلوبين المرتّل والمجوّد.',
    bioNoteSource: "Verified via Wikipedia (Abdul Basit 'Abd us-Samad)",
    bioNoteSourceArabic: 'موثّق عبر ويكيبيديا (عبد الباسط عبد الصمد)',
    forLearning: false,
  },
  {
    id: 'abdulbasit-mujawwad',
    folder: 'Abdul_Basit_Mujawwad_128kbps',
    reciterName: 'Abdul Basit Abdus-Samad',
    reciterNameArabic: 'عبد الباسط عبد الصمد',
    style: 'mujawwad',
    styleLabel: 'Mujawwad (melodic)',
    bitrate: '128kbps',
    format: 'mp3',
    sourceName: 'EveryAyah',
    sourceSite: 'https://everyayah.com',
    bioNote:
      'Egyptian Quran reciter (1927-1988), renowned for his recitation in both murattal and melodic mujawwad styles.',
    bioNoteArabic:
      'قارئ قرآن مصري (1927-1988)، اشتهر بتلاوته بالأسلوبين المرتّل والمجوّد.',
    bioNoteSource: "Verified via Wikipedia (Abdul Basit 'Abd us-Samad)",
    bioNoteSourceArabic: 'موثّق عبر ويكيبيديا (عبد الباسط عبد الصمد)',
    forLearning: false,
  },
  {
    id: 'hudhaify',
    folder: 'Hudhaify_128kbps',
    reciterName: 'Ali Al-Hudhaify',
    reciterNameArabic: 'علي الحذيفي',
    style: 'murattal',
    styleLabel: 'Murattal (measured)',
    bitrate: '128kbps',
    format: 'mp3',
    sourceName: 'EveryAyah',
    sourceSite: 'https://everyayah.com',
    bioNote:
      'Saudi imam; Imam of the Prophet’s Mosque (Al-Masjid an-Nabawi) in Medina.',
    bioNoteArabic:
      'إمام سعودي؛ إمام المسجد النبوي الشريف في المدينة المنورة.',
    bioNoteSource: 'Verified via Wikipedia (Ali al-Hudhayfi)',
    bioNoteSourceArabic: 'موثّق عبر ويكيبيديا (علي الحذيفي)',
    forLearning: false,
  },
  {
    id: 'salah-budair',
    folder: 'Salah_Al_Budair_128kbps',
    reciterName: 'Salah Al-Budair',
    reciterNameArabic: 'صلاح البدير',
    style: 'murattal',
    styleLabel: 'Murattal (measured)',
    bitrate: '128kbps',
    format: 'mp3',
    sourceName: 'EveryAyah',
    sourceSite: 'https://everyayah.com',
    bioNote:
      'Saudi imam; imam of the Prophet’s Mosque (Al-Masjid an-Nabawi) in Medina.',
    bioNoteArabic:
      'إمام سعودي؛ إمام المسجد النبوي الشريف في المدينة المنورة.',
    bioNoteSource: 'Verified via Wikipedia (Salah Al Budair)',
    bioNoteSourceArabic: 'موثّق عبر ويكيبيديا (صلاح البدير)',
    forLearning: false,
  },
]

/** Style lookup by id. */
export function getStyleDefinition(styleId: string): RecitationStyleDefinition | undefined {
  return RECITATION_STYLES.find((style) => style.id === styleId)
}

/** True when the style id is part of the verified catalog. */
export function isKnownStyleId(styleId: string): boolean {
  return getStyleDefinition(styleId) !== undefined
}
