/**
 * Global Quran - capability matrix (PROMPT 11 §4).
 *
 * The app deliberately distinguishes FIVE language/audio capability
 * categories that must NEVER be merged or implied equal:
 *
 *  A. Interface languages - the configured app UI locales (exactly 80).
 *  B. Quran translation languages - datasets with translated text that the
 *     QuranEnc catalog actually publishes.
 *  C. Human-recorded translation narration - translations whose recorded
 *     audio the QuranEnc audio dashboard actually serves (verified keys +
 *     manifests only).
 *  D. Device/browser TTS voices - whatever speechSynthesis exposes on THIS
 *     device at runtime; never assumed, never listed before detected.
 *  E. Quran recitation - the verified EveryAyah reciter catalog (styles,
 *     ayat coverage, live availability).
 *
 * Each category reports its own count, its own source and its own honesty
 * note. A translation language without recorded audio is in B but not C;
 * a language with no installed voice is in neither D's detected set nor
 * claimable; recitation (E) is Arabic-only and completely separate from
 * every translation-related category.
 */

import { RECITATION_STYLES } from '@/data/audio-styles'
import { SUPPORTED_LOCALES } from '@/i18n/config'

/** Stable category ids (used by the API and the Settings card). */
export type CapabilityCategoryId =
  | 'interface-languages'
  | 'translation-languages'
  | 'recorded-translation-audio'
  | 'device-tts'
  | 'recitation-audio'

export interface CapabilityCategory {
  id: CapabilityCategoryId
  /** Display label key base (i18n: capability.<id>.title / .description). */
  titleKey: string
  descriptionKey: string
  /** Where this category's availability comes from (shown to the user). */
  source: string
  /** Whether the count can only be determined on the device at runtime. */
  runtimeOnly: boolean
}

export const CAPABILITY_CATEGORIES: readonly CapabilityCategory[] = [
  {
    id: 'interface-languages',
    titleKey: 'capability.interfaceLanguages.title',
    descriptionKey: 'capability.interfaceLanguages.description',
    source: 'App locale registry',
    runtimeOnly: false,
  },
  {
    id: 'translation-languages',
    titleKey: 'capability.translationLanguages.title',
    descriptionKey: 'capability.translationLanguages.description',
    source: 'QuranEnc translation catalog (live)',
    runtimeOnly: false,
  },
  {
    id: 'recorded-translation-audio',
    titleKey: 'capability.recordedAudio.title',
    descriptionKey: 'capability.recordedAudio.description',
    source: 'QuranEnc audio dashboard (verified manifests)',
    runtimeOnly: false,
  },
  {
    id: 'device-tts',
    titleKey: 'capability.deviceTts.title',
    descriptionKey: 'capability.deviceTts.description',
    source: 'This device (detected at runtime)',
    runtimeOnly: true,
  },
  {
    id: 'recitation-audio',
    titleKey: 'capability.recitation.title',
    descriptionKey: 'capability.recitation.description',
    source: 'EveryAyah (verified inventory)',
    runtimeOnly: false,
  },
] as const

/** Category A: the exact number of configured interface locales. */
export const INTERFACE_LANGUAGE_COUNT: number = SUPPORTED_LOCALES.length

/** Category E: recitation styles from the verified catalog definition. */
export const RECITATION_STYLE_COUNT: number = RECITATION_STYLES.length

/** Server-side capability snapshot (A/B/C/E). D is device-runtime only. */
export interface CapabilitySnapshotDto {
  interfaceLanguages: {
    count: number
    completeCount: number
    /** Locales with zero translated strings (pure English fallback). */
    untranslatedCodes: string[]
    source: string
  }
  translationLanguages: {
    datasetCount: number
    languageCount: number
    sampleLanguages: string[]
    source: string
    checkedAt: string
  } | null
  recordedTranslationAudio: {
    translationCount: number
    languageIsos: string[]
    sampleNames: string[]
    source: string
    checkedAt: string
  } | null
  deviceTts: {
    runtimeOnly: true
    note: string
  }
  recitation: {
    styleCount: number
    ayatPerStyle: number
    completeStyles: number
    source: string
    verifiedAt: string
  }
  generatedAt: string
}
