/**
 * Juz index - the standard 30-part division of the Quran.
 *
 * Each juz is defined by its starting position (sura, ayah) and runs up to
 * (excluding) the next juz's start; Juz 30 runs to the end of the Quran.
 * The start positions are the widely published standard boundaries (the
 * machine-readable juz table published by Tanzil.net, which quran.com and
 * other reference readers use).
 *
 * Honesty rules: only the boundaries themselves live here - no additional
 * metadata is invented. Every boundary is validated at load time against the
 * authentic structural index (sura exists, ayah within the sura); a mismatch
 * would be a programming error and is surfaced as an exception rather than
 * silently serving wrong divisions.
 */

import { SURA_INDEX } from '@/data/sura-index'
import { getSuraAyahCount } from '@/lib/audio/urls'

export interface JuzBoundary {
  /** Juz number (1-30). */
  juz: number
  /** Sura the juz starts in. */
  startSura: number
  /** Ayah the juz starts at. */
  startAyah: number
}

/**
 * The 30 standard juz start boundaries.
 * Source: Tanzil.net juz division (standard aya-to-juz mapping).
 */
const JUZ_BOUNDARIES: readonly JuzBoundary[] = [
  { juz: 1, startSura: 1, startAyah: 1 },
  { juz: 2, startSura: 2, startAyah: 142 },
  { juz: 3, startSura: 2, startAyah: 253 },
  { juz: 4, startSura: 3, startAyah: 93 },
  { juz: 5, startSura: 4, startAyah: 24 },
  { juz: 6, startSura: 4, startAyah: 148 },
  { juz: 7, startSura: 5, startAyah: 82 },
  { juz: 8, startSura: 6, startAyah: 111 },
  { juz: 9, startSura: 7, startAyah: 88 },
  { juz: 10, startSura: 8, startAyah: 41 },
  { juz: 11, startSura: 9, startAyah: 93 },
  { juz: 12, startSura: 11, startAyah: 6 },
  { juz: 13, startSura: 12, startAyah: 53 },
  { juz: 14, startSura: 15, startAyah: 1 },
  { juz: 15, startSura: 17, startAyah: 1 },
  { juz: 16, startSura: 18, startAyah: 75 },
  { juz: 17, startSura: 21, startAyah: 1 },
  { juz: 18, startSura: 23, startAyah: 1 },
  { juz: 19, startSura: 25, startAyah: 21 },
  { juz: 20, startSura: 27, startAyah: 56 },
  { juz: 21, startSura: 29, startAyah: 46 },
  { juz: 22, startSura: 33, startAyah: 31 },
  { juz: 23, startSura: 36, startAyah: 28 },
  { juz: 24, startSura: 39, startAyah: 32 },
  { juz: 25, startSura: 41, startAyah: 47 },
  { juz: 26, startSura: 46, startAyah: 1 },
  { juz: 27, startSura: 51, startAyah: 31 },
  { juz: 28, startSura: 58, startAyah: 1 },
  { juz: 29, startSura: 67, startAyah: 1 },
  { juz: 30, startSura: 78, startAyah: 1 },
]

/** Validate every boundary against the structural index (fail loudly). */
function validateBoundaries(): void {
  if (JUZ_BOUNDARIES.length !== 30) {
    throw new Error('Juz index must contain exactly 30 boundaries')
  }
  for (let i = 0; i < JUZ_BOUNDARIES.length; i += 1) {
    const boundary = JUZ_BOUNDARIES[i]
    if (boundary.juz !== i + 1) throw new Error('Juz boundaries must be ordered 1..30')
    if (getSuraAyahCount(boundary.startSura) === 0) {
      throw new Error(`Juz ${boundary.juz} references an invalid sura`)
    }
    if (boundary.startAyah < 1 || boundary.startAyah > getSuraAyahCount(boundary.startSura)) {
      throw new Error(`Juz ${boundary.juz} references an invalid ayah`)
    }
  }
}

validateBoundaries()

export const JUZ_COUNT = JUZ_BOUNDARIES.length

/** All 30 boundaries (readonly). */
export function getJuzBoundaries(): readonly JuzBoundary[] {
  return JUZ_BOUNDARIES
}

/** One boundary by juz number (1-30); null when invalid. */
export function getJuzBoundary(juz: number): JuzBoundary | null {
  if (!Number.isInteger(juz) || juz < 1 || juz > JUZ_COUNT) return null
  return JUZ_BOUNDARIES[juz - 1]
}

/** The juz a position falls into (1-30); null for invalid positions. */
export function getJuzForPosition(sura: number, ayah: number): number | null {
  if (getSuraAyahCount(sura) === 0 || ayah < 1 || ayah > getSuraAyahCount(sura)) return null
  for (let i = JUZ_BOUNDARIES.length - 1; i >= 0; i -= 1) {
    const boundary = JUZ_BOUNDARIES[i]
    if (sura > boundary.startSura || (sura === boundary.startSura && ayah >= boundary.startAyah)) {
      return boundary.juz
    }
  }
  return null
}

/** A serializable position inside the Quran. */
export interface QuranPosition {
  sura: number
  ayah: number
}

/**
 * Every (sura, ayah) position of one juz in reading order - the exact file
 * list a juz audio download covers.
 */
export function getJuzPositions(juz: number): QuranPosition[] {
  const boundary = getJuzBoundary(juz)
  if (!boundary) return []
  const next = juz < JUZ_COUNT ? JUZ_BOUNDARIES[juz] : null

  const positions: QuranPosition[] = []
  for (let sura = boundary.startSura; sura <= (next?.startSura ?? SURA_INDEX.length); sura += 1) {
    const ayahCount = getSuraAyahCount(sura)
    const from = sura === boundary.startSura ? boundary.startAyah : 1
    const to = next && sura === next.startSura ? next.startAyah - 1 : ayahCount
    for (let ayah = from; ayah <= to; ayah += 1) {
      positions.push({ sura, ayah })
    }
  }
  return positions
}
