/**
 * Sura index - structural navigation metadata.
 *
 * - `ayahCount` values are derived from the official QuranEnc Hafs v20 text
 *   package (Quran_text.csv, 6236 numbered ayat).
 * - `nameArabic` / `nameEnglish` are the localized sura names returned by the
 *   documented QuranEnc endpoint GET /api/v1/translations/sowar_names
 *   (captured from the live API, not edited by hand).
 * - No other metadata is invented: revelation place and other details are not
 *   part of this source and are therefore absent.
 */

export interface SuraMeta {
  number: number
  ayahCount: number
  nameArabic: string
  nameEnglish: string
}

export const SURA_INDEX: readonly SuraMeta[] = [
  { number: 1, ayahCount: 7, nameArabic: 'الفاتحة', nameEnglish: 'Al-Fātihah' },
  { number: 2, ayahCount: 286, nameArabic: 'البقرة', nameEnglish: 'Al-Baqarah' },
  { number: 3, ayahCount: 200, nameArabic: 'آل عمران', nameEnglish: 'Āl-‘Imrān' },
  { number: 4, ayahCount: 176, nameArabic: 'النساء', nameEnglish: 'An-Nisā’' },
  { number: 5, ayahCount: 120, nameArabic: 'المائدة', nameEnglish: 'Al-Mā’idah' },
  { number: 6, ayahCount: 165, nameArabic: 'الأنعام', nameEnglish: 'Al-An‘ām' },
  { number: 7, ayahCount: 206, nameArabic: 'الأعراف', nameEnglish: 'Al-A‘rāf' },
  { number: 8, ayahCount: 75, nameArabic: 'الأنفال', nameEnglish: 'Al-Anfāl' },
  { number: 9, ayahCount: 129, nameArabic: 'التوبة', nameEnglish: 'At-Tawbah' },
  { number: 10, ayahCount: 109, nameArabic: 'يونس', nameEnglish: 'Yūnus' },
  { number: 11, ayahCount: 123, nameArabic: 'هود', nameEnglish: 'Hūd' },
  { number: 12, ayahCount: 111, nameArabic: 'يوسف', nameEnglish: 'Yūsuf' },
  { number: 13, ayahCount: 43, nameArabic: 'الرعد', nameEnglish: 'Ar-Ra‘d' },
  { number: 14, ayahCount: 52, nameArabic: 'ابراهيم', nameEnglish: 'Ibrāhīm' },
  { number: 15, ayahCount: 99, nameArabic: 'الحجر', nameEnglish: 'Al-Hijr' },
  { number: 16, ayahCount: 128, nameArabic: 'النحل', nameEnglish: 'An-Nahl' },
  { number: 17, ayahCount: 111, nameArabic: 'الإسراء', nameEnglish: 'Al-Isrā’' },
  { number: 18, ayahCount: 110, nameArabic: 'الكهف', nameEnglish: 'Al-Kahf' },
  { number: 19, ayahCount: 98, nameArabic: 'مريم', nameEnglish: 'Maryam' },
  { number: 20, ayahCount: 135, nameArabic: 'طه', nameEnglish: 'Tā-ha' },
  { number: 21, ayahCount: 112, nameArabic: 'الأنبياء', nameEnglish: 'Al-Anbiyā’' },
  { number: 22, ayahCount: 78, nameArabic: 'الحج', nameEnglish: 'Al-Hajj' },
  { number: 23, ayahCount: 118, nameArabic: 'المؤمنون', nameEnglish: 'Al-Mu’minūn' },
  { number: 24, ayahCount: 64, nameArabic: 'النور', nameEnglish: 'An-Noor' },
  { number: 25, ayahCount: 77, nameArabic: 'الفرقان', nameEnglish: 'Al-Furqān' },
  { number: 26, ayahCount: 227, nameArabic: 'الشعراء', nameEnglish: 'Ash-Shu‘arā’' },
  { number: 27, ayahCount: 93, nameArabic: 'النمل', nameEnglish: 'An-Naml' },
  { number: 28, ayahCount: 88, nameArabic: 'القصص', nameEnglish: 'Al-Qasas' },
  { number: 29, ayahCount: 69, nameArabic: 'العنكبوت', nameEnglish: 'Al-‘Ankabūt' },
  { number: 30, ayahCount: 60, nameArabic: 'الروم', nameEnglish: 'Ar-Rūm' },
  { number: 31, ayahCount: 34, nameArabic: 'لقمان', nameEnglish: 'Luqmān' },
  { number: 32, ayahCount: 30, nameArabic: 'السجدة', nameEnglish: 'As-Sajdah' },
  { number: 33, ayahCount: 73, nameArabic: 'الأحزاب', nameEnglish: 'Al-Ahzāb' },
  { number: 34, ayahCount: 54, nameArabic: 'سبإ', nameEnglish: 'Saba’' },
  { number: 35, ayahCount: 45, nameArabic: 'فاطر', nameEnglish: 'Fātir' },
  { number: 36, ayahCount: 83, nameArabic: 'يس', nameEnglish: 'Yā-Sīn' },
  { number: 37, ayahCount: 182, nameArabic: 'الصافات', nameEnglish: 'As-Sāffāt' },
  { number: 38, ayahCount: 88, nameArabic: 'ص', nameEnglish: 'Sād' },
  { number: 39, ayahCount: 75, nameArabic: 'الزمر', nameEnglish: 'Az-Zumar' },
  { number: 40, ayahCount: 85, nameArabic: 'غافر', nameEnglish: 'Ghāfir' },
  { number: 41, ayahCount: 54, nameArabic: 'فصلت', nameEnglish: 'Fussilat' },
  { number: 42, ayahCount: 53, nameArabic: 'الشورى', nameEnglish: 'Ash-Shūra' },
  { number: 43, ayahCount: 89, nameArabic: 'الزخرف', nameEnglish: 'Az-Zukhruf' },
  { number: 44, ayahCount: 59, nameArabic: 'الدخان', nameEnglish: 'Ad-Dukhān' },
  { number: 45, ayahCount: 37, nameArabic: 'الجاثية', nameEnglish: 'Al-Jāthiyah' },
  { number: 46, ayahCount: 35, nameArabic: 'الأحقاف', nameEnglish: 'Al-Ahqāf' },
  { number: 47, ayahCount: 38, nameArabic: 'محمد', nameEnglish: 'Muhammad' },
  { number: 48, ayahCount: 29, nameArabic: 'الفتح', nameEnglish: 'Al-Fat\'h' },
  { number: 49, ayahCount: 18, nameArabic: 'الحجرات', nameEnglish: 'Al-Hujurāt' },
  { number: 50, ayahCount: 45, nameArabic: 'ق', nameEnglish: 'Qāf' },
  { number: 51, ayahCount: 60, nameArabic: 'الذاريات', nameEnglish: 'Adh-Dhāriyāt' },
  { number: 52, ayahCount: 49, nameArabic: 'الطور', nameEnglish: 'At-Toor' },
  { number: 53, ayahCount: 62, nameArabic: 'النجم', nameEnglish: 'An-Najm' },
  { number: 54, ayahCount: 55, nameArabic: 'القمر', nameEnglish: 'Al-Qamar' },
  { number: 55, ayahCount: 78, nameArabic: 'الرحمن', nameEnglish: 'Ar-Rahmān' },
  { number: 56, ayahCount: 96, nameArabic: 'الواقعة', nameEnglish: 'Al-Wāqi‘ah' },
  { number: 57, ayahCount: 29, nameArabic: 'الحديد', nameEnglish: 'Al-Hadīd' },
  { number: 58, ayahCount: 22, nameArabic: 'المجادلة', nameEnglish: 'Al-Mujādalah' },
  { number: 59, ayahCount: 24, nameArabic: 'الحشر', nameEnglish: 'Al-Hashr' },
  { number: 60, ayahCount: 13, nameArabic: 'الممتحنة', nameEnglish: 'Al-Mumtahanah' },
  { number: 61, ayahCount: 14, nameArabic: 'الصف', nameEnglish: 'As-Saff' },
  { number: 62, ayahCount: 11, nameArabic: 'الجمعة', nameEnglish: 'Al-Jumu‘ah' },
  { number: 63, ayahCount: 11, nameArabic: 'المنافقون', nameEnglish: 'Al-Munāfiqūn' },
  { number: 64, ayahCount: 18, nameArabic: 'التغابن', nameEnglish: 'At-Taghābun' },
  { number: 65, ayahCount: 12, nameArabic: 'الطلاق', nameEnglish: 'At-Talāq' },
  { number: 66, ayahCount: 12, nameArabic: 'التحريم', nameEnglish: 'At-Tahrīm' },
  { number: 67, ayahCount: 30, nameArabic: 'الملك', nameEnglish: 'Al-Mulk' },
  { number: 68, ayahCount: 52, nameArabic: 'القلم', nameEnglish: 'Al-Qalam' },
  { number: 69, ayahCount: 52, nameArabic: 'الحاقة', nameEnglish: 'Al-Hāqqah' },
  { number: 70, ayahCount: 44, nameArabic: 'المعارج', nameEnglish: 'Al-Ma‘ārij' },
  { number: 71, ayahCount: 28, nameArabic: 'نوح', nameEnglish: 'Nūh' },
  { number: 72, ayahCount: 28, nameArabic: 'الجن', nameEnglish: 'Al-Jinn' },
  { number: 73, ayahCount: 20, nameArabic: 'المزمل', nameEnglish: 'Al-Muzzammil' },
  { number: 74, ayahCount: 56, nameArabic: 'المدثر', nameEnglish: 'Al-Muddaththir' },
  { number: 75, ayahCount: 40, nameArabic: 'القيامة', nameEnglish: 'Al-Qiyāmah' },
  { number: 76, ayahCount: 31, nameArabic: 'الانسان', nameEnglish: 'Al-Insān' },
  { number: 77, ayahCount: 50, nameArabic: 'المرسلات', nameEnglish: 'Al-Mursalāt' },
  { number: 78, ayahCount: 40, nameArabic: 'النبإ', nameEnglish: 'An-Naba’' },
  { number: 79, ayahCount: 46, nameArabic: 'النازعات', nameEnglish: 'An-Nāzi‘āt' },
  { number: 80, ayahCount: 42, nameArabic: 'عبس', nameEnglish: '‘Abasa' },
  { number: 81, ayahCount: 29, nameArabic: 'التكوير', nameEnglish: 'At-Takwīr' },
  { number: 82, ayahCount: 19, nameArabic: 'الإنفطار', nameEnglish: 'Al-Infitār' },
  { number: 83, ayahCount: 36, nameArabic: 'المطففين', nameEnglish: 'Al-Mutaffifīn' },
  { number: 84, ayahCount: 25, nameArabic: 'الإنشقاق', nameEnglish: 'Al-Inshiqāq' },
  { number: 85, ayahCount: 22, nameArabic: 'البروج', nameEnglish: 'Al-Burūj' },
  { number: 86, ayahCount: 17, nameArabic: 'الطارق', nameEnglish: 'At-Tāriq' },
  { number: 87, ayahCount: 19, nameArabic: 'الأعلى', nameEnglish: 'Al-A‘lā' },
  { number: 88, ayahCount: 26, nameArabic: 'الغاشية', nameEnglish: 'Al-Ghāshiyah' },
  { number: 89, ayahCount: 30, nameArabic: 'الفجر', nameEnglish: 'Al-Fajr' },
  { number: 90, ayahCount: 20, nameArabic: 'البلد', nameEnglish: 'Al-Balad' },
  { number: 91, ayahCount: 15, nameArabic: 'الشمس', nameEnglish: 'Ash-Shams' },
  { number: 92, ayahCount: 21, nameArabic: 'الليل', nameEnglish: 'Al-Layl' },
  { number: 93, ayahCount: 11, nameArabic: 'الضحى', nameEnglish: 'Ad-Duhā' },
  { number: 94, ayahCount: 8, nameArabic: 'الشرح', nameEnglish: 'Ash-Sharh' },
  { number: 95, ayahCount: 8, nameArabic: 'التين', nameEnglish: 'At-Teen' },
  { number: 96, ayahCount: 19, nameArabic: 'العلق', nameEnglish: 'Al-‘Alaq' },
  { number: 97, ayahCount: 5, nameArabic: 'القدر', nameEnglish: 'Al-Qadr' },
  { number: 98, ayahCount: 8, nameArabic: 'البينة', nameEnglish: 'Al-Bayyinah' },
  { number: 99, ayahCount: 8, nameArabic: 'الزلزلة', nameEnglish: 'Az-Zalzalah' },
  { number: 100, ayahCount: 11, nameArabic: 'العاديات', nameEnglish: 'Al-‘Ādiyāt' },
  { number: 101, ayahCount: 11, nameArabic: 'القارعة', nameEnglish: 'Al-Qāri‘ah' },
  { number: 102, ayahCount: 8, nameArabic: 'التكاثر', nameEnglish: 'At-Takāthur' },
  { number: 103, ayahCount: 3, nameArabic: 'العصر', nameEnglish: 'Al-‘Asr' },
  { number: 104, ayahCount: 9, nameArabic: 'الهمزة', nameEnglish: 'Al-Humazah' },
  { number: 105, ayahCount: 5, nameArabic: 'الفيل', nameEnglish: 'Al-Feel' },
  { number: 106, ayahCount: 4, nameArabic: 'قريش', nameEnglish: 'Quraysh' },
  { number: 107, ayahCount: 7, nameArabic: 'الماعون', nameEnglish: 'Al-Mā‘ūn' },
  { number: 108, ayahCount: 3, nameArabic: 'الكوثر', nameEnglish: 'Al-Kawthar' },
  { number: 109, ayahCount: 6, nameArabic: 'الكافرون', nameEnglish: 'Al-Kāfirūn' },
  { number: 110, ayahCount: 3, nameArabic: 'النصر', nameEnglish: 'An-Nasr' },
  { number: 111, ayahCount: 5, nameArabic: 'المسد', nameEnglish: 'Al-Masad' },
  { number: 112, ayahCount: 4, nameArabic: 'الإخلاص', nameEnglish: 'Al-Ikhlās' },
  { number: 113, ayahCount: 5, nameArabic: 'الفلق', nameEnglish: 'Al-Falaq' },
  { number: 114, ayahCount: 6, nameArabic: 'الناس', nameEnglish: 'An-Nās' },
] as const

export const SURA_COUNT = 114
export const TOTAL_AYAT = 6236

export function getSuraMeta(number: number): SuraMeta | undefined {
  return number >= 1 && number <= 114 ? SURA_INDEX[number - 1] : undefined
}
