/**
 * Geolocation service.
 *
 * Typed, platform-aware wrapper around device location:
 * - Web: the browser Geolocation API (permission querying included).
 * - Native (Capacitor app): the official @capacitor/geolocation plugin,
 *   which uses the native LocationManager and works reliably inside the
 *   WebView. Before any request, the Android system location service state
 *   is checked through the DeviceBridge plugin - granting the app
 *   permission does NOT enable the system-wide service, and without it
 *   every request fails; the app must tell the user and offer to open the
 *   settings screen instead of failing silently.
 *
 * Used by the Home, Prayer Times, and Qibla screens. Location is only ever
 * requested as a direct response to a user action - or as the automatic
 * follow-up of that same action: the settings trip in use-geolocation
 * re-enters requestCurrentLocation() after the user returns from the
 * device settings with the service enabled, so the manual and the
 * automatic acquisition always share ONE identical request path.
 */

import { Geolocation } from '@capacitor/geolocation'

import { isRealNativePlatform } from '@/services/platform/native-mode'
import {
  isLocationServiceEnabled as nativeIsLocationServiceEnabled,
  openLocationSettings as nativeOpenLocationSettings,
} from '@/services/native/device-bridge'

export type GeoPermissionState = 'granted' | 'denied' | 'prompt' | 'unavailable' | 'unsupported'

export interface GeoCoordinates {
  latitude: number
  longitude: number
  accuracy: number
}

/**
 * Typed failure codes so the UI can present localized, actionable messages
 * (raw English strings never reach the interface).
 *
 * 'service-disabled': the Android system location service is switched off
 * (distinct from permission denied) - the UI offers to open the settings.
 */
export type GeoErrorCode =
  | 'unsupported'
  | 'denied'
  | 'unavailable'
  | 'timeout'
  | 'service-disabled'
  | 'unknown'

export class GeolocationError extends Error {
  readonly code: GeoErrorCode

  constructor(code: GeoErrorCode) {
    super(`geolocation:${code}`)
    this.name = 'GeolocationError'
    this.code = code
  }
}

export class GeolocationUnavailableError extends Error {
  constructor(message = 'Geolocation is not available on this device') {
    super(message)
    this.name = 'GeolocationUnavailableError'
  }
}

export function isGeolocationSupported(): boolean {
  if (isRealNativePlatform()) return true // the native plugin provides it
  return typeof navigator !== 'undefined' && typeof navigator.geolocation !== 'undefined'
}

/**
 * Whether the Android system location service is enabled.
 * Returns null when the state cannot be determined (web browser).
 */
export async function isLocationServiceEnabled(): Promise<boolean | null> {
  if (!isRealNativePlatform()) return null
  return nativeIsLocationServiceEnabled()
}

/**
 * Open the Android system location settings screen.
 * Returns false when not running in the native app.
 */
export async function openLocationSettings(): Promise<boolean> {
  if (!isRealNativePlatform()) return false
  return nativeOpenLocationSettings()
}

function toPermissionState(status: PermissionStatus | null): GeoPermissionState {
  if (!status) return 'unavailable'
  switch (status.state) {
    case 'granted':
      return 'granted'
    case 'denied':
      return 'denied'
    case 'prompt':
    default:
      return 'prompt'
  }
}

/** Query the current permission state without prompting the user. */
export async function queryLocationPermission(): Promise<GeoPermissionState> {
  try {
    if (isRealNativePlatform()) {
      // The WebView Permissions API does not reflect native states
      // reliably - ask the plugin (falls back to the bridge states).
      const status = await Geolocation.checkPermissions()
      if (status.location === 'granted' || status.coarseLocation === 'granted') return 'granted'
      if (status.location === 'denied' && status.coarseLocation === 'denied') return 'denied'
      return 'prompt'
    }
    if (typeof navigator === 'undefined' || !navigator.permissions) return 'unavailable'
    if (!isGeolocationSupported()) return 'unsupported'
    const status = await navigator.permissions.query({ name: 'geolocation' as PermissionName })
    return toPermissionState(status)
  } catch {
    return 'unavailable'
  }
}

/** Map a @capacitor/geolocation rejection to a typed code. */
function mapNativeGeolocationError(error: unknown): GeoErrorCode {
  if (error && typeof error === 'object' && 'code' in error) {
    const code = (error as { code: unknown }).code
    if (code === 'permissionDenied') return 'denied'
    if (code === 'timeout') return 'timeout'
    if (code === 'locationUnavailable' || code === 'positionUnavailable') return 'unavailable'
    // Browser-style numeric codes (the plugin's web fallback).
    if (code === 1) return 'denied'
    if (code === 2) return 'unavailable'
    if (code === 3) return 'timeout'
  }
  return 'unknown'
}

/**
 * Request the current position (triggers the permission prompt when needed).
 * The SINGLE acquisition path shared by the manual button press and the
 * automatic post-settings attempt (same 20s timeout, same typed errors) -
 * callers never duplicate this logic. Approximate (coarse) fixes are
 * acceptable and always returned with their real accuracy value.
 */
export async function requestCurrentLocation(timeoutMs = 20000): Promise<GeoCoordinates> {
  if (!isGeolocationSupported()) {
    throw new GeolocationUnavailableError()
  }

  if (isRealNativePlatform()) {
    // 1. The system-wide location service must be ON - app permission
    //    alone cannot produce a position. Fail with a typed code the UI
    //    turns into an explanation + "open settings" action.
    const serviceEnabled = await isLocationServiceEnabled()
    if (serviceEnabled === false) {
      throw new GeolocationError('service-disabled')
    }
    // 2. Acquire through the native plugin (reliable inside the WebView).
    try {
      const position = await Geolocation.getCurrentPosition({
        enableHighAccuracy: false,
        timeout: timeoutMs,
        maximumAge: 5 * 60 * 1000,
      })
      return {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
      }
    } catch (error) {
      throw new GeolocationError(mapNativeGeolocationError(error))
    }
  }

  /* Web path: the browser Geolocation API. */
  return new Promise<GeoCoordinates>((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        })
      },
      (error) => {
        reject(
          new GeolocationError(
            error.code === error.PERMISSION_DENIED
              ? 'denied'
              : error.code === error.POSITION_UNAVAILABLE
                ? 'unavailable'
                : 'timeout',
          ),
        )
      },
      { enableHighAccuracy: false, timeout: timeoutMs, maximumAge: 5 * 60 * 1000 },
    )
  })
}
