/**
 * Audio recitation services (client side).
 *
 * Thin, typed wrappers over the app API routes. The routes only ever
 * return VERIFIED inventories (seed + live checks); the client therefore
 * never has to guess availability - it renders exactly what the server
 * proved, and ayat without a verified file are never offered as playable.
 */

import { apiFetch } from './client'
import type {
  AudioBatchPlanResponse,
  ReciterCatalogResponse,
  SuraAudioResponse,
  TranslationAudioBatchPlanResponse,
  TranslationAudioCatalogResponse,
  TranslationSuraAudioResponse,
} from '@/types'

/** GET /api/quran/audio/reciters - the verified reciter catalog. */
export function getReciterCatalog(): Promise<ReciterCatalogResponse> {
  return apiFetch<ReciterCatalogResponse>('/api/quran/audio/reciters')
}

/** GET /api/quran/audio/sura/[styleId]/[sura] - verified per-ayah inventory. */
export function getSuraAudio(styleId: string, sura: number): Promise<SuraAudioResponse> {
  return apiFetch<SuraAudioResponse>(
    `/api/quran/audio/sura/${encodeURIComponent(styleId)}/${sura}`,
  )
}

/**
 * GET /api/quran/audio/batch - the verified download plan for one batch
 * (ayah / sura / range / juz / complete). Used to display exact sizes and
 * source completeness BEFORE anything is downloaded.
 */
export function getAudioBatchPlan(params: {
  styleId: string
  kind: 'ayah' | 'sura' | 'range' | 'juz' | 'complete'
  sura?: number
  ayah?: number
  from?: number
  to?: number
  juz?: number
}): Promise<AudioBatchPlanResponse> {
  const query = new URLSearchParams({ styleId: params.styleId, kind: params.kind })
  if (params.sura !== undefined) query.set('sura', String(params.sura))
  if (params.ayah !== undefined) query.set('ayah', String(params.ayah))
  if (params.from !== undefined) query.set('from', String(params.from))
  if (params.to !== undefined) query.set('to', String(params.to))
  if (params.juz !== undefined) query.set('juz', String(params.juz))
  return apiFetch<AudioBatchPlanResponse>(`/api/quran/audio/batch?${query.toString()}`)
}

/* ------------------------------------------------------------------ */
/* Translation narration audio (QuranEnc recordings, PROMPT 10)         */
/* ------------------------------------------------------------------ */

/** GET /api/quran/translation-audio/catalog - the verified audio translations. */
export function getTranslationAudioCatalog(): Promise<TranslationAudioCatalogResponse> {
  return apiFetch<TranslationAudioCatalogResponse>('/api/quran/translation-audio/catalog')
}

/**
 * GET /api/quran/translation-audio/sura/[translationKey]/[sura] - the
 * verified per-ayah inventory of a translation's recorded narration.
 */
export function getTranslationSuraAudio(
  translationKey: string,
  sura: number,
): Promise<TranslationSuraAudioResponse> {
  return apiFetch<TranslationSuraAudioResponse>(
    `/api/quran/translation-audio/sura/${encodeURIComponent(translationKey)}/${sura}`,
  )
}

/**
 * GET /api/quran/translation-audio/batch - the verified download plan for
 * one translation audio batch. Exact sizes for ordinary batches; a clearly
 * flagged estimate for the complete package.
 */
export function getTranslationAudioBatchPlan(params: {
  translationKey: string
  kind: 'ayah' | 'sura' | 'range' | 'juz' | 'complete'
  sura?: number
  ayah?: number
  from?: number
  to?: number
  juz?: number
}): Promise<TranslationAudioBatchPlanResponse> {
  const query = new URLSearchParams({
    translationKey: params.translationKey,
    kind: params.kind,
  })
  if (params.sura !== undefined) query.set('sura', String(params.sura))
  if (params.ayah !== undefined) query.set('ayah', String(params.ayah))
  if (params.from !== undefined) query.set('from', String(params.from))
  if (params.to !== undefined) query.set('to', String(params.to))
  if (params.juz !== undefined) query.set('juz', String(params.juz))
  return apiFetch<TranslationAudioBatchPlanResponse>(
    `/api/quran/translation-audio/batch?${query.toString()}`,
  )
}
