/**
 * Global Quran - Prayer API client services.
 *
 * All requests use relative paths only. Prayer endpoints return their own
 * honest `status` field, including on HTTP errors - so the fetcher parses
 * the body regardless of status code and lets the response speak for
 * itself (the UI never shows a raw technical error).
 */

import { platformFetch } from '@/services/platform/fetch'
import type {
  CalculationMethodId,
  CitySearchResponse,
  HighLatitudeRuleMode,
  Madhhab,
  PrayerAdjustments,
  PrayerCalendarResponse,
  PrayerMetaResponse,
  PrayerRegistryResponse,
  PrayerTimesResponse,
  ReverseGeocodeResponse,
} from '@/types'

/** Parameters shared by the day and calendar endpoints. */
export interface PrayerQueryParams {
  latitude: number
  longitude: number
  timeZone: string | null
  countryCode: string | null
  methodMode: 'auto' | 'manual'
  methodId: CalculationMethodId
  madhhab: Madhhab
  highLatitudeRule: HighLatitudeRuleMode
  adjustments: PrayerAdjustments
  jakimZone: string | null
}

export function buildPrayerSearchParams(params: PrayerQueryParams): URLSearchParams {
  const search = new URLSearchParams({
    latitude: String(params.latitude),
    longitude: String(params.longitude),
    methodMode: params.methodMode,
    methodId: params.methodId,
    madhhab: params.madhhab,
    highLatitudeRule: params.highLatitudeRule,
  })
  if (params.timeZone) search.set('timeZone', params.timeZone)
  if (params.countryCode) search.set('countryCode', params.countryCode)
  if (params.jakimZone) search.set('jakimZone', params.jakimZone)
  const adjustmentParts = Object.entries(params.adjustments)
    .filter(([, minutes]) => minutes !== 0)
    .map(([prayer, minutes]) => `${prayer}:${minutes}`)
  if (adjustmentParts.length > 0) {
    search.set('adjustments', adjustmentParts.join(','))
  }
  return search
}

/** Stable key part for React Query caching. */
export function prayerParamsKeyPart(params: PrayerQueryParams): string {
  return [
    params.latitude.toFixed(3),
    params.longitude.toFixed(3),
    params.timeZone ?? '-',
    params.countryCode ?? '-',
    params.methodMode,
    params.methodMode === 'manual' ? params.methodId : '-',
    params.madhhab,
    params.highLatitudeRule,
    params.jakimZone ?? '-',
    Object.entries(params.adjustments)
      .map(([prayer, minutes]) => `${prayer}${minutes}`)
      .join('.'),
  ].join('|')
}

async function fetchPrayerJson<T>(path: string): Promise<T> {
  let response: Response
  try {
    response = await platformFetch(path, { headers: { Accept: 'application/json' } })
  } catch {
    // Network-level failure: return a typed honest error the UI can show.
    return {
      status: 'unavailable',
      messageKey: 'prayer.error.network',
    } as unknown as T
  }
  try {
    return (await response.json()) as T
  } catch {
    return {
      status: 'unavailable',
      messageKey: 'prayer.error.network',
    } as unknown as T
  }
}

export async function fetchPrayerDay(
  date: string,
  params: PrayerQueryParams,
): Promise<PrayerTimesResponse> {
  const search = buildPrayerSearchParams(params)
  search.set('date', date)
  return fetchPrayerJson<PrayerTimesResponse>(`/api/prayer/times?${search.toString()}`)
}

export async function fetchPrayerMonth(
  month: string,
  params: PrayerQueryParams,
): Promise<PrayerCalendarResponse> {
  const search = buildPrayerSearchParams(params)
  search.set('month', month)
  return fetchPrayerJson<PrayerCalendarResponse>(`/api/prayer/calendar?${search.toString()}`)
}

export async function fetchPrayerMeta(): Promise<PrayerMetaResponse> {
  return fetchPrayerJson<PrayerMetaResponse>('/api/prayer/meta')
}

export async function fetchPrayerRegistry(): Promise<PrayerRegistryResponse> {
  return fetchPrayerJson<PrayerRegistryResponse>('/api/prayer/registry')
}

export async function searchCitiesOnline(query: string): Promise<CitySearchResponse> {
  const search = new URLSearchParams({ q: query })
  return fetchPrayerJson<CitySearchResponse>(`/api/prayer/geocode?${search.toString()}`)
}

export async function reverseGeocodeCoordinates(
  latitude: number,
  longitude: number,
): Promise<ReverseGeocodeResponse> {
  const search = new URLSearchParams({
    latitude: String(latitude),
    longitude: String(longitude),
  })
  return fetchPrayerJson<ReverseGeocodeResponse>(
    `/api/prayer/reverse-geocode?${search.toString()}`,
  )
}
