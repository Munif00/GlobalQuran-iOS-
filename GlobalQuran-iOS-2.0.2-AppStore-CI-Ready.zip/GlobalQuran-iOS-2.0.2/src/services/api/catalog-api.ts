/**
 * Library & Quran content services (client side).
 *
 * Thin, typed wrappers over the app API routes, which in turn proxy the
 * documented QuranEnc endpoints with caching and validation.
 */

import { apiFetch } from './client'
import { getCachedCatalog, putCachedCatalog } from '@/services/storage/quran-cache'
import type {
  SuraContentResponse,
  SuraNamesResponse,
  TranslationsCatalogResponse,
  VerificationListResponse,
  VerificationRecordDto,
  VerificationUpsertPayload,
} from '@/types'

/**
 * GET /api/translations/catalog - live catalog from QuranEnc.
 *
 * The last successfully loaded catalog per locale is kept in the offline
 * cache: when the request fails for connectivity reasons, that copy is
 * served (marked servedFromCache) so the library and the reader keep
 * working without a connection. No catalog data is ever fabricated.
 */
export async function getTranslationsCatalog(locale?: string): Promise<TranslationsCatalogResponse> {
  const query = locale ? `?localization=${encodeURIComponent(locale)}` : ''
  const cacheKey = locale ?? 'en'
  try {
    const response = await apiFetch<TranslationsCatalogResponse>(`/api/translations/catalog${query}`)
    void putCachedCatalog(cacheKey, response)
    return response
  } catch (error) {
    const cached = await getCachedCatalog(cacheKey)
    if (cached) {
      return { ...cached.response, servedFromCache: true }
    }
    throw error
  }
}

/** GET /api/quran/sura/[translationKey]/[suraNumber] - one sura with ayat. */
export async function getSuraContent(translationKey: string, sura: number): Promise<SuraContentResponse> {
  return apiFetch<SuraContentResponse>(
    `/api/quran/sura/${encodeURIComponent(translationKey)}/${sura}`,
  )
}

/** GET /api/quran/sowar-names?locale=.. - localized sura names. */
export async function getSuraNames(locale: string): Promise<SuraNamesResponse> {
  return apiFetch<SuraNamesResponse>(
    `/api/quran/sowar-names?locale=${encodeURIComponent(locale)}`,
  )
}

/** GET /api/translations/verification - administrator records. */
export async function listVerificationRecords(): Promise<VerificationListResponse> {
  return apiFetch<VerificationListResponse>('/api/translations/verification')
}

/**
 * Administrator token handling.
 *
 * The token is typed by the administrator at runtime and kept in
 * sessionStorage only (per-tab, cleared when the tab closes, never written
 * to disk). It is sent as the `x-admin-token` header on mutating requests.
 * It is never logged, echoed, or bundled.
 */
const ADMIN_TOKEN_STORAGE_KEY = 'global-quran-admin-token'

export function getAdminToken(): string {
  try {
    return window.sessionStorage.getItem(ADMIN_TOKEN_STORAGE_KEY) ?? ''
  } catch {
    return ''
  }
}

export function setAdminToken(token: string): void {
  try {
    if (token) window.sessionStorage.setItem(ADMIN_TOKEN_STORAGE_KEY, token)
    else window.sessionStorage.removeItem(ADMIN_TOKEN_STORAGE_KEY)
  } catch {
    // Storage unavailable - the token simply is not remembered.
  }
}

function adminTokenHeaders(): Record<string, string> {
  const token = getAdminToken()
  return token ? { 'x-admin-token': token } : {}
}

/** POST /api/translations/verification - upsert an administrator record. */
export async function upsertVerificationRecord(
  payload: VerificationUpsertPayload,
): Promise<{ record: VerificationRecordDto }> {
  return apiFetch<{ record: VerificationRecordDto }>('/api/translations/verification', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...adminTokenHeaders() },
    body: JSON.stringify(payload),
  })
}

/** DELETE /api/translations/verification?key=.. - remove a record. */
export async function deleteVerificationRecord(translationKey: string): Promise<{ removed: boolean }> {
  return apiFetch<{ removed: boolean }>(
    `/api/translations/verification?key=${encodeURIComponent(translationKey)}`,
    { method: 'DELETE', headers: adminTokenHeaders() },
  )
}
