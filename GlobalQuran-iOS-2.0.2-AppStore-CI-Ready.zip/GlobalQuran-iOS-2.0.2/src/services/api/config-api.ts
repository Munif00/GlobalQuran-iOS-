/**
 * Application configuration service (GET /api/config).
 * Exposes integration status honestly to the client.
 */

import { apiFetch } from './client'
import type { AppConfigDto } from '@/types'

export async function getAppConfig(): Promise<AppConfigDto> {
  return apiFetch<AppConfigDto>('/api/config')
}
