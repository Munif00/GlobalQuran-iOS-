/**
 * Modular API client. All requests use relative paths only.
 *
 * In web mode this is a same-origin fetch to the Next.js server; in native
 * mode (Capacitor app) platformFetch dispatches /api/ requests to the
 * client-side adapter that reproduces the server routes.
 */

import { platformFetch } from '@/services/platform/fetch'

/** Machine-readable failure classes for localized, actionable UI messages. */
export type ApiErrorCode =
  | 'network' // request never reached a server (offline / DNS / no route)
  | 'timeout' // aborted by a deadline (AbortSignal)
  | 'rate-limit' // HTTP 429
  | 'unavailable' // HTTP 503 (service honest-unavailable)
  | 'server' // any other HTTP >= 500
  | 'client' // HTTP 4xx (bad request / not found)
  | 'unknown'

export class ApiError extends Error {
  readonly status: number
  readonly code: ApiErrorCode

  constructor(message: string, status: number, code?: ApiErrorCode) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code ?? codeForStatus(status)
  }
}

function codeForStatus(status: number): ApiErrorCode {
  if (status === 0) return 'network'
  if (status === 429) return 'rate-limit'
  if (status === 503) return 'unavailable'
  if (status >= 500) return 'server'
  if (status >= 400) return 'client'
  return 'unknown'
}

function isAbortError(error: unknown): boolean {
  return error instanceof Error && (error.name === 'AbortError' || error.name === 'TimeoutError')
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response
  try {
    response = await platformFetch(path, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init?.headers ?? {}),
      },
    })
  } catch (error) {
    throw new ApiError('Network request failed', 0, isAbortError(error) ? 'timeout' : 'network')
  }

  let data: unknown = null
  try {
    data = await response.json()
  } catch {
    // Non-JSON body; fall through with null.
  }

  if (!response.ok) {
    const message =
      data && typeof data === 'object' && 'message' in data && typeof (data as { message: unknown }).message === 'string'
        ? (data as { message: string }).message
        : `Request failed with status ${response.status}`
    throw new ApiError(message, response.status)
  }

  return data as T
}
