/**
 * Global Quran - Localized API error descriptions.
 *
 * Replaces the old behavior where every failure surfaced as the same
 * generic "An error occurred / unexpected error" pair. The failure is
 * classified (network, timeout, rate limit, service-unavailable, server,
 * geolocation...) and described with a specific, localized, actionable
 * message. Technical details (URLs, raw upstream bodies, status codes)
 * never reach the user.
 */

import type { TranslationKey } from '@/i18n'

import { ApiError } from '@/services/api/client'
import { GeolocationError } from '@/services/location/geolocation-service'

/** A translator keyed by the app's i18n dictionary (accepts useTranslation's t). */
export type ErrorTranslator = (key: TranslationKey) => string

/**
 * The best localized description for an arbitrary caught error, keyed for
 * the i18n dictionaries. Unknown errors fall back to the generic message
 * (the old behavior) - but every classified failure gets a specific one.
 */
export function describeApiError(error: unknown, t: ErrorTranslator): string {
  if (error instanceof ApiError) {
    switch (error.code) {
      case 'network':
        return t('errors.network')
      case 'timeout':
        return t('errors.timeout')
      case 'rate-limit':
        return t('errors.rateLimited')
      case 'unavailable':
        return t('errors.serviceUnavailable')
      case 'server':
        return t('errors.serverError')
      case 'client':
        return t('errors.clientError')
      default:
        return t('common.errorDescription')
    }
  }
  if (error instanceof GeolocationError) {
    return t(`geo.error.${error.code}`)
  }
  return t('common.errorDescription')
}

/** i18n keys added for the classified failures (see locales/en.ts). */
export const ERROR_I18N_KEYS = [
  'errors.network',
  'errors.timeout',
  'errors.rateLimited',
  'errors.serviceUnavailable',
  'errors.serverError',
  'errors.clientError',
  'geo.error.service-disabled',
  'geo.locationSettings.open',
] as const
