/**
 * Global Quran - Recitation audio library (IndexedDB).
 *
 * The persistent offline store for DOWNLOADED recitation audio (PROMPT 9):
 *
 * - `manifest`: one record per stored ayah audio file - reciter identifier,
 *   sura, ayah, storage key, exact file size, download status, verification
 *   status and the source reference (the persistent download manifest).
 * - `blobs`: the MP3 payloads, keyed by the manifest id.
 * - `partials`: partial payloads of an in-flight single file transfer, keyed
 *   by `${batchId}:${fileId}` - the pause/resume data of the audio batch
 *   engine (survives app restarts).
 *
 * Design rules:
 * - A manifest entry and its blob are written together in ONE transaction -
 *   a hard termination can never leave a manifest entry without its payload
 *   or an orphan payload presented as a stored file.
 * - Deleting audio NEVER touches any other store: this is a dedicated
 *   database (`global-quran-audio`), fully separate from the Quran text
 *   cache and the document offline library.
 * - The manifest is the single source of truth for offline status: a sura
 *   is "available offline" only when every one of its ayat has a verified
 *   manifest entry - never merely because a download once ran.
 * - The database opens lazily (SSR-safe); every method is client-only.
 */

import type { AudioManifestEntry, AudioStyleOfflineStatus, AudioSuraOfflineStatus } from '@/types'
import { getSuraAyahCount } from '@/lib/audio/urls'

const DB_NAME = 'global-quran-audio'
const DB_VERSION = 1
const STORE_MANIFEST = 'manifest'
const STORE_BLOBS = 'blobs'
const STORE_PARTIALS = 'partials'

let dbPromise: Promise<IDBDatabase> | null = null

function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise !== null) return dbPromise
  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available in this environment'))
      return
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(STORE_MANIFEST)) {
        db.createObjectStore(STORE_MANIFEST, { keyPath: 'id' })
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS)
      }
      if (!db.objectStoreNames.contains(STORE_PARTIALS)) {
        db.createObjectStore(STORE_PARTIALS)
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'))
    request.onblocked = () => reject(new Error('IndexedDB open blocked'))
  })
  dbPromise.catch(() => {
    dbPromise = null
  })
  return dbPromise
}

function withStore<T>(
  storeName: string,
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T> {
  return openDatabase().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const transaction = db.transaction(storeName, mode)
        const store = transaction.objectStore(storeName)
        let result: T | undefined
        const request = run(store)
        if (request) {
          request.onsuccess = () => {
            result = request.result
          }
          request.onerror = () => reject(request.error)
        }
        transaction.oncomplete = () => resolve(result as T)
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

/** Atomic write across the manifest + blobs stores. */
function withManifestAndBlobs(
  run: (manifest: IDBObjectStore, blobs: IDBObjectStore) => void,
): Promise<void> {
  return openDatabase().then(
    (db) =>
      new Promise<void>((resolve, reject) => {
        const transaction = db.transaction([STORE_MANIFEST, STORE_BLOBS], 'readwrite')
        run(transaction.objectStore(STORE_MANIFEST), transaction.objectStore(STORE_BLOBS))
        transaction.oncomplete = () => resolve()
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

export function audioEntryId(styleId: string, sura: number, ayah: number): string {
  return `${styleId}:${sura}:${ayah}`
}

function readAllManifest(): Promise<AudioManifestEntry[]> {
  return withStore<AudioManifestEntry[]>(STORE_MANIFEST, 'readonly', (store) => store.getAll())
}

/** The app's recitation audio library (singleton). */
class IndexedDbAudioLibrary {
  /* ------------------------------ manifest ------------------------------ */

  /** One manifest entry (null when the file is not stored). */
  async getEntry(styleId: string, sura: number, ayah: number): Promise<AudioManifestEntry | null> {
    const entry = await withStore<AudioManifestEntry | undefined>(
      STORE_MANIFEST,
      'readonly',
      (store) => store.get(audioEntryId(styleId, sura, ayah)),
    )
    return entry ?? null
  }

  /** Every manifest entry of one recitation style. */
  async listEntriesForStyle(styleId: string): Promise<AudioManifestEntry[]> {
    const all = await readAllManifest()
    return all.filter((entry) => entry.styleId === styleId)
  }

  /** Every manifest entry (all styles). */
  async listAllEntries(): Promise<AudioManifestEntry[]> {
    return readAllManifest()
  }

  /**
   * Store one VERIFIED file: manifest entry + blob in a single atomic
   * transaction. An existing entry for the same id is replaced together
   * with its blob (dedupe-by-overwrite).
   */
  async putVerifiedFile(entry: AudioManifestEntry, blob: Blob): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.put(entry)
      blobs.put(blob, entry.id)
    })
  }

  /**
   * Mark an existing entry's verification status (used by the re-verify
   * flow when a stored copy no longer matches its recorded size).
   */
  async updateVerification(id: string, verification: 'verified' | 'corrupted'): Promise<void> {
    await withStore<void>(STORE_MANIFEST, 'readwrite', (store) => {
      const request = store.get(id)
      request.onsuccess = () => {
        const entry = request.result as AudioManifestEntry | undefined
        if (entry) {
          entry.verification = verification
          store.put(entry)
        }
      }
    })
  }

  /* ------------------------------- blobs -------------------------------- */

  /** The stored audio payload of one manifest entry (null when absent). */
  async getBlob(id: string): Promise<Blob | null> {
    const blob = await withStore<Blob | undefined>(STORE_BLOBS, 'readonly', (store) =>
      store.get(id),
    )
    return blob ?? null
  }

  /* ------------------------------ deletion ------------------------------ */

  /** Delete one stored audio file (manifest entry + blob, atomically).
   *  Touches nothing else - Quran text and translations live in other
   *  databases and are never affected. */
  async deleteFile(styleId: string, sura: number, ayah: number): Promise<void> {
    const id = audioEntryId(styleId, sura, ayah)
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.delete(id)
      blobs.delete(id)
    })
  }

  /** Delete every stored audio file of one sura of one style. */
  async deleteSura(styleId: string, sura: number): Promise<void> {
    const entries = await this.listEntriesForStyle(styleId)
    const doomed = entries.filter((entry) => entry.sura === sura).map((entry) => entry.id)
    await withManifestAndBlobs((manifest, blobs) => {
      for (const id of doomed) {
        manifest.delete(id)
        blobs.delete(id)
      }
    })
  }

  /** Delete every stored audio file of one recitation style. */
  async deleteStyle(styleId: string): Promise<void> {
    const entries = await this.listEntriesForStyle(styleId)
    const doomed = entries.map((entry) => entry.id)
    await withManifestAndBlobs((manifest, blobs) => {
      for (const id of doomed) {
        manifest.delete(id)
        blobs.delete(id)
      }
    })
  }

  /** Delete EVERY stored audio file (all styles). Text/translations stay. */
  async deleteAll(): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.clear()
      blobs.clear()
    })
  }

  /* -------------------------- offline status ---------------------------- */

  /**
   * The honest offline status of one style, computed from the real
   * manifest: per-sura counts, total bytes and which suras are truly
   * complete (every ayah stored AND verified). A sura is only listed as
   * complete when the stored count matches the authentic ayah count.
   */
  async getStyleStatus(styleId: string): Promise<AudioStyleOfflineStatus> {
    const entries = await this.listEntriesForStyle(styleId)

    const bySura = new Map<number, { stored: number; corrupted: number; bytes: number }>()
    for (const entry of entries) {
      if (entry.verification !== 'verified' && entry.verification !== 'corrupted') continue
      const record = bySura.get(entry.sura) ?? { stored: 0, corrupted: 0, bytes: 0 }
      if (entry.verification === 'verified') {
        record.stored += 1
        record.bytes += entry.fileSize
      } else {
        record.corrupted += 1
      }
      bySura.set(entry.sura, record)
    }

    const suras: AudioSuraOfflineStatus[] = []
    let completeSuras = 0
    for (const [sura, record] of bySura) {
      const ayahCount = getSuraAyahCount(sura)
      const complete = ayahCount > 0 && record.stored >= ayahCount && record.corrupted === 0
      if (complete) completeSuras += 1
      suras.push({
        styleId,
        sura,
        ayahCount,
        storedAyat: record.stored,
        corruptedAyat: record.corrupted,
        complete,
        totalBytes: record.bytes,
      })
    }
    suras.sort((a, b) => a.sura - b.sura)

    return {
      styleId,
      storedFiles: entries.filter((entry) => entry.verification === 'verified').length,
      corruptedFiles: entries.filter((entry) => entry.verification === 'corrupted').length,
      totalBytes: suras.reduce((sum, sura) => sum + sura.totalBytes, 0),
      completeSuras,
      suras,
    }
  }

  /**
   * Re-verify the stored files of one sura of one style against their
   * recorded sizes (and the manifest presence of their blobs). Returns the
   * number of files that failed verification; failing entries are marked
   * `corrupted` in the manifest (they are then excluded from offline
   * availability until re-downloaded).
   */
  async verifySura(styleId: string, sura: number): Promise<{ checked: number; failed: number }> {
    const entries = (await this.listEntriesForStyle(styleId)).filter(
      (entry) => entry.sura === sura,
    )
    let failed = 0
    for (const entry of entries) {
      const blob = await this.getBlob(entry.id).catch(() => null)
      const ok = blob !== null && blob.size === entry.fileSize
      if (!ok) {
        failed += 1
        await this.updateVerification(entry.id, 'corrupted').catch(() => undefined)
      } else if (entry.verification === 'corrupted') {
        // A previously corrupted copy that now matches - restore it.
        await this.updateVerification(entry.id, 'verified').catch(() => undefined)
      }
    }
    return { checked: entries.length, failed }
  }

  /* --------------------------- paused transfers -------------------------- */

  /** Persist the partial payload of one in-flight file transfer. */
  async putPartial(key: string, blob: Blob): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      store.put(blob, key)
    })
  }

  /** The persisted partial payload (null when none). */
  async getPartial(key: string): Promise<Blob | null> {
    const blob = await withStore<Blob | undefined>(STORE_PARTIALS, 'readonly', (store) =>
      store.get(key),
    )
    return blob ?? null
  }

  /** Drop one partial payload. */
  async deletePartial(key: string): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      store.delete(key)
    })
  }

  /** Drop every partial payload belonging to one batch. */
  async deletePartialsForBatch(batchId: string): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      const cursorRequest = store.openCursor()
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result
        if (!cursor) return
        const key = String(cursor.key)
        if (key.startsWith(`${batchId}:`)) cursor.delete()
        cursor.continue()
      }
    })
  }
}

let libraryInstance: IndexedDbAudioLibrary | null = null

/** The app's recitation audio library (created on first use). */
export function getAudioLibrary(): IndexedDbAudioLibrary {
  if (libraryInstance === null) libraryInstance = new IndexedDbAudioLibrary()
  return libraryInstance
}
