/**
 * Global Quran - Offline document library (IndexedDB).
 *
 * The persistent store behind the app's download manager and import flow:
 *
 * - `files`: one record per stored offline document - the full metadata
 *   (`StoredFileMetadata`, in-line key `metadata.id`) TOGETHER with its blob
 *   payload in the same record, so a hard termination can never leave a
 *   metadata entry without its bytes (or an orphan blob presented as a file).
 * - `jobs`: download-manager job records (`DownloadJobRecord`), persisted so
 *   pause/resume state and completed-file references survive app restarts.
 * - `partials`: partial payloads of in-flight transfers, keyed by job id -
 *   the pause/resume data of the streaming download engines.
 *
 * Design rules:
 * - Files become visible in the library only after the download engine has
 *   validated them (size + SHA-256); this module stores what it is given and
 *   never invents or repairs metadata.
 * - Deleting a stored file never touches the audio libraries, the Quran text
 *   cache or any other database: this is a dedicated database
 *   (`global-quran-files`), fully separate from every other store.
 * - The database opens lazily (SSR-safe): every method is async and rejects
 *   with a clear error when IndexedDB is unavailable (server rendering,
 *   private mode); callers already treat storage failures as best-effort.
 * - A failed open never poisons the singleton - the next call retries.
 */

import type { DownloadFormat, DownloadJobRecord, StorageEstimateInfo } from '@/types'

/**
 * Metadata of one stored offline file.
 *
 * Downloaded copies carry the catalog translation key, the catalog file id
 * and the source version recorded at download time (used for the gold
 * "update available" comparison against the live catalog). Imported files
 * carry `origin: 'imported'` with null translation references - the app can
 * never identify their provider, and never claims one.
 *
 * Note on `format`: the union is the catalog-driven `DownloadFormat`. Validated
 * ZIP archives are persisted as-is with format `'zip'`, which widens the union
 * at runtime; the import flow documents this with a single cast at this
 * storage boundary (see `import-card.tsx`).
 */
export interface StoredFileMetadata {
  /** Stable storage id (UUID, or a timestamp-based fallback). */
  id: string
  /** Sanitized file name (imports) or the catalog file's URL name. */
  fileName: string
  /** Real format of the stored payload. */
  format: DownloadFormat
  /** Exact size in bytes (the blob's size at save time). */
  fileSize: number
  /** ISO 8601 timestamp of when the file was stored. */
  storedAt: string
  /** Locally computed SHA-256 checksum (null when hashing failed). */
  checksum: string | null
  /** How the file entered the library. */
  origin: 'downloaded' | 'imported'
  /** Catalog translation key (null for direct imports). */
  translationId: string | null
  /** Source version recorded at download time (null when the source has none). */
  version: string | null
  /** Catalog file id this copy was downloaded from (null for imports). */
  fileId: string | null
}

/** A stored file with its payload, exactly as kept in IndexedDB. */
export interface StoredFile {
  metadata: StoredFileMetadata
  blob: Blob
}

/** The offline library API (see `getFileStorage` for the singleton). */
export interface LocalFileStorage {
  /** Every stored file, newest first. */
  listFiles(): Promise<StoredFileMetadata[]>
  /** One stored file with its blob (null when not stored). */
  getFile(id: string): Promise<StoredFile | null>
  /**
   * Store a file and return the full metadata (including the generated id).
   * An existing record with the same id is replaced (the caller generates
   * fresh ids, so this is effectively an insert).
   */
  saveFile(metadata: Omit<StoredFileMetadata, 'id'>, blob: Blob): Promise<StoredFileMetadata>
  /** Remove one stored file (metadata + payload). */
  deleteFile(id: string): Promise<void>
  /** Remove every stored file (the offline library's "delete all"). */
  deleteAllFiles(): Promise<void>
  /** The newest stored copy of one catalog translation file (null when none). */
  findForTranslationFile(translationKey: string, fileId: string): Promise<StoredFileMetadata | null>
  /** The newest stored copy of a translation, any format (null when none). */
  findLatestForTranslation(translationKey: string): Promise<StoredFileMetadata | null>
  /** Persist a download-manager job record (best-effort, read by restore). */
  putJob(record: DownloadJobRecord): Promise<void>
  /** Every persisted job record (all engines). */
  listJobs(): Promise<DownloadJobRecord[]>
  /** Remove a job record. */
  deleteJob(jobId: string): Promise<void>
  /** Persist the partial payload of an in-flight transfer (resume data). */
  putPartial(jobId: string, blob: Blob): Promise<void>
  /** The persisted partial payload of a transfer (null when none). */
  getPartial(jobId: string): Promise<Blob | null>
  /** Drop the partial payload of a transfer. */
  deletePartial(jobId: string): Promise<void>
}

const DB_NAME = 'global-quran-files'
const DB_VERSION = 1
const STORE_FILES = 'files'
const STORE_JOBS = 'jobs'
const STORE_PARTIALS = 'partials'

let dbPromise: Promise<IDBDatabase> | null = null

function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise !== null) return dbPromise
  const opened = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available in this environment'))
      return
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      // `files` records are { metadata, blob } with the in-line key
      // metadata.id, so a metadata entry and its payload are always written
      // and removed together.
      if (!db.objectStoreNames.contains(STORE_FILES)) {
        db.createObjectStore(STORE_FILES, { keyPath: 'metadata.id' })
      }
      if (!db.objectStoreNames.contains(STORE_JOBS)) {
        db.createObjectStore(STORE_JOBS, { keyPath: 'id' })
      }
      if (!db.objectStoreNames.contains(STORE_PARTIALS)) {
        db.createObjectStore(STORE_PARTIALS)
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'))
    request.onblocked = () => reject(new Error('IndexedDB open blocked'))
  })
  // A failed open must not poison the singleton: reset so the next call
  // retries, while current callers still see the rejection.
  opened.catch(() => {
    if (dbPromise === opened) dbPromise = null
  })
  dbPromise = opened
  return dbPromise
}

/**
 * Run one request against a store inside a single transaction and resolve
 * with the request result when the transaction completes.
 */
function withStore<T>(
  storeName: string,
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T> {
  return openDatabase().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const transaction = db.transaction(storeName, mode)
        const store = transaction.objectStore(storeName)
        let result: T | undefined
        const request = run(store)
        if (request) {
          request.onsuccess = () => {
            result = request.result
          }
          request.onerror = () => reject(request.error)
        }
        transaction.oncomplete = () => resolve(result as T)
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

/** Every record of a store. */
function readAll<T>(storeName: string): Promise<T[]> {
  return withStore<T[]>(storeName, 'readonly', (store) => store.getAll())
}

/** The app's offline file library (IndexedDB-backed singleton). */
class IndexedDbFileStorage implements LocalFileStorage {
  async listFiles(): Promise<StoredFileMetadata[]> {
    const records = await readAll<StoredFile>(STORE_FILES)
    return records.map((record) => record.metadata).sort((a, b) => b.storedAt.localeCompare(a.storedAt))
  }

  async getFile(id: string): Promise<StoredFile | null> {
    const record = await withStore<StoredFile | undefined>(STORE_FILES, 'readonly', (store) =>
      store.get(id),
    )
    return record ?? null
  }

  async saveFile(metadata: Omit<StoredFileMetadata, 'id'>, blob: Blob): Promise<StoredFileMetadata> {
    const id =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `f-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
    const full: StoredFileMetadata = { ...metadata, id }
    const record: StoredFile = { metadata: full, blob }
    await withStore<void>(STORE_FILES, 'readwrite', (store) => {
      store.put(record)
    })
    return full
  }

  async deleteFile(id: string): Promise<void> {
    await withStore<void>(STORE_FILES, 'readwrite', (store) => {
      store.delete(id)
    })
  }

  async deleteAllFiles(): Promise<void> {
    await withStore<void>(STORE_FILES, 'readwrite', (store) => {
      store.clear()
    })
  }

  async findForTranslationFile(
    translationKey: string,
    fileId: string,
  ): Promise<StoredFileMetadata | null> {
    const files = await this.listFiles()
    return (
      files.find((file) => file.translationId === translationKey && file.fileId === fileId) ?? null
    )
  }

  async findLatestForTranslation(translationKey: string): Promise<StoredFileMetadata | null> {
    const files = await this.listFiles()
    return files.find((file) => file.translationId === translationKey) ?? null
  }

  async putJob(record: DownloadJobRecord): Promise<void> {
    await withStore<void>(STORE_JOBS, 'readwrite', (store) => {
      store.put(record)
    })
  }

  async listJobs(): Promise<DownloadJobRecord[]> {
    return readAll<DownloadJobRecord>(STORE_JOBS)
  }

  async deleteJob(jobId: string): Promise<void> {
    await withStore<void>(STORE_JOBS, 'readwrite', (store) => {
      store.delete(jobId)
    })
  }

  async putPartial(jobId: string, blob: Blob): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      store.put(blob, jobId)
    })
  }

  async getPartial(jobId: string): Promise<Blob | null> {
    const blob = await withStore<Blob | undefined>(STORE_PARTIALS, 'readonly', (store) =>
      store.get(jobId),
    )
    return blob ?? null
  }

  async deletePartial(jobId: string): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      store.delete(jobId)
    })
  }
}

let singleton: LocalFileStorage | null = null

/** The offline file library singleton (methods are client-only). */
export function getFileStorage(): LocalFileStorage {
  if (singleton === null) {
    singleton = new IndexedDbFileStorage()
  }
  return singleton
}

/**
 * The browser storage quota and persistence state, when the platform reports
 * them. Values are null when unknown (never guessed); failures resolve to
 * the all-unknown shape so quota checks degrade to "informational".
 */
export async function getStorageEstimate(): Promise<StorageEstimateInfo> {
  try {
    if (typeof navigator === 'undefined' || !navigator.storage?.estimate) {
      return { usage: null, quota: null, persisted: false }
    }
    const [estimate, persisted] = await Promise.all([
      navigator.storage.estimate(),
      navigator.storage.persisted?.().catch(() => false) ?? Promise.resolve(false),
    ])
    return {
      usage: typeof estimate.usage === 'number' ? estimate.usage : null,
      quota: typeof estimate.quota === 'number' ? estimate.quota : null,
      persisted,
    }
  } catch {
    return { usage: null, quota: null, persisted: false }
  }
}

/**
 * Ask the platform for persistent storage (best effort, once per call site
 * policy). Returns whether storage is (already) persistent; never throws.
 */
export async function requestPersistentStorage(): Promise<boolean> {
  try {
    if (typeof navigator === 'undefined' || !navigator.storage?.persist) {
      return false
    }
    if (await navigator.storage.persisted?.().catch(() => false)) {
      return true
    }
    return await navigator.storage.persist()
  } catch {
    return false
  }
}
