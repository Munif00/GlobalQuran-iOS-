/**
 * Quran content cache (IndexedDB).
 *
 * Sura responses that were successfully loaded are cached locally so that
 * previously read suras remain available offline. The cache is a genuine
 * offline store (never localStorage) and always records the source version
 * so cached content can be compared with the live catalog.
 *
 * Database v2 adds:
 * - `packs`: a compact per-translation index of cached suras (sura numbers,
 *   versions, approximate sizes) so offline status checks never load the
 *   heavy ayat payloads. Maintained on every write and by the v1 -> v2
 *   migration for previously cached suras.
 * - `catalog`: the last successfully loaded translation catalog per locale,
 *   so the library and the reader keep working without a connection.
 */

import type { QuranAya, TranslationsCatalogResponse } from '@/types'

const DB_NAME = 'global-quran-cache'
const DB_VERSION = 2
const STORE = 'suras'
const PACKS_STORE = 'packs'
const CATALOG_STORE = 'catalog'

export interface CachedSura {
  /** `${translationKey}:${sura}` */
  id: string
  translationKey: string
  sura: number
  /** Source version at fetch time (null when unknown). */
  version: string | null
  fetchedAt: string
  ayahCount: number
  ayat: QuranAya[]
}

/** Compact per-sura info inside a pack index (no ayat payloads). */
export interface CachedSuraInfo {
  sura: number
  version: string | null
  storedAt: string
  /** Approximate stored size in bytes (JSON length, computed locally). */
  bytes: number
}

/** Per-translation index of everything cached for offline reading. */
export interface PackIndex {
  translationKey: string
  updatedAt: string
  entries: CachedSuraInfo[]
}

function suraId(translationKey: string, sura: number): string {
  return `${translationKey}:${sura}`
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available'))
      return
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const database = request.result
      if (!database.objectStoreNames.contains(STORE)) {
        database.createObjectStore(STORE, { keyPath: 'id' })
      }
      if (!database.objectStoreNames.contains(PACKS_STORE)) {
        database.createObjectStore(PACKS_STORE, { keyPath: 'translationKey' })
      }
      if (!database.objectStoreNames.contains(CATALOG_STORE)) {
        database.createObjectStore(CATALOG_STORE, { keyPath: 'locale' })
      }
    }
    request.onsuccess = () => {
      resolve(request.result)
      // v1 -> v2: reconcile pack indexes for suras cached by earlier
      // versions (one-time, guarded by a marker record).
      void reconcileLegacySuras(request.result)
    }
    request.onerror = () => reject(request.error ?? new Error('Failed to open cache'))
  })
}

/** Marker record key inside the packs store (never a real translation key). */
const MIGRATION_MARKER_KEY = '__migration_v2__'
let migrationStarted = false

/** Build pack indexes for suras cached before the packs store existed. */
async function reconcileLegacySuras(database: IDBDatabase): Promise<void> {
  if (migrationStarted) return
  migrationStarted = true
  try {
    const checkTx = database.transaction([PACKS_STORE], 'readonly')
    const marker = await requestToPromise(checkTx.objectStore(PACKS_STORE).get(MIGRATION_MARKER_KEY))
    if (marker !== undefined) return

    const packs = new Map<string, Map<number, CachedSuraInfo>>()
    const readTx = database.transaction([STORE], 'readonly')
    const cursorRequest = readTx.objectStore(STORE).openCursor()
    await new Promise<void>((resolve, reject) => {
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result
        if (!cursor) {
          resolve()
          return
        }
        const record = cursor.value as CachedSura
        if (record && typeof record.translationKey === 'string') {
          let entries = packs.get(record.translationKey)
          if (!entries) {
            entries = new Map()
            packs.set(record.translationKey, entries)
          }
          entries.set(record.sura, {
            sura: record.sura,
            version: record.version ?? null,
            storedAt: record.fetchedAt ?? new Date(0).toISOString(),
            bytes: jsonByteSize(record),
          })
        }
        cursor.continue()
      }
      cursorRequest.onerror = () => reject(cursorRequest.error ?? new Error('Migration scan failed'))
    })

    const writeTx = database.transaction([PACKS_STORE], 'readwrite')
    const store = writeTx.objectStore(PACKS_STORE)
    for (const [translationKey, entries] of packs) {
      store.put({
        translationKey,
        updatedAt: new Date().toISOString(),
        entries: [...entries.values()].sort((a, b) => a.sura - b.sura),
      } satisfies PackIndex)
    }
    store.put({ translationKey: MIGRATION_MARKER_KEY, updatedAt: new Date().toISOString(), entries: [] })
    await transactionDone(writeTx)
  } catch {
    // Migration is best-effort; the affected pack can simply be re-downloaded.
    migrationStarted = false
  }
}

function requestToPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('Cache request failed'))
  })
}

/** UTF-8 byte length of a value (accurate for multi-byte scripts). */
const textEncoder = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null
function jsonByteSize(value: unknown): number {
  const json = JSON.stringify(value) ?? ''
  if (textEncoder !== null) return textEncoder.encode(json).length
  return json.length
}

/** Resolve when a transaction completes (commit), reject on abort/error. */
function transactionDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve()
    tx.onabort = () => reject(tx.error ?? new Error('Cache transaction aborted'))
    tx.onerror = () => reject(tx.error ?? new Error('Cache transaction failed'))
  })
}

/** Get a cached sura, if it was loaded before. */
export async function getCachedSura(translationKey: string, sura: number): Promise<CachedSura | null> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([STORE], 'readonly')
      const value = await requestToPromise(tx.objectStore(STORE).get(suraId(translationKey, sura)))
      return (value as CachedSura | undefined) ?? null
    } finally {
      database.close()
    }
  } catch {
    return null
  }
}

/** Shape accepted by both single and batch cache writes. */
export interface SuraCacheInput {
  translationKey: string
  sura: number
  version: string | null
  ayahCount: number
  ayat: QuranAya[]
}

/** Persist sura entries (one transaction) and refresh the pack index. */
export async function putCachedSuras(entries: SuraCacheInput[]): Promise<void> {
  if (entries.length === 0) return
  try {
    const database = await openDatabase()
    try {
      const storedAt = new Date().toISOString()
      const tx = database.transaction([STORE, PACKS_STORE], 'readwrite')
      const suraStore = tx.objectStore(STORE)
      const packStore = tx.objectStore(PACKS_STORE)

      // Write every sura record.
      const infos: CachedSuraInfo[] = []
      for (const entry of entries) {
        const record: CachedSura = {
          id: suraId(entry.translationKey, entry.sura),
          translationKey: entry.translationKey,
          sura: entry.sura,
          version: entry.version,
          fetchedAt: storedAt,
          ayahCount: entry.ayahCount,
          ayat: entry.ayat,
        }
        suraStore.put(record)
        infos.push({
          sura: entry.sura,
          version: entry.version,
          storedAt,
          bytes: jsonByteSize(record),
        })
      }

      // Merge into the translation's pack index.
      const translationKey = entries[0].translationKey
      const getRequest = packStore.get(translationKey)
      getRequest.onsuccess = () => {
        const existing = getRequest.result as PackIndex | undefined
        const bySura = new Map<number, CachedSuraInfo>()
        for (const info of existing?.entries ?? []) bySura.set(info.sura, info)
        for (const info of infos) bySura.set(info.sura, info)
        packStore.put({
          translationKey,
          updatedAt: storedAt,
          entries: [...bySura.values()].sort((a, b) => a.sura - b.sura),
        } satisfies PackIndex)
      }

      await transactionDone(tx)
    } finally {
      database.close()
    }
  } catch {
    // Caching is best-effort; reading must never fail because of it.
  }
}

/** Store a successfully loaded sura for offline reading. */
export async function putCachedSura(entry: Omit<CachedSura, 'id' | 'fetchedAt'>): Promise<void> {
  return putCachedSuras([entry])
}

/** All cached suras (for the offline indicator / debugging). */
export async function listCachedSuras(): Promise<CachedSura[]> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([STORE], 'readonly')
      const all = await requestToPromise(tx.objectStore(STORE).getAll())
      return (all as CachedSura[]).sort((a, b) => b.fetchedAt.localeCompare(a.fetchedAt))
    } finally {
      database.close()
    }
  } catch {
    return []
  }
}

/** The pack index of one translation (null when nothing is cached). */
export async function getPackIndex(translationKey: string): Promise<PackIndex | null> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([PACKS_STORE], 'readonly')
      const value = await requestToPromise(tx.objectStore(PACKS_STORE).get(translationKey))
      return (value as PackIndex | undefined) ?? null
    } finally {
      database.close()
    }
  } catch {
    return null
  }
}

/** All pack indexes (offline status overview). Marker records are skipped. */
export async function listPackIndexes(): Promise<PackIndex[]> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([PACKS_STORE], 'readonly')
      const all = await requestToPromise(tx.objectStore(PACKS_STORE).getAll())
      return (all as PackIndex[])
        .filter((pack) => !pack.translationKey.startsWith('__'))
        .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
    } finally {
      database.close()
    }
  } catch {
    return []
  }
}

/**
 * Delete every cached sura of one translation (the "remove offline copy"
 * action). The pack index is removed too; nothing of other translations is
 * touched.
 */
export async function deleteTranslationCache(translationKey: string): Promise<void> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([STORE, PACKS_STORE], 'readwrite')
      const suraStore = tx.objectStore(STORE)
      const packStore = tx.objectStore(PACKS_STORE)
      const packRequest = packStore.get(translationKey)
      packRequest.addEventListener('success', () => {
        const pack = packRequest.result as PackIndex | undefined
        if (!pack) {
          // No index (pre-migration data): clear by known key range.
          for (let sura = 1; sura <= 114; sura += 1) suraStore.delete(suraId(translationKey, sura))
        } else {
          for (const info of pack.entries) suraStore.delete(suraId(translationKey, info.sura))
        }
        packStore.delete(translationKey)
      })
      await transactionDone(tx)
    } finally {
      database.close()
    }
  } catch {
    // Removal is best-effort; a leftover entry simply stays offline-readable.
  }
}

/* ------------------------------------------------------------------ */
/* Catalog offline cache                                               */
/* ------------------------------------------------------------------ */

/** Store the last successfully loaded catalog for a locale. */
export async function putCachedCatalog(locale: string, response: TranslationsCatalogResponse): Promise<void> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([CATALOG_STORE], 'readwrite')
      tx.objectStore(CATALOG_STORE).put({ locale, cachedAt: new Date().toISOString(), response })
      await transactionDone(tx)
    } finally {
      database.close()
    }
  } catch {
    // Best-effort.
  }
}

/**
 * The last successfully loaded catalog for a locale, with its cache time.
 * Returns null when this locale was never loaded successfully.
 */
export async function getCachedCatalog(
  locale: string,
): Promise<{ cachedAt: string; response: TranslationsCatalogResponse } | null> {
  try {
    const database = await openDatabase()
    try {
      const tx = database.transaction([CATALOG_STORE], 'readonly')
      const value = (await requestToPromise(tx.objectStore(CATALOG_STORE).get(locale))) as
        | { locale: string; cachedAt: string; response: TranslationsCatalogResponse }
        | undefined
      return value ?? null
    } finally {
      database.close()
    }
  } catch {
    return null
  }
}
