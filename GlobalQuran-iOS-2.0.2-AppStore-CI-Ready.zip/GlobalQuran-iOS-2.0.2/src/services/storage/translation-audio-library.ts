/**
 * Global Quran - Translation narration audio library (IndexedDB).
 *
 * The persistent offline store for DOWNLOADED human-recorded translation
 * narration audio (PROMPT 10). This is a DEDICATED database
 * (`global-quran-translation-audio`), fully separate from:
 * - the recitation audio library (`global-quran-audio`),
 * - the Quran text cache (`global-quran-cache`),
 * - the document offline library.
 *
 * Deleting translation narration audio can therefore never touch Arabic
 * recitation audio, Quran text or translations - and vice versa.
 *
 * - `manifest`: one record per stored narration file - translation key,
 *   sura, ayah, storage key, exact file size, verification status and the
 *   source reference (the persistent download manifest).
 * - `blobs`: the MP3 payloads, keyed by the manifest id.
 * - `partials`: partial payloads of in-flight transfers (pause/resume).
 *
 * A manifest entry and its blob are always written in ONE transaction. The
 * manifest is the single source of truth for offline status: a sura is
 * "available offline" only when every one of its ayat has a verified entry.
 */

import type {
  TranslationAudioManifestEntry,
  TranslationAudioOfflineStatus,
  TranslationAudioSuraOfflineStatus,
} from '@/types'
import { getSuraAyahCount } from '@/lib/audio/urls'

const DB_NAME = 'global-quran-translation-audio'
const DB_VERSION = 1
const STORE_MANIFEST = 'manifest'
const STORE_BLOBS = 'blobs'
const STORE_PARTIALS = 'partials'

let dbPromise: Promise<IDBDatabase> | null = null

function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise !== null) return dbPromise
  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available in this environment'))
      return
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(STORE_MANIFEST)) {
        db.createObjectStore(STORE_MANIFEST, { keyPath: 'id' })
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS)
      }
      if (!db.objectStoreNames.contains(STORE_PARTIALS)) {
        db.createObjectStore(STORE_PARTIALS)
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'))
    request.onblocked = () => reject(new Error('IndexedDB open blocked'))
  })
  dbPromise.catch(() => {
    dbPromise = null
  })
  return dbPromise
}

function withStore<T>(
  storeName: string,
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T> {
  return openDatabase().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const transaction = db.transaction(storeName, mode)
        const store = transaction.objectStore(storeName)
        let result: T | undefined
        const request = run(store)
        if (request) {
          request.onsuccess = () => {
            result = request.result
          }
          request.onerror = () => reject(request.error)
        }
        transaction.oncomplete = () => resolve(result as T)
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

/** Atomic write across the manifest + blobs stores. */
function withManifestAndBlobs(
  run: (manifest: IDBObjectStore, blobs: IDBObjectStore) => void,
): Promise<void> {
  return openDatabase().then(
    (db) =>
      new Promise<void>((resolve, reject) => {
        const transaction = db.transaction([STORE_MANIFEST, STORE_BLOBS], 'readwrite')
        run(transaction.objectStore(STORE_MANIFEST), transaction.objectStore(STORE_BLOBS))
        transaction.oncomplete = () => resolve()
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

export function translationAudioEntryId(
  translationKey: string,
  sura: number,
  ayah: number,
): string {
  return `${translationKey}:${sura}:${ayah}`
}

function readAllManifest(): Promise<TranslationAudioManifestEntry[]> {
  return withStore<TranslationAudioManifestEntry[]>(STORE_MANIFEST, 'readonly', (store) =>
    store.getAll(),
  )
}

/** The app's translation narration audio library (singleton). */
class IndexedDbTranslationAudioLibrary {
  /* ------------------------------ manifest ------------------------------ */

  async getEntry(
    translationKey: string,
    sura: number,
    ayah: number,
  ): Promise<TranslationAudioManifestEntry | null> {
    const entry = await withStore<TranslationAudioManifestEntry | undefined>(
      STORE_MANIFEST,
      'readonly',
      (store) => store.get(translationAudioEntryId(translationKey, sura, ayah)),
    )
    return entry ?? null
  }

  async listEntriesForTranslation(translationKey: string): Promise<TranslationAudioManifestEntry[]> {
    const all = await readAllManifest()
    return all.filter((entry) => entry.translationKey === translationKey)
  }

  async listAllEntries(): Promise<TranslationAudioManifestEntry[]> {
    return readAllManifest()
  }

  /** Store one VERIFIED file: manifest entry + blob in one atomic transaction. */
  async putVerifiedFile(entry: TranslationAudioManifestEntry, blob: Blob): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.put(entry)
      blobs.put(blob, entry.id)
    })
  }

  async updateVerification(id: string, verification: 'verified' | 'corrupted'): Promise<void> {
    await withStore<void>(STORE_MANIFEST, 'readwrite', (store) => {
      const request = store.get(id)
      request.onsuccess = () => {
        const entry = request.result as TranslationAudioManifestEntry | undefined
        if (entry) {
          entry.verification = verification
          store.put(entry)
        }
      }
    })
  }

  /* ------------------------------- blobs -------------------------------- */

  async getBlob(id: string): Promise<Blob | null> {
    const blob = await withStore<Blob | undefined>(STORE_BLOBS, 'readonly', (store) =>
      store.get(id),
    )
    return blob ?? null
  }

  /* ------------------------------ deletion ------------------------------ */

  /** Delete one stored narration file. Never touches any other store. */
  async deleteFile(translationKey: string, sura: number, ayah: number): Promise<void> {
    const id = translationAudioEntryId(translationKey, sura, ayah)
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.delete(id)
      blobs.delete(id)
    })
  }

  /** Delete every stored narration file of one sura of one translation. */
  async deleteSura(translationKey: string, sura: number): Promise<void> {
    const entries = await this.listEntriesForTranslation(translationKey)
    const doomed = entries.filter((entry) => entry.sura === sura).map((entry) => entry.id)
    await withManifestAndBlobs((manifest, blobs) => {
      for (const id of doomed) {
        manifest.delete(id)
        blobs.delete(id)
      }
    })
  }

  /** Delete every stored narration file of one translation. */
  async deleteTranslation(translationKey: string): Promise<void> {
    const entries = await this.listEntriesForTranslation(translationKey)
    const doomed = entries.map((entry) => entry.id)
    await withManifestAndBlobs((manifest, blobs) => {
      for (const id of doomed) {
        manifest.delete(id)
        blobs.delete(id)
      }
    })
  }

  /** Delete EVERY stored narration file (all translations). Nothing else. */
  async deleteAll(): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.clear()
      blobs.clear()
    })
  }

  /* -------------------------- offline status ---------------------------- */

  /**
   * The honest offline status of one translation's narration audio:
   * per-sura counts, total bytes, and which suras are truly complete
   * (every ayah stored AND verified - never merely because a download ran).
   */
  async getStatus(translationKey: string): Promise<TranslationAudioOfflineStatus> {
    const entries = await this.listEntriesForTranslation(translationKey)

    const bySura = new Map<number, { stored: number; corrupted: number; bytes: number }>()
    for (const entry of entries) {
      if (entry.verification !== 'verified' && entry.verification !== 'corrupted') continue
      const record = bySura.get(entry.sura) ?? { stored: 0, corrupted: 0, bytes: 0 }
      if (entry.verification === 'verified') {
        record.stored += 1
        record.bytes += entry.fileSize
      } else {
        record.corrupted += 1
      }
      bySura.set(entry.sura, record)
    }

    const suras: TranslationAudioSuraOfflineStatus[] = []
    let completeSuras = 0
    for (const [sura, record] of bySura) {
      const ayahCount = getSuraAyahCount(sura)
      const complete = ayahCount > 0 && record.stored >= ayahCount && record.corrupted === 0
      if (complete) completeSuras += 1
      suras.push({
        translationKey,
        sura,
        ayahCount,
        storedAyat: record.stored,
        corruptedAyat: record.corrupted,
        complete,
        totalBytes: record.bytes,
      })
    }
    suras.sort((a, b) => a.sura - b.sura)

    return {
      translationKey,
      storedFiles: entries.filter((entry) => entry.verification === 'verified').length,
      corruptedFiles: entries.filter((entry) => entry.verification === 'corrupted').length,
      totalBytes: suras.reduce((sum, sura) => sum + sura.totalBytes, 0),
      completeSuras,
      suras,
    }
  }

  /** Which (sura, ayah) of a sura have verified local files. */
  async listVerifiedAyat(
    translationKey: string,
    sura: number,
  ): Promise<Set<number>> {
    const entries = await this.listEntriesForTranslation(translationKey)
    const set = new Set<number>()
    for (const entry of entries) {
      if (entry.sura === sura && entry.verification === 'verified') set.add(entry.ayah)
    }
    return set
  }

  /**
   * Re-verify the stored files of one sura against their recorded sizes.
   * Failing entries are marked `corrupted` (excluded from offline playback
   * until re-downloaded). Returns the number of failures.
   */
  async verifySura(translationKey: string, sura: number): Promise<{ checked: number; failed: number }> {
    const entries = (await this.listEntriesForTranslation(translationKey)).filter(
      (entry) => entry.sura === sura,
    )
    let failed = 0
    for (const entry of entries) {
      const blob = await this.getBlob(entry.id).catch(() => null)
      const ok = blob !== null && blob.size === entry.fileSize
      if (!ok) {
        failed += 1
        await this.updateVerification(entry.id, 'corrupted').catch(() => undefined)
      } else if (entry.verification === 'corrupted') {
        await this.updateVerification(entry.id, 'verified').catch(() => undefined)
      }
    }
    return { checked: entries.length, failed }
  }

  /* --------------------------- paused transfers -------------------------- */

  async putPartial(key: string, blob: Blob): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      store.put(blob, key)
    })
  }

  async getPartial(key: string): Promise<Blob | null> {
    const blob = await withStore<Blob | undefined>(STORE_PARTIALS, 'readonly', (store) =>
      store.get(key),
    )
    return blob ?? null
  }

  async deletePartial(key: string): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      store.delete(key)
    })
  }

  async deletePartialsForBatch(batchId: string): Promise<void> {
    await withStore<void>(STORE_PARTIALS, 'readwrite', (store) => {
      const cursorRequest = store.openCursor()
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result
        if (!cursor) return
        const key = String(cursor.key)
        if (key.startsWith(`${batchId}:`)) cursor.delete()
        cursor.continue()
      }
    })
  }
}

let libraryInstance: IndexedDbTranslationAudioLibrary | null = null

/** The app's translation narration audio library (created on first use). */
export function getTranslationAudioLibrary(): IndexedDbTranslationAudioLibrary {
  if (libraryInstance === null) libraryInstance = new IndexedDbTranslationAudioLibrary()
  return libraryInstance
}
