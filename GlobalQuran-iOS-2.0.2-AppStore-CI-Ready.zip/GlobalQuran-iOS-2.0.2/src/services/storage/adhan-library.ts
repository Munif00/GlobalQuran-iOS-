'use client'

/**
 * Global Quran - Adhan recording library (IndexedDB).
 *
 * PROMPT 13. The persistent offline store for DOWNLOADED Adhan recordings:
 *
 * - `manifest`: one record per stored recording - the persistent download
 *   manifest (recording id, muezzin names, title, source reference, exact
 *   file size, format, download status, verification status, download date).
 * - `blobs`: the MP3 payloads, keyed by the manifest id.
 *
 * Design rules (mirrors the recitation audio library):
 * - A manifest entry and its blob are written together in ONE transaction -
 *   a hard termination can never leave a manifest entry without its payload
 *   or an orphan payload presented as a stored file.
 * - "Offline ready" is reported ONLY when the manifest entry exists AND its
 *   blob is present AND its recorded size matches - never merely because a
 *   download once ran.
 * - Deleting a recording NEVER touches any other store: this is a dedicated
 *   database (`global-quran-adhans`), fully separate from the Quran text
 *   cache, the recitation audio and the document library.
 * - The database opens lazily (SSR-safe); every method is client-only.
 */

import type { AdhanManifestEntry } from '@/types'

const DB_NAME = 'global-quran-adhans'
const DB_VERSION = 1
const STORE_MANIFEST = 'manifest'
const STORE_BLOBS = 'blobs'

let dbPromise: Promise<IDBDatabase> | null = null

function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise !== null) return dbPromise
  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available in this environment'))
      return
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION)
    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(STORE_MANIFEST)) {
        db.createObjectStore(STORE_MANIFEST, { keyPath: 'id' })
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS)
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'))
    request.onblocked = () => reject(new Error('IndexedDB open blocked'))
  })
  dbPromise.catch(() => {
    dbPromise = null
  })
  return dbPromise
}

function withStore<T>(
  storeName: string,
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T> {
  return openDatabase().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const transaction = db.transaction(storeName, mode)
        const store = transaction.objectStore(storeName)
        let result: T | undefined
        const request = run(store)
        if (request) {
          request.onsuccess = () => {
            result = request.result
          }
          request.onerror = () => reject(request.error)
        }
        transaction.oncomplete = () => resolve(result as T)
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

/** Atomic write across the manifest + blobs stores. */
function withManifestAndBlobs(
  run: (manifest: IDBObjectStore, blobs: IDBObjectStore) => void,
): Promise<void> {
  return openDatabase().then(
    (db) =>
      new Promise<void>((resolve, reject) => {
        const transaction = db.transaction([STORE_MANIFEST, STORE_BLOBS], 'readwrite')
        run(transaction.objectStore(STORE_MANIFEST), transaction.objectStore(STORE_BLOBS))
        transaction.oncomplete = () => resolve()
        transaction.onabort = () => reject(transaction.error)
        transaction.onerror = () => reject(transaction.error)
      }),
  )
}

/** The app's Adhan recording library (singleton). */
class IndexedDbAdhanLibrary {
  /* ------------------------------ manifest ------------------------------ */

  /** One manifest entry (null when the recording is not stored). */
  async getEntry(id: string): Promise<AdhanManifestEntry | null> {
    const entry = await withStore<AdhanManifestEntry | undefined>(
      STORE_MANIFEST,
      'readonly',
      (store) => store.get(id),
    )
    return entry ?? null
  }

  /** Every manifest entry (all recordings). */
  async listEntries(): Promise<AdhanManifestEntry[]> {
    return withStore<AdhanManifestEntry[]>(STORE_MANIFEST, 'readonly', (store) => store.getAll())
  }

  /**
   * Store one VERIFIED recording: manifest entry + blob in a single atomic
   * transaction. An existing entry for the same id is replaced together with
   * its blob (dedupe-by-overwrite - re-downloading a deleted recording
   * overwrites cleanly, never duplicates).
   */
  async putVerifiedFile(entry: AdhanManifestEntry, blob: Blob): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.put(entry)
      blobs.put(blob, entry.id)
    })
  }

  /* ------------------------------- blobs -------------------------------- */

  /** The stored audio payload of one manifest entry (null when absent). */
  async getBlob(id: string): Promise<Blob | null> {
    const blob = await withStore<Blob | undefined>(STORE_BLOBS, 'readonly', (store) =>
      store.get(id),
    )
    return blob ?? null
  }

  /* --------------------------- verification ----------------------------- */

  /**
   * The honest offline check: the entry exists, its blob exists, and the
   * blob's size matches the recorded size. Used before claiming "offline
   * ready" and before scheduled playback (a corrupt copy is never played).
   */
  async getVerifiedFile(id: string): Promise<{ entry: AdhanManifestEntry; blob: Blob } | null> {
    try {
      const entry = await this.getEntry(id)
      if (!entry || entry.verification !== 'verified' || entry.status !== 'ready') return null
      const blob = await this.getBlob(id)
      if (blob === null) return null
      if (blob.size !== entry.fileSize) return null
      if (blob.size === 0) return null
      return { entry, blob }
    } catch {
      return null
    }
  }

  /* ------------------------------ deletion ------------------------------ */

  /** Delete one stored recording (manifest entry + blob, atomically).
   *  Touches nothing else. */
  async deleteFile(id: string): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.delete(id)
      blobs.delete(id)
    })
  }

  /** Delete every stored recording. */
  async deleteAll(): Promise<void> {
    await withManifestAndBlobs((manifest, blobs) => {
      manifest.clear()
      blobs.clear()
    })
  }

  /* ------------------------------ usage --------------------------------- */

  /** Total bytes used by stored Adhan recordings (for storage management). */
  async totalBytes(): Promise<number> {
    const entries = await this.listEntries()
    return entries.reduce((sum, entry) => sum + entry.fileSize, 0)
  }
}

let libraryInstance: IndexedDbAdhanLibrary | null = null

/** The app's Adhan recording library (created on first use). */
export function getAdhanLibrary(): IndexedDbAdhanLibrary {
  if (libraryInstance === null) libraryInstance = new IndexedDbAdhanLibrary()
  return libraryInstance
}
