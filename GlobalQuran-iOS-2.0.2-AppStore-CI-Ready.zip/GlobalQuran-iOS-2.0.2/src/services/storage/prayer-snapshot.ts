/**
 * Prayer times client-side offline snapshot (localStorage).
 *
 * Purpose: keep the main prayer dashboard working when the app server
 * itself is unreachable (page reload while offline). The server already
 * serves labeled cache / local-engine fallbacks when IT can be reached;
 * this snapshot covers the remaining failure mode - no server at all.
 *
 * Honesty rules:
 * - Only successfully fetched `live` responses are ever stored.
 * - A snapshot is keyed by the exact query parameters and date, so it can
 *   never resurface times computed for another location or method.
 * - Served snapshots are flagged `clientCache` so the UI labels them
 *   clearly ("Cached") together with their original retrieval date.
 *   They are never presented as freshly verified data.
 */

import type { PrayerSourceInfo, PrayerTimeRecord } from '@/types'

const STORAGE_KEY = 'global-quran-prayer-snapshots'
/** Keep the most recent snapshots (today + tomorrow across a few settings). */
const MAX_ENTRIES = 12

export interface PrayerSnapshotEntry {
  /** The verified record as originally returned by the server. */
  record: PrayerTimeRecord
  /** The transparency block that accompanied it. */
  source: PrayerSourceInfo | null
  /** When the underlying data was originally fetched (record.fetchedAt). */
  fetchedAt: string
  /** When this snapshot was written to the device. */
  savedAt: string
}

type SnapshotMap = Record<string, PrayerSnapshotEntry>

function readMap(): SnapshotMap {
  if (typeof window === 'undefined') return {}
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return {}
    const parsed = JSON.parse(raw) as SnapshotMap
    if (!parsed || typeof parsed !== 'object') return {}
    return parsed
  } catch {
    return {}
  }
}

function writeMap(map: SnapshotMap): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(map))
  } catch {
    // Quota or privacy mode: the snapshot is a best-effort cache; failing
    // to persist it must never break the prayer screen.
  }
}

/** Build the map key: parameters + date (never mixes locations or methods). */
export function snapshotKey(paramsKey: string, date: string): string {
  return `${date}|${paramsKey}`
}

/** Store a successful response. Prunes the oldest entries beyond the cap. */
export function savePrayerSnapshot(paramsKey: string, record: PrayerTimeRecord, source: PrayerSourceInfo | null): void {
  const map = readMap()
  map[snapshotKey(paramsKey, record.date)] = {
    record,
    source,
    fetchedAt: record.fetchedAt,
    savedAt: new Date().toISOString(),
  }
  const entries = Object.entries(map)
  if (entries.length > MAX_ENTRIES) {
    entries.sort((a, b) => (a[1].savedAt < b[1].savedAt ? -1 : 1))
    for (const [key] of entries.slice(0, entries.length - MAX_ENTRIES)) {
      delete map[key]
    }
  }
  writeMap(map)
}

/** Retrieve a stored snapshot for the exact parameters + date. */
export function loadPrayerSnapshot(paramsKey: string, date: string): PrayerSnapshotEntry | null {
  const entry = readMap()[snapshotKey(paramsKey, date)]
  if (!entry || !entry.record) return null
  // Guard against corrupted/partial writes: a usable record needs the six times.
  for (const slot of ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as const) {
    const value = entry.record[slot]
    if (typeof value !== 'string' || Number.isNaN(new Date(value).getTime())) return null
  }
  return entry
}
