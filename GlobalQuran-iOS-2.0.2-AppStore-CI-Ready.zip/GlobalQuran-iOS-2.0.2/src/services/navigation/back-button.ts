'use client'

/**
 * Global Quran - Android hardware Back button controller.
 *
 * Without a 'backButton' listener, Capacitor's default Back handling finishes
 * the Android activity on the very first press - the app dies instantly with
 * no chance to close a dialog or go back a screen. This module installs that
 * listener and routes every press through a fixed priority:
 *
 *   1. Close the topmost dismissible layer - any open Radix layer (dialog,
 *      menu, select listbox, popover) or the built-in FileViewer - by
 *      dispatching one synthetic Escape keydown, exactly the key a keyboard
 *      user presses. Radix closes only its topmost layer, and the FileViewer
 *      defers to inner Radix layers, so each press peels exactly one layer.
 *   2. The audio/narration player bars are persistent bottom bars, not
 *      layers - deliberately NOT back targets. The DuaSplash (passive,
 *      self-dismissing) and the AdhanFireBanner are never treated as layers
 *      either; they simply do not match the layer detection below.
 *   3./4. Walk the app's own hash history backwards via history.back(). The
 *      existing hashchange sync in navigation-store updates the screen, so
 *      nested screens return to their parents naturally.
 *   5. Only at Home with no in-app history left: double-back-to-exit. The
 *      first press shows the localized hint toast (nav.backExitHint); a
 *      second press within EXIT_WINDOW_MS exits via App.exitApp(). After the
 *      window expires the state resets - a single stray press can never
 *      exit the app.
 *
 * Platform honesty:
 * - Web: the controller installs NOTHING. The browser's own Back button
 *   keeps its native behavior; this module never intercepts on the web.
 * - iOS: also nothing. There is no hardware Back button on iOS, so there is
 *   nothing to handle - pretending otherwise would be dishonest.
 * - If the @capacitor/app plugin cannot be imported or the listener fails to
 *   register, the controller degrades to doing nothing (Capacitor's default
 *   exit-on-back remains). It never fakes success.
 *
 * History discipline: the controller never calls pushState/replaceState. It
 * only calls history.back() and reads location.hash, plus the one documented
 * exception at synthesizeHomeReturn (deep-link fallback), which navigates
 * through the app's own navigation store - the same thing tapping the Home
 * tab does. The initNavigationSync hashchange listener stays untouched.
 *
 * The listener event's `canGoBack` flag is deliberately ignored: it knows
 * nothing about overlays or the exit window and can disagree with the app's
 * own hash stack. The depth counter below is the app-level truth.
 */

import { Capacitor } from '@capacitor/core'
import type { PluginListenerHandle } from '@capacitor/core'
import { toast } from 'sonner'

import { createTranslator, resolveLanguage } from '@/i18n'
import { isRealNativePlatform } from '@/services/platform/native-mode'
import { useNavigationStore } from '@/stores/navigation-store'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useViewerStore } from '@/stores/viewer-store'

/** Burst protection: Android can deliver duplicate Back events for one
 * physical press. Anything arriving inside this window is ignored. */
const BACK_REENTRY_LOCKOUT_MS = 100

/** If a controller-initiated history.back() produces no hashchange within
 * this window, the target entry was dead (nothing behind the current one) -
 * the depth counter self-heals to zero instead of calling back into
 * nothing forever. */
const BACK_DEAD_ENTRY_TIMEOUT_MS = 250

/** How long the "press back again to exit" window stays open. */
const EXIT_WINDOW_MS = 2500

/** Radix marks every open layer with data-state="open" plus an ARIA role.
 * Dialogs, popovers and sheets render role="dialog", menus role="menu",
 * selects role="listbox". */
const RADIX_OPEN_LAYER_SELECTOR =
  '[data-state="open"][role="dialog"], [data-state="open"][role="menu"], [data-state="open"][role="listbox"]'

/** The action a Back press requires, in priority order. */
export type BackAction =
  | 'dismiss-overlay'
  | 'history-back'
  | 'show-exit-hint'
  | 'exit-app'
  | 'ignore'

/** Immutable snapshot of the world at the moment Back was pressed. */
export interface BackActionSnapshot {
  /** A dismissible layer (Radix layer or the built-in file viewer) is open. */
  overlayOpen: boolean
  /** Remaining in-app history entries (hash pushes not yet backed out of). */
  depth: number
  /** True while the previous press opened the double-back exit window. */
  withinExitWindow: boolean
  /** True while the burst-protection lockout is active (duplicate event).
   * Optional because snapshots built outside the controller have no lock. */
  locked?: boolean
}

/**
 * Pure back-press policy: which action the given world-state requires.
 * Priority: duplicate burst -> ignore; open layer -> dismiss; in-app
 * history -> back; exit window open -> exit; otherwise -> show the hint.
 * Exported so the full priority order is verifiable without a device - the
 * controller below only wires real inputs into this function.
 */
export function resolveBackAction(snapshot: BackActionSnapshot): BackAction {
  if (snapshot.locked === true) return 'ignore'
  if (snapshot.overlayOpen) return 'dismiss-overlay'
  if (snapshot.depth > 0) return 'history-back'
  if (snapshot.withinExitWindow) return 'exit-app'
  return 'show-exit-hint'
}

/* ------------------------------------------------------------------ */
/* Controller state (module level; reset on install, cleared on teardown) */
/* ------------------------------------------------------------------ */

/** Hash pushes still "undone" - the depth of the in-app back stack. */
let appHistoryDepth = 0

/** Last observed location.hash (input for the hashchange comparison). */
let lastHash = ''

/**
 * True while the NEXT hashchange is the result of a controller-initiated
 * navigation (its own history.back(), or the deep-link return-home) - that
 * change consumed an entry and must not be counted as a new push.
 */
let pendingSelfChange = false

/** Dead-entry watchdog for the pending self-change. */
let pendingSelfTimer: ReturnType<typeof setTimeout> | null = null

/** Timestamp of the last HANDLED Back press (burst lockout input). */
let lastBackHandledAt = 0

/** Timestamp of the shown exit hint (0 = no exit window open). */
let exitHintShownAt = 0

/** Resolved @capacitor/app plugin (null until the dynamic import lands). */
let appPlugin: (typeof import('@capacitor/app'))['App'] | null = null

/** The teardown of the active install, or null when not installed. */
let activeTeardown: (() => void) | null = null

/** True only inside the real Android native shell (not web, not iOS). */
function isAndroidNativeShell(): boolean {
  if (!isRealNativePlatform()) return false
  try {
    return Capacitor.getPlatform() === 'android'
  } catch {
    return false
  }
}

/**
 * True while a Back press should close a layer instead of navigating.
 * Radix layers are found through their open-state attributes; the built-in
 * FileViewer is a plain fixed overlay (not Radix - it carries no
 * data-state/role) that closes itself on Escape, so the viewer store is
 * consulted directly. Persistent player bars, the DuaSplash and the
 * AdhanFireBanner never match either check, by design.
 */
function isDismissibleLayerOpen(): boolean {
  if (document.querySelector(RADIX_OPEN_LAYER_SELECTOR) !== null) return true
  return useViewerStore.getState().openFileId !== null
}

/**
 * Close the topmost dismissible layer the way a keyboard user would: one
 * synthetic Escape keydown. Radix closes exactly its topmost layer, and the
 * FileViewer's own Escape handler defers while an inner Radix layer is open
 * (see file-viewer.tsx) - so one press always peels exactly one layer.
 */
function dismissTopmostLayer(): void {
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
}

/** The localized exit-hint toast (same language resolution as the UI). */
function showExitHintToast(): void {
  const prefs = usePreferencesStore.getState()
  const locale = resolveLanguage(prefs.languageMode, prefs.manualLanguage, prefs.detectedLanguage)
  const t = createTranslator(locale)
  toast(t('nav.backExitHint'), {
    id: 'android-back-exit-hint',
    /* The toast stays visible exactly as long as the exit window is valid -
     * when it disappears, a new first press is needed again. */
    duration: EXIT_WINDOW_MS,
  })
}

function clearPendingSelfTimer(): void {
  if (pendingSelfTimer !== null) {
    clearTimeout(pendingSelfTimer)
    pendingSelfTimer = null
  }
}

/**
 * history.back() lands asynchronously. If no hashchange arrives within the
 * watchdog window, the entry was dead - self-heal the depth to zero so the
 * next press reaches the exit logic instead of looping on a no-op.
 */
function armPendingSelfWatchdog(): void {
  clearPendingSelfTimer()
  pendingSelfTimer = setTimeout(() => {
    pendingSelfTimer = null
    if (!pendingSelfChange) return
    pendingSelfChange = false
    appHistoryDepth = 0
  }, BACK_DEAD_ENTRY_TIMEOUT_MS)
}

/**
 * Track the app's own hash history. hashchange fires for BOTH pushes (the
 * app's navigate() assigns location.hash) and pops (this controller's
 * history.back()); the pendingSelfChange flag distinguishes them: a pending
 * self-change consumed an entry (decrement), anything else with a genuinely
 * different hash was a push (increment).
 */
function onHashChange(): void {
  const nextHash = window.location.hash
  const previousHash = lastHash
  lastHash = nextHash

  if (pendingSelfChange) {
    pendingSelfChange = false
    clearPendingSelfTimer()
    appHistoryDepth = Math.max(0, appHistoryDepth - 1)
    return
  }

  if (nextHash === previousHash) return // no real change (defensive)
  appHistoryDepth += 1
}

/** One step back inside the app's hash history (levels 3-4). */
function goBackInApp(): void {
  pendingSelfChange = true
  armPendingSelfWatchdog()
  window.history.back()
  // The hashchange sync in navigation-store updates the visible screen.
}

/**
 * The deep-link edge (documented exception to "only history.back()"): the
 * app was launched with a non-home hash (e.g. '#/quran') as the FIRST
 * history entry, so there is nothing behind it and plain history.back()
 * would be a dead no-op - the user would be trapped away from Home.
 * Android's own convention for this case is to return to the start
 * destination first. That is done through the app's navigation store -
 * byte-for-byte the code path of tapping the Home tab - and the resulting
 * hashchange is consumed via the pending-self-change mechanism, so the
 * depth stays 0 and the NEXT press at Home enters the exit logic.
 */
function synthesizeHomeReturn(): void {
  pendingSelfChange = true
  armPendingSelfWatchdog()
  useNavigationStore.getState().navigate('home')
}

/** Best-effort exit through the plugin; a rejection leaves the user in the
 * app (never crashes it). A missing plugin means there is nothing to exit
 * through - honestly a no-op. */
function exitNativeApp(): void {
  const plugin = appPlugin
  if (plugin === null) return
  void plugin.exitApp().catch(() => {
    // Exit failed (e.g. platform quirk): stay alive, do not throw.
  })
}

/** The Back press handler: snapshot the world, decide, act. */
function onBackButton(): void {
  const now = Date.now()
  const locked = now - lastBackHandledAt < BACK_REENTRY_LOCKOUT_MS
  const overlayOpen = isDismissibleLayerOpen()

  /* Deep-link guard (level 4 fallback, before the exit level): an empty
   * in-app stack while NOT at Home means the first history entry is a
   * non-home screen. Back must return to Home - never exit from a nested
   * screen, never swallow the press as a dead no-op. */
  if (
    !locked &&
    !overlayOpen &&
    appHistoryDepth === 0 &&
    useNavigationStore.getState().activeScreen !== 'home'
  ) {
    lastBackHandledAt = now
    exitHintShownAt = 0
    synthesizeHomeReturn()
    return
  }

  const action = resolveBackAction({
    overlayOpen,
    depth: appHistoryDepth,
    withinExitWindow: exitHintShownAt > 0 && now - exitHintShownAt < EXIT_WINDOW_MS,
    locked,
  })

  if (action === 'ignore') {
    // Duplicate burst event for an already-handled physical press.
    return
  }
  lastBackHandledAt = now

  switch (action) {
    case 'dismiss-overlay':
      /* Any layer interaction restarts the exit sequence from scratch, so
       * a stale exit window can never leak across an overlay round-trip. */
      exitHintShownAt = 0
      dismissTopmostLayer()
      break
    case 'history-back':
      /* Same reset here: navigating anywhere must cancel a pending exit. */
      exitHintShownAt = 0
      goBackInApp()
      break
    case 'show-exit-hint':
      exitHintShownAt = now
      showExitHintToast()
      break
    case 'exit-app':
      exitHintShownAt = 0
      exitNativeApp()
      break
  }
}

/**
 * Install the Android hardware Back controller. Mount once from the AppShell.
 *
 * - Non-Android / non-native contexts (web browser, iOS shell, SSR): returns
 *   a no-op cleanup and installs nothing. The browser's native Back behavior
 *   is left completely untouched.
 * - Android native shell: registers the @capacitor/app 'backButton' listener
 *   (dynamic import wrapped in try/catch - if the plugin is unavailable the
 *   controller does nothing) and the hashchange depth tracker.
 *
 * Idempotent: a second call while installed returns the existing teardown.
 * The returned function removes both listeners and resets module state.
 */
export function initBackButtonController(): () => void {
  if (!isAndroidNativeShell()) return () => undefined
  if (activeTeardown !== null) return activeTeardown

  /* Reset every piece of module state (also covers dev StrictMode remounts,
   * where the effect is torn down and re-run on the same page). */
  appHistoryDepth = 0
  lastHash = window.location.hash
  pendingSelfChange = false
  clearPendingSelfTimer()
  lastBackHandledAt = 0
  exitHintShownAt = 0

  window.addEventListener('hashchange', onHashChange)

  let disposed = false
  let listenerHandle: PluginListenerHandle | null = null

  void (async () => {
    try {
      const { App } = await import('@capacitor/app')
      if (disposed) return
      appPlugin = App
      listenerHandle = await App.addListener('backButton', onBackButton)
      if (disposed) {
        // Teardown ran while the listener was still being registered.
        const handle = listenerHandle
        listenerHandle = null
        void handle.remove().catch(() => {
          // Best-effort cleanup; the activity is going away regardless.
        })
      }
    } catch {
      /* Plugin unavailable (not expected inside the real Android shell):
       * fall back to doing nothing. Capacitor's default Back handling
       * remains in charge - the same behavior this app had before the
       * controller existed. Honest, never faked. */
    }
  })()

  const teardown = () => {
    disposed = true
    window.removeEventListener('hashchange', onHashChange)
    clearPendingSelfTimer()
    pendingSelfChange = false
    exitHintShownAt = 0
    appPlugin = null
    if (listenerHandle !== null) {
      const handle = listenerHandle
      listenerHandle = null
      void handle.remove().catch(() => {
        // Best-effort cleanup; the activity is going away regardless.
      })
    }
    if (activeTeardown === teardown) activeTeardown = null
  }
  activeTeardown = teardown
  return teardown
}
