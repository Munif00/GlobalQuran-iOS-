'use client'

/**
 * Global Quran - Native reminder bridge (PROMPT 16 §5.4/§5.5).
 *
 * Connects the EXISTING trusted prayer-time architecture to native Android
 * scheduling through the AdhanScheduler Capacitor plugin:
 *
 * - Event computation reuses the same prayer resolver chain the app already
 *   serves (the calendar endpoint, via platformFetch - identical in web and
 *   native modes), and the same settings-to-params builder the Prayer screen
 *   uses (src/lib/prayer/prayer-context.ts). No second prayer engine.
 * - The horizon covers the current + next calendar month (up to ~60 days),
 *   refreshed on every app open and on every settings change. The native
 *   side keeps its events across reboots and clock/time-zone changes, so
 *   reminders survive without the app being opened for weeks.
 * - Scheduling uses Android's alarm-clock mechanism (AlarmManager
 *   setAlarmClock) - exact, Doze-proof, and permission-free by design; the
 *   honest status is surfaced in the reminder sheet.
 * - At fire time: app in foreground -> the full Adhan plays through the
 *   existing single Adhan player with the in-app banner; app closed or in
 *   the background -> a high-priority notification whose channel sound is
 *   the user's verified Adhan recording (where the device supports long
 *   notification sounds; some device makers truncate them - stated honestly
 *   in the platform note, never claimed otherwise).
 * - Adhan audio mirrors: after a recording is downloaded+verified by the
 *   existing web library, it is copied (chunked, size-verified) into the
 *   app's private native storage so the notification channel can use it.
 *   The web library stays the single source of truth; the mirror is kept in
 *   sync on every app open and after every download.
 *
 * Web/PWA/iOS: the plugin is unavailable; this module reports that honestly
 * and the app keeps the shipped foreground web scheduler. Nothing is claimed
 * that the platform cannot do.
 */

import { platformFetch } from '@/services/platform/fetch'
import {
  AdhanScheduler,
  type NativeReminderEvent,
  type NativeSchedulerStatus,
} from '@/services/native/adhan-scheduler-plugin'

/** Public alias for UI consumers (reminder sheet). */
export type NativeReminderStatusView = NativeSchedulerStatus
import { isRealNativePlatform } from '@/services/platform/native-mode'
import { resolveAdhanForSlot } from '@/services/notifications/prayer-notification-service'
import { fireAdhanReminder, bodyForOutcome, type AdhanFireOutcome } from '@/services/notifications/adhan-fire'
import { buildPrayerContext } from '@/lib/prayer/prayer-context'
import { resolveLanguage, createTranslator } from '@/i18n'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useAdhanFireStore } from '@/stores/adhan-fire-store'
import { getAdhanLibrary } from '@/services/storage/adhan-library'
import { prayerParamsKeyPart } from '@/services/api/prayer-api'
import { todayInZone } from '@/lib/prayer/timezone'
import type { PrayerTimeRecord, PrayerCalendarResponse } from '@/types'
import type { PrayerSlotKey } from '@/hooks/use-prayer-data'

/* ------------------------------------------------------------------ */
/* Availability                                                         */
/* ------------------------------------------------------------------ */

let availability: 'unknown' | 'native' | 'web' = 'unknown'
const availabilityWaiters: Array<() => void> = []

/** Resolve (once) whether native scheduling is present. Safe to call often. */
export async function resolveNativeAvailability(): Promise<'native' | 'web'> {
  if (availability !== 'unknown') return availability
  if (!isRealNativePlatform()) {
    // The plugin only exists in the real native shell (never in the browser
    // simulation - the simulation has no AlarmManager).
    availability = 'web'
    return 'web'
  }
  try {
    await AdhanScheduler.status()
    availability = 'native'
  } catch {
    availability = 'web'
  }
  return availability
}

/** Synchronous view for UI wiring. 'unknown' only during the first probe. */
export function nativeRemindersMode(): 'native' | 'web' | 'unknown' {
  return availability
}

/* ------------------------------------------------------------------ */
/* Event horizon                                                        */
/* ------------------------------------------------------------------ */

const HORIZON_CACHE_TTL_MS = 6 * 60 * 60 * 1000
interface HorizonCacheEntry {
  key: string
  records: PrayerTimeRecord[]
  fetchedAt: number
}
let horizonCache: HorizonCacheEntry | null = null

/** Month values (YYYY-MM) for the current + next month in the location's zone. */
function horizonMonths(timeZone: string | null): string[] {
  const today = timeZone ? todayInZone(timeZone) : new Date().toISOString().slice(0, 10)
  const [y, m] = today.split('-').map(Number)
  const first = `${y}-${String(m).padStart(2, '0')}`
  const nextY = m === 12 ? y + 1 : y
  const nextM = m === 12 ? 1 : m + 1
  const second = `${nextY}-${String(nextM).padStart(2, '0')}`
  return [first, second]
}

async function fetchMonthRecords(
  month: string,
  urlQuery: string,
): Promise<PrayerTimeRecord[]> {
  const response = await platformFetch(`/api/prayer/calendar?${urlQuery}&month=${encodeURIComponent(month)}`, {
    credentials: 'same-origin',
    headers: { Accept: 'application/json' },
  })
  const body = (await response.json()) as PrayerCalendarResponse
  if (body.status === 'live' && Array.isArray(body.days)) {
    return body.days
  }
  throw new Error(`calendar ${month} unavailable (${body.status})`)
}

/**
 * Fetch the two-month horizon through the app's own prayer API (the same
 * resolver chain, caching, and honesty the month dialog uses). Cached per
 * parameter key for 6 hours; failures keep the previous schedule running.
 */
async function getHorizonRecords(): Promise<PrayerTimeRecord[] | null> {
  const prefs = usePreferencesStore.getState()
  const context = buildPrayerContext(
    prefs.prayerSettings,
    prefs.savedLocations,
    prefs.activeLocationId,
  )
  if (!context) return null

  const key = prayerParamsKeyPart(context.params)
  if (horizonCache && horizonCache.key === key && Date.now() - horizonCache.fetchedAt < HORIZON_CACHE_TTL_MS) {
    return horizonCache.records
  }

  const search = new URLSearchParams({
    latitude: String(context.params.latitude),
    longitude: String(context.params.longitude),
    methodMode: context.params.methodMode,
    methodId: context.params.methodId,
    madhhab: context.params.madhhab,
    highLatitudeRule: context.params.highLatitudeRule,
  })
  if (context.params.timeZone) search.set('timeZone', context.params.timeZone)
  if (context.params.countryCode) search.set('countryCode', context.params.countryCode)
  if (context.params.jakimZone) search.set('jakimZone', context.params.jakimZone)
  const adjustmentParts = Object.entries(context.params.adjustments)
    .filter(([, minutes]) => minutes !== 0)
    .map(([prayer, minutes]) => `${prayer}:${minutes}`)
  if (adjustmentParts.length > 0) search.set('adjustments', adjustmentParts.join(','))

  const months = horizonMonths(context.requestTimeZone)
  const days: PrayerTimeRecord[] = []
  for (const month of months) {
    // Both months are fetched; a failing SECOND month is non-fatal (the
    // first alone still covers the rest of this month).
    try {
      days.push(...(await fetchMonthRecords(month, search.toString())))
    } catch (error) {
      if (month === months[0]) throw error
    }
  }
  if (days.length === 0) throw new Error('no horizon records')

  horizonCache = { key, records: days, fetchedAt: Date.now() }
  return days
}

/* ------------------------------------------------------------------ */
/* Event building                                                       */
/* ------------------------------------------------------------------ */

const SLOT_KEYS: PrayerSlotKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha']
const SLOT_LABEL_KEYS: Record<PrayerSlotKey, string> = {
  fajr: 'prayer.fajr',
  sunrise: 'prayer.sunrise',
  dhuhr: 'prayer.dhuhr',
  asr: 'prayer.asr',
  maghrib: 'prayer.maghrib',
  isha: 'prayer.isha',
}

function buildEvents(records: PrayerTimeRecord[]): NativeReminderEvent[] {
  const prefs = usePreferencesStore.getState()
  const notifications = prefs.prayerNotifications
  const adhan = notifications.adhanSettings
  const quietHours = notifications.quietHours

  const locale = resolveLanguage(prefs.languageMode, prefs.manualLanguage, prefs.detectedLanguage)
  const t = createTranslator(locale)

  const events: NativeReminderEvent[] = []
  const now = Date.now()

  for (const record of records) {
    for (const slotKey of SLOT_KEYS) {
      if (!notifications.perPrayer[slotKey]) continue
      const iso = record[slotKey]
      const instant = new Date(iso)
      if (Number.isNaN(instant.getTime())) continue

      const audioEvent = adhan.mode === 'audio' && slotKey !== 'sunrise'
      const assignedAdhan = audioEvent ? resolveAdhanForSlot(slotKey, adhan) : null
      const fireAt = audioEvent
        ? instant.getTime()
        : instant.getTime() - notifications.leadMinutes * 60_000
      if (fireAt <= now) continue

      events.push({
        id: `${instant.getTime()}-${slotKey}`,
        at: fireAt,
        slot: slotKey,
        slotIso: iso,
        timeZone: record.timeZone ?? null,
        mode: adhan.mode,
        adhanId: assignedAdhan,
        volume: adhan.volume,
        title: t(SLOT_LABEL_KEYS[slotKey] as Parameters<typeof t>[0]),
        bodyPlaying: t('adhan.reminder.playingBody'),
        bodyUnavailable: t('adhan.reminder.unavailableBody'),
        bodyFallback: t('adhan.reminder.fallbackBody'),
        bodySilent: t('adhan.reminder.silentBody'),
        quiet: quietHours.enabled
          ? { enabled: true, start: quietHours.start, end: quietHours.end }
          : null,
      })
    }
  }

  events.sort((a, b) => a.at - b.at)
  return events
}

/* ------------------------------------------------------------------ */
/* Sync orchestration                                                   */
/* ------------------------------------------------------------------ */

let syncTimer: ReturnType<typeof setTimeout> | null = null
let lastSyncKey: string | null = null
let lastSyncAt = 0
const SYNC_DEBOUNCE_MS = 1500
const SYNC_MIN_INTERVAL_MS = 30_000

function currentSyncKey(): string {
  const prefs = usePreferencesStore.getState()
  const notifications = prefs.prayerNotifications
  const context = buildPrayerContext(prefs.prayerSettings, prefs.savedLocations, prefs.activeLocationId)
  const locale = resolveLanguage(prefs.languageMode, prefs.manualLanguage, prefs.detectedLanguage)
  return JSON.stringify({
    location: context ? prayerParamsKeyPart(context.params) : null,
    enabled: notifications.enabled,
    lead: notifications.leadMinutes,
    perPrayer: notifications.perPrayer,
    mode: notifications.adhanSettings.mode,
    useSameForAll: notifications.adhanSettings.useSameForAll,
    sameForAll: notifications.adhanSettings.sameForAllRecordingId,
    perPrayerIds: notifications.adhanSettings.perPrayerRecordingIds,
    volume: notifications.adhanSettings.volume,
    quiet: notifications.quietHours,
    locale,
  })
}

async function runSync(): Promise<void> {
  if (availability !== 'native') return
  const notifications = usePreferencesStore.getState().prayerNotifications

  // Disabled (or no location): cancel the whole native schedule ALWAYS -
  // even on a fresh app start (stale alarms from a previous session must
  // never keep firing; the empty sync is idempotent).
  if (!notifications.enabled) {
    await AdhanScheduler.sync({ version: 1, generatedAt: Date.now(), events: [] }).catch(() => undefined)
    lastSyncKey = currentSyncKey()
    lastSyncAt = Date.now()
    return
  }

  try {
    const records = await getHorizonRecords()
    if (records === null || records.length === 0) {
      // No location configured: nothing to schedule. Keep any old schedule?
      // No - without a location reminders cannot be trusted; cancel honestly.
      await AdhanScheduler.sync({ version: 1, generatedAt: Date.now(), events: [] }).catch(() => undefined)
      return
    }
    const events = buildEvents(records)
    await AdhanScheduler.sync({ version: 1, generatedAt: Date.now(), events })
  } catch (error) {
    // Keep the previously stored native schedule running; log honestly.
    console.warn('[native-reminders] sync failed - previous schedule kept:', error)
  } finally {
    lastSyncKey = currentSyncKey()
    lastSyncAt = Date.now()
  }
}

/**
 * Request a (debounced) resync. Called from the Prayer screen effect (the
 * same place the web scheduler used to sync), from the reminder sheet after
 * changes, and once at app start.
 */
export function requestNativeReminderSync(): void {
  if (availability === 'web') return
  if (syncTimer !== null) clearTimeout(syncTimer)
  syncTimer = setTimeout(() => {
    syncTimer = null
    // Skip when nothing changed and a sync ran recently.
    const key = currentSyncKey()
    if (key === lastSyncKey && Date.now() - lastSyncAt < SYNC_MIN_INTERVAL_MS) return
    void runSync()
  }, SYNC_DEBOUNCE_MS)
}

/** Force an immediate sync (app start / explicit refresh). */
export async function forceNativeReminderSync(): Promise<void> {
  if (availability !== 'native') return
  await runSync()
}

/* ------------------------------------------------------------------ */
/* Status for the UI                                                    */
/* ------------------------------------------------------------------ */

export async function getNativeReminderStatus(): Promise<NativeSchedulerStatus | null> {
  if (availability !== 'native') return null
  try {
    return await AdhanScheduler.status()
  } catch {
    return null
  }
}

export async function requestNativeNotificationPermission(): Promise<'granted' | 'denied' | 'unavailable'> {
  if (availability !== 'native') return 'unavailable'
  try {
    const result = await AdhanScheduler.requestNotificationPermission()
    return result.granted ? 'granted' : 'denied'
  } catch {
    return 'unavailable'
  }
}

/* ------------------------------------------------------------------ */
/* Adhan audio mirroring (web library -> native storage)                */
/* ------------------------------------------------------------------ */

const MIRROR_CHUNK_BYTES = 512 * 1024

function bytesToBase64(bytes: Uint8Array): string {
  let binary = ''
  const CHUNK = 0x8000
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK))
  }
  return btoa(binary)
}

/** Mirror one verified recording into native storage (chunked, verified). */
export async function mirrorAdhanToNative(
  adhanId: string,
  blob: Blob,
  label = '',
): Promise<boolean> {
  if (availability !== 'native') return false
  try {
    const buffer = new Uint8Array(await blob.arrayBuffer())
    await AdhanScheduler.beginFile({ adhanId })
    for (let offset = 0; offset < buffer.length; offset += MIRROR_CHUNK_BYTES) {
      const chunk = buffer.subarray(offset, Math.min(offset + MIRROR_CHUNK_BYTES, buffer.length))
      await AdhanScheduler.writeFileChunk({ adhanId, offset, base64: bytesToBase64(chunk) })
    }
    const result = await AdhanScheduler.finalizeFile({
      adhanId,
      sizeBytes: buffer.length,
      label: label || adhanId,
    })
    return result.ok
  } catch (error) {
    console.warn('[native-reminders] mirror failed (native falls back to the plain channel):', error)
    return false
  }
}

/** Remove the native mirror when the user deletes a recording. */
export async function removeNativeAdhanMirror(adhanId: string): Promise<void> {
  if (availability !== 'native') return
  try {
    await AdhanScheduler.deleteFile({ adhanId })
  } catch {
    // Non-fatal: the orphan file is cleaned up by the next reconciliation.
  }
}

/** Ensure every VERIFIED web-library recording has a native mirror. */
export async function reconcileNativeAdhans(): Promise<void> {
  if (availability !== 'native') return
  try {
    const library = getAdhanLibrary()
    const entries = await library.listEntries()
    const stored = await AdhanScheduler.listFiles()
    const byNativeId = new Map(stored.files.map((file) => [file.adhanId, file.sizeBytes]))

    for (const entry of entries) {
      if (entry.verification !== 'verified') continue
      const blob = await library.getBlob(entry.id).catch(() => null)
      if (blob === null) continue
      const nativeSize = byNativeId.get(entry.id)
      if (nativeSize === blob.size) continue
      // Missing or size-mismatched mirror: rewrite it from the verified copy.
      await mirrorAdhanToNative(entry.id, blob, entry.muezzinEn || entry.title)
    }
  } catch (error) {
    console.warn('[native-reminders] reconciliation failed:', error)
  }
}

/* ------------------------------------------------------------------ */
/* Foreground fire handling                                             */
/* ------------------------------------------------------------------ */

async function handleForegroundFire(event: NativeReminderEvent): Promise<void> {
  const outcome = await fireAdhanReminder({
    slotKey: event.slot,
    mode: event.mode,
    adhanId: event.adhanId,
    volume: event.volume,
    timeZone: event.timeZone,
    quietHours: event.quiet,
    messages: {
      playingBody: event.bodyPlaying,
      unavailableBody: event.bodyUnavailable,
      fallbackBody: event.bodyFallback,
      silentBody: event.bodySilent,
    },
  })

  if (outcome === 'quiet') return

  const body = bodyForOutcome(outcome, {
    playingBody: event.bodyPlaying,
    unavailableBody: event.bodyUnavailable,
    fallbackBody: event.bodyFallback,
    silentBody: event.bodySilent,
  })

  useAdhanFireStore.getState().show({
    title: event.title,
    body,
    state: outcome,
    firedAt: Date.now(),
  })
}

/* ------------------------------------------------------------------ */
/* Initialization                                                       */
/* ------------------------------------------------------------------ */

let initialized = false

/**
 * One-time bridge init. Called from Providers after mount:
 * - resolves availability,
 * - subscribes to the foreground-fire event,
 * - reconciles audio mirrors,
 * - runs the first sync (also standing down the web scheduler when native
 *   takes over, so no path double-fires).
 */
export async function initNativeReminders(): Promise<void> {
  if (initialized) return
  initialized = true

  const mode = await resolveNativeAvailability()
  if (mode !== 'native') return

  // Foreground fire events from the native scheduler.
  await AdhanScheduler.addListener('foregroundFire', (payload) => {
    const event = (payload as { event?: NativeReminderEvent }).event
    if (event) void handleForegroundFire(event)
  })

  // Stand down the web scheduler the moment native scheduling is active -
  // both paths must never double-fire.
  const { prayerNotificationScheduler } = await import(
    '@/services/notifications/prayer-notification-service'
  )
  prayerNotificationScheduler.stop()

  await reconcileNativeAdhans()
  await forceNativeReminderSync()
}
