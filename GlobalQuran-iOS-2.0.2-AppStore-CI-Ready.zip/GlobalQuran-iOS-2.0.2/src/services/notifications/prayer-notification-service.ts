'use client'

/**
 * Global Quran - Prayer notification architecture (PROMPT 13 upgrade).
 *
 * Honesty rules implemented here:
 * - Notification permission is requested ONLY in response to an explicit
 *   user action (the enable toggle in the reminder sheet calls
 *   `requestNotificationPermission`).
 * - Reminders fire while the app is open in the browser - this is stated
 *   plainly in the UI. Background/native delivery is NOT claimed.
 * - Quiet hours are evaluated at fire time in the location's local time.
 *
 * PROMPT 13 additions:
 * - 'audio' reminder mode: at the EXACT prayer time, the assigned VERIFIED
 *   local Adhan recording plays through the single Adhan player at the
 *   user's volume (never streamed, never another muezzin substituted).
 *   When the assigned recording is not stored/verified, the fallback is
 *   honest: a plain notification whose body says so - no fake playback, no
 *   silent switch to a different muezzin.
 * - 'silent' mode: the plain notification, `leadMinutes` early (the
 *   previous behavior).
 * - Sunrise never plays Adhan (it is not a prayer).
 * - Duplicate prevention: every scheduled prayer event fires at most once
 *   per app session, no matter how often the schedule is re-synced while
 *   the timer is pending.
 */

import type { AdhanReminderSettings, PrayerNotificationPreferences, PrayerTimeRecord } from '@/types'
import { prayerSlots, type PrayerSlotKey } from '@/hooks/use-prayer-data'
import { fireAdhanReminder, bodyForOutcome, type AdhanFireMessages } from '@/services/notifications/adhan-fire'

export type NotificationPermissionState = 'unsupported' | 'default' | 'granted' | 'denied'

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window
}

export function currentNotificationPermission(): NotificationPermissionState {
  if (!isNotificationSupported()) return 'unsupported'
  return Notification.permission as NotificationPermissionState
}

/**
 * Request permission - ONLY ever call this from an explicit user action.
 * Returns the resulting permission state.
 */
export async function requestNotificationPermission(): Promise<NotificationPermissionState> {
  if (!isNotificationSupported()) return 'unsupported'
  try {
    const result = await Notification.requestPermission()
    return result as NotificationPermissionState
  } catch {
    return currentNotificationPermission()
  }
}

/**
 * Resolve the recording assigned to one prayer slot under the user's
 * adhan settings (null = no assignment). Pure - used by the scheduler and
 * the reminder sheet. Sunrise never carries an Adhan.
 */
export function resolveAdhanForSlot(
  slotKey: PrayerSlotKey,
  settings: AdhanReminderSettings,
): string | null {
  if (slotKey === 'sunrise') return null
  if (settings.useSameForAll) return settings.sameForAllRecordingId
  const perPrayer = settings.perPrayerRecordingIds
  if (slotKey === 'fajr') return perPrayer.fajr
  if (slotKey === 'dhuhr') return perPrayer.dhuhr
  if (slotKey === 'asr') return perPrayer.asr
  if (slotKey === 'maghrib') return perPrayer.maghrib
  if (slotKey === 'isha') return perPrayer.isha
  return null
}

interface ScheduledReminder {
  at: number
  slotKey: PrayerSlotKey
  /** The exact slot this reminder belongs to (own snapshot - no re-lookup). */
  slotIso: string
  timeZone: string | null
  /** The recording assigned to this slot (audio mode), null in silent mode. */
  adhanId: string | null
  /** Snapshot of the preference fields needed at fire time. */
  adhan: AdhanReminderSettings
  quietHours: PrayerNotificationPreferences['quietHours']
  fire: () => void
}

/**
 * Foreground scheduler: one outstanding timer at a time, rescheduled
 * whenever the prayer data or preferences change. Timeouts are capped at
 * ~24h to stay robust across sleep/wake cycles.
 */
class PrayerNotificationScheduler {
  private timer = 0
  private pending: ScheduledReminder | null = null
  /**
   * Duplicate prevention: every prayer event fires AT MOST ONCE per app
   * session, keyed by the slot's exact instant. A re-sync while the timer
   * is pending (data refresh, preference change, day rollover) can never
   * cause a second notification for the same event.
   */
  private fired = new Set<string>()
  private labels: Record<PrayerSlotKey, string> = {
    fajr: 'Fajr',
    sunrise: 'Sunrise',
    dhuhr: 'Dhuhr',
    asr: 'Asr',
    maghrib: 'Maghrib',
    isha: 'Isha',
  }
  private adhanMessages: AdhanFireMessages = {
    playingBody: 'Adhan',
    unavailableBody: 'Adhan time - no Adhan recording is selected yet.',
    fallbackBody: 'Adhan time - the selected recording is not stored on this device.',
    silentBody: 'Prayer time reminder.',
  }

  /** Provide localized prayer names for notification titles. */
  setLabels(labels: Partial<Record<PrayerSlotKey, string>>): void {
    this.labels = { ...this.labels, ...labels }
  }

  /** Provide localized Adhan status texts for notification bodies. */
  setAdhanMessages(messages: Partial<typeof this.adhanMessages>): void {
    this.adhanMessages = { ...this.adhanMessages, ...messages }
  }

  /**
   * Recompute the schedule from the given records. Records are expected to
   * include today (and tomorrow when known); duplicates are fine.
   */
  sync(
    records: PrayerTimeRecord[],
    preferences: PrayerNotificationPreferences,
  ): void {
    this.stop()

    if (!preferences.enabled || !isNotificationSupported() || Notification.permission !== 'granted') {
      return
    }

    const now = Date.now()
    const adhan = preferences.adhanSettings
    const candidates: Array<{
      at: number
      slotKey: PrayerSlotKey
      slotIso: string
      timeZone: string | null
      adhanId: string | null
    }> = []

    for (const record of records) {
      for (const slot of prayerSlots(record)) {
        if (!preferences.perPrayer[slot.key]) continue

        const audioEvent = adhan.mode === 'audio' && slot.key !== 'sunrise'
        const assignedAdhan = audioEvent ? resolveAdhanForSlot(slot.key, adhan) : null

        // Audio mode: the event fires at the EXACT prayer time (the Adhan is
        // the call - it is never early). Silent mode: lead minutes earlier.
        const fireAt = audioEvent
          ? slot.instant.getTime()
          : slot.instant.getTime() - preferences.leadMinutes * 60_000

        if (fireAt <= now) continue
        // Each prayer event fires only once per session.
        if (this.fired.has(slot.iso)) continue

        candidates.push({
          at: fireAt,
          slotKey: slot.key,
          slotIso: slot.iso,
          timeZone: record.timeZone ?? null,
          adhanId: assignedAdhan,
        })
      }
    }

    if (candidates.length === 0) return
    candidates.sort((a, b) => a.at - b.at)

    const next = candidates[0]
    const delay = Math.min(next.at - now, 24 * 60 * 60 * 1000)

    const pendingReminder: ScheduledReminder = {
      ...next,
      adhan,
      quietHours: preferences.quietHours,
      fire: () => {
        this.fired.add(pendingReminder.slotIso)
        if (this.fired.size > 64) {
          // Keep the set small; only recent events matter for dedupe.
          const keep = [...this.fired].slice(-32)
          this.fired = new Set(keep)
        }
        this.fireNow(pendingReminder)
      },
    }
    this.pending = pendingReminder

    this.timer = window.setTimeout(() => {
      const pending = this.pending
      this.pending = null
      this.timer = 0
      pending?.fire()
      // Re-sync: the same records produce the next candidate.
      this.sync(records, preferences)
    }, delay)
  }

  private fireNow(reminder: ScheduledReminder): void {
    // Shared honest-fallback behavior (adhan-fire.ts) - the SAME logic the
    // native Android foreground path uses, so the two delivery paths can
    // never diverge (PROMPT 16).
    void (async () => {
      const outcome = await fireAdhanReminder({
        slotKey: reminder.slotKey,
        mode: reminder.adhan.mode,
        adhanId: reminder.adhanId,
        volume: reminder.adhan.volume,
        timeZone: reminder.timeZone,
        quietHours: reminder.quietHours,
        messages: this.adhanMessages,
      })
      if (outcome === 'quiet') return
      const title = this.labels[reminder.slotKey]
      this.emitNotification(title, bodyForOutcome(outcome, this.adhanMessages))
    })()
  }

  private emitNotification(title: string, body: string): void {
    if (isNotificationSupported() && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          tag: `prayer-${title}`,
        })
      } catch {
        // Some platforms restrict constructor use - never crash on it.
      }
    }
  }

  stop(): void {
    if (this.timer !== 0) {
      window.clearTimeout(this.timer)
      this.timer = 0
    }
    this.pending = null
  }
}

/** Module singleton - the app runs one scheduler. */
export const prayerNotificationScheduler = new PrayerNotificationScheduler()
