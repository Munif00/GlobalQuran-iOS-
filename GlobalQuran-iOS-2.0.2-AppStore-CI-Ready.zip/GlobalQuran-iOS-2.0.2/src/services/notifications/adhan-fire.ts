/**
 * Global Quran - shared Adhan fire logic (PROMPT 16).
 *
 * The single honest-fallback behavior for firing a prayer reminder, used by
 * BOTH delivery paths so they can never diverge:
 *  1. the web foreground scheduler (prayer-notification-service.ts), and
 *  2. the native Android foreground-fire event (native-reminders.ts).
 *
 * Behavior (identical to the shipped PROMPT 13 semantics, now shared):
 * - Quiet hours are evaluated at FIRE time in the location's zone; a muted
 *   event is skipped entirely (outcome 'quiet').
 * - Audio mode with an assigned recording: play the VERIFIED local file at
 *   the user's volume. Never streamed, never another muezzin substituted.
 *   When the assigned recording is not stored/verified the outcome is
 *   'not-stored' - the caller renders the honest fallback text.
 * - Audio mode with no recording selected (or sunrise, which never carries
 *   an Adhan): outcome 'not-selected'.
 * - Silent mode: outcome 'silent' (plain notification text).
 */

import type { PrayerSlotKey } from '@/hooks/use-prayer-data'

export interface AdhanFireMessages {
  playingBody: string
  unavailableBody: string
  fallbackBody: string
  silentBody: string
}

export interface AdhanFireInput {
  slotKey: PrayerSlotKey
  mode: 'audio' | 'silent'
  /** Assigned recording id (audio mode); null = none. */
  adhanId: string | null
  volume: number
  timeZone: string | null
  quietHours: { enabled: boolean; start: string; end: string } | null
  messages: AdhanFireMessages
}

export type AdhanFireOutcome = 'played' | 'not-stored' | 'not-selected' | 'quiet' | 'silent'

/** Body text for an outcome - the honest sentence the user sees. */
export function bodyForOutcome(
  outcome: AdhanFireOutcome,
  messages: AdhanFireMessages,
): string {
  switch (outcome) {
    case 'played':
      return messages.playingBody
    case 'not-stored':
      return messages.fallbackBody
    case 'not-selected':
      return messages.unavailableBody
    case 'quiet':
      return messages.silentBody
    case 'silent':
      return messages.silentBody
  }
}

export async function fireAdhanReminder(input: AdhanFireInput): Promise<AdhanFireOutcome> {
  // Quiet hours at fire time, in the location's local time. The Adhan
  // respects quiet hours too: a muted event is skipped entirely.
  if (input.quietHours?.enabled && input.timeZone) {
    if (isWithinQuietHoursWindow(new Date(), input.timeZone, input.quietHours)) {
      return 'quiet'
    }
  }

  if (input.mode === 'audio' && input.slotKey !== 'sunrise' && input.adhanId !== null) {
    // Audio mode with an assigned recording: play the VERIFIED local file.
    // Never streamed, never substituted. Honest failure when not stored.
    //
    // iOS first (platform-gated): the native mirror is played by the
    // native plugin with REAL per-stream volume — WKWebView cannot
    // control HTMLAudioElement volume. Any other platform, a missing
    // mirror, or a plugin failure falls through to the shared web player
    // (Android's shipped 2.0.2 behavior, byte-for-byte unchanged).
    try {
      const { nativePlayAdhanMirror } = await import('@/services/native/adhan-native-playback')
      if (await nativePlayAdhanMirror(input.adhanId, input.volume)) {
        return 'played'
      }
    } catch {
      /* fall through to the shared web player - never a hard failure. */
    }
    try {
      const { adhanPlayer } = await import('@/services/audio/adhan-player')
      const played = await adhanPlayer.playFromLibrary(input.adhanId, input.volume)
      return played ? 'played' : 'not-stored'
    } catch {
      return 'not-stored'
    }
  }

  if (input.mode === 'audio' && input.slotKey !== 'sunrise') {
    // Audio mode but no recording selected yet.
    return 'not-selected'
  }

  return 'silent'
}

/** Wall clock HH:mm inside a zone (never throws; '00:00' on failure). */
export function wallClockInZoneText(instant: Date, timeZone: string): string {
  try {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).formatToParts(instant)
    const hour = parts.find((part) => part.type === 'hour')?.value ?? '00'
    const minute = parts.find((part) => part.type === 'minute')?.value ?? '00'
    return `${hour}:${minute}`
  } catch {
    return '00:00'
  }
}

/** Quiet-hours check with wall-clock strings (supports overnight windows).
 * Fail-open: an unknown zone or malformed window NEVER mutes a reminder
 * (muting requires verified data - never a fallback guess). */
export function isWithinQuietHoursWindow(
  instant: Date,
  timeZone: string,
  window: { enabled: boolean; start: string; end: string },
): boolean {
  if (!window.enabled) return false
  if (!isValidZone(timeZone)) return false
  const wallClock = wallClockInZoneText(instant, timeZone)
  const toMinutes = (value: string): number => {
    const match = /^(\d{1,2}):(\d{2})$/.exec(value)
    if (!match) return -1
    return Number(match[1]) * 60 + Number(match[2])
  }
  const now = toMinutes(wallClock)
  const from = toMinutes(window.start)
  const to = toMinutes(window.end)
  if (now < 0 || from < 0 || to < 0) return false
  if (from === to) return false
  if (from < to) return now >= from && now < to
  return now >= from || now < to
}

/** Zone validation (never throws). */
function isValidZone(timeZone: string): boolean {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone })
    return true
  } catch {
    return false
  }
}
