'use client'

/**
 * Global Quran - Adhan playback engine (PROMPT 13).
 *
 * One single audio element for ALL Adhan playback in the application:
 * preview playback in the muezzin library AND the scheduled prayer-time
 * Adhan. This guarantees by construction that:
 *
 * - two Adhan recordings can never overlap (starting a different recording
 *   stops the previous one completely),
 * - the Adhan coordinates with the existing Quran audio manager through the
 *   app-wide session coordinator: claiming the 'adhan' stage suspends every
 *   other active audio channel (recitation and translation narration pause,
 *   position kept) - and conversely, another channel claiming the stage
 *   suspends the Adhan preview.
 *
 * Playback ALWAYS uses a local verified blob from the Adhan library - the
 * Adhan is never streamed from a website and never requested from an API at
 * fire time.
 */

import { claimAudioChannel, releaseAudioChannel } from '@/services/audio/session-coordinator'
import { setWebAudioSessionActive } from '@/services/native/audio-session-bridge'
import { getAdhanLibrary } from '@/services/storage/adhan-library'
import { getStoredAdhanBlob } from '@/services/downloads/adhan-download-manager'

export type AdhanPlayerState = 'idle' | 'playing' | 'paused'

export interface AdhanPlaybackMeta {
  /** The adhan recording id being played. */
  adhanId: string
  muezzinEn: string
  muezzinAr: string
  volume: number
}

interface AdhanPlayerListeners {
  onStateChange?: (state: AdhanPlayerState, meta: AdhanPlaybackMeta | null) => void
  onTime?: (positionSeconds: number, durationSeconds: number, meta: AdhanPlaybackMeta) => void
  onEnded?: (meta: AdhanPlaybackMeta) => void
  onError?: (adhanId: string) => void
}

const ADHAN_CHANNEL = 'adhan'

class AdhanPlayer {
  private element: HTMLAudioElement | null = null
  private objectUrl: string | null = null
  private release: (() => void) | null = null
  private meta: AdhanPlaybackMeta | null = null
  /** Multiple subscribers coexist (library list, reminder sheet, ...). */
  private listeners: AdhanPlayerListeners[] = []
  private timeTimer = 0

  private ensureElement(): HTMLAudioElement {
    if (this.element) return this.element
    const audio = new Audio()
    audio.preload = 'auto'
    audio.addEventListener('ended', () => this.handleEnded())
    audio.addEventListener('pause', () => {
      if (this.meta) this.notifyState('paused')
    })
    audio.addEventListener('play', () => {
      if (this.meta) this.notifyState('playing')
    })
    audio.addEventListener('error', () => {
      if (this.meta) {
        for (const listener of this.listeners) {
          listener.onError?.(this.meta!.adhanId)
        }
        this.stop()
      }
    })
    this.element = audio
    return audio
  }

  private notifyState(state: AdhanPlayerState) {
    for (const listener of this.listeners) {
      listener.onStateChange?.(state, this.meta)
    }
  }

  private notifyTime() {
    if (!this.element || !this.meta) return
    const duration = Number.isFinite(this.element.duration) ? this.element.duration : 0
    for (const listener of this.listeners) {
      listener.onTime?.(this.element.currentTime, duration, this.meta)
    }
  }

  private handleEnded() {
    const endedMeta = this.meta
    this.releaseChannel()
    if (this.objectUrl) {
      URL.revokeObjectURL(this.objectUrl)
      this.objectUrl = null
    }
    this.meta = null
    if (this.element) {
      this.element.removeAttribute('src')
      this.element.load()
    }
    this.stopTimeTimer()
    this.notifyState('idle')
    if (endedMeta) {
      for (const listener of this.listeners) {
        listener.onEnded?.(endedMeta)
      }
    }
  }

  private startTimeTimer() {
    this.stopTimeTimer()
    this.timeTimer = window.setInterval(() => this.notifyTime(), 250)
  }

  private stopTimeTimer() {
    if (this.timeTimer !== 0) {
      window.clearInterval(this.timeTimer)
      this.timeTimer = 0
    }
  }

  private releaseChannel() {
    if (this.release) {
      this.release()
      this.release = null
    }
  }

  /**
   * Subscribe to player events. Multiple subscribers coexist (the muezzin
   * list, the reminder sheet, the scheduler diagnostics). Returns an
   * unsubscribe function.
   */
  addListener(listener: AdhanPlayerListeners): () => void {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((item) => item !== listener)
    }
  }

  /** The current state + what is playing (for UI rendering). */
  current(): { state: AdhanPlayerState; meta: AdhanPlaybackMeta | null } {
    const state: AdhanPlayerState = this.element
      ? this.element.paused
        ? this.meta
          ? 'paused'
          : 'idle'
        : 'playing'
      : 'idle'
    return { state: this.meta ? state : 'idle', meta: this.meta }
  }

  /**
   * Play one recording from its verified local blob. Starting a different
   * recording stops the previous one completely first (no overlap).
   */
  async playBlob(blob: Blob, meta: Omit<AdhanPlaybackMeta, 'volume'>, volume: number): Promise<boolean> {
    // Stop whatever is currently playing (fully - never overlap).
    this.stopInternal()

    const audio = this.ensureElement()
    if (this.objectUrl) {
      URL.revokeObjectURL(this.objectUrl)
      this.objectUrl = null
    }
    this.objectUrl = URL.createObjectURL(blob)
    audio.src = this.objectUrl
    audio.volume = Math.min(1, Math.max(0, volume))

    this.meta = { ...meta, volume }
    this.releaseChannel()
    /* iOS: the web-fallback Adhan must be audible with the Ring/Silent
     * switch in silent (the same intent as Android's ALARM stream).
     * The primary iOS path is the native player (real volume control);
     * this covers the honest web fallback. No-op on Android/web. */
    void setWebAudioSessionActive(true)
    this.release = claimAudioChannel(ADHAN_CHANNEL, () => {
      // Another audio source claimed the stage: pause the Adhan, keep position.
      if (this.element && !this.element.paused) {
        this.element.pause()
        this.notifyState('paused')
      }
    })

    try {
      await audio.play()
      this.startTimeTimer()
      this.notifyState('playing')
      return true
    } catch {
      // Autoplay restrictions or decode failure - honest failure, clean up.
      this.stopInternal()
      for (const listener of this.listeners) {
        listener.onError?.(meta.adhanId)
      }
      return false
    }
  }

  /**
   * Play one recording by id, resolved from the VERIFIED local library.
   * Returns false when the recording is not stored/verified - the caller
   * decides the honest fallback. Never streams, never substitutes.
   */
  async playFromLibrary(adhanId: string, volume: number): Promise<boolean> {
    const blob = await getStoredAdhanBlob(adhanId)
    if (blob === null) return false
    const meta = { adhanId, muezzinEn: '', muezzinAr: '' }
    try {
      const record = await getAdhanLibrary().getEntry(adhanId)
      if (record) {
        meta.muezzinEn = record.muezzinEn
        meta.muezzinAr = record.muezzinAr
      }
    } catch {
      // Labels are cosmetic; playback itself proceeds.
    }
    return this.playBlob(blob, meta, volume)
  }

  pause(): void {
    if (this.element && this.meta && !this.element.paused) {
      this.element.pause()
    }
  }

  resume(): void {
    if (this.element && this.meta && this.element.paused) {
      void this.element.play().catch(() => undefined)
    }
  }

  /** Fully stop the current playback and release the audio stage. */
  stop(): void {
    this.stopInternal()
    this.notifyState('idle')
  }

  private stopInternal(): void {
    this.stopTimeTimer()
    if (this.element) {
      try {
        this.element.pause()
      } catch {
        /* already stopped */
      }
      if (this.meta) {
        this.element.removeAttribute('src')
        this.element.load()
      }
    }
    if (this.objectUrl) {
      URL.revokeObjectURL(this.objectUrl)
      this.objectUrl = null
    }
    if (this.release) {
      /* iOS: stopped Adhan playback releases the audio session. */
      void setWebAudioSessionActive(false)
    }
    this.releaseChannel()
    this.meta = null
  }

  /** Set volume on the live element (where the platform allows it). */
  setVolume(volume: number): void {
    if (this.element && this.meta) {
      this.element.volume = Math.min(1, Math.max(0, volume))
      this.meta = { ...this.meta, volume }
    }
  }
}

/** Module singleton - the app runs ONE Adhan player. */
export const adhanPlayer = new AdhanPlayer()
