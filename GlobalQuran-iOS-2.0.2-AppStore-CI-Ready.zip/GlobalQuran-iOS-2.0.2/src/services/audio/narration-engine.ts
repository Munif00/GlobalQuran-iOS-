'use client'

/**
 * Translation narration engine (client singleton, PROMPT 10).
 *
 * Produces the NARRATION of the selected Quran translation - a completely
 * separate audio concern from Arabic recitation:
 *
 * - a dedicated HTMLAudioElement plays HUMAN-RECORDED QuranEnc translation
 *   audio (never recitation, never TTS),
 * - a DEVICE VOICE speaks the translation text when no exact recording
 *   exists (never Arabic text - Arabic content is never synthesized, so
 *   TTS can never be mistaken for Quran recitation). The speech backend
 *   is chosen per platform:
 *   - inside the Android app (Capacitor): the NATIVE TtsBridge
 *     (android.speech.tts.TextToSpeech) - the WebView's Web Speech API
 *     cannot reach the system engines there (empty voice list, silent
 *     speak), so before the bridge it could only report unavailable;
 *   - in browsers: the Web Speech API, exactly as before,
 * - the engine claims the 'narration' channel of the session coordinator:
 *   starting narration pauses any active recitation and vice versa - the
 *   two can never be audible at the same time.
 *
 * Playback priority (mandated):
 * 1. the EXACT human-recorded narration of the SELECTED translation, when
 *    the verified catalog lists it and the verified inventory has the ayah
 *    (a recording of a DIFFERENT translation is never substituted);
 * 2. a device TTS voice matching the translation's language, speaking the
 *    translation's own text;
 * 3. an honest explanation that narration is unavailable for the language.
 *
 * Honesty rules:
 * - a verified local (downloaded) file is ALWAYS played directly from
 *   device storage - the network is never contacted for it;
 * - ayat without a verified recording file produce an honest 'file-missing'
 *   report and are never streamed by guesswork;
 * - TTS voices are offered only after they were actually detected (the
 *   web speechSynthesis.getVoices() list loads asynchronously; the native
 *   bridge answers with the engine's real voice list); a missing voice is
 *   reported honestly, never assumed;
 * - the MODE (recording vs device voice) and the speech BACKEND (native
 *   bridge vs Web Speech) are always pushed to the store so the UI can
 *   label every second of narration truthfully.
 *
 * Session model (simpler than the recitation engine):
 * - SINGLE mode: narrate the selected ayah, stop at its end.
 * - SEQUENTIAL mode: advance automatically through the sura in order,
 *   stopping at the end of the sura (bounded - never endless on one ayah).
 * - REPEAT: repeat the current ayah's narration 2..10 times or endlessly.
 * - Manual prev/next start a NEW session at the target ayah.
 */

import { getTranslationSuraAudio } from '@/services/api/audio-api'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { claimAudioChannel, releaseAudioChannel } from '@/services/audio/session-coordinator'
import { setWebAudioSessionActive } from '@/services/native/audio-session-bridge'
import { isRealNativePlatform } from '@/services/platform/native-mode'
import {
  addTtsUtteranceListener,
  isTtsBridgeAvailable,
  ttsGetVoices,
  ttsIsLanguageAvailable,
  ttsSpeak,
  ttsStop,
  TtsBridgeError,
  type TtsVoiceDescriptor,
} from '@/services/native/tts-bridge'
import { getTranslationAudioLibrary } from '@/services/storage/translation-audio-library'
import {
  useNarrationStore,
  type NarrationErrorKind,
  type NarrationSessionInfo,
} from '@/stores/narration-store'
import type { NarrationMode, TranslationSuraAudioResponse } from '@/types'

type NarrationSyncState = ReturnType<typeof useNarrationStore.getState>

const inventoryCache = new Map<string, TranslationSuraAudioResponse>()

/** Gap inserted between repetitions (recordings only; TTS re-speaks). */
const REPEAT_GAP_MS = 550
/** How long to wait for the async voice list before giving up. */
const VOICES_TIMEOUT_MS = 3000

function cacheKey(translationKey: string, sura: number): string {
  return `${translationKey}:${sura}`
}

async function loadInventory(
  translationKey: string,
  sura: number,
): Promise<TranslationSuraAudioResponse | null> {
  const key = cacheKey(translationKey, sura)
  const cached = inventoryCache.get(key)
  if (cached) return cached
  try {
    const response = await getTranslationSuraAudio(translationKey, sura)
    inventoryCache.set(key, response)
    return response
  } catch {
    return null
  }
}

/** Primary subtag of a BCP-47 language tag ('pt-BR' -> 'pt'). */
function primarySubtag(tag: string): string {
  return tag.trim().toLowerCase().split(/[-_]/)[0] ?? ''
}

/**
 * Aliases: some platforms label the same language differently. Tagalog
 * voices are exposed as 'tl' and 'fil' (Filipino); both match.
 */
const LANGUAGE_ALIASES: Record<string, string[]> = {
  tl: ['tl', 'fil'],
  fil: ['fil', 'tl'],
  nb: ['nb', 'no'],
  nn: ['nn', 'no'],
  in: ['in', 'id'],
  iw: ['iw', 'he'],
}

function languageMatches(voiceLang: string, translationIso: string): boolean {
  const voicePrimary = primarySubtag(voiceLang)
  const wanted = primarySubtag(translationIso)
  if (voicePrimary === wanted && wanted !== '') return true
  const aliases = LANGUAGE_ALIASES[wanted] ?? [wanted]
  return aliases.includes(voicePrimary)
}

/**
 * A device voice as the engine (and the voice picker) sees it, unified
 * across the two speech backends:
 * - id: the stable choice key persisted per language (the web voiceURI,
 *   the Android voice name on native),
 * - name/lang for display,
 * - localService: the web offline-capable hint (native voices carry no
 *   such flag - false, never a guess),
 * - webVoice: the original SpeechSynthesisVoice (web backend only).
 */
export interface NarrationVoice {
  id: string
  name: string
  lang: string
  localService: boolean
  webVoice?: SpeechSynthesisVoice
}

/** Map a native bridge voice descriptor to the unified voice shape. */
function toNarrationVoice(descriptor: TtsVoiceDescriptor): NarrationVoice {
  return {
    id: descriptor.id,
    name: descriptor.name,
    lang: descriptor.locale,
    // The native contract has no offline hint - never claimed.
    localService: false,
  }
}

/** Map a native bridge speak failure to its honest engine error kind. */
function nativeTtsErrorKind(error: unknown): NarrationErrorKind {
  if (error instanceof TtsBridgeError) {
    switch (error.code) {
      case 'engine-unavailable':
        return 'tts-engine-missing'
      case 'voice-missing':
        return 'tts-voice-missing'
      case 'missing-data':
        return 'tts-voice-data'
      default:
        return 'tts-synthesis-failed'
    }
  }
  return 'tts-synthesis-failed'
}

/* ------------------------------------------------------------------ */
/* Web Speech helpers                                                  */
/* ------------------------------------------------------------------ */

interface SpeechBridge {
  getVoices(): SpeechSynthesisVoice[]
  speak(utterance: SpeechSynthesisUtterance): void
  pause(): void
  resume(): void
  cancel(): void
  paused(): boolean
  speaking(): boolean
}

function getSpeechBridge(): SpeechBridge | null {
  if (typeof window === 'undefined') return null
  const synth = window.speechSynthesis
  if (!synth || typeof SpeechSynthesisUtterance === 'undefined') return null
  return {
    getVoices: () => synth.getVoices(),
    speak: (utterance) => synth.speak(utterance),
    pause: () => synth.pause(),
    resume: () => synth.resume(),
    cancel: () => synth.cancel(),
    paused: () => synth.paused,
    speaking: () => synth.speaking,
  }
}

/** Wait (bounded) until the voice list is populated (it loads async). */
function waitForVoices(bridge: SpeechBridge): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    const immediate = bridge.getVoices()
    if (immediate.length > 0) {
      resolve(immediate)
      return
    }
    let settled = false
    const finish = () => {
      if (settled) return
      settled = true
      window.speechSynthesis.onvoiceschanged = null
      resolve(bridge.getVoices())
    }
    window.speechSynthesis.onvoiceschanged = finish
    setTimeout(finish, VOICES_TIMEOUT_MS)
  })
}

/* ------------------------------------------------------------------ */
/* Engine                                                              */
/* ------------------------------------------------------------------ */

class NarrationEngine {
  private audio: HTMLAudioElement | null = null
  /** (translationKey, sura, ayah) currently loaded - guards stale events. */
  private loadedRef: { translationKey: string; sura: number; ayah: number } | null = null
  private session: NarrationSessionInfo | null = null
  private advanceTimer: ReturnType<typeof setTimeout> | null = null
  private channelRelease: (() => void) | null = null
  private localObjectUrl: string | null = null

  /** Current TTS utterance token (stale-end protection). */
  private utteranceToken = 0
  private unsubscribeStore: (() => void) | null = null

  /** The utteranceId of the NATIVE speech session this engine expects
   *  events for (null = none/stale; mirrors the web token guard). */
  private nativeUtteranceId: string | null = null
  /** Whether the native utterance event listener is registered (once). */
  private nativeListenerRegistered = false

  /**
   * The text source for TTS: the reader registers the currently displayed
   * ayat (of the selected translation). The engine speaks ONLY text that
   * came from this source - never guessed or fetched on its own - and only
   * while the registered translation matches the narrated one (a switch of
   * translation invalidates the previous text).
   */
  private textSource: Map<
    number,
    { translationKey: string; ayat: Array<{ ayah: number; translation: string }> }
  > = new Map()

  /** Lazily create the audio element and store wiring (client only). */
  private ensureAudio(): HTMLAudioElement | null {
    if (typeof window === 'undefined') return null
    if (this.audio) return this.audio

    // NO crossOrigin attribute: plain cross-origin media playback does not
    // require CORS, and the QuranEnc MP3 responses carry no CORS headers.
    const audio = new Audio()
    audio.preload = 'auto'
    this.audio = audio

    audio.addEventListener('playing', () =>
      this.sync({ isPlaying: true, isBuffering: false, isSpeaking: false }),
    )
    audio.addEventListener('pause', () => this.sync({ isPlaying: false, isSpeaking: false }))
    audio.addEventListener('waiting', () => this.sync({ isBuffering: true }))
    audio.addEventListener('timeupdate', () => {
      if (Number.isFinite(audio.currentTime)) this.sync({ currentTime: audio.currentTime })
    })
    audio.addEventListener('durationchange', () => {
      if (Number.isFinite(audio.duration)) this.sync({ duration: audio.duration })
    })
    audio.addEventListener('ended', () => this.handleEnded())
    audio.addEventListener('error', () => this.handleError())

    // Apply persisted speed on creation.
    audio.playbackRate = useNarrationStore.getState().speed

    // React to settings changes while narration is live.
    let lastSettings = this.readSettingsSnapshot()
    this.unsubscribeStore = useNarrationStore.subscribe(() => {
      const snapshot = this.readSettingsSnapshot()
      if (snapshot !== lastSettings) {
        lastSettings = snapshot
        this.recomputeSession()
      }
    })

    // PLATFORM RULE (native app): Android's speech engine would happily
    // keep talking in the background; this app never does background TTS.
    // The moment the app becomes hidden, native narration stops (the
    // session and position survive - the user resumes by replaying).
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState !== 'hidden') return
      const state = useNarrationStore.getState()
      if (state.mode === 'tts' && state.ttsBackend === 'native') {
        this.cancelSpeech()
        this.sync({ isPlaying: false, isSpeaking: false })
      }
    })

    return audio
  }

  private readSettingsSnapshot(): string {
    const { speed, advanceMode, repeatEnabled, repeatCount } = useNarrationStore.getState()
    return `${speed}|${advanceMode}|${String(repeatEnabled)}|${String(repeatCount)}`
  }

  /** Serializable snapshot sync (typed). */
  private sync(
    patch: Partial<
      Pick<
        NarrationSyncState,
        | 'narrationTranslationKey'
        | 'mode'
        | 'narratingSura'
        | 'narratingAyah'
        | 'isPlaying'
        | 'isBuffering'
        | 'isSpeaking'
        | 'error'
        | 'currentTime'
        | 'duration'
        | 'session'
        | 'sourceMode'
        | 'activeVoiceName'
        | 'ttsEngineAvailable'
        | 'ttsBackend'
        | 'languageIso'
        | 'languageName'
      >
    >,
  ): void {
    useNarrationStore.getState().syncEngineState(patch)
  }

  private pushSession(): void {
    this.sync({ session: this.session ? { ...this.session } : null })
  }

  /* --------------------------------------------------------------- */
  /* Text source registration (the reader's displayed translation)     */
  /* --------------------------------------------------------------- */

  /**
   * Register the currently displayed ayat of one sura (the SELECTED
   * translation's own text). The map keeps at most the reader's current
   * sura and the actively narrated sura, so a navigation never orphans a
   * live narration.
   */
  registerTextSource(
    translationKey: string,
    sura: number,
    ayat: Array<{ ayah: number; translation: string }>,
  ): void {
    this.textSource.set(sura, { translationKey, ayat })
    // Keep at most 2 suras of text (the newest registered + the playing one).
    const keep = new Set<number>([sura])
    if (this.loadedRef) keep.add(this.loadedRef.sura)
    for (const key of this.textSource.keys()) {
      if (!keep.has(key)) this.textSource.delete(key)
    }
  }

  private getAyahText(translationKey: string, sura: number, ayah: number): string | null {
    const source = this.textSource.get(sura)
    if (!source || source.translationKey !== translationKey) return null
    const entry = source.ayat.find((item) => item.ayah === ayah)
    if (!entry) return null
    const text = entry.translation.trim()
    return text.length > 0 ? text : null
  }

  /* --------------------------------------------------------------- */
  /* Session computation                                              */
  /* --------------------------------------------------------------- */

  private computeSession(press: { sura: number; ayah: number }): NarrationSessionInfo {
    const { advanceMode, repeatEnabled, repeatCount } = useNarrationStore.getState()
    return {
      advance: advanceMode,
      pressSura: press.sura,
      pressAyah: press.ayah,
      ayahPlay: 1,
      ayahPlayCount: repeatEnabled ? repeatCount : 1,
    }
  }

  /** Recompute the ACTIVE session after a settings change. */
  private recomputeSession(): void {
    if (!this.session || !this.loadedRef) return
    const fresh = this.computeSession({
      sura: this.session.pressSura,
      ayah: this.session.pressAyah,
    })
    const clamp = (value: number, total: number | 'infinite'): number =>
      total === 'infinite' ? value : Math.min(value, total)
    fresh.ayahPlay = clamp(this.session.ayahPlay, fresh.ayahPlayCount)
    this.session = fresh
    this.pushSession()
    // Live speed change applies immediately.
    this.applySpeed(useNarrationStore.getState().speed)
  }

  /* --------------------------------------------------------------- */
  /* Public control surface                                           */
  /* --------------------------------------------------------------- */

  /**
   * Begin narrating one ayah of the given translation. A NEW session
   * starts at the pressed ayah, computed from the live settings.
   */
  async playAyah(translationKey: string, sura: number, ayah: number): Promise<void> {
    this.ensureAudio()
    this.session = this.computeSession({ sura, ayah })
    this.pushSession()
    await this.loadAndNarrate(translationKey, sura, ayah)
  }

  togglePlayPause(): void {
    const state = useNarrationStore.getState()
    if (state.narratingSura === null || state.narratingAyah === null) return
    const translationKey = state.narrationTranslationKey
    if (translationKey === null) return

    if (state.error !== null) {
      // A previous attempt failed at this position: pressing play retries.
      void this.playAyah(translationKey, state.narratingSura, state.narratingAyah)
      return
    }

    if (state.mode === 'tts') {
      // NATIVE backend: Android's TextToSpeech has no pause/resume - a
      // pause is never faked. Playing -> an honest stop; stopped -> the
      // current ayah restarts from its beginning (no resume exists).
      if (state.ttsBackend === 'native') {
        if (state.isPlaying || state.isSpeaking) {
          this.stop()
        } else {
          void this.playAyah(translationKey, state.narratingSura, state.narratingAyah)
        }
        return
      }
      // WEB backend: pause/resume as before.
      const bridge = getSpeechBridge()
      if (!bridge) {
        this.sync({ error: 'unsupported' })
        return
      }
      if (state.isPlaying || state.isSpeaking) {
        bridge.pause()
        this.sync({ isPlaying: false, isSpeaking: false })
      } else {
        bridge.resume()
        this.sync({ isPlaying: true, isSpeaking: true })
      }
      return
    }

    const audio = this.ensureAudio()
    if (!audio) return
    if (audio.paused) {
      if (audio.ended) {
        void this.playAyah(translationKey, state.narratingSura, state.narratingAyah)
      } else {
        void audio.play().catch(() => this.sync({ isPlaying: false }))
      }
    } else {
      audio.pause()
    }
  }

  /** Manual next: a NEW session at the next ayah. */
  async nextAyah(): Promise<void> {
    const state = useNarrationStore.getState()
    if (state.narratingSura === null || state.narratingAyah === null) return
    if (!state.narrationTranslationKey) return
    const { narratingSura, narratingAyah } = state
    const ayahCount = getSuraAyahCount(narratingSura)
    if (narratingAyah < ayahCount) {
      await this.playAyah(state.narrationTranslationKey, narratingSura, narratingAyah + 1)
    } else if (narratingSura < 114) {
      await this.playAyah(state.narrationTranslationKey, narratingSura + 1, 1)
    }
  }

  /** Manual previous: a NEW session at the previous ayah. */
  async prevAyah(): Promise<void> {
    const state = useNarrationStore.getState()
    if (state.narratingSura === null || state.narratingAyah === null) return
    if (!state.narrationTranslationKey) return
    const { narratingSura, narratingAyah } = state
    if (narratingAyah > 1) {
      await this.playAyah(state.narrationTranslationKey, narratingSura, narratingAyah - 1)
    } else if (narratingSura > 1) {
      await this.playAyah(
        state.narrationTranslationKey,
        narratingSura - 1,
        getSuraAyahCount(narratingSura - 1),
      )
    }
  }

  seek(time: number): void {
    const audio = this.ensureAudio()
    if (!audio) return
    if (Number.isFinite(time) && time >= 0 && Number.isFinite(audio.duration)) {
      audio.currentTime = Math.min(time, audio.duration)
    }
  }

  /** Apply a new speed immediately when narration is live. */
  applySpeed(speed: number): void {
    if (this.audio && useNarrationStore.getState().mode === 'recording') {
      this.audio.playbackRate = speed
    }
    // TTS rate applies to the NEXT utterance (neither the Web Speech API
    // nor the native bridge can change the rate of a speaking utterance).
  }

  /** Stop narration, clear the session, keep nothing playing. */
  stop(): void {
    this.clearAdvanceTimer()
    this.cancelSpeech()
    this.session = null
    this.pushSession()
    this.releaseChannel()
    this.releaseLocalObjectUrl()
    if (this.audio) {
      this.audio.pause()
      this.audio.removeAttribute('src')
      this.audio.load()
    }
    this.loadedRef = null
    this.sync({
      narrationTranslationKey: null,
      mode: null,
      narratingSura: null,
      narratingAyah: null,
      isPlaying: false,
      isBuffering: false,
      isSpeaking: false,
      currentTime: 0,
      duration: 0,
      error: null,
      sourceMode: null,
      activeVoiceName: null,
      ttsBackend: null,
    })
  }

  /* --------------------------------------------------------------- */
  /* Voice detection (offered only after actual detection)            */
  /* --------------------------------------------------------------- */

  /**
   * Whether the platform exposes a speech synthesis engine at all.
   * Inside the native app the TtsBridge is the engine (its real state is
   * verified per call, with honest failures); in browsers, the Web Speech
   * API. Synchronous by design - the picker probes the real state via
   * listDetectedVoices().
   */
  isTtsEngineAvailable(): boolean {
    if (isRealNativePlatform()) return true
    return getSpeechBridge() !== null
  }

  /**
   * The device voices actually detected for a translation language, on
   * the platform's real speech backend (native bridge inside the Android
   * app, Web Speech API in browsers). Voices are offered only after they
   * were actually detected - never an assumption.
   */
  async listDetectedVoices(
    languageIso: string,
  ): Promise<{ engine: boolean; voices: NarrationVoice[] }> {
    if (isRealNativePlatform()) {
      const available = await isTtsBridgeAvailable()
      if (!available) return { engine: false, voices: [] }
      const descriptors = await ttsGetVoices(languageIso)
      return { engine: true, voices: descriptors.map(toNarrationVoice) }
    }
    const bridge = getSpeechBridge()
    if (!bridge) return { engine: false, voices: [] }
    const voices = await waitForVoices(bridge)
    return {
      engine: true,
      voices: voices
        .filter((voice) => languageMatches(voice.lang, languageIso))
        .map((voice) => ({
          id: voice.voiceURI,
          name: voice.name,
          lang: voice.lang,
          localService: voice.localService,
          webVoice: voice,
        })),
    }
  }

  /* --------------------------------------------------------------- */
  /* Loading and narrating                                            */
  /* --------------------------------------------------------------- */

  private releaseLocalObjectUrl(): void {
    if (this.localObjectUrl !== null) {
      URL.revokeObjectURL(this.localObjectUrl)
      this.localObjectUrl = null
    }
  }

  /** A verified local copy of the narration file (offline playback). */
  private async resolveLocalFile(
    translationKey: string,
    sura: number,
    ayah: number,
  ): Promise<string | null> {
    try {
      const library = getTranslationAudioLibrary()
      const entry = await library.getEntry(translationKey, sura, ayah)
      if (!entry || entry.verification !== 'verified') return null
      const blob = await library.getBlob(entry.storageKey)
      if (!blob || blob.size !== entry.fileSize) {
        await library.updateVerification(entry.id, 'corrupted').catch(() => undefined)
        return null
      }
      this.releaseLocalObjectUrl()
      this.localObjectUrl = URL.createObjectURL(blob)
      return this.localObjectUrl
    } catch {
      return null
    }
  }

  /**
   * Load and narrate one ayah WITHOUT touching the active session.
   *
   * Priority ladder (strict):
   * 1. verified local file (offline),
   * 2. verified recording at the source (exact translation only),
   * 3. device TTS voice for the translation's language,
   * 4. honest 'unavailable' error.
   */
  private async loadAndNarrate(translationKey: string, sura: number, ayah: number): Promise<void> {
    const audio = this.ensureAudio()
    if (!audio) return

    this.clearAdvanceTimer()
    this.cancelSpeech()

    const { speed } = useNarrationStore.getState()
    this.sync({
      isBuffering: true,
      isSpeaking: false,
      error: null,
      currentTime: 0,
      duration: 0,
      narrationTranslationKey: translationKey,
      narratingSura: sura,
      narratingAyah: ayah,
    })

    // 1. Verified local file? Play it offline - no network request at all.
    const localUrl = await this.resolveLocalFile(translationKey, sura, ayah)
    if (localUrl !== null) {
      this.loadedRef = { translationKey, sura, ayah }
      this.sync({ mode: 'recording', sourceMode: 'local', error: null })
      audio.src = localUrl
      audio.playbackRate = speed
      this.claimChannel()
      try {
        await audio.play()
        this.updateMediaSession(translationKey, sura, ayah)
      } catch {
        this.sync({ isPlaying: false, isBuffering: false })
      }
      return
    }

    // 2. Verified recording at the source (EXACT translation only).
    const inventory = await loadInventory(translationKey, sura)
    if (inventory && inventory.live.status === 'available') {
      const file = inventory.files.find((entry) => entry.ayah === ayah)
      if (file) {
        this.releaseLocalObjectUrl()
        this.loadedRef = { translationKey, sura, ayah }
        this.sync({ mode: 'recording', sourceMode: 'network', error: null })
        audio.src = file.url
        audio.playbackRate = speed
        this.claimChannel()
        try {
          await audio.play()
          this.updateMediaSession(translationKey, sura, ayah)
        } catch {
          this.sync({ isPlaying: false, isBuffering: false })
        }
        return
      }
      // The translation HAS recordings, but the EXACT recording of THIS
      // ayah is unavailable: fall back to a device voice; when that is
      // impossible too, report the missing file honestly (never a guess,
      // never another translation's recording).
      const spoken = await this.narrateWithTts(translationKey, sura, ayah)
      if (spoken) return
      this.sync({
        mode: null,
        sourceMode: null,
        isBuffering: false,
        isPlaying: false,
        error: 'file-missing',
      })
      return
    }

    // 3. Device TTS voice for the translation's language.
    await this.narrateWithTts(translationKey, sura, ayah, inventory === null)
  }

  /**
   * Narrate one ayah with a device voice (priority 2 of the ladder).
   * The speech backend is chosen here: the native TtsBridge inside the
   * Android app, the Web Speech API in browsers (unchanged web behavior).
   * Returns true when TTS narration actually started; false when it could
   * not (the caller then decides the honest error for its branch).
   */
  private async narrateWithTts(
    translationKey: string,
    sura: number,
    ayah: number,
    inventoryUnknown = false,
  ): Promise<boolean> {
    const useNative = isRealNativePlatform()

    // 1. Backend presence - honest: no engine means no narration.
    if (useNative) {
      const available = await isTtsBridgeAvailable()
      if (!available) {
        this.sync({
          mode: null,
          sourceMode: null,
          isBuffering: false,
          isPlaying: false,
          ttsEngineAvailable: false,
          ttsBackend: 'native',
          error: 'tts-engine-missing',
        })
        return false
      }
      this.sync({ ttsEngineAvailable: true, ttsBackend: 'native' })
    } else {
      const bridge = getSpeechBridge()
      if (!bridge) {
        this.sync({
          mode: null,
          sourceMode: null,
          isBuffering: false,
          isPlaying: false,
          ttsEngineAvailable: false,
          ttsBackend: null,
          error: 'no-audio',
        })
        return false
      }
      this.sync({ ttsEngineAvailable: true, ttsBackend: 'web' })
    }

    // HARD RULE (both backends): device TTS is never used for Arabic
    // content - a synthetic voice must never be mistakable for Quran
    // recitation. Arabic-language translations get an honest 'unsupported'.
    const languageIso = this.languageOf(translationKey, sura)
    if (primarySubtag(languageIso) === 'ar') {
      this.sync({
        mode: null,
        sourceMode: null,
        isBuffering: false,
        isPlaying: false,
        error: 'unsupported',
      })
      return false
    }

    // The translation's OWN text (never another translation, never Arabic).
    const text = this.getAyahText(translationKey, sura, ayah)
    if (text === null) {
      // Without the text there is nothing to speak - if the inventory is
      // merely unreachable this is a network problem, otherwise honest
      // no-audio (no recording + no text to speak).
      this.sync({
        mode: null,
        sourceMode: null,
        isBuffering: false,
        isPlaying: false,
        error: inventoryUnknown ? 'network' : 'no-audio',
      })
      return false
    }

    const { voices } = await this.listDetectedVoices(languageIso)
    if (voices.length === 0) {
      if (useNative) {
        // Native: distinguish WHY the language cannot be spoken, so the UI
        // can point the user at the right system setting.
        const status = await ttsIsLanguageAvailable(languageIso)
        const error: NarrationErrorKind =
          status === 'engine-unavailable'
            ? 'tts-engine-missing'
            : status === 'missing-data'
              ? 'tts-voice-data'
              : 'tts-voice-missing'
        this.sync({
          mode: null,
          sourceMode: null,
          isBuffering: false,
          isPlaying: false,
          error,
        })
      } else {
        this.sync({
          mode: null,
          sourceMode: null,
          isBuffering: false,
          isPlaying: false,
          error: 'voice-missing',
        })
      }
      return false
    }

    const chosenVoice = this.pickVoice(voices)
    this.loadedRef = { translationKey, sura, ayah }
    this.sync({
      mode: 'tts',
      sourceMode: null,
      error: null,
      activeVoiceName: chosenVoice.name,
      isBuffering: false,
      ttsBackend: useNative ? 'native' : 'web',
    })
    this.claimChannel()

    const token = ++this.utteranceToken
    const { speed } = useNarrationStore.getState()

    if (useNative) {
      return this.speakWithNativeBridge(text, chosenVoice, speed, token, translationKey, sura, ayah)
    }

    const utterance = new SpeechSynthesisUtterance(text)
    if (chosenVoice.webVoice) utterance.voice = chosenVoice.webVoice
    utterance.lang = chosenVoice.lang
    utterance.rate = speed
    utterance.pitch = 1
    utterance.onstart = () => {
      if (token !== this.utteranceToken) return
      this.sync({ isPlaying: true, isSpeaking: true })
    }
    utterance.onend = () => {
      if (token !== this.utteranceToken) return
      this.sync({ isPlaying: false, isSpeaking: false })
      this.handleEnded()
    }
    utterance.onerror = () => {
      if (token !== this.utteranceToken) return
      this.sync({ isPlaying: false, isSpeaking: false, error: 'unsupported' })
    }
    getSpeechBridge()?.speak(utterance)
    this.updateMediaSession(translationKey, sura, ayah)
    return true
  }

  /**
   * Speak through the NATIVE bridge. The call resolves only when the
   * engine actually starts (onStart); 'done'/'error' then arrive through
   * the ttsUtterance listener (the native mirror of the web end event).
   */
  private async speakWithNativeBridge(
    text: string,
    chosenVoice: NarrationVoice,
    speed: number,
    token: number,
    translationKey: string,
    sura: number,
    ayah: number,
  ): Promise<boolean> {
    await this.ensureNativeUtteranceListener()
    try {
      const result = await ttsSpeak({
        text,
        // The chosen voice's own locale: guaranteed installed (it came
        // from the engine's real voice list for the translation language).
        lang: chosenVoice.lang,
        voiceId: chosenVoice.id,
        rate: speed,
        pitch: 1,
      })
      if (token !== this.utteranceToken) {
        // A newer session (or a stop) superseded this request mid-flight;
        // the newer flow owns the state - never overwrite it here.
        return true
      }
      this.nativeUtteranceId = result.utteranceId
      this.sync({ isPlaying: true, isSpeaking: true })
    } catch (error) {
      if (token !== this.utteranceToken) return true
      this.nativeUtteranceId = null
      this.sync({
        mode: null,
        sourceMode: null,
        isBuffering: false,
        isPlaying: false,
        isSpeaking: false,
        error: nativeTtsErrorKind(error),
      })
      return false
    }
    this.updateMediaSession(translationKey, sura, ayah)
    return true
  }

  /** Register the native utterance event listener once (client only). */
  private async ensureNativeUtteranceListener(): Promise<void> {
    if (this.nativeListenerRegistered) return
    this.nativeListenerRegistered = true
    await addTtsUtteranceListener((event) => {
      const expected = this.nativeUtteranceId
      // Stale guard: only the CURRENT session's events count (the same
      // protection the web path gets from the utterance token).
      if (expected === null || event.utteranceId !== expected) return
      this.nativeUtteranceId = null
      if (event.type === 'done') {
        this.sync({ isPlaying: false, isSpeaking: false })
        this.handleEnded()
      } else {
        this.sync({ isPlaying: false, isSpeaking: false, error: 'tts-synthesis-failed' })
      }
    })
  }

  /** The user's chosen voice for the language, or the platform default. */
  private pickVoice(voices: NarrationVoice[]): NarrationVoice {
    const { voiceChoice } = useNarrationStore.getState()
    for (const iso of this.currentLanguageCandidates()) {
      const chosen = voiceChoice[iso]
      if (chosen) {
        const match = voices.find((voice) => voice.id === chosen)
        if (match) return match
      }
    }
    // Prefer a localService voice (usually offline-capable), then default.
    return voices.find((voice) => voice.localService) ?? voices[0]
  }

  private currentLanguageCandidates(): string[] {
    // The language ISO of the active narration, from the last registered
    // language context (the reader sets it via setLanguageContext).
    return this.languageContext ? [this.languageContext] : []
  }

  private languageContext: string | null = null
  private languageNameContext: string | null = null

  /**
   * Set by the reader: the language (ISO + display name) of the SELECTED
   * translation. Voice matching follows THIS language - never the app
   * interface language.
   */
  setLanguageContext(languageIso: string | null, languageName: string | null = null): void {
    this.languageContext = languageIso
    this.languageNameContext = languageName
    this.sync({ languageIso, languageName })
  }

  private languageOf(translationKey: string, sura: number): string {
    // Preferred: the reader's language context; fallback: the inventory's
    // metadata (both describe the SAME translation).
    if (this.languageContext) return this.languageContext
    const inventory = inventoryCache.get(cacheKey(translationKey, sura))
    return inventory?.languageIso ?? 'en'
  }

  /* --------------------------------------------------------------- */
  /* Boundary logic                                                   */
  /* --------------------------------------------------------------- */

  private clearAdvanceTimer(): void {
    if (this.advanceTimer) {
      clearTimeout(this.advanceTimer)
      this.advanceTimer = null
    }
  }

  private cancelSpeech(): void {
    this.utteranceToken += 1
    this.nativeUtteranceId = null
    const bridge = getSpeechBridge()
    if (bridge) {
      try {
        bridge.cancel()
      } catch {
        /* best-effort */
      }
    }
    // Native: a NEW narration always stops whatever is still speaking
    // (the plugin also uses QUEUE_FLUSH - both layers guarantee no overlap).
    if (isRealNativePlatform()) {
      void ttsStop()
    }
  }

  private handleEnded(): void {
    const state = useNarrationStore.getState()
    const ref = this.loadedRef
    if (!ref || state.narratingSura !== ref.sura || state.narratingAyah !== ref.ayah) return
    if (this.advanceTimer) return

    const session = this.session
    if (!session) {
      this.sync({ isPlaying: false, isSpeaking: false })
      return
    }

    // 1. Ayah repetition.
    const belowCount = (value: number, total: number | 'infinite'): boolean =>
      total === 'infinite' || value < total
    if (belowCount(session.ayahPlay, session.ayahPlayCount)) {
      session.ayahPlay += 1
      this.pushSession()
      this.advanceTimer = setTimeout(() => {
        this.advanceTimer = null
        void this.loadAndNarrate(ref.translationKey, ref.sura, ref.ayah)
      }, REPEAT_GAP_MS)
      return
    }

    // 2. Sequential advance through the sura (bounded at the sura end).
    if (session.advance === 'sequential') {
      const ayahCount = getSuraAyahCount(ref.sura)
      if (ref.ayah < ayahCount) {
        session.ayahPlay = 1
        this.pushSession()
        void this.loadAndNarrate(ref.translationKey, ref.sura, ref.ayah + 1)
        return
      }
    }

    // 3. Session complete: stop at the boundary, keep the position visible.
    this.session = null
    this.pushSession()
    this.sync({ isPlaying: false, isSpeaking: false })
  }

  /* --------------------------------------------------------------- */
  /* Interruptions, errors and coordination                           */
  /* --------------------------------------------------------------- */

  private async handleError(): Promise<void> {
    const ref = this.loadedRef
    this.sync({ isPlaying: false, isBuffering: false })

    if (!ref) {
      this.sync({ error: 'unknown' })
      return
    }
    // Classify with the same-origin inventory API (a direct HEAD to the
    // CDN is not possible from the browser - no CORS headers on the MP3s).
    const inventory = await loadInventory(ref.translationKey, ref.sura)
    if (!inventory) {
      this.sync({ error: 'network' })
      return
    }
    const file = inventory.files.find((entry) => entry.ayah === ref.ayah)
    this.sync({ error: file ? 'network' : 'file-missing' })
  }

  /** Take the coordinated audio stage for narration. While held, starting
   *  recitation pauses this narration (and this claim pauses recitation).
   *  Narration and recitation can therefore never be audible together. */
  private claimChannel(): void {
    if (this.channelRelease) return
    /* iOS: activate the .playback AVAudioSession for WebView narration
     * audio (no-op on Android and web — the shipped Android 2.0.2
     * behavior is untouched; the native TTS path manages its own
     * session inside the plugin). */
    void setWebAudioSessionActive(true)
    this.channelRelease = claimAudioChannel('narration', () => {
      const state = useNarrationStore.getState()
      if (state.mode === 'tts') {
        this.cancelSpeech()
      } else if (this.audio && !this.audio.paused) {
        this.audio.pause()
      }
      // The session and position survive the suspension (pause semantics).
    })
  }

  private releaseChannel(): void {
    if (this.channelRelease) {
      /* iOS: fully stopped narration politely releases the session. */
      void setWebAudioSessionActive(false)
    }
    this.channelRelease?.()
    this.channelRelease = null
  }

  private updateMediaSession(translationKey: string, sura: number, ayah: number): void {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return
    const state = useNarrationStore.getState()
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: `Surah ${sura} · Ayah ${ayah}`,
        artist:
          state.mode === 'tts'
            ? `Translation narration (device voice${state.activeVoiceName ? ` — ${state.activeVoiceName}` : ''})`
            : 'Translation narration (recorded)',
        album: translationKey,
      })
      navigator.mediaSession.setActionHandler('play', () => this.togglePlayPause())
      navigator.mediaSession.setActionHandler('pause', () => this.togglePlayPause())
      navigator.mediaSession.setActionHandler('previoustrack', () => void this.prevAyah())
      navigator.mediaSession.setActionHandler('nexttrack', () => void this.nextAyah())
      navigator.mediaSession.setActionHandler('stop', () => this.stop())
    } catch {
      /* MediaSession is best-effort; never blocks narration */
    }
  }

  /** Test-only / teardown helper (the singleton lives for the app lifetime). */
  dispose(): void {
    this.clearAdvanceTimer()
    this.unsubscribeStore?.()
    this.stop()
    this.audio = null
  }
}

/** App-wide narration engine singleton (created lazily on first use). */
export const narrationEngine: NarrationEngine = new NarrationEngine()
