'use client'

/**
 * Coordinated audio session management (app-wide).
 *
 * ONE audio stage for the whole application. Every audio source must claim a
 * named channel before producing sound; claiming a channel automatically
 * suspends every OTHER active channel (playback pauses, positions are kept).
 *
 * Registered channels today:
 * - 'recitation'  - the ayah-by-ayah Arabic recitation player
 *   (src/services/audio/playback-engine.ts, EveryAyah recordings);
 * - 'narration'   - the translation narration engine
 *   (src/services/audio/narration-engine.ts: human-recorded QuranEnc
 *   translation audio, or a device TTS voice reading the translation).
 *
 * This is the single enforcement point for the rule that Arabic recitation
 * and translation narration NEVER play simultaneously: starting one pauses
 * the other (position kept), and each engine also stops its own audio when
 * it loses the stage. The coordinator never fabricates audio and never
 * mutes anything by assumption: it only pauses sources that actively
 * registered themselves.
 */

export type AudioChannelId = 'recitation' | (string & {})

interface ChannelHolder {
  /** Called when another channel claims the stage: pause, keep position. */
  suspend: () => void
}

const holders = new Map<AudioChannelId, ChannelHolder>()

/**
 * Claim the audio stage for `id`. Any OTHER active channel is suspended
 * (paused, position kept) before the claim is registered. Re-claiming an
 * already-held channel is a no-op.
 *
 * @returns a release function (idempotent).
 */
export function claimAudioChannel(id: AudioChannelId, suspend: () => void): () => void {
  const existing = holders.get(id)
  if (existing) return () => releaseAudioChannel(id)

  for (const [otherId, holder] of holders) {
    if (otherId === id) continue
    try {
      holder.suspend()
    } catch {
      /* A misbehaving source never blocks the new claim. */
    }
  }
  holders.set(id, { suspend })
  return () => releaseAudioChannel(id)
}

/** Release a previously claimed channel (no-op when not held). */
export function releaseAudioChannel(id: AudioChannelId): void {
  holders.delete(id)
}

/** Channels currently holding the stage (diagnostics / testing only). */
export function activeAudioChannels(): AudioChannelId[] {
  return [...holders.keys()]
}
