'use client'

/**
 * Audio playback engine (client singleton).
 *
 * Owns exactly ONE HTMLAudioElement for the whole app and drives the audio
 * store with its state. This is the coordinated audio manager: it claims the
 * 'recitation' channel of the session coordinator (any other registered audio
 * source is paused when recitation starts, and vice versa), so recitation and
 * any future translation narration can never play simultaneously.
 *
 * Playback model (PROMPT 8):
 *
 * - SINGLE-AYAH MODE: pressing play on an ayah plays ONLY that ayah and stops
 *   at its end. No automatic continuation.
 * - SEQUENTIAL MODE: a separate opt-in mode. Playback starts from the selected
 *   ayah and advances automatically to the next ayah, through the selected
 *   range, stopping at the configured ending ayah or the end of the sura.
 *   Sequential advance is bounded - it is never an endless loop of one ayah.
 * - REPEAT CONTROLS: repeat the current ayah, repeat the selected range, or
 *   repeat the whole surah, each with a repeat count (2..10 or endless), or
 *   no repetition at all. 'range'/'sura' repetition are sequential concepts
 *   and force sequential advance.
 * - Sessions are computed from the live settings at every boundary, so
 *   changing the mode/repeat/end settings while playing takes effect at the
 *   next ayah boundary - the visible state always matches the behavior.
 *
 * Honesty rules (unchanged from the verified-audio foundation):
 *
 * - Only files from a VERIFIED inventory (API response) are ever loaded; the
 *   engine never constructs or plays a URL by assumption. An ayah without a
 *   verified file produces an honest `file-missing` error and is never played.
 * - The original recording structure is preserved exactly: each file is one
 *   complete ayah from the source recording. The Muallim recording's natural
 *   silences and teaching pauses are NEVER trimmed, shortened or altered -
 *   playback is the source file, nothing else. A short gap (~650 ms) is only
 *   inserted between REPETITIONS, never inside a recording.
 * - When the selected recitation style changes mid-playback, the engine
 *   reloads the CURRENT ayah in the new style - the reading position (and
 *   the playing position) are never lost.
 * - Media Session integration (where supported) gives lock-screen /
 *   hardware-key controls: play/pause, previous/next ayah, stop.
 * - Interruptions (incoming calls, headphone disconnection where the platform
 *   reports it, audio-focus loss) surface as a 'pause' event on the element:
 *   playback stops, the position is kept, and the state stays honest. Audio
 *   element errors are classified with a follow-up source check so the user
 *   sees an honest reason, never a fabricated one.
 */

import { getSuraAudio } from '@/services/api/audio-api'
import { getStyleDefinition } from '@/data/audio-styles'
import {
  useAudioStore,
  type AudioErrorKind,
  type PlaybackSessionInfo,
} from '@/stores/audio-store'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { claimAudioChannel, releaseAudioChannel } from '@/services/audio/session-coordinator'
import { setWebAudioSessionActive } from '@/services/native/audio-session-bridge'
import { getAudioLibrary } from '@/services/storage/audio-library'
import type { SuraAudioResponse } from '@/types'

const inventoryCache = new Map<string, SuraAudioResponse>()

/** Gap inserted between REPETITIONS of an ayah (never inside a recording). */
const REPEAT_GAP_MS = 650

function cacheKey(styleId: string, sura: number): string {
  return `${styleId}:${sura}`
}

async function loadInventory(styleId: string, sura: number): Promise<SuraAudioResponse | null> {
  const key = cacheKey(styleId, sura)
  const cached = inventoryCache.get(key)
  if (cached) return cached
  try {
    const response = await getSuraAudio(styleId, sura)
    inventoryCache.set(key, response)
    return response
  } catch {
    return null
  }
}

/** Position inside the Quran (suras are never crossed by session advance). */
interface AyahPosition {
  sura: number
  ayah: number
}

/** True while `value` has not reached the configured `total` ('infinite'
 *  totals are never reached - repetition only stops by user action). */
function belowCount(value: number, total: number | 'infinite'): boolean {
  return total === 'infinite' || value < total
}

function samePosition(a: AyahPosition, b: AyahPosition): boolean {
  return a.sura === b.sura && a.ayah === b.ayah
}

function positionAtOrBefore(pos: AyahPosition, boundary: AyahPosition): boolean {
  return pos.sura < boundary.sura || (pos.sura === boundary.sura && pos.ayah <= boundary.ayah)
}

class PlaybackEngine {
  private audio: HTMLAudioElement | null = null
  /** (styleId, sura, ayah) currently loaded - guards against stale events. */
  private loadedRef: { styleId: string; sura: number; ayah: number } | null = null
  /** The active playback session (null when no session is running). */
  private session: PlaybackSessionInfo | null = null
  private advanceTimer: ReturnType<typeof setTimeout> | null = null
  private unsubscribeStore: (() => void) | null = null
  /** Release function for the coordinated 'recitation' audio channel. */
  private channelRelease: (() => void) | null = null
  /** Object URL of the local file currently loaded (revoked on the next
   *  load / stop - offline playback never touches the network). */
  private localObjectUrl: string | null = null

  /** Lazily create the audio element and store wiring (client only). */
  private ensureAudio(): HTMLAudioElement | null {
    if (typeof window === 'undefined') return null
    if (this.audio) return this.audio

    const audio = new Audio()
    audio.preload = 'auto'
    audio.crossOrigin = 'anonymous' // EveryAyah sends Access-Control-Allow-Origin: *
    this.audio = audio

    audio.addEventListener('playing', () => this.sync({ isPlaying: true, isBuffering: false }))
    audio.addEventListener('pause', () => this.sync({ isPlaying: false }))
    audio.addEventListener('waiting', () => this.sync({ isBuffering: true }))
    audio.addEventListener('timeupdate', () => {
      if (Number.isFinite(audio.currentTime)) this.sync({ currentTime: audio.currentTime })
    })
    audio.addEventListener('durationchange', () => {
      if (Number.isFinite(audio.duration)) this.sync({ duration: audio.duration })
    })
    audio.addEventListener('ended', () => this.handleEnded())
    audio.addEventListener('error', () => this.handleError())

    // Apply the persisted preferences on creation.
    const { speed } = useAudioStore.getState()
    audio.playbackRate = speed

    // React to settings changes while playback is live:
    // - style change: reload the CURRENT ayah in the new style (position and
    //   session are preserved - only the audio follows the new selection);
    // - playback settings change: recompute the active session from the new
    //   settings so the next boundary decision follows them.
    let lastStyleId = useAudioStore.getState().selectedStyleId
    let lastSettings = this.readSettingsSnapshot()
    this.unsubscribeStore = useAudioStore.subscribe((state) => {
      if (state.selectedStyleId !== lastStyleId) {
        lastStyleId = state.selectedStyleId
        void this.handleStyleChanged()
        return
      }
      const snapshot = this.readSettingsSnapshot()
      if (snapshot !== lastSettings) {
        lastSettings = snapshot
        this.recomputeSession()
      }
    })

    return audio
  }

  /** Comparable snapshot of the settings that shape a session. */
  private readSettingsSnapshot(): string {
    const { playbackMode, repeatMode, repeatCount, sequenceEndAyah } = useAudioStore.getState()
    return `${playbackMode}|${repeatMode}|${String(repeatCount)}|${String(sequenceEndAyah)}`
  }

  private sync(patch: {
    playingSura?: number | null
    playingAyah?: number | null
    isPlaying?: boolean
    isBuffering?: boolean
    error?: AudioErrorKind | null
    currentTime?: number
    duration?: number
    session?: PlaybackSessionInfo | null
    sourceMode?: 'local' | 'network' | null
  }): void {
    useAudioStore.getState().syncEngineState(patch)
  }

  /** Publish the current session (serializable copy) for the UI. */
  private pushSession(): void {
    this.sync({ session: this.session ? { ...this.session } : null })
  }

  /* --------------------------------------------------------------- */
  /* Session computation                                              */
  /* --------------------------------------------------------------- */

  /**
   * Compute a fresh session for a press point from the LIVE settings.
   *
   * - single mode: the range is exactly the pressed ayah; an 'ayah' repeat
   *   still applies (the ayah replays N times, then the session stops).
   * - sequential mode: the range runs from the pressed ayah to the configured
   *   end boundary (a custom ending ayah, clamped into [press, sura end], or
   *   the end of the sura). The first pass starts at the pressed ayah; later
   *   passes restart at the range start - which is ayah 1 for 'sura'
   *   repetition (the whole surah) and the pressed ayah for 'range'.
   */
  private computeSession(press: AyahPosition): PlaybackSessionInfo {
    const { playbackMode, repeatMode, repeatCount, sequenceEndAyah } = useAudioStore.getState()
    const suraLast = getSuraAyahCount(press.sura)
    const forcesSequential = repeatMode === 'range' || repeatMode === 'sura'
    const mode = forcesSequential || playbackMode === 'sequential' ? 'sequential' : 'single'

    if (mode === 'single') {
      return {
        mode: 'single',
        pressSurah: press.sura,
        pressAyah: press.ayah,
        startSurah: press.sura,
        startAyah: press.ayah,
        endSurah: press.sura,
        endAyah: press.ayah,
        pass: 1,
        passCount: 1,
        ayahPlay: 1,
        ayahPlayCount: repeatMode === 'ayah' ? repeatCount : 1,
      }
    }

    const endAyah =
      sequenceEndAyah !== null
        ? Math.min(Math.max(sequenceEndAyah, press.ayah), Math.max(suraLast, press.ayah))
        : Math.max(suraLast, press.ayah)
    const startAyah = repeatMode === 'sura' ? 1 : press.ayah

    return {
      mode: 'sequential',
      pressSurah: press.sura,
      pressAyah: press.ayah,
      startSurah: press.sura,
      startAyah,
      endSurah: press.sura,
      endAyah,
      pass: 1,
      passCount: forcesSequential ? repeatCount : 1,
      ayahPlay: 1,
      ayahPlayCount: repeatMode === 'ayah' ? repeatCount : 1,
    }
  }

  /**
   * Recompute the ACTIVE session after a settings change: the shape follows
   * the new settings from the next boundary on, while the progress counters
   * are kept (clamped into the new totals). Switching to single mode
   * re-anchors the range to the currently playing ayah.
   */
  private recomputeSession(): void {
    if (!this.session) return
    const current: AyahPosition | null =
      this.loadedRef !== null
        ? { sura: this.loadedRef.sura, ayah: this.loadedRef.ayah }
        : null
    const fresh = this.computeSession({
      sura: this.session.pressSurah,
      ayah: this.session.pressAyah,
    })

    if (fresh.mode === 'single' && current !== null) {
      // Honest display: in single mode the "range" is the ayah being played.
      fresh.startSurah = current.sura
      fresh.startAyah = current.ayah
      fresh.endSurah = current.sura
      fresh.endAyah = current.ayah
    }

    const clampCount = (value: number, total: number | 'infinite'): number =>
      total === 'infinite' ? value : Math.min(value, total)
    fresh.pass = clampCount(this.session.pass, fresh.passCount)
    fresh.ayahPlay = clampCount(this.session.ayahPlay, fresh.ayahPlayCount)

    this.session = fresh
    this.pushSession()
  }

  /* --------------------------------------------------------------- */
  /* Loading and playing a verified file                              */
  /* --------------------------------------------------------------- */

  /**
   * Begin playing one ayah of the selected style (verified inventory only).
   * Starts a NEW session at the pressed ayah, computed from the live
   * settings.
   */
  async playAyah(sura: number, ayah: number): Promise<void> {
    const audio = this.ensureAudio()
    if (!audio) return

    this.session = this.computeSession({ sura, ayah })
    this.pushSession()
    await this.loadAndPlay(sura, ayah)
  }

  /** Release the previous local object URL (called before every load and
   *  on stop - an object URL is only alive while its file plays). */
  private releaseLocalObjectUrl(): void {
    if (this.localObjectUrl !== null) {
      URL.revokeObjectURL(this.localObjectUrl)
      this.localObjectUrl = null
    }
  }

  /**
   * Resolve a VERIFIED local copy of one ayah of the selected style from
   * the offline audio library. Returns a playable object URL plus the
   * recorded file size, or null when no verified local file exists (the
   * caller then falls back to the network stream).
   */
  private async resolveLocalFile(
    styleId: string,
    sura: number,
    ayah: number,
  ): Promise<{ url: string; sizeBytes: number } | null> {
    try {
      const library = getAudioLibrary()
      const entry = await library.getEntry(styleId, sura, ayah)
      if (!entry || entry.verification !== 'verified') return null
      const blob = await library.getBlob(entry.storageKey)
      if (!blob || blob.size !== entry.fileSize) {
        // The stored copy no longer matches its manifest record - mark it
        // honestly and fall back to the network stream.
        await library.updateVerification(entry.id, 'corrupted').catch(() => undefined)
        return null
      }
      this.releaseLocalObjectUrl()
      this.localObjectUrl = URL.createObjectURL(blob)
      return { url: this.localObjectUrl, sizeBytes: entry.fileSize }
    } catch {
      return null
    }
  }

  /**
   * Load and play one ayah WITHOUT touching the active session (used for
   * automatic advance, repetitions, range restarts and style swaps).
   *
   * LOCAL-FIRST (PROMPT 9): a verified local file is played directly from
   * device storage - the network is never contacted for it. Only when no
   * verified local file exists does the engine load the network stream
   * from the verified inventory.
   */
  private async loadAndPlay(sura: number, ayah: number): Promise<void> {
    const audio = this.ensureAudio()
    if (!audio) return

    this.clearAdvanceTimer()

    const { selectedStyleId, speed } = useAudioStore.getState()
    if (!selectedStyleId) {
      this.sync({ error: 'style-unavailable', isPlaying: false, isBuffering: false, sourceMode: null })
      return
    }

    this.sync({ isBuffering: true, error: null, currentTime: 0, duration: 0 })

    // 1. Verified local file? Play it offline - no network request at all.
    const local = await this.resolveLocalFile(selectedStyleId, sura, ayah)
    if (local !== null) {
      this.loadedRef = { styleId: selectedStyleId, sura, ayah }
      this.sync({ playingSura: sura, playingAyah: ayah, error: null, sourceMode: 'local' })
      audio.src = local.url
      audio.playbackRate = speed
      this.claimChannel()
      try {
        await audio.play()
        this.updateMediaSession(selectedStyleId, sura, ayah)
      } catch {
        this.sync({ isPlaying: false, isBuffering: false })
      }
      return
    }

    // 2. No local copy: the network stream from the VERIFIED inventory.
    const inventory = await loadInventory(selectedStyleId, sura)
    if (!inventory) {
      this.sync({ error: 'network', isPlaying: false, isBuffering: false, sourceMode: null, playingSura: sura, playingAyah: ayah })
      return
    }
    if (inventory.live.status !== 'available') {
      this.sync({ error: 'style-unavailable', isPlaying: false, isBuffering: false, sourceMode: null, playingSura: sura, playingAyah: ayah })
      return
    }
    const file = inventory.files.find((entry) => entry.ayah === ayah)
    if (!file) {
      // Never played without a verified file - honest missing-file report.
      this.sync({
        error: 'file-missing',
        isPlaying: false,
        isBuffering: false,
        playingSura: sura,
        playingAyah: ayah,
        sourceMode: null,
      })
      return
    }

    this.releaseLocalObjectUrl()
    this.loadedRef = { styleId: selectedStyleId, sura, ayah }
    this.sync({ playingSura: sura, playingAyah: ayah, error: null, sourceMode: 'network' })
    audio.src = file.url
    audio.playbackRate = speed
    this.claimChannel()
    try {
      await audio.play()
      this.updateMediaSession(selectedStyleId, sura, ayah)
    } catch {
      // Autoplay block or load failure - honest state, no throw to callers.
      this.sync({ isPlaying: false, isBuffering: false })
    }
  }

  togglePlayPause(): void {
    const audio = this.ensureAudio()
    if (!audio) return
    const { playingSura, playingAyah, error } = useAudioStore.getState()
    if (playingSura === null || playingAyah === null) return

    if (error !== null) {
      // A previous attempt failed at this position: pressing play retries the
      // load honestly instead of toggling a broken element.
      void this.playAyah(playingSura, playingAyah)
      return
    }

    if (audio.paused) {
      if (audio.ended) {
        // Finished playback replays as a fresh session at the same position.
        void this.playAyah(playingSura, playingAyah)
      } else {
        void audio.play().catch(() => this.sync({ isPlaying: false }))
      }
    } else {
      audio.pause()
    }
  }

  /** Manual next: a NEW session starts at the next ayah (never crosses the
   *  session range - manual navigation is the user's own choice). */
  async nextAyah(): Promise<void> {
    const { playingSura, playingAyah } = useAudioStore.getState()
    if (playingSura === null || playingAyah === null) return
    const ayahCount = getSuraAyahCount(playingSura)
    if (playingAyah < ayahCount) {
      await this.playAyah(playingSura, playingAyah + 1)
    } else if (playingSura < 114) {
      await this.playAyah(playingSura + 1, 1)
    }
  }

  /** Manual previous: a NEW session starts at the previous ayah. */
  async prevAyah(): Promise<void> {
    const { playingSura, playingAyah } = useAudioStore.getState()
    if (playingSura === null || playingAyah === null) return
    if (playingAyah > 1) {
      await this.playAyah(playingSura, playingAyah - 1)
    } else if (playingSura > 1) {
      await this.playAyah(playingSura - 1, getSuraAyahCount(playingSura - 1))
    }
  }

  seek(time: number): void {
    const audio = this.ensureAudio()
    if (!audio) return
    if (Number.isFinite(time) && time >= 0 && Number.isFinite(audio.duration)) {
      audio.currentTime = Math.min(time, audio.duration)
    }
  }

  /** Apply a new speed immediately when audio is live. */
  applySpeed(speed: number): void {
    if (this.audio) this.audio.playbackRate = speed
  }

  /** Stop playback, clear the session, keep nothing playing. */
  stop(): void {
    this.clearAdvanceTimer()
    this.session = null
    this.pushSession()
    this.releaseChannel()
    this.releaseLocalObjectUrl()
    if (this.audio) {
      this.audio.pause()
      this.audio.removeAttribute('src')
      this.audio.load()
    }
    this.loadedRef = null
    this.sync({
      playingSura: null,
      playingAyah: null,
      isPlaying: false,
      isBuffering: false,
      currentTime: 0,
      duration: 0,
      error: null,
      sourceMode: null,
    })
  }

  /* --------------------------------------------------------------- */
  /* Boundary logic (the session state machine)                       */
  /* --------------------------------------------------------------- */

  private clearAdvanceTimer(): void {
    if (this.advanceTimer) {
      clearTimeout(this.advanceTimer)
      this.advanceTimer = null
    }
  }

  /**
   * The next ayah inside the range, or null when the current position is at
   * or past the range end (the pass is complete). Session advance never
   * crosses suras - the end boundary always lies within the starting sura.
   */
  private successorWithinRange(current: AyahPosition): AyahPosition | null {
    if (!this.session) return null
    const end: AyahPosition = { sura: this.session.endSurah, ayah: this.session.endAyah }
    if (!samePosition(current, end) && !positionAtOrBefore(current, end)) {
      // Manually navigated beyond the boundary: the pass is complete.
      return null
    }
    const next = { sura: current.sura, ayah: current.ayah + 1 }
    return positionAtOrBefore(next, end) ? next : null
  }

  private handleEnded(): void {
    const state = useAudioStore.getState()
    const ref = this.loadedRef
    if (!ref || state.playingSura !== ref.sura || state.playingAyah !== ref.ayah) return
    if (this.advanceTimer) return // A scheduled transition is already pending.

    const session = this.session
    const current: AyahPosition = { sura: ref.sura, ayah: ref.ayah }

    if (!session) {
      // No active session (e.g. it completed and playback was resumed bare):
      // the ayah ends and playback simply stops, position kept.
      this.sync({ isPlaying: false })
      return
    }

    // 1. Ayah repetition: replay the same ayah (gap only between repeats).
    if (belowCount(session.ayahPlay, session.ayahPlayCount)) {
      session.ayahPlay += 1
      this.pushSession()
      this.advanceTimer = setTimeout(() => {
        this.advanceTimer = null
        void this.loadAndPlay(current.sura, current.ayah)
      }, REPEAT_GAP_MS)
      return
    }
    session.ayahPlay = 1

    // 2. Sequential advance through the range.
    if (session.mode === 'sequential') {
      const next = this.successorWithinRange(current)
      if (next !== null) {
        this.pushSession()
        void this.loadAndPlay(next.sura, next.ayah)
        return
      }
      // The pass reached the configured end boundary.
      if (belowCount(session.pass, session.passCount)) {
        session.pass += 1
        session.ayahPlay = 1
        this.pushSession()
        this.advanceTimer = setTimeout(() => {
          this.advanceTimer = null
          void this.loadAndPlay(session.startSurah, session.startAyah)
        }, REPEAT_GAP_MS)
        return
      }
    }

    // 3. Session complete: stop at the boundary, keep the position visible.
    this.session = null
    this.pushSession()
    this.sync({ isPlaying: false })
  }

  /* --------------------------------------------------------------- */
  /* Interruptions, errors and coordination                           */
  /* --------------------------------------------------------------- */

  /** Style change mid-playback: reload the same ayah in the new style; the
   *  session and the reading position are preserved. */
  private async handleStyleChanged(): Promise<void> {
    const { playingSura, playingAyah, isPlaying } = useAudioStore.getState()
    if (playingSura === null || playingAyah === null) return
    await this.loadAndPlay(playingSura, playingAyah)
    if (!isPlaying && this.audio) this.audio.pause()
  }

  private async handleError(): Promise<void> {
    const ref = this.loadedRef
    const styleId = useAudioStore.getState().selectedStyleId
    this.sync({ isPlaying: false, isBuffering: false })

    // Classify the failure honestly with a direct source check.
    if (!ref || !styleId) {
      this.sync({ error: 'unknown' })
      return
    }
    const inventory = await loadInventory(styleId, ref.sura)
    if (!inventory) {
      this.sync({ error: 'network' })
      return
    }
    const file = inventory.files.find((entry) => entry.ayah === ref.ayah)
    if (!file) {
      this.sync({ error: 'file-missing' })
      return
    }
    try {
      const check = await fetch(file.url, { method: 'HEAD', signal: AbortSignal.timeout(10_000) })
      this.sync({ error: check.ok ? 'unknown' : 'file-missing' })
    } catch {
      this.sync({ error: 'network' })
    }
  }

  /** Take the coordinated audio stage for recitation. While held, any other
   *  registered source that claims the stage pauses this playback (and this
   *  claim pauses them). Recitation and translation narration can therefore
   *  never be audible at the same time. */
  private claimChannel(): void {
    if (this.channelRelease) return
    /* iOS: activate the .playback AVAudioSession so WebView recitation
     * can continue in the background / with the screen locked, where
     * iOS permits it (no-op on Android and web — the shipped Android
     * 2.0.2 behavior is untouched). */
    void setWebAudioSessionActive(true)
    this.channelRelease = claimAudioChannel('recitation', () => {
      if (this.audio && !this.audio.paused) this.audio.pause()
    })
  }

  private releaseChannel(): void {
    if (this.channelRelease) {
      /* iOS: fully stopped playback politely releases the session. */
      void setWebAudioSessionActive(false)
    }
    this.channelRelease?.()
    this.channelRelease = null
  }

  private updateMediaSession(styleId: string, sura: number, ayah: number): void {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return
    const style = getStyleDefinition(styleId)
    if (!style) return
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: `Surah ${sura} · Ayah ${ayah}`,
        artist: `${style.reciterName} — ${style.styleLabel}`,
        album: 'Global Quran',
      })
      navigator.mediaSession.setActionHandler('play', () => this.togglePlayPause())
      navigator.mediaSession.setActionHandler('pause', () => this.togglePlayPause())
      navigator.mediaSession.setActionHandler('previoustrack', () => void this.prevAyah())
      navigator.mediaSession.setActionHandler('nexttrack', () => void this.nextAyah())
      navigator.mediaSession.setActionHandler('stop', () => this.stop())
    } catch {
      /* MediaSession is best-effort; never blocks playback */
    }
  }

  /** Test-only / teardown helper (the singleton lives for the app lifetime). */
  dispose(): void {
    this.clearAdvanceTimer()
    this.unsubscribeStore?.()
    this.stop()
    this.audio = null
  }
}

/** App-wide playback engine singleton (created lazily on first use). */
export const playbackEngine: PlaybackEngine = new PlaybackEngine()
