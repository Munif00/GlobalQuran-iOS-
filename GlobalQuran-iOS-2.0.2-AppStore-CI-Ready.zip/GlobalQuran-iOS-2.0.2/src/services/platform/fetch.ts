/**
 * Global Quran - Platform-aware fetch.
 *
 * Every client-side request that targets one of the app's own /api/ routes
 * goes through this helper:
 * - Web mode: a plain same-origin fetch to the Next.js server route.
 * - Native mode (Capacitor app / ?nativeSim=1): the request is dispatched
 *   to the client-side native adapter, which reproduces each route's
 *   behavior (validation, caching, response shapes) without a server.
 *
 * Requests that do NOT target /api/ (static assets, external URLs) are
 * passed through to fetch unchanged.
 *
 * The native adapter is imported dynamically so its code (and everything it
 * pulls in - the shared prayer engine, the QuranEnc client, the docx
 * builder) is code-split out of the regular web bundle and only loaded when
 * native mode is actually active.
 */

import { isNativeAdapterActive } from './native-mode'

export async function platformFetch(path: string, init?: RequestInit): Promise<Response> {
  if (typeof path === 'string' && path.startsWith('/api/') && isNativeAdapterActive()) {
    const { dispatchNativeApi } = await import('@/services/native/router')
    return dispatchNativeApi(path, init)
  }
  return fetch(path, init)
}
