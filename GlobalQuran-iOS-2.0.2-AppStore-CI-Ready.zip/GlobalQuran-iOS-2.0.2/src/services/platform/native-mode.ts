/**
 * Global Quran - Native adapter mode detection.
 *
 * The app runs in two modes:
 * - Web: API calls go to the Next.js server routes (relative /api/ paths).
 * - Native (Capacitor): the app is a static bundle inside the Android/iOS
 *   app; there is no server, so /api/ calls are served by the client-side
 *   native adapter (src/services/native/).
 *
 * A `?nativeSim=1` query flag forces the native adapter while running in a
 * normal browser. This exists so the whole client-side data path can be
 * exercised and verified in a desktop browser during development (the
 * adapter detects the simulation and stays honest about the one capability
 * a plain browser cannot provide - see native/http.ts).
 */

import { Capacitor } from '@capacitor/core'

let simulationForced = false

/** Force (or clear) native-adapter simulation mode at runtime. */
export function setNativeSimulation(enabled: boolean): void {
  simulationForced = enabled
}

function readSimulationFlagFromLocation(): boolean {
  try {
    return new URLSearchParams(window.location.search).has('nativeSim')
  } catch {
    return false
  }
}

/**
 * True when /api/ calls must be served by the client-side native adapter.
 * Inside the Capacitor WebView this is Capacitor's own native-platform
 * detection; in a browser it is only ever true with the explicit
 * development flag.
 */
export function isNativeAdapterActive(): boolean {
  if (typeof window === 'undefined') return false
  if (simulationForced || readSimulationFlagFromLocation()) return true
  try {
    return Capacitor.isNativePlatform()
  } catch {
    return false
  }
}

/** True only inside the real Capacitor native runtime (not the simulation). */
export function isRealNativePlatform(): boolean {
  if (typeof window === 'undefined') return false
  try {
    return Capacitor.isNativePlatform()
  } catch {
    return false
  }
}

/**
 * True inside the Android native app only. Used for capabilities that
 * are Android-specific (e.g. the alarm-output Adhan note) so a claim is
 * never shown on a platform where it would be false.
 */
export function isAndroidNativeShell(): boolean {
  if (!isRealNativePlatform()) return false
  try {
    return Capacitor.getPlatform() === 'android'
  } catch {
    return false
  }
}

/**
 * True inside the iOS native app only. Used to route iOS-specific
 * integrations (native Adhan volume playback, AVAudioSession control).
 */
export function isIosNativeShell(): boolean {
  if (!isRealNativePlatform()) return false
  try {
    return Capacitor.getPlatform() === 'ios'
  } catch {
    return false
  }
}
