/**
 * Global Quran - AdhanScheduler Capacitor plugin (JS interface).
 *
 * PROMPT 16: native Android scheduling for prayer/Adhan reminders. The
 * Kotlin implementation lives in the Android project
 * (android/app/src/main/java/com/globalquran/app/plugins/AdhanSchedulerPlugin.kt)
 * and is registered from MainActivity.
 *
 * This module only DECLARES the interface. On platforms without the native
 * implementation (web/PWA, iOS until implemented) the calls reject with
 * `unimplemented` - the app treats that honestly as "native scheduling
 * unavailable" and falls back to the foreground web scheduler, never
 * claiming capabilities the platform does not provide.
 */

import { registerPlugin, type Plugin, type PluginListenerHandle } from '@capacitor/core'

export type ForegroundFirePayload = {
  /** The full snapshotted event that fired (see NativeReminderEvent). */
  event: NativeReminderEvent
}

export interface NativeReminderEvent {
  /** Stable id for this single fire (epoch ms of the slot + slot key). */
  id: string
  /** Epoch milliseconds (UTC) when the reminder must fire. */
  at: number
  /** Which prayer slot this is. */
  slot: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'
  /** The slot's ISO instant (dedupe key, also used for quiet-hours context). */
  slotIso: string
  /** IANA zone of the location (quiet-hours + notification formatting). */
  timeZone: string | null
  /** 'audio' = full Adhan from the local library; 'silent' = notification only. */
  mode: 'audio' | 'silent'
  /** Assigned verified recording id (audio mode); null = none selected. */
  adhanId: string | null
  /** Playback volume 0..1 for the in-app foreground path. */
  volume: number
  /** Localized texts snapshotted at sync time. */
  title: string
  bodyPlaying: string
  bodyUnavailable: string
  bodyFallback: string
  bodySilent: string
  /** Quiet-hours window evaluated at fire time in the event's zone. */
  quiet: { enabled: boolean; start: string; end: string } | null
}

export interface NativeReminderSyncPayload {
  version: 1
  generatedAt: number
  events: NativeReminderEvent[]
}

export interface NativeSchedulerStatus {
  /** Native scheduling is available on this platform. */
  available: true
  /** Number of stored (future) events. */
  eventCount: number
  /** Epoch ms of the next scheduled fire (null when none). */
  nextAt: number | null
  /** Slot key of the next scheduled fire (null when none). */
  nextSlot: string | null
  /** IANA zone of the next scheduled fire (null when none). */
  nextTimeZone: string | null
  /** Whether the next fire uses alarm-clock-grade exact scheduling. */
  exact: boolean
  /** How many days ahead the stored schedule reaches (0 when empty). */
  horizonDays: number
  /** Notification permission state on Android 13+. */
  notificationPermission: 'granted' | 'denied' | 'unavailable'
  /** Whether the app is currently in the foreground. */
  foreground: boolean
}

export interface FileChunkPayload {
  /** Adhan recording id (final file name = <id>.mp3). */
  adhanId: string
  /** Chunk index (0-based, sequential). */
  offset: number
  /** Base64 of this chunk. */
  base64: string
}

export interface FinalizeFilePayload {
  adhanId: string
  /** Expected total size in bytes (verification on the native side too). */
  sizeBytes: number
  /** Human label for the notification channel (muezzin / recording title). */
  label?: string
}

export interface AdhanSchedulerPlugin extends Plugin {
  /** Replace the whole schedule atomically. Empty events = full cancel. */
  sync(payload: NativeReminderSyncPayload): Promise<{ stored: number }>
  /** Read-only status for UI. */
  status(): Promise<NativeSchedulerStatus>
  /** Request POST_NOTIFICATIONS on Android 13+ (resolves with the result). */
  requestNotificationPermission(): Promise<{ granted: boolean }>
  /** First chunk of a mirror write (starts a fresh temp file). */
  beginFile(payload: { adhanId: string }): Promise<void>
  /** Append one chunk (must follow beginFile in order). */
  writeFileChunk(payload: FileChunkPayload): Promise<void>
  /** Verify size, move temp -> final, (re)create the sound channel. */
  finalizeFile(payload: FinalizeFilePayload): Promise<{ ok: boolean }>
  /** Remove the mirrored file + its channel (recording deleted by the user). */
  deleteFile(payload: { adhanId: string }): Promise<void>
  /** Which recordings currently have a verified native mirror. */
  listFiles(): Promise<{ files: Array<{ adhanId: string; sizeBytes: number }> }>
  /** Test helper: fire the next event now (never in production paths). */
  debugFireNext(): Promise<void>
  /**
   * iOS extension (no equivalent on Android, where the WebView audio path
   * already honors volume): play a verified native mirror with REAL
   * per-stream volume — WKWebView cannot control HTMLAudioElement volume,
   * so the iOS foreground Adhan routes through the native player.
   * Resolves { playing: false } when no usable mirror exists (the caller
   * falls back to the shared web player).
   */
  playMirrored(payload: { adhanId: string; volume: number }): Promise<{ playing: boolean }>
  /** Stop the native foreground playback (iOS extension). */
  stopMirroredPlayback(): Promise<{ stopped: boolean }>
  /** Listen for native playback completion (iOS extension). */
  addListener(
    eventName: 'foregroundFire',
    listenerFunc: (event: ForegroundFirePayload) => void,
  ): Promise<PluginListenerHandle>
  /** Playback-completed event (iOS extension, 'playbackEnded'). */
  addListener(
    eventName: 'playbackEnded',
    listenerFunc: (event: { ended: true }) => void,
  ): Promise<PluginListenerHandle>
  removeAllListeners(): Promise<void>
}

export type ForegroundFireEventName = 'foregroundFire'

export const AdhanScheduler = registerPlugin<AdhanSchedulerPlugin>('AdhanScheduler', {
  web: () => import('./adhan-scheduler-web').then((m) => new m.AdhanSchedulerWeb()),
})

/** Probe helper: is the native implementation present on this device?
 * A rejected `status()` call means the plugin is unavailable - never a crash. */
export async function probeAdhanScheduler(): Promise<boolean> {
  try {
    await AdhanScheduler.status()
    return true
  } catch {
    return false
  }
}
