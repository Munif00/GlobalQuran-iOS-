/**
 * Global Quran - AudioSessionBridge plugin interface (custom Capacitor
 * plugin, iOS only).
 *
 * Lets the shared web audio engines manage the app's AVAudioSession so
 * WebView (WKWebView) media can continue in the background / with the
 * screen locked, where iOS permits it:
 *
 *  - activate: category .playback + setActive(true) — audible with the
 *    Ring/Silent switch set to silent (the same user expectation as
 *    Android's media stream) and eligible for background playback with
 *    the `audio` UIBackgroundModes entry.
 *  - deactivate: setActive(false, notifyOthersOnDeactivation) — a fully
 *    stopped player politely releases audio focus.
 *
 * Every helper is a no-op on Android and web (the plugin exists only in
 * the iOS app; Android's WebView media stack needs no equivalent), so
 * the shipped Android 2.0.2 behavior is untouched.
 */

import { registerPlugin } from '@capacitor/core'

import { Capacitor } from '@capacitor/core'
import { isRealNativePlatform } from '@/services/platform/native-mode'

export interface AudioSessionBridgeInterface {
  /** Activate/deactivate the .playback audio session. */
  setPlaybackActive(options: { active: boolean }): Promise<{ active: boolean }>
  /** Read the tracked session state (honest: reports the last transition). */
  isPlaybackActive(): Promise<{ active: boolean; category: string }>
}

const AudioSessionBridgeNative = registerPlugin<AudioSessionBridgeInterface>('AudioSessionBridge')

/** True only inside the iOS native app. */
function isIosNative(): boolean {
  if (typeof window === 'undefined') return false
  if (!isRealNativePlatform()) return false
  try {
    return Capacitor.getPlatform() === 'ios'
  } catch {
    return false
  }
}

/**
 * Activate (.playback) or deactivate the audio session. Best-effort and
 * iOS-gated: a rejection is swallowed (the WebView audio itself is not
 * blocked by a failed session transition), Android/web are no-ops.
 */
export async function setWebAudioSessionActive(active: boolean): Promise<void> {
  if (!isIosNative()) return
  try {
    await AudioSessionBridgeNative.setPlaybackActive({ active })
  } catch {
    /* honest best-effort: background playback is a best-case capability */
  }
}
