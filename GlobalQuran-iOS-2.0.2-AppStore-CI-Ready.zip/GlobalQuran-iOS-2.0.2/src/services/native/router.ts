/**
 * Global Quran - Native adapter API router (full implementation).
 *
 * In native mode (the Capacitor app, or `?nativeSim=1` during development)
 * there is no Next.js server, so every same-origin `/api/...` request made
 * through `platformFetch` is dispatched here instead of `fetch`.
 *
 * Each handler reproduces its server route's exact behavior (validation,
 * response envelope, status codes, honest failure states) by composing the
 * SAME isomorphic modules the server uses:
 *
 *   - the hybrid prayer engine (src/lib/prayer-engine/*) with an IndexedDB
 *     cache backend (./prayer-cache) and a native geocoding transport;
 *   - the QuranEnc client (src/server/quranenc/client.ts - no Node APIs,
 *     the API host sends CORS `Access-Control-Allow-Origin: *`);
 *   - the audio catalogs (src/server/audio/* - static verified inventories
 *     plus live checks against CORS-open hosts);
 *   - the export document builders (src/lib/quran-export/builders.ts).
 *
 * Hosts that do NOT send CORS headers (cdn.aladhan.com, the QuranEnc file
 * host, the d.quranenc.com MP3 files) are fetched through CapacitorHttp on
 * a real device (./http). In the desktop simulation those fetches fail
 * honestly - no response is ever fabricated.
 *
 * Differences from the web server, all deliberate and honest:
 *   - no per-IP rate limiting (single-user app);
 *   - no admin verification registry (empty overrides - identical to an
 *     empty web registry);
 *   - no CatalogSync persistence (lastSyncedAt reflects this session).
 */

import {
  PRAYER_METHODS,
  METHODS_VERIFIED_AT,
  METHODS_VERIFIED_FROM,
} from '@/lib/prayer/methods'
import { countryDefaultsForApi } from '@/lib/prayer/country-methods'
import {
  JAKIM_ZONES,
  OFFICIAL_AUTHORITY_REGISTRY,
  REGISTRY_SUMMARY,
} from '@/lib/prayer/authorities'
import { resolvePrayerDay, resolvePrayerMonth } from '@/lib/prayer-engine/resolver'
import { parsePrayerQuery } from '@/lib/prayer-engine/request'
import { reverseGeocode, searchCities, type GeocodingTransport } from '@/lib/prayer-engine/geocoding'
import { fetchJsonWithTimeout } from '@/lib/prayer-engine/types'

import {
  QURANENC_API_DOCS_URL,
  QURANENC_SITE_URL,
  QuranEncUpstreamError,
  TRANSLATION_KEY_PATTERN,
  getIsoCodes,
  getMergedTranslationsList,
  getSuraNames,
  getSuraTranslation,
} from '@/server/quranenc/client'
import {
  EMPTY_VERIFICATION_OVERRIDES,
  buildLanguageSummary,
  mapTranslation,
  prettifyLanguageName,
} from '@/server/quranenc/mappers'

import {
  ADHAN_CATALOG,
  ADHAN_LICENSE_NOTE,
  ADHAN_SOURCE_PAGE,
  getAdhanById,
  isVerifiedAdhanUrl,
} from '@/server/audio/adhan-catalog'
import { getAllStyleSummaries, getStyleSummary, getSuraAudioFiles } from '@/server/audio/catalog'
import { verifyStyleLive, verifySuraLive } from '@/server/audio/everyayah'
import {
  QURANENC_AUDIO_DASHBOARD_URL,
  getTranslationAudioCatalog,
  getTranslationAudioInventory,
  getTranslationFilesManifest,
  probeTranslationAudioSizes,
  quranEncTranslationAudioUrl,
} from '@/server/audio/translation-audio'
import { getStyleDefinition, isKnownStyleId } from '@/data/audio-styles'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { getJuzPositions } from '@/data/juz-index'
import { SURA_INDEX } from '@/data/sura-index'

import {
  RIGHTS_NOTICE,
  buildDocxExport,
  buildFileStem,
  buildHtmlExport,
  buildJsonExport,
  buildTxtExport,
  contentDisposition,
  type ExportAya,
  type ExportMeta,
  type ExportSura,
} from '@/lib/quran-export/builders'

import { buildAppConfigPayload } from '@/lib/app-config-payload'
import { INTERFACE_LANGUAGE_COUNT, RECITATION_STYLE_COUNT } from '@/data/capability-matrix'
import { RECITATION_STYLES } from '@/data/audio-styles'
import { hasTranslations } from '@/i18n'
import { SUPPORTED_LOCALES, FALLBACK_LOCALE } from '@/i18n/config'

import { isRealNativePlatform } from '@/services/platform/native-mode'
import { isNativeHttpAvailable, nativeGetBinary, nativeHead } from './http'
import { registerNativePrayerCache } from './prayer-cache'
/* ------------------------------------------------------------------ */
/* Response helpers                                                    */
/* ------------------------------------------------------------------ */

function jsonResponse(body: unknown, status = 200, headers?: Record<string, string>): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...(headers ?? {}) },
  })
}

function messageResponse(message: string, status: number): Response {
  return jsonResponse({ message }, status)
}

/** UTF-8 byte length (Buffer is unavailable in the browser runtime). */
function byteLength(value: string): number {
  return new TextEncoder().encode(value).length
}

/* ------------------------------------------------------------------ */
/* Native transports for the shared engines                            */
/* ------------------------------------------------------------------ */

/**
 * Geocoding transport: on a real device the identifying User-Agent header
 * (Nominatim usage policy) is sent through the native HTTP stack - browsers
 * forbid setting User-Agent on fetch. In the desktop simulation the plain
 * fetch transport is used (requests still work; the UA is the browser's).
 */
const nativeGeocodingTransport: GeocodingTransport = async (url, timeoutMs, init) => {
  if (!isNativeHttpAvailable()) {
    return fetchJsonWithTimeout(url, timeoutMs, init)
  }
  try {
    const { CapacitorHttp } = await import('@capacitor/core')
    const headerInit = (init?.headers ?? {}) as Record<string, string>
    const response = await CapacitorHttp.request({
      url,
      method: 'GET',
      headers: { Accept: 'application/json', ...headerInit },
      responseType: 'json',
      connectTimeout: timeoutMs,
      readTimeout: timeoutMs,
    })
    if (response.status >= 200 && response.status < 300) {
      return { ok: true, data: response.data }
    }
    return { ok: false, failure: { reason: 'network_error', detail: `HTTP ${response.status}` } }
  } catch {
    return { ok: false, failure: { reason: 'network_error' } }
  }
}

/* ------------------------------------------------------------------ */
/* Adapter boot                                                        */
/* ------------------------------------------------------------------ */

let booted = false

function ensureAdapterBoot(): void {
  if (booted) return
  booted = true
  registerNativePrayerCache()
}

/* ------------------------------------------------------------------ */
/* Route helpers (mirror the server routes' validation exactly)        */
/* ------------------------------------------------------------------ */

/** Parse a `bytes=N-` Range header start offset (offline-pack resume). */
function parseRangeStart(header: string | null): number | null {
  if (!header) return null
  const match = /^bytes=(\d+)-/.exec(header.trim())
  if (!match) return null
  const start = Number(match[1])
  return Number.isSafeInteger(start) && start >= 0 ? start : null
}

/** The strict single Range form the download proxies accept. */
function safeRangeHeader(header: string | null): string | null {
  if (header === null) return null
  return /^bytes=\d{0,15}-(\d{0,15})?$/.test(header.trim()) ? header.trim() : null
}

function headerOf(init: RequestInit | undefined, name: string): string | null {
  const raw = init?.headers
  if (!raw) return null
  const map = new Headers(raw)
  return map.get(name)
}

/**
 * Fetch a binary file from an upstream host, honoring the proxy contract
 * (Range pass-through, content-type/length/range headers, 200/206).
 *
 * `mode` decides the transport:
 * - 'native-only': the host sends no CORS headers; CapacitorHttp is
 *   required (real device). In the desktop simulation this fails honestly.
 * - 'cors': the host sends CORS headers; the WebView fetch works (and the
 *   simulation too).
 */
async function fetchBinaryProxied(
  url: string,
  init: RequestInit | undefined,
  options: {
    mode: 'native-only' | 'cors'
    timeoutMs: number
    accept: string
    fallbackFileName: string
    /** Serves HEAD-style: headers only, body omitted (seed sizes instead). */
    headOnly?: { contentLength: number }
  },
): Promise<Response> {
  const range = safeRangeHeader(headerOf(init, 'range'))

  if (options.mode === 'native-only') {
    if (!isNativeHttpAvailable()) {
      return messageResponse(
        'This file cannot be fetched in the browser simulation (the source host does not allow cross-origin requests). It works on the device.',
        502,
      )
    }
    try {
      const result = await nativeGetBinary(url, {
        timeoutMs: options.timeoutMs,
        headers: {
          Accept: options.accept,
          ...(range ? { Range: range } : {}),
        },
      })
      if (!result || (result.status !== 200 && result.status !== 206)) {
        return messageResponse('The file could not be fetched from the source.', 502)
      }
      const headers = new Headers()
      headers.set('Content-Type', result.headers['content-type'] ?? 'application/octet-stream')
      const length = result.headers['content-length']
      if (length) headers.set('Content-Length', length)
      const contentRange = result.headers['content-range']
      if (contentRange) headers.set('Content-Range', contentRange)
      const acceptRanges = result.headers['accept-ranges']
      if (acceptRanges) headers.set('Accept-Ranges', acceptRanges)
      if (!range) {
        headers.set(
          'Content-Disposition',
          `attachment; filename="${options.fallbackFileName}"`,
        )
      }
      headers.set('Cache-Control', 'no-store')
      return new Response(new Blob([result.bytes]), { status: result.status === 206 ? 206 : 200, headers })
    } catch {
      return messageResponse('The file could not be fetched from the source.', 502)
    }
  }

  /* CORS-open host: the WebView's own fetch. */
  try {
    const upstream = await fetch(url, {
      credentials: 'omit',
      cache: 'no-store',
      signal: AbortSignal.timeout(options.timeoutMs),
      headers: {
        Accept: options.accept,
        ...(range ? { Range: range } : {}),
      },
    })
    if (!upstream.ok && upstream.status !== 206) {
      return messageResponse('The file could not be fetched from the source.', 502)
    }
    const headers = new Headers()
    headers.set('Content-Type', upstream.headers.get('content-type') ?? 'application/octet-stream')
    const contentLength = upstream.headers.get('content-length')
    if (contentLength) headers.set('Content-Length', contentLength)
    const contentRange = upstream.headers.get('content-range')
    if (contentRange) headers.set('Content-Range', contentRange)
    const acceptRanges = upstream.headers.get('accept-ranges')
    if (acceptRanges) headers.set('Accept-Ranges', acceptRanges)
    if (!range) {
      headers.set(
        'Content-Disposition',
        `attachment; filename="${options.fallbackFileName}"`,
      )
    }
    headers.set('Cache-Control', 'no-store')
    return new Response(upstream.body, {
      status: upstream.status === 206 ? 206 : 200,
      headers,
    })
  } catch {
    return messageResponse('The file could not be fetched from the source.', 502)
  }
}

/* ------------------------------------------------------------------ */
/* Prayer routes                                                       */
/* ------------------------------------------------------------------ */

async function handlePrayerTimes(pathname: string, searchParams: URLSearchParams): Promise<Response> {
  const parsed = parsePrayerQuery(searchParams)
  if (!parsed.ok) {
    return jsonResponse(
      { status: 'unavailable', message: null, messageKey: parsed.errorKey, record: null, source: null },
      400,
    )
  }
  const { date, ctx } = parsed.value
  if (!date) {
    return jsonResponse(
      { status: 'unavailable', message: null, messageKey: 'prayer.error.badRequest', record: null, source: null },
      400,
    )
  }
  const response = await resolvePrayerDay(date, ctx)
  return jsonResponse(response, response.status === 'live' ? 200 : 503)
}

async function handlePrayerCalendar(searchParams: URLSearchParams): Promise<Response> {
  const parsed = parsePrayerQuery(searchParams)
  if (!parsed.ok) {
    return jsonResponse(
      {
        status: 'unavailable',
        message: null,
        messageKey: parsed.errorKey,
        month: searchParams.get('month') ?? '',
        days: [],
        source: null,
      },
      400,
    )
  }
  const { month, ctx } = parsed.value
  if (!month) {
    return jsonResponse(
      {
        status: 'unavailable',
        message: null,
        messageKey: 'prayer.error.badRequest',
        month: '',
        days: [],
        source: null,
      },
      400,
    )
  }
  const response = await resolvePrayerMonth(month, ctx)
  return jsonResponse(response, response.status === 'live' ? 200 : 503)
}

async function handlePrayerGeocode(searchParams: URLSearchParams): Promise<Response> {
  const query = searchParams.get('q') ?? ''
  if (query.length > 100) {
    return jsonResponse({ status: 'degraded', messageKey: 'prayer.search.degraded', results: [] })
  }
  const outcome = await searchCities(query, nativeGeocodingTransport)
  return jsonResponse(outcome)
}

async function handlePrayerReverseGeocode(searchParams: URLSearchParams): Promise<Response> {
  const latitude = Number(searchParams.get('latitude'))
  const longitude = Number(searchParams.get('longitude'))
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
    return jsonResponse(
      { status: 'unavailable', city: null, region: null, countryName: null, countryCode: null },
      400,
    )
  }
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    return jsonResponse(
      { status: 'unavailable', city: null, region: null, countryName: null, countryCode: null },
      400,
    )
  }
  const outcome = await reverseGeocode(latitude, longitude, nativeGeocodingTransport)
  return jsonResponse(outcome, outcome.status === 'live' ? 200 : 503)
}

/* ------------------------------------------------------------------ */
/* Adhan catalog + file                                                */
/* ------------------------------------------------------------------ */

/**
 * HEAD probe of one Adhan CDN file. cdn.aladhan.com sends no CORS headers,
 * so the probe runs through the native stack on a real device; everywhere
 * else it fails (null) and the verified seed size is used.
 */
async function probeAdhanSizeNative(url: string): Promise<number | null> {
  if (!isNativeHttpAvailable()) return null
  try {
    const head = await nativeHead(url, { timeoutMs: 8_000, headers: { Accept: 'audio/mpeg, */*' } })
    if (!head || (head.status !== 200 && head.status !== 206)) return null
    const length = Number(head.headers['content-length'])
    return Number.isFinite(length) && length > 0 ? length : null
  } catch {
    return null
  }
}

async function handleAdhanCatalog(): Promise<Response> {
  let reachable = true
  const recordings = await Promise.all(
    ADHAN_CATALOG.map(async (entry) => {
      const liveSize = await probeAdhanSizeNative(entry.url)
      if (liveSize === null) {
        reachable = false
        return entry
      }
      return { ...entry, sizeBytes: liveSize }
    }),
  )
  return jsonResponse(
    {
      status: 'live',
      source: 'AlAdhan',
      sourceUrl: ADHAN_SOURCE_PAGE,
      licenseNote: ADHAN_LICENSE_NOTE,
      sourceReachable: reachable,
      recordings,
    },
    200,
    { 'cache-control': 'no-store' },
  )
}

async function handleAdhanFile(adhanId: string, init: RequestInit | undefined): Promise<Response> {
  const entry = getAdhanById(adhanId)
  if (!entry) {
    return messageResponse('No verified Adhan recording with this id.', 404)
  }
  if (!isVerifiedAdhanUrl(entry.url)) {
    return messageResponse('Blocked audio URL.', 400)
  }
  if ((init?.method ?? 'GET').toUpperCase() === 'HEAD') {
    return new Response(null, {
      status: 200,
      headers: {
        'content-length': String(entry.sizeBytes),
        'content-type': 'audio/mpeg',
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
      },
    })
  }
  return fetchBinaryProxied(entry.url, init, {
    mode: 'native-only',
    timeoutMs: 180_000,
    accept: 'audio/mpeg, */*',
    fallbackFileName: entry.fileName,
  })
}

/* ------------------------------------------------------------------ */
/* QuranEnc content routes                                             */
/* ------------------------------------------------------------------ */

async function handleSowarNames(searchParams: URLSearchParams): Promise<Response> {
  const locale = searchParams.get('locale') ?? 'en'
  try {
    const { names, effectiveLocale } = await getSuraNames(locale)
    return jsonResponse({ status: 'live', locale, effectiveLocale, names })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return messageResponse('Sura names could not be loaded from the source.', 502)
    }
    return messageResponse('Sura names could not be loaded.', 500)
  }
}

async function handleSuraContent(translationKey: string, suraNumber: number): Promise<Response> {
  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return messageResponse('Invalid translation key.', 400)
  }
  if (!Number.isInteger(suraNumber) || suraNumber < 1 || suraNumber > 114) {
    return messageResponse('Invalid sura number.', 400)
  }
  try {
    const [result, listResult] = await Promise.all([
      getSuraTranslation(translationKey, suraNumber),
      getMergedTranslationsList('en').catch(() => null),
    ])
    const meta = listResult?.translations.find((item) => item.key === translationKey) ?? null
    if (result.ayat.length === 0) {
      return messageResponse('This sura is not available in the selected translation.', 404)
    }
    return jsonResponse({
      status: 'live',
      source: 'QuranEnc API v1',
      translationKey,
      translationTitle: meta?.title ?? null,
      languageCode: meta?.language_iso_code ?? null,
      direction: meta?.direction === 'rtl' ? 'rtl' : 'ltr',
      sura: suraNumber,
      ayahCount: result.ayat.length,
      version: meta?.version ?? null,
      ayat: result.ayat,
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return messageResponse('The translation content could not be fetched from QuranEnc.', 502)
    }
    return messageResponse('The sura content could not be loaded.', 500)
  }
}

async function handleTranslationsCatalog(searchParams: URLSearchParams): Promise<Response> {
  const localization = searchParams.get('localization') ?? 'en'
  try {
    const [{ translations, servedFromCache }, isoCodes] = await Promise.all([
      getMergedTranslationsList(localization),
      getIsoCodes(),
    ])
    const lastCheckedAt = new Date().toISOString()
    const items = translations.map((item) =>
      mapTranslation(item, isoCodes.codeToName, EMPTY_VERIFICATION_OVERRIDES, lastCheckedAt),
    )
    const languages = buildLanguageSummary(items, isoCodes.codeToName)
    return jsonResponse({
      status: 'live',
      source: 'QuranEnc API v1',
      sourceUrl: QURANENC_API_DOCS_URL,
      message: `${items.length} translations in ${languages.length} languages, synchronized from QuranEnc.`,
      items,
      languages,
      total: items.length,
      lastSyncedAt: servedFromCache ? null : lastCheckedAt,
      lastCheckedAt,
      servedFromCache,
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return jsonResponse(
        {
          status: 'not_integrated',
          source: 'QuranEnc API v1',
          sourceUrl: QURANENC_API_DOCS_URL,
          message: 'The QuranEnc catalog is temporarily unreachable. Please try again shortly.',
          items: [],
          languages: [],
          total: 0,
          lastSyncedAt: null,
          lastCheckedAt: null,
          servedFromCache: false,
        },
        502,
      )
    }
    return jsonResponse(
      {
        status: 'not_integrated',
        source: 'QuranEnc API v1',
        sourceUrl: QURANENC_API_DOCS_URL,
        message: 'The catalog could not be loaded. Please try again.',
        items: [],
        languages: [],
        total: 0,
        lastSyncedAt: null,
        lastCheckedAt: null,
        servedFromCache: false,
      },
      500,
    )
  }
}

/* ------------------------------------------------------------------ */
/* Offline pack + export                                               */
/* ------------------------------------------------------------------ */

const PACK_CONCURRENCY = 8
const ALL_SURAS = Array.from({ length: 114 }, (_, index) => index + 1)

interface PackSura {
  sura: number
  ayahCount: number
  ayat: Array<{ sura: number; aya: number; arabicText: string; translation: string; footnotes: string | null }>
}

async function fetchPackSura(translationKey: string, sura: number): Promise<PackSura | null> {
  const { ayat } = await getSuraTranslation(translationKey, sura)
  if (ayat.length === 0) return null
  return {
    sura,
    ayahCount: ayat.length,
    ayat: ayat.map((aya) => ({
      sura: aya.sura,
      aya: aya.aya,
      arabicText: aya.arabicText,
      translation: aya.translation,
      footnotes: aya.footnotes,
    })),
  }
}

/** Composed packs are memoized so HEAD probe + GET download share one aggregation. */
const packMemo = new Map<string, { bytes: Uint8Array<ArrayBuffer>; length: number }>()

async function buildOfflinePack(translationKey: string): Promise<{ bytes: Uint8Array<ArrayBuffer>; length: number } | Response> {
  const memo = packMemo.get(translationKey)
  if (memo) return memo

  const listResult = await getMergedTranslationsList('en').catch(() => null)
  const meta = listResult?.translations.find((item) => item.key === translationKey) ?? null
  if (listResult && listResult.translations.length > 0 && meta === null) {
    return messageResponse('This translation is not available at the source.', 404)
  }

  const results: Array<PackSura | null> = new Array(ALL_SURAS.length).fill(null)
  let cursor = 0
  const workers = Array.from({ length: PACK_CONCURRENCY }, async () => {
    for (;;) {
      const index = cursor++
      if (index >= ALL_SURAS.length) break
      results[index] = await fetchPackSura(translationKey, ALL_SURAS[index])
    }
  })
  await Promise.all(workers)

  if (results.every((sura) => sura === null)) {
    return messageResponse('This translation is not available at the source.', 404)
  }

  const suras = results.filter((sura): sura is PackSura => sura !== null)
  const payload = {
    status: 'live' as const,
    source: 'QuranEnc API v1',
    translationKey,
    translationTitle: meta?.title ?? null,
    languageCode: meta?.language_iso_code ?? null,
    direction: meta?.direction === 'rtl' ? 'rtl' : 'ltr',
    version: typeof meta?.version === 'string' && meta.version.length > 0 ? meta.version : null,
    totalSuras: 114,
    suraCount: suras.length,
    suras,
  }
  const bytes = new TextEncoder().encode(JSON.stringify(payload))
  const composed = { bytes, length: bytes.byteLength }
  if (packMemo.size > 4) packMemo.clear()
  packMemo.set(translationKey, composed)
  return composed
}

async function handleOfflinePack(
  translationKey: string,
  init: RequestInit | undefined,
): Promise<Response> {
  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return messageResponse('Invalid translation key', 400)
  }
  try {
    const composed = await buildOfflinePack(translationKey)
    if (composed instanceof Response) return composed
    const { bytes, length } = composed

    if ((init?.method ?? 'GET').toUpperCase() === 'HEAD') {
      return new Response(null, {
        status: 200,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'content-length': String(length),
          'accept-ranges': 'bytes',
          'cache-control': 'no-store',
        },
      })
    }

    const rangeStart = parseRangeStart(headerOf(init, 'range'))
    if (rangeStart !== null && rangeStart > 0 && rangeStart < length) {
      const slice = bytes.subarray(rangeStart)
      return new Response(new Blob([slice]), {
        status: 206,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'content-length': String(slice.byteLength),
          'content-range': `bytes ${rangeStart}-${length - 1}/${length}`,
          'accept-ranges': 'bytes',
          'cache-control': 'no-store',
        },
      })
    }
    return new Response(new Blob([bytes]), {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'content-length': String(length),
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
      },
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return messageResponse('The offline copy could not be built from the source.', 502)
    }
    return messageResponse('The offline copy could not be built.', 500)
  }
}

/* ------------------------- export ------------------------- */

const EXPORT_FORMATS = ['docx', 'txt', 'json', 'html'] as const
type ExportFormat = (typeof EXPORT_FORMATS)[number]
const EXPORT_BATCH_SIZE = 6
const EXPORT_TIME_LIMIT_MS = 4 * 60 * 1000

class ExportTimeoutError extends Error {
  constructor() {
    super('Export deadline exceeded')
    this.name = 'ExportTimeoutError'
  }
}

class ExportIncompleteError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ExportIncompleteError'
  }
}

class ExportNotFoundError extends Error {
  constructor() {
    super('Translation not found in the catalog')
    this.name = 'ExportNotFoundError'
  }
}

interface AggregatedExport {
  meta: ExportMeta
  suras: ExportSura[]
  stem: string
}

/** Aggregation memo: probe + real export share one upstream pass. */
let exportMemo: { key: string; localization: string; value: AggregatedExport } | null = null

async function aggregateTranslationExport(
  translationKey: string,
  localization: string,
): Promise<AggregatedExport> {
  if (
    exportMemo &&
    exportMemo.key === translationKey &&
    exportMemo.localization === localization
  ) {
    return exportMemo.value
  }

  const [{ translations }, isoCodes] = await Promise.all([
    getMergedTranslationsList(localization),
    getIsoCodes(),
  ])
  const catalogItem = translations.find((item) => item.key === translationKey)
  if (!catalogItem) throw new ExportNotFoundError()

  const languageName = prettifyLanguageName(
    isoCodes.codeToName[catalogItem.language_iso_code] ?? catalogItem.language_iso_code,
  )
  const lastUpdate =
    typeof catalogItem.last_update === 'number'
      ? new Date(catalogItem.last_update * 1000).toISOString()
      : null

  const deadline = Date.now() + EXPORT_TIME_LIMIT_MS
  const suras: ExportSura[] = []
  for (let start = 1; start <= 114; start += EXPORT_BATCH_SIZE) {
    if (Date.now() > deadline) throw new ExportTimeoutError()
    const batchNumbers: number[] = []
    for (let n = start; n < Math.min(start + EXPORT_BATCH_SIZE, 115); n += 1) {
      batchNumbers.push(n)
    }
    const results = await Promise.all(
      batchNumbers.map((n) => getSuraTranslation(translationKey, n)),
    )
    for (let index = 0; index < results.length; index += 1) {
      const suraNumber = batchNumbers[index]
      const result = results[index]
      if (result.ayat.length === 0) {
        throw new ExportIncompleteError(`Sura ${suraNumber} returned no ayat at the source.`)
      }
      const suraMeta = SURA_INDEX[suraNumber - 1]
      suras.push({
        number: suraNumber,
        nameArabic: suraMeta.nameArabic,
        nameEnglish: suraMeta.nameEnglish,
        ayahCount: result.ayat.length,
        ayat: result.ayat.map((aya): ExportAya => ({
          number: aya.aya,
          arabicText: aya.arabicText,
          translation: aya.translation,
          footnotes: aya.footnotes,
        })),
      })
    }
  }
  if (Date.now() > deadline) throw new ExportTimeoutError()

  const meta: ExportMeta = {
    key: translationKey,
    title: catalogItem.title ?? translationKey,
    languageCode: catalogItem.language_iso_code,
    languageName,
    direction: catalogItem.direction === 'rtl' ? 'rtl' : 'ltr',
    version: catalogItem.version ?? null,
    lastUpdate,
    exportedAt: new Date().toISOString(),
    source: QURANENC_SITE_URL,
    suraCount: suras.length,
    ayahCount: suras.reduce((total, sura) => total + sura.ayat.length, 0),
    rightsNotice: RIGHTS_NOTICE,
  }

  const value = { meta, suras, stem: buildFileStem(translationKey) }
  exportMemo = { key: translationKey, localization, value }
  return value
}

async function handleExport(
  translationKey: string,
  searchParams: URLSearchParams,
): Promise<Response> {
  const requestedFormat = searchParams.get('format') ?? ''
  const localization = searchParams.get('localization') ?? 'en'
  const isProbe = searchParams.get('probe') === '1'

  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return messageResponse('Invalid translation key.', 400)
  }
  const format = (EXPORT_FORMATS as readonly string[]).includes(requestedFormat)
    ? (requestedFormat as ExportFormat)
    : null
  if (!isProbe && !format) {
    return messageResponse(
      `Unsupported format. Available formats: ${EXPORT_FORMATS.join(', ')}.`,
      400,
    )
  }

  try {
    const { meta, suras, stem } = await aggregateTranslationExport(translationKey, localization)

    if (isProbe) {
      const [json, txt, html, docx] = await Promise.all([
        Promise.resolve(buildJsonExport(meta, suras)),
        Promise.resolve(buildTxtExport(meta, suras)),
        Promise.resolve(buildHtmlExport(meta, suras)),
        buildDocxExport(meta, suras),
      ])
      return jsonResponse(
        {
          translationKey,
          title: meta.title,
          version: meta.version,
          sizes: {
            json: byteLength(json),
            txt: byteLength(txt),
            html: byteLength(html),
            docx: docx.size,
          },
        },
        200,
        { 'cache-control': 'no-store' },
      )
    }

    if (format === 'json') {
      return new Response(buildJsonExport(meta, suras), {
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Disposition': contentDisposition(true, `${stem}.json`),
        },
      })
    }
    if (format === 'txt') {
      return new Response(buildTxtExport(meta, suras), {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Content-Disposition': contentDisposition(true, `${stem}.txt`),
        },
      })
    }
    if (format === 'docx') {
      const blob = await buildDocxExport(meta, suras)
      return new Response(blob, {
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'Content-Disposition': contentDisposition(true, `${stem}.docx`),
        },
      })
    }
    return new Response(buildHtmlExport(meta, suras), {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': contentDisposition(false, `${stem}.html`),
      },
    })
  } catch (error) {
    if (error instanceof ExportNotFoundError) {
      return messageResponse('This translation does not exist in the QuranEnc catalog.', 404)
    }
    if (error instanceof ExportTimeoutError) {
      return messageResponse(
        'The export took too long to fetch from the source and was aborted. Please try again - repeat exports are served from the cache.',
        502,
      )
    }
    if (error instanceof ExportIncompleteError) {
      return messageResponse(
        'The export could not be completed because the source returned incomplete content. No partial file was generated.',
        502,
      )
    }
    if (error instanceof Error && error.name === 'QuranEncUpstreamError') {
      return messageResponse(
        'The translation content could not be fetched from QuranEnc. Please check your connection and try again shortly.',
        502,
      )
    }
    return messageResponse('The export could not be generated.', 500)
  }
}

/* ------------------------------------------------------------------ */
/* Recitation audio (EveryAyah - CORS open)                            */
/* ------------------------------------------------------------------ */

async function handleReciters(): Promise<Response> {
  try {
    const styleIds = ['husary-muallim', 'abdulbasit-murattal', 'abdulbasit-mujawwad', 'hudhaify', 'salah-budair']
    const liveChecks = await Promise.all(styleIds.map((id) => verifyStyleLive(id).catch(() => null)))
    const liveResults = new Map<string, Awaited<ReturnType<typeof verifyStyleLive>> | null>()
    styleIds.forEach((id, index) => liveResults.set(id, liveChecks[index]))
    const styles = getAllStyleSummaries(liveResults)
    return jsonResponse({ styles })
  } catch {
    return messageResponse('The recitation catalog could not be loaded.', 500)
  }
}

async function handleSuraAudio(styleId: string, sura: number): Promise<Response> {
  if (!isKnownStyleId(styleId)) {
    return messageResponse('Unknown recitation style', 400)
  }
  if (getSuraAyahCount(sura) === 0) {
    return messageResponse('Invalid sura number', 400)
  }
  const style = getStyleDefinition(styleId) ?? null
  const summary = getSuraAudioFiles(styleId, sura)
  if (!summary) {
    return messageResponse('No verified audio inventory for this recitation style.', 404)
  }
  let live: Awaited<ReturnType<typeof verifySuraLive>> = null
  try {
    live = await verifySuraLive(styleId, sura)
  } catch {
    live = null
  }
  return jsonResponse({
    styleId,
    styleLabel: style?.styleLabel ?? null,
    reciterName: style?.reciterName ?? null,
    bitrate: style?.bitrate ?? null,
    folder: style?.folder ?? null,
    sourceName: style?.sourceName ?? null,
    sura: summary.sura,
    ayahCount: summary.ayahCount,
    availableAyat: summary.availableAyat,
    missingAyat: summary.missingAyat,
    totalBytes: summary.totalBytes,
    live,
    files: summary.files,
  })
}

async function handleAudioBatch(searchParams: URLSearchParams): Promise<Response> {
  const styleId = searchParams.get('styleId') ?? ''
  const kind = (searchParams.get('kind') ?? '') as string
  const suraParam = Number(searchParams.get('sura'))
  const ayahParam = Number(searchParams.get('ayah'))
  const fromParam = Number(searchParams.get('from'))
  const toParam = Number(searchParams.get('to'))
  const juzParam = Number(searchParams.get('juz'))

  if (!isKnownStyleId(styleId)) {
    return messageResponse('Unknown recitation style.', 400)
  }
  const style = getStyleDefinition(styleId)
  if (!style) {
    return messageResponse('Unknown recitation style.', 400)
  }

  let positions: Array<{ sura: number; ayah: number }> = []
  let batchSura: number | null = null
  let ayahFrom: number | null = null
  let ayahTo: number | null = null
  let juz: number | null = null

  switch (kind) {
    case 'ayah': {
      if (
        getSuraAyahCount(suraParam) === 0 ||
        !Number.isInteger(ayahParam) ||
        ayahParam < 1 ||
        ayahParam > getSuraAyahCount(suraParam)
      ) {
        return messageResponse('Invalid sura or ayah.', 400)
      }
      positions = [{ sura: suraParam, ayah: ayahParam }]
      batchSura = suraParam
      ayahFrom = ayahParam
      ayahTo = ayahParam
      break
    }
    case 'sura': {
      if (getSuraAyahCount(suraParam) === 0) {
        return messageResponse('Invalid sura.', 400)
      }
      positions = Array.from({ length: getSuraAyahCount(suraParam) }, (_, i) => ({
        sura: suraParam,
        ayah: i + 1,
      }))
      batchSura = suraParam
      break
    }
    case 'range': {
      if (getSuraAyahCount(suraParam) === 0) {
        return messageResponse('Invalid sura.', 400)
      }
      const suraLast = getSuraAyahCount(suraParam)
      if (
        !Number.isInteger(fromParam) ||
        !Number.isInteger(toParam) ||
        fromParam < 1 ||
        toParam < fromParam ||
        fromParam > suraLast
      ) {
        return messageResponse('Invalid ayah range.', 400)
      }
      const to = Math.min(toParam, suraLast)
      positions = []
      for (let ayah = fromParam; ayah <= to; ayah += 1) positions.push({ sura: suraParam, ayah })
      batchSura = suraParam
      ayahFrom = fromParam
      ayahTo = to
      break
    }
    case 'juz': {
      const juzPositions = getJuzPositions(juzParam)
      if (juzPositions.length === 0) {
        return messageResponse('Invalid juz number.', 400)
      }
      positions = juzPositions
      juz = juzParam
      break
    }
    case 'complete': {
      positions = []
      for (let sura = 1; sura <= 114; sura += 1) {
        for (let ayah = 1; ayah <= getSuraAyahCount(sura); ayah += 1) {
          positions.push({ sura, ayah })
        }
      }
      break
    }
    default:
      return messageResponse('Invalid batch kind.', 400)
  }

  const files: Array<{ sura: number; ayah: number; sizeBytes: number }> = []
  const missing: Array<{ sura: number; ayah: number }> = []
  const positionsBySura = new Map<number, number[]>()
  for (const position of positions) {
    const list = positionsBySura.get(position.sura)
    if (list) list.push(position.ayah)
    else positionsBySura.set(position.sura, [position.ayah])
  }
  for (const [sura, ayat] of positionsBySura) {
    const summary = getSuraAudioFiles(styleId, sura)
    if (!summary) {
      for (const ayah of ayat) missing.push({ sura, ayah })
      continue
    }
    for (const ayah of ayat) {
      const file = summary.files.find((entry) => entry.ayah === ayah)
      if (file) files.push({ sura, ayah, sizeBytes: file.sizeBytes })
      else missing.push({ sura, ayah })
    }
  }
  files.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)
  missing.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)
  const totalBytes = files.reduce((sum, file) => sum + file.sizeBytes, 0)

  return jsonResponse({
    styleId,
    reciterName: style.reciterName,
    styleLabel: style.styleLabel,
    folder: style.folder,
    sourceName: style.sourceName,
    batchKind: kind,
    sura: batchSura,
    ayahFrom,
    ayahTo,
    juz,
    files,
    totalFiles: files.length,
    totalBytes,
    missing,
    sourceComplete: missing.length === 0,
    completePackageOfferable: kind === 'complete' && files.length === 6236,
  })
}

async function handleAudioFile(
  styleId: string,
  sura: number,
  ayah: number,
  init: RequestInit | undefined,
): Promise<Response> {
  if (!isKnownStyleId(styleId)) {
    return messageResponse('Unknown recitation style.', 400)
  }
  if (getSuraAyahCount(sura) === 0 || !Number.isInteger(sura) || sura < 1) {
    return messageResponse('Invalid sura.', 400)
  }
  if (!Number.isInteger(ayah) || ayah < 1 || ayah > getSuraAyahCount(sura)) {
    return messageResponse('Invalid ayah.', 400)
  }
  const summary = getSuraAudioFiles(styleId, sura)
  const file = summary?.files.find((entry) => entry.ayah === ayah)
  if (!file) {
    return messageResponse('No verified audio file for this ayah at the source.', 404)
  }
  // URL allow-list guard (https + everyayah.com/data/).
  let parsed: URL
  try {
    parsed = new URL(file.url)
  } catch {
    return messageResponse('Blocked audio URL.', 400)
  }
  if (
    parsed.protocol !== 'https:' ||
    !['everyayah.com', 'www.everyayah.com'].includes(parsed.hostname) ||
    !parsed.pathname.startsWith('/data/')
  ) {
    return messageResponse('Blocked audio URL.', 400)
  }

  if ((init?.method ?? 'GET').toUpperCase() === 'HEAD') {
    return new Response(null, {
      status: 200,
      headers: {
        'content-length': String(file.sizeBytes),
        'content-type': 'audio/mpeg',
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
      },
    })
  }

  const fileName = parsed.pathname.split('/').pop() ?? 'audio.mp3'
  return fetchBinaryProxied(file.url, init, {
    mode: 'cors',
    timeoutMs: 120_000,
    accept: 'audio/mpeg, */*',
    fallbackFileName: fileName,
  })
}

/* ------------------------------------------------------------------ */
/* Translation audio (d.quranenc.com)                                  */
/* ------------------------------------------------------------------ */

async function handleTranslationAudioCatalog(): Promise<Response> {
  try {
    let translations: Awaited<ReturnType<typeof getTranslationAudioCatalog>>
    try {
      const [{ translations: textList }, isoCodes] = await Promise.all([
        getMergedTranslationsList('en'),
        getIsoCodes(),
      ])
      const byKey = new Map(textList.map((item) => [item.key, item]))
      translations = await getTranslationAudioCatalog((translationKey) => {
        const item = byKey.get(translationKey)
        if (!item) return null
        return {
          title: item.title ?? null,
          languageIso: item.language_iso_code ?? null,
          languageName: isoCodes.codeToName[item.language_iso_code] ?? null,
          direction: item.direction ?? null,
        }
      })
    } catch {
      translations = await getTranslationAudioCatalog()
    }
    return jsonResponse({
      source: 'QuranEnc audio dashboard',
      sourceUrl: QURANENC_AUDIO_DASHBOARD_URL,
      translations,
    })
  } catch {
    return jsonResponse(
      {
        message: 'The QuranEnc translation audio catalog could not be reached. Please try again shortly.',
        translations: [],
      },
      502,
    )
  }
}

async function handleTranslationAudioSura(
  translationKey: string,
  sura: number,
): Promise<Response> {
  if (!/^[a-z0-9_]+$/.test(translationKey)) {
    return messageResponse('Invalid translation key.', 400)
  }
  if (getSuraAyahCount(sura) === 0) {
    return messageResponse('Invalid sura number.', 400)
  }
  const manifest = await getTranslationFilesManifest(translationKey)
  const inventory = await getTranslationAudioInventory(translationKey)
  if (!manifest || !inventory) {
    return messageResponse('No recorded audio for this translation.', 404)
  }
  const ayatSet = inventory.get(sura)
  if (!ayatSet || ayatSet.size === 0) {
    return messageResponse('No recorded audio for this translation.', 404)
  }
  const ayat = [...ayatSet].sort((a, b) => a - b)
  const files = ayat.map((ayah) => ({
    ayah,
    url: quranEncTranslationAudioUrl(translationKey, sura, ayah),
  }))
  const missing: number[] = []
  for (let ayah = 1; ayah <= getSuraAyahCount(sura); ayah += 1) {
    if (!ayatSet.has(ayah)) missing.push(ayah)
  }

  // Live check of the first file: d.quranenc.com MP3s carry no CORS headers,
  // so the probe runs natively when available (honest null otherwise).
  let live: { status: 'available' | 'unavailable' | 'unknown'; checkedAt: string; httpStatus: number | null } = {
    status: 'unknown',
    checkedAt: new Date().toISOString(),
    httpStatus: null,
  }
  const firstUrl = files[0]?.url
  if (firstUrl && isNativeHttpAvailable()) {
    try {
      const head = await nativeHead(firstUrl, { timeoutMs: 12_000, headers: { Accept: 'audio/mpeg, */*' } })
      if (head) {
        const contentType = head.headers['content-type'] ?? ''
        live = {
          status:
            (head.status === 200 || head.status === 206) && contentType.includes('audio')
              ? 'available'
              : 'unavailable',
          checkedAt: new Date().toISOString(),
          httpStatus: head.status,
        }
      }
    } catch {
      live = { status: 'unavailable', checkedAt: new Date().toISOString(), httpStatus: null }
    }
  }

  return jsonResponse({
    translationKey,
    translationTitle: null,
    audioName: manifest.translation,
    languageIso: null,
    sura,
    ayahCount: getSuraAyahCount(sura),
    availableAyat: files.length,
    missingAyat: missing,
    live,
    files,
  })
}

/* ------------------------- batch ------------------------- */

/** Batches up to this many files are probed for exact sizes. */
const TRANSLATION_AUDIO_EXACT_PROBE_LIMIT = 700
const TRANSLATION_AUDIO_PROBE_CONCURRENCY = 14
const TRANSLATION_AUDIO_ESTIMATE_SAMPLE_SIZE = 40

/** Cache for native HEAD size probes (mirrors the shared module's cache). */
const nativeSizeCache = new Map<string, { size: number | null; expiresAt: number }>()

async function nativeProbeTranslationAudioSize(
  translationKey: string,
  sura: number,
  ayah: number,
): Promise<number | null> {
  const key = `${translationKey}:${sura}:${ayah}`
  const cached = nativeSizeCache.get(key)
  if (cached && cached.expiresAt > Date.now()) return cached.size
  const url = quranEncTranslationAudioUrl(translationKey, sura, ayah)
  if (!url) return null
  let size: number | null = null
  try {
    const head = await nativeHead(url, { timeoutMs: 12_000, headers: { Accept: 'audio/mpeg, */*' } })
    if (head && (head.status === 200 || head.status === 206)) {
      const length = Number(head.headers['content-length'])
      if (Number.isFinite(length) && length > 0) size = length
    }
  } catch {
    size = null
  }
  nativeSizeCache.set(key, {
    size,
    expiresAt: Date.now() + (size !== null ? 6 * 60 * 60 * 1000 : 5 * 60 * 1000),
  })
  return size
}

/** Exact sizes for a verified batch via the native HTTP stack. */
async function nativeProbeTranslationAudioSizes(
  translationKey: string,
  positions: Array<{ sura: number; ayah: number }>,
): Promise<Array<{ sura: number; ayah: number; sizeBytes: number }>> {
  const results: Array<{ sura: number; ayah: number; sizeBytes: number }> = []
  let cursor = 0
  const worker = async (): Promise<void> => {
    while (cursor < positions.length) {
      const position = positions[cursor]
      cursor += 1
      const size = await nativeProbeTranslationAudioSize(translationKey, position.sura, position.ayah)
      results.push({ ...position, sizeBytes: size ?? 0 })
    }
  }
  await Promise.all(
    Array.from(
      { length: Math.min(TRANSLATION_AUDIO_PROBE_CONCURRENCY, Math.max(positions.length, 1)) },
      worker,
    ),
  )
  return results
}

/** Sampled size estimate for very large batches (flagged as estimate). */
async function nativeEstimateTranslationAudioSize(
  translationKey: string,
  positions: Array<{ sura: number; ayah: number }>,
): Promise<number> {
  if (positions.length === 0) return 0
  const sampleCount = Math.min(TRANSLATION_AUDIO_ESTIMATE_SAMPLE_SIZE, positions.length)
  const step = Math.max(1, Math.floor(positions.length / sampleCount))
  const probed: number[] = []
  for (let i = 0; i < positions.length && probed.length < sampleCount; i += step) {
    const size = await nativeProbeTranslationAudioSize(
      translationKey,
      positions[i].sura,
      positions[i].ayah,
    )
    if (size !== null) probed.push(size)
  }
  if (probed.length === 0) return 0
  const mean = probed.reduce((sum, value) => sum + value, 0) / probed.length
  return Math.round(mean * positions.length)
}

async function handleTranslationAudioBatch(searchParams: URLSearchParams): Promise<Response> {
  const translationKey = searchParams.get('translationKey') ?? ''
  const kind = searchParams.get('kind') ?? ''

  if (!/^[a-z0-9_]+$/.test(translationKey)) {
    return messageResponse('Invalid translation key.', 400)
  }
  if (!['ayah', 'sura', 'range', 'juz', 'complete'].includes(kind)) {
    return messageResponse('Invalid batch kind.', 400)
  }

  const manifest = await getTranslationFilesManifest(translationKey)
  if (!manifest) {
    return messageResponse('No recorded audio for this translation at the source.', 404)
  }

  const suraParam = Number(searchParams.get('sura'))
  const ayahParam = Number(searchParams.get('ayah'))
  const fromParam = Number(searchParams.get('from'))
  const toParam = Number(searchParams.get('to'))
  const juzParam = Number(searchParams.get('juz'))

  let positions: Array<{ sura: number; ayah: number }> = []
  let batchSura: number | null = null
  let ayahFrom: number | null = null
  let ayahTo: number | null = null
  let juz: number | null = null

  switch (kind) {
    case 'ayah': {
      if (
        getSuraAyahCount(suraParam) === 0 ||
        !Number.isInteger(ayahParam) ||
        ayahParam < 1 ||
        ayahParam > getSuraAyahCount(suraParam)
      ) {
        return messageResponse('Invalid sura or ayah.', 400)
      }
      positions = [{ sura: suraParam, ayah: ayahParam }]
      batchSura = suraParam
      ayahFrom = ayahParam
      ayahTo = ayahParam
      break
    }
    case 'sura': {
      if (getSuraAyahCount(suraParam) === 0) {
        return messageResponse('Invalid sura.', 400)
      }
      positions = Array.from({ length: getSuraAyahCount(suraParam) }, (_, i) => ({
        sura: suraParam,
        ayah: i + 1,
      }))
      batchSura = suraParam
      break
    }
    case 'range': {
      if (getSuraAyahCount(suraParam) === 0) {
        return messageResponse('Invalid sura.', 400)
      }
      const suraLast = getSuraAyahCount(suraParam)
      if (
        !Number.isInteger(fromParam) ||
        !Number.isInteger(toParam) ||
        fromParam < 1 ||
        toParam < fromParam ||
        fromParam > suraLast
      ) {
        return messageResponse('Invalid ayah range.', 400)
      }
      const to = Math.min(toParam, suraLast)
      positions = []
      for (let ayah = fromParam; ayah <= to; ayah += 1) positions.push({ sura: suraParam, ayah })
      batchSura = suraParam
      ayahFrom = fromParam
      ayahTo = to
      break
    }
    case 'juz': {
      const juzPositions = getJuzPositions(juzParam)
      if (juzPositions.length === 0) {
        return messageResponse('Invalid juz number.', 400)
      }
      positions = juzPositions
      juz = juzParam
      break
    }
    case 'complete': {
      positions = []
      for (let sura = 1; sura <= 114; sura += 1) {
        for (let ayah = 1; ayah <= getSuraAyahCount(sura); ayah += 1) {
          positions.push({ sura, ayah })
        }
      }
      break
    }
    default:
      return messageResponse('Invalid batch kind.', 400)
  }

  const inventory = await getTranslationAudioInventory(translationKey)
  if (!inventory) {
    return messageResponse('No recorded audio for this translation at the source.', 404)
  }
  const verified: Array<{ sura: number; ayah: number }> = []
  const missing: Array<{ sura: number; ayah: number }> = []
  for (const position of positions) {
    const set = inventory.get(position.sura)
    if (set && set.has(position.ayah)) verified.push(position)
    else missing.push(position)
  }
  verified.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)
  missing.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)

  /* Exact sizes for ordinary batches; sampled estimate for the full
   * package. On a real device the probes run through the native HTTP
   * stack (the MP3 host sends no CORS headers); in the desktop simulation
   * the shared module's fetch probes are used and fail honestly when the
   * host blocks them (sizes stay 0, never invented). */
  let files: Array<{ sura: number; ayah: number; sizeBytes: number }>
  let totalBytes = 0
  let sizeEstimated = false
  if (kind === 'complete' || verified.length > TRANSLATION_AUDIO_EXACT_PROBE_LIMIT) {
    sizeEstimated = true
    if (isNativeHttpAvailable()) {
      totalBytes = await nativeEstimateTranslationAudioSize(translationKey, verified)
    } else {
      const { estimateTranslationAudioSize } = await import(
        '@/server/audio/translation-audio'
      )
      totalBytes = (await estimateTranslationAudioSize(translationKey, verified)).estimatedBytes
    }
    files = verified.map((position) => ({ ...position, sizeBytes: 0 }))
  } else if (isNativeHttpAvailable()) {
    files = await nativeProbeTranslationAudioSizes(translationKey, verified)
    totalBytes = files.reduce((sum, file) => sum + file.sizeBytes, 0)
  } else {
    const probed = await probeTranslationAudioSizes(translationKey, verified)
    files = probed.files
    totalBytes = files.reduce((sum, file) => sum + file.sizeBytes, 0)
  }

  let audioName = manifest.translation
  let translationTitle: string | null = null
  let languageName: string | null = null
  try {
    const catalog = await getTranslationAudioCatalog()
    const entry = catalog.find((item) => item.translationKey === translationKey)
    if (entry) {
      audioName = entry.audioName
      translationTitle = entry.textTitle
      languageName = entry.languageName
    }
  } catch {
    /* metadata stays honest-null */
  }

  return jsonResponse({
    translationKey,
    audioName,
    translationTitle,
    languageName,
    batchKind: kind,
    sura: batchSura,
    ayahFrom,
    ayahTo,
    juz,
    files,
    totalFiles: files.length,
    totalBytes,
    sizeEstimated,
    missing,
    sourceComplete: missing.length === 0,
    completePackageOfferable: kind === 'complete' && files.length === 6236,
    sourceName: 'QuranEnc',
  })
}

async function handleTranslationAudioFile(
  translationKey: string,
  sura: number,
  ayah: number,
  init: RequestInit | undefined,
): Promise<Response> {
  if (!/^[a-z0-9_]+$/.test(translationKey)) {
    return messageResponse('Invalid translation key.', 400)
  }
  if (getSuraAyahCount(sura) === 0) {
    return messageResponse('Invalid sura number.', 400)
  }
  if (!Number.isInteger(ayah) || ayah < 1 || ayah > getSuraAyahCount(sura)) {
    return messageResponse('Invalid ayah number.', 400)
  }
  const inventory = await getTranslationAudioInventory(translationKey)
  if (!inventory || !inventory.get(sura)?.has(ayah)) {
    return messageResponse('No recorded narration file for this ayah at the source.', 404)
  }
  const url = quranEncTranslationAudioUrl(translationKey, sura, ayah)
  if (!url) {
    return messageResponse('No recorded narration file for this ayah at the source.', 404)
  }
  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    return messageResponse('Blocked audio URL.', 400)
  }
  if (
    parsed.protocol !== 'https:' ||
    parsed.hostname !== 'd.quranenc.com' ||
    !/^\/data\/audio\/[a-z0-9_]+\/\d{6}\.mp3$/.test(parsed.pathname)
  ) {
    return messageResponse('Blocked audio URL.', 400)
  }

  const fileName = `${translationKey}-${parsed.pathname.split('/').pop()}`

  if ((init?.method ?? 'GET').toUpperCase() === 'HEAD') {
    // Live size probe (the manifest lists names, not sizes).
    if (isNativeHttpAvailable()) {
      try {
        const head = await nativeHead(url, { timeoutMs: 15_000, headers: { Accept: 'audio/mpeg, */*' } })
        if (head && (head.status === 200 || head.status === 206)) {
          const length = Number(head.headers['content-length'])
          if (Number.isFinite(length) && length >= 0) {
            return new Response(null, {
              status: 200,
              headers: {
                'content-length': String(length),
                'content-type': 'audio/mpeg',
                'accept-ranges': 'bytes',
                'cache-control': 'no-store',
              },
            })
          }
        }
      } catch {
        // fall through to the honest failure
      }
    }
    return new Response(null, { status: 502, headers: { 'cache-control': 'no-store' } })
  }

  return fetchBinaryProxied(url, init, {
    mode: 'native-only',
    timeoutMs: 120_000,
    accept: 'audio/mpeg, */*',
    fallbackFileName: fileName,
  })
}

/* ------------------------------------------------------------------ */
/* Downloads proxy (quranenc.com file host - no CORS)                  */
/* ------------------------------------------------------------------ */

const ALLOWED_DOWNLOAD_HOSTS = new Set(['quranenc.com', 'www.quranenc.com'])

function fileNameFromUrl(rawUrl: string): string {
  try {
    const url = new URL(rawUrl)
    const segments = url.pathname.split('/').filter(Boolean)
    return segments.length > 0 ? segments[segments.length - 1] : 'download'
  } catch {
    return 'download'
  }
}

async function resolveCatalogFileUrl(
  translationKey: string,
  fileId: string,
): Promise<{ fileUrl: string } | { error: Response }> {
  const { translations } = await getMergedTranslationsList('en')
  const item = translations.find((entry) => entry.key === translationKey)
  if (!item) {
    return { error: messageResponse('Translation not found.', 404) }
  }
  const files: Record<string, string | null | undefined> = {
    'sql-database': item.database_url,
    'sql-database-uncompressed': item.database_uncompressed_url,
    'pdf-standard': item.pdf_url,
    'pdf-pure': item.pdf_pure_url,
    'pdf-mobile': item.pdf_mobile_url,
    epub: item.epub_url,
  }
  const candidate = files[fileId]
  if (typeof candidate !== 'string' || !candidate.startsWith('https://')) {
    return { error: messageResponse('File not available for this translation.', 404) }
  }
  return { fileUrl: candidate }
}

async function handleDownloadsFile(
  translationKey: string,
  fileId: string,
  init: RequestInit | undefined,
): Promise<Response> {
  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return messageResponse('Invalid translation key.', 400)
  }
  try {
    const resolved = await resolveCatalogFileUrl(translationKey, fileId)
    if ('error' in resolved) return resolved.error
    const fileUrl = resolved.fileUrl
    let parsed: URL
    try {
      parsed = new URL(fileUrl)
    } catch {
      return messageResponse('Blocked download URL.', 400)
    }
    if (parsed.protocol !== 'https:' || !ALLOWED_DOWNLOAD_HOSTS.has(parsed.hostname)) {
      return messageResponse('Blocked download URL.', 400)
    }

    if ((init?.method ?? 'GET').toUpperCase() === 'HEAD') {
      // Exact size probe: HEAD first, then a 1-byte Range GET fallback.
      let size: number | null = null
      if (isNativeHttpAvailable()) {
        try {
          const head = await nativeHead(fileUrl, { timeoutMs: 15_000 })
          if (head && head.status >= 200 && head.status < 300) {
            const length = Number(head.headers['content-length'])
            if (Number.isFinite(length) && length >= 0) size = length
          }
        } catch {
          // fall through
        }
        if (size === null) {
          try {
            const probed = await nativeGetBinary(fileUrl, {
              timeoutMs: 15_000,
              headers: { Range: 'bytes=0-0', Accept: 'application/octet-stream' },
            })
            if (probed && (probed.status === 206 || probed.status === 200)) {
              const rangeMatch = /\/\s*(\d+)\s*$/.exec(probed.headers['content-range'] ?? '')
              if (rangeMatch) {
                size = Number(rangeMatch[1])
              } else if (probed.status === 200) {
                size = Number(probed.headers['content-length'])
                if (!Number.isFinite(size) || size < 0) size = null
              }
            }
          } catch {
            // both probes failed
          }
        }
      }
      if (size === null) {
        return new Response(null, {
          status: 503,
          headers: { 'cache-control': 'no-store', 'x-size-resolved': 'false' },
        })
      }
      return new Response(null, {
        status: 200,
        headers: {
          'content-length': String(size),
          'x-size-resolved': 'true',
          'cache-control': 'no-store',
        },
      })
    }

    return fetchBinaryProxied(fileUrl, init, {
      mode: 'native-only',
      timeoutMs: 120_000,
      accept: 'application/octet-stream',
      fallbackFileName: fileNameFromUrl(fileUrl),
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return messageResponse('Catalog temporarily unreachable.', 502)
    }
    return messageResponse('The file could not be fetched from the source.', 502)
  }
}

/* ------------------------------------------------------------------ */
/* Capabilities + config                                               */
/* ------------------------------------------------------------------ */

async function handleCapabilities(): Promise<Response> {
  const nowIso = new Date().toISOString()

  const untranslatedCodes = SUPPORTED_LOCALES.filter(
    (locale) => locale.code !== FALLBACK_LOCALE && !hasTranslations(locale.code),
  ).map((locale) => locale.code)

  let translationLanguages: {
    datasetCount: number
    languageCount: number
    sampleLanguages: string[]
    source: string
    checkedAt: string
  } | null = null
  try {
    const [{ translations }, isoCodes] = await Promise.all([
      getMergedTranslationsList('en'),
      getIsoCodes(),
    ])
    const languages = new Set<string>()
    const names: string[] = []
    for (const translation of translations) {
      const iso = translation.language_iso_code
      if (!languages.has(iso)) {
        languages.add(iso)
        names.push(isoCodes.codeToName[iso] ?? iso)
      }
    }
    translationLanguages = {
      datasetCount: translations.length,
      languageCount: languages.size,
      sampleLanguages: names.slice(0, 6),
      source: 'QuranEnc translation catalog',
      checkedAt: nowIso,
    }
  } catch {
    translationLanguages = null
  }

  let recordedTranslationAudio: {
    translationCount: number
    languageIsos: string[]
    sampleNames: string[]
    source: string
    checkedAt: string
  } | null = null
  try {
    let audioCatalog: Awaited<ReturnType<typeof getTranslationAudioCatalog>>
    try {
      const [{ translations }, isoCodes] = await Promise.all([
        getMergedTranslationsList('en'),
        getIsoCodes(),
      ])
      const byKey = new Map(translations.map((item) => [item.key, item]))
      audioCatalog = await getTranslationAudioCatalog((translationKey) => {
        const item = byKey.get(translationKey)
        if (!item) return null
        return {
          title: item.title ?? null,
          languageIso: item.language_iso_code ?? null,
          languageName: isoCodes.codeToName[item.language_iso_code] ?? null,
          direction: item.direction ?? null,
        }
      })
    } catch {
      audioCatalog = await getTranslationAudioCatalog()
    }
    const languageIsos = [
      ...new Set(
        audioCatalog
          .map((entry) => entry.languageIso)
          .filter((iso): iso is string => typeof iso === 'string'),
      ),
    ]
    recordedTranslationAudio = {
      translationCount: audioCatalog.length,
      languageIsos,
      sampleNames: audioCatalog.slice(0, 6).map((entry) => entry.audioName),
      source: 'QuranEnc audio dashboard (verified manifests)',
      checkedAt: nowIso,
    }
  } catch {
    recordedTranslationAudio = null
  }

  /* Seed-based complete-style count (identical to the server route). */
  let completeStyles = 0
  for (const style of RECITATION_STYLES) {
    const summary = getStyleSummary(style.id, null)
    if (summary && summary.seedVerified && summary.totalAyat === 6236) completeStyles += 1
  }

  const snapshot = {
    interfaceLanguages: {
      count: INTERFACE_LANGUAGE_COUNT,
      completeCount: 1,
      untranslatedCodes,
      source: 'App locale registry',
    },
    translationLanguages,
    recordedTranslationAudio,
    deviceTts: {
      runtimeOnly: true,
      note: 'Device and browser voices are detected on this device at runtime; the app never assumes a voice before it is detected.',
    },
    recitation: {
      styleCount: RECITATION_STYLE_COUNT,
      ayatPerStyle: 6236,
      completeStyles,
      source: 'EveryAyah (verified inventory)',
      verifiedAt: nowIso,
    },
    generatedAt: nowIso,
  }
  return jsonResponse(snapshot)
}

/* ------------------------------------------------------------------ */
/* Dispatch                                                            */
/* ------------------------------------------------------------------ */

function decodePathSegment(segment: string): string {
  try {
    return decodeURIComponent(segment)
  } catch {
    return segment
  }
}

/**
 * Dispatch one same-origin `/api/...` request inside the native app.
 *
 * @param path The request path (always starts with `/api/` - the caller
 *        guarantees this).
 * @param init The original request init (method, headers, body, signal).
 */
export async function dispatchNativeApi(path: string, init?: RequestInit): Promise<Response> {
  ensureAdapterBoot()

  const method = (init?.method ?? 'GET').toUpperCase()
  const queryIndex = path.indexOf('?')
  const pathname = queryIndex === -1 ? path : path.slice(0, queryIndex)
  const searchParams = new URLSearchParams(queryIndex === -1 ? '' : path.slice(queryIndex + 1))

  /* ---------- config / capabilities ---------- */
  if (pathname === '/api/config') {
    return jsonResponse(buildAppConfigPayload())
  }
  if (pathname === '/api/capabilities') {
    return handleCapabilities()
  }

  /* ---------- prayer ---------- */
  if (pathname === '/api/prayer/times') return handlePrayerTimes(pathname, searchParams)
  if (pathname === '/api/prayer/calendar') return handlePrayerCalendar(searchParams)
  if (pathname === '/api/prayer/meta') {
    return jsonResponse({
      status: 'live',
      methods: PRAYER_METHODS.map((method) => ({
        id: method.id,
        numericId: method.numericId,
        name: method.name,
        paramsSummary: method.paramsSummary,
        experimental: method.experimental,
        localEngineSupported: method.localEngineSupported,
      })),
      countryDefaults: countryDefaultsForApi(),
      verifiedAt: METHODS_VERIFIED_AT,
      verifiedFrom: METHODS_VERIFIED_FROM,
    })
  }
  if (pathname === '/api/prayer/registry') {
    return jsonResponse({
      status: 'live',
      registry: OFFICIAL_AUTHORITY_REGISTRY,
      jakimZones: JAKIM_ZONES,
      summary: REGISTRY_SUMMARY,
    })
  }
  if (pathname === '/api/prayer/geocode') return handlePrayerGeocode(searchParams)
  if (pathname === '/api/prayer/reverse-geocode') return handlePrayerReverseGeocode(searchParams)
  if (pathname === '/api/prayer/adhans/catalog') return handleAdhanCatalog()

  const adhanFileMatch = /^\/api\/prayer\/adhans\/file\/([^/]+)$/.exec(pathname)
  if (adhanFileMatch) {
    return handleAdhanFile(decodePathSegment(adhanFileMatch[1]), init)
  }

  /* ---------- quranenc content ---------- */
  if (pathname === '/api/quran/sowar-names') return handleSowarNames(searchParams)
  if (pathname === '/api/translations/catalog') return handleTranslationsCatalog(searchParams)
  if (pathname === '/api/translations/verification') {
    if (method === 'GET') {
      return jsonResponse({ records: [] })
    }
    return messageResponse(
      'The verification registry is a server-side administrator tool and is not available in the app.',
      503,
    )
  }

  const suraContentMatch = /^\/api\/quran\/sura\/([^/]+)\/(\d+)$/.exec(pathname)
  if (suraContentMatch) {
    return handleSuraContent(
      decodePathSegment(suraContentMatch[1]),
      Number(suraContentMatch[2]),
    )
  }

  const offlinePackMatch = /^\/api\/quran\/offline-pack\/([^/]+)$/.exec(pathname)
  if (offlinePackMatch) {
    return handleOfflinePack(decodePathSegment(offlinePackMatch[1]), init)
  }

  const exportMatch = /^\/api\/quran\/export\/([^/]+)$/.exec(pathname)
  if (exportMatch) {
    return handleExport(decodePathSegment(exportMatch[1]), searchParams)
  }

  /* ---------- recitation audio (EveryAyah) ---------- */
  if (pathname === '/api/quran/audio/reciters') return handleReciters()
  if (pathname === '/api/quran/audio/batch') return handleAudioBatch(searchParams)

  const suraAudioMatch = /^\/api\/quran\/audio\/sura\/([^/]+)\/(\d+)$/.exec(pathname)
  if (suraAudioMatch) {
    return handleSuraAudio(decodePathSegment(suraAudioMatch[1]), Number(suraAudioMatch[2]))
  }

  const audioFileMatch = /^\/api\/quran\/audio\/file\/([^/]+)\/(\d+)\/(\d+)$/.exec(pathname)
  if (audioFileMatch) {
    return handleAudioFile(
      decodePathSegment(audioFileMatch[1]),
      Number(audioFileMatch[2]),
      Number(audioFileMatch[3]),
      init,
    )
  }

  /* ---------- translation audio (d.quranenc.com) ---------- */
  if (pathname === '/api/quran/translation-audio/catalog') {
    return handleTranslationAudioCatalog()
  }

  if (pathname === '/api/quran/translation-audio/batch') {
    return handleTranslationAudioBatch(searchParams)
  }

  const translationAudioSuraMatch = /^\/api\/quran\/translation-audio\/sura\/([^/]+)\/(\d+)$/.exec(pathname)
  if (translationAudioSuraMatch) {
    return handleTranslationAudioSura(
      decodePathSegment(translationAudioSuraMatch[1]),
      Number(translationAudioSuraMatch[2]),
    )
  }

  const translationAudioFileMatch =
    /^\/api\/quran\/translation-audio\/file\/([^/]+)\/(\d+)\/(\d+)$/.exec(pathname)
  if (translationAudioFileMatch) {
    return handleTranslationAudioFile(
      decodePathSegment(translationAudioFileMatch[1]),
      Number(translationAudioFileMatch[2]),
      Number(translationAudioFileMatch[3]),
      init,
    )
  }

  /* ---------- downloads proxy ---------- */
  const downloadsMatch = /^\/api\/downloads\/([^/]+)\/([^/]+)$/.exec(pathname)
  if (downloadsMatch) {
    return handleDownloadsFile(
      decodePathSegment(downloadsMatch[1]),
      decodePathSegment(downloadsMatch[2]),
      init,
    )
  }

  /* ---------- unknown route ---------- */
  return messageResponse(
    `The native adapter does not implement this endpoint (${method} ${pathname}).`,
    404,
  )
}
