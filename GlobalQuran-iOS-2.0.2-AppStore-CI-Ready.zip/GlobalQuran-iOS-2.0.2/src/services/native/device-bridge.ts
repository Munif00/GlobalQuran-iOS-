/**
 * Global Quran - DeviceBridge plugin interface (custom Capacitor plugin).
 *
 * Small native bridge for the two location-related capabilities the WebView
 * cannot provide:
 * 1. isLocationServiceEnabled() - whether the Android system-wide location
 *    service (GPS/network provider) is switched ON. Granting the app
 *    permission does NOT enable this service; without it every position
 *    request fails, so the app must detect the state and guide the user.
 * 2. openLocationSettings() - deep-links to Android's location settings so
 *    the user can enable the service, then returns to the app.
 * 3. getPermissionState() - the real Android runtime permission state for
 *    the location permissions (the WebView Permissions API does not reflect
 *    native states reliably).
 *
 * Web fallback: every method reports 'unavailable' (honest - a browser has
 * no access to these states; the flows fall back to their web behavior).
 */

import { registerPlugin } from '@capacitor/core'

export interface DeviceBridgePluginInterface {
  /** Whether the system location service is enabled (Android). */
  isLocationServiceEnabled(): Promise<{ enabled: boolean }>
  /** Whether the native plugin is available at all (always false on web). */
  isAvailable(): Promise<{ available: boolean }>
  /** Open the system location settings screen. */
  openLocationSettings(): Promise<{ opened: boolean }>
  /** Real Android permission state for the location permissions. */
  getPermissionState(): Promise<{
    fine: 'granted' | 'denied' | 'not-requested'
    coarse: 'granted' | 'denied' | 'not-requested'
  }>
}

const DeviceBridgeNative = registerPlugin<DeviceBridgePluginInterface>('DeviceBridge')

/** True when the native DeviceBridge plugin is implemented (Android app). */
export async function isDeviceBridgeAvailable(): Promise<boolean> {
  try {
    const result = await DeviceBridgeNative.isAvailable()
    return result.available === true
  } catch {
    return false
  }
}

/**
 * Whether the Android system location service is enabled.
 * Returns null when the state cannot be determined (web browser).
 */
export async function isLocationServiceEnabled(): Promise<boolean | null> {
  try {
    const result = await DeviceBridgeNative.isLocationServiceEnabled()
    return result.enabled === true
  } catch {
    return null
  }
}

/**
 * Open the Android location settings screen.
 * Returns false when not running in the native app.
 */
export async function openLocationSettings(): Promise<boolean> {
  try {
    const result = await DeviceBridgeNative.openLocationSettings()
    return result.opened === true
  } catch {
    return false
  }
}

/**
 * The real Android permission state for location.
 * Returns null when not running in the native app.
 */
export async function getNativePermissionState(): Promise<{
  fine: 'granted' | 'denied' | 'not-requested'
  coarse: 'granted' | 'denied' | 'not-requested'
} | null> {
  try {
    return await DeviceBridgeNative.getPermissionState()
  } catch {
    return null
  }
}

export { DeviceBridgeNative }
