/**
 * Global Quran - AdhanScheduler web stub.
 *
 * The web/PWA platform has no native alarm scheduler. Every method rejects
 * with `unimplemented` so the app detects "native scheduling unavailable"
 * and keeps using the honest foreground web scheduler. No capability is
 * ever claimed that the platform cannot provide.
 */

import type { AdhanSchedulerPlugin } from './adhan-scheduler-plugin'
import type { PluginListenerHandle } from '@capacitor/core'

export class AdhanSchedulerWeb implements AdhanSchedulerPlugin {
  async addListener(): Promise<PluginListenerHandle> {
    throw new Error('unimplemented')
  }

  async removeAllListeners(): Promise<void> {
    throw new Error('unimplemented')
  }

  async sync(): Promise<{ stored: number }> {
    throw new Error('unimplemented')
  }

  async status(): Promise<never> {
    throw new Error('unimplemented')
  }

  async requestNotificationPermission(): Promise<{ granted: boolean }> {
    throw new Error('unimplemented')
  }

  async beginFile(): Promise<void> {
    throw new Error('unimplemented')
  }

  async writeFileChunk(): Promise<void> {
    throw new Error('unimplemented')
  }

  async finalizeFile(): Promise<{ ok: boolean }> {
    throw new Error('unimplemented')
  }

  async deleteFile(): Promise<void> {
    throw new Error('unimplemented')
  }

  async listFiles(): Promise<{ files: Array<{ adhanId: string; sizeBytes: number }> }> {
    throw new Error('unimplemented')
  }

  async debugFireNext(): Promise<void> {
    throw new Error('unimplemented')
  }

  /** iOS foreground-playback extension — no native player on web. */
  async playMirrored(): Promise<{ playing: boolean }> {
    return { playing: false }
  }

  async stopMirroredPlayback(): Promise<{ stopped: boolean }> {
    return { stopped: false }
  }
}
