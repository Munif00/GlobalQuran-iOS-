/**
 * Global Quran - Native HTTP transport (CapacitorHttp).
 *
 * The WebView's own fetch enforces CORS. Most upstream services the app uses
 * send `Access-Control-Allow-Origin: *` (QuranEnc API, EveryAyah, AlAdhan
 * API, Nominatim, BigDataCloud) and work with plain fetch - including from
 * inside the Capacitor WebView. A few hosts the app must reach do NOT send
 * CORS headers and can never be fetched by the WebView:
 *
 *   - cdn.aladhan.com      (Adhan MP3 recordings)
 *   - quranenc.com files   (translation database/PDF/EPUB downloads)
 *
 * On a real native device CapacitorHttp performs the request through the
 * native HTTP stack instead, where CORS does not apply. This module is the
 * single place that decision is made:
 *
 *   - real native runtime  -> CapacitorHttp (native stack, custom headers
 *                             such as User-Agent and Range actually sent,
 *                             all response headers visible);
 *   - native simulation (?nativeSim=1 in a desktop browser) -> the plain
 *     fetch fallback, which honestly fails for the CORS-less hosts (the
 *     adapter surfaces the failure; nothing is faked).
 *
 * CapacitorHttp always delivers binary bodies as a BASE64 STRING (both the
 * web shim and the native implementation) - decodeBase64() converts them
 * back to bytes.
 */

import { CapacitorHttp } from '@capacitor/core'

import { isRealNativePlatform } from '@/services/platform/native-mode'

/** True when requests can bypass WebView CORS through the native stack. */
export function isNativeHttpAvailable(): boolean {
  return isRealNativePlatform()
}

/** Decode a base64 string (optionally a data: URL) into bytes. */
function decodeBase64(base64: string): Uint8Array<ArrayBuffer> {
  const clean = base64.includes(',') ? base64.slice(base64.indexOf(',') + 1) : base64
  const binary = atob(clean)
  const bytes = new Uint8Array(binary.length)
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index)
  }
  return bytes
}

/** Normalize CapacitorHttp's header object into a plain lowercase map. */
function toHeaderMap(raw: Record<string, unknown> | undefined): Record<string, string> {
  const map: Record<string, string> = {}
  if (!raw) return map
  for (const key of Object.keys(raw)) {
    const value = raw[key]
    if (typeof value === 'string') map[key.toLowerCase()] = value
    else if (typeof value === 'number') map[key.toLowerCase()] = String(value)
  }
  return map
}

export interface NativeBinaryResponse {
  status: number
  headers: Record<string, string>
  bytes: Uint8Array<ArrayBuffer>
}

export interface NativeJsonResponse {
  status: number
  headers: Record<string, string>
  data: unknown
}

/**
 * Perform a native GET that returns the raw bytes.
 * Returns null when the native HTTP stack is not available (browser).
 */
export async function nativeGetBinary(
  url: string,
  options: { timeoutMs?: number; headers?: Record<string, string> } = {},
): Promise<NativeBinaryResponse | null> {
  if (!isNativeHttpAvailable()) return null
  const response = await CapacitorHttp.request({
    url,
    method: 'GET',
    headers: options.headers ?? {},
    responseType: 'blob',
    connectTimeout: options.timeoutMs ?? 120_000,
    readTimeout: options.timeoutMs ?? 120_000,
  })
  const data = response.data as unknown
  let bytes: Uint8Array<ArrayBuffer>
  if (typeof data === 'string') {
    bytes = decodeBase64(data)
  } else if (data instanceof ArrayBuffer) {
    bytes = new Uint8Array(data)
  } else if (data instanceof Blob) {
    bytes = new Uint8Array(await data.arrayBuffer())
  } else if (data instanceof Uint8Array) {
    bytes = new Uint8Array(data)
  } else {
    bytes = new Uint8Array(0)
  }
  return {
    status: response.status,
    headers: toHeaderMap(response.headers),
    bytes,
  }
}

/**
 * Perform a native HEAD request (all response headers visible - the WebView
 * fetch would hide content-length behind CORS expose rules).
 * Returns null when the native HTTP stack is not available (browser).
 */
export async function nativeHead(
  url: string,
  options: { timeoutMs?: number; headers?: Record<string, string> } = {},
): Promise<{ status: number; headers: Record<string, string> } | null> {
  if (!isNativeHttpAvailable()) return null
  const response = await CapacitorHttp.request({
    url,
    method: 'HEAD',
    headers: options.headers ?? {},
    responseType: 'text',
    connectTimeout: options.timeoutMs ?? 15_000,
    readTimeout: options.timeoutMs ?? 15_000,
  })
  return { status: response.status, headers: toHeaderMap(response.headers) }
}

/**
 * Perform a native GET returning parsed JSON.
 * Returns null when the native HTTP stack is not available (browser).
 */
export async function nativeGetJson(
  url: string,
  options: { timeoutMs?: number; headers?: Record<string, string> } = {},
): Promise<NativeJsonResponse | null> {
  if (!isNativeHttpAvailable()) return null
  const response = await CapacitorHttp.request({
    url,
    method: 'GET',
    headers: { Accept: 'application/json', ...(options.headers ?? {}) },
    responseType: 'json',
    connectTimeout: options.timeoutMs ?? 15_000,
    readTimeout: options.timeoutMs ?? 15_000,
  })
  return {
    status: response.status,
    headers: toHeaderMap(response.headers),
    data: response.data,
  }
}
