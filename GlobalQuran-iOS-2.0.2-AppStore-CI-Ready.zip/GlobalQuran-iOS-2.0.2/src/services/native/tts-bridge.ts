/**
 * Global Quran - TtsBridge plugin interface (custom Capacitor plugin).
 *
 * Real native text-to-speech for translation narration inside the Android
 * app. The Android WebView exposes the Web Speech API surface but cannot
 * reach the system's android.speech.tts engines (the voice list stays
 * empty and speak() never produces audio), so the WebView path can only
 * report TTS as unavailable. This bridge forwards narration to the REAL
 * device engine through android.speech.tts.TextToSpeech.
 *
 * Java implementation: android/app/src/main/java/com/globalquran/app/
 * plugins/TtsBridgePlugin.java (registered from MainActivity).
 *
 * Web fallback: every helper resolves to an honest unavailable state -
 * the wrapper is only ever CALLED on the real native platform (callers
 * check isRealNativePlatform() first), and each helper re-checks it so a
 * mistaken call can never touch a non-existent plugin.
 */

import { registerPlugin, type PluginListenerHandle } from '@capacitor/core'

import { isRealNativePlatform } from '@/services/platform/native-mode'

/** A device voice as exposed by the native engine (see getVoices). */
export interface TtsVoiceDescriptor {
  /** Stable voice identifier (the Android voice name). */
  id: string
  /** Display name (Android exposes no separate display name - this is the id). */
  name: string
  /** BCP-47 locale of the voice. */
  locale: string
}

/** Engine status as probed from the native side (all honest, never guessed). */
export interface TtsStatus {
  /** A usable engine exists (false when init failed or no engine is installed). */
  available: boolean
  /** The engine object is initialized (an engine can be ready yet empty). */
  ready: boolean
  /** Package name of the default engine (null when unknown). */
  engine: string | null
  /** Package names of all installed engines. */
  engines: string[]
}

/** Result of isLanguageAvailable (the "engine-unavailable" variant is honest:
 *  no engine could be initialized, so nothing can be said about the language). */
export type TtsLanguageStatus = 'ok' | 'missing-data' | 'not-supported' | 'engine-unavailable'

/** Failure codes the native speak() path rejects with. */
export type TtsSpeakErrorCode = 'engine-unavailable' | 'voice-missing' | 'missing-data' | 'failed'

/** Options for ttsSpeak (mirrors the native speak contract). */
export interface TtsSpeakOptions {
  /** The text to speak (never Arabic content - enforced by the engine). */
  text: string
  /** BCP-47 language of the text (the translation's language). */
  lang: string
  /** Optional explicit voice id (the user's pick from ttsGetVoices). */
  voiceId?: string
  /** Speech rate (1 = normal; the same scale as the Web Speech API). */
  rate?: number
  /** Pitch (1 = normal). */
  pitch?: number
}

/** Event emitted by the native engine when an utterance finishes or fails
 *  (the native mirror of the web utterance's end/error events). */
export interface TtsUtteranceEvent {
  type: 'done' | 'error'
  /** The session utteranceId returned by the resolved ttsSpeak call. */
  utteranceId: string
}

export interface TtsBridgeInterface {
  getStatus(): Promise<TtsStatus>
  getVoices(options: { lang: string }): Promise<{ voices: TtsVoiceDescriptor[] }>
  isLanguageAvailable(options: { lang: string }): Promise<{ status: TtsLanguageStatus }>
  speak(options: TtsSpeakOptions): Promise<{ started: boolean; utteranceId: string }>
  stop(): Promise<{ stopped: boolean }>
  pauseSupported(): Promise<{ supported: boolean }>
  openTtsSettings(): Promise<{ opened: boolean }>
  addListener(
    eventName: 'ttsUtterance',
    listenerFunc: (event: TtsUtteranceEvent) => void,
  ): Promise<PluginListenerHandle>
  removeAllListeners(): Promise<void>
}

const TtsBridge = registerPlugin<TtsBridgeInterface>('TtsBridge')

/**
 * Typed error thrown by ttsSpeak: `code` is one of the contract's failure
 * codes (the narration engine maps it to its honest UI message).
 */
export class TtsBridgeError extends Error {
  readonly code: TtsSpeakErrorCode

  constructor(code: TtsSpeakErrorCode, message: string) {
    super(message)
    this.name = 'TtsBridgeError'
    this.code = code
  }
}

/** Normalize an unknown rejection into a typed TtsBridgeError. */
function toTtsBridgeError(error: unknown): TtsBridgeError {
  if (error instanceof TtsBridgeError) return error
  const code = error instanceof Error ? (error as Error & { code?: unknown }).code : undefined
  if (
    code === 'engine-unavailable' ||
    code === 'voice-missing' ||
    code === 'missing-data' ||
    code === 'failed'
  ) {
    return new TtsBridgeError(code, error instanceof Error ? error.message : String(error))
  }
  return new TtsBridgeError('failed', error instanceof Error ? error.message : String(error))
}

/** True when the native TtsBridge plugin is present and a TTS engine works. */
export async function isTtsBridgeAvailable(): Promise<boolean> {
  if (!isRealNativePlatform()) return false
  try {
    const status = await TtsBridge.getStatus()
    return status.available === true
  } catch {
    return false
  }
}

/**
 * The native engine status (null on web / when the probe fails - a browser
 * has no native text-to-speech bridge, honestly reported).
 */
export async function ttsGetStatus(): Promise<TtsStatus | null> {
  if (!isRealNativePlatform()) return null
  try {
    return await TtsBridge.getStatus()
  } catch {
    return null
  }
}

/**
 * The device voices actually installed for a language (primary-subtag
 * match, with the same alias table the web path uses). Empty on web.
 */
export async function ttsGetVoices(lang: string): Promise<TtsVoiceDescriptor[]> {
  if (!isRealNativePlatform()) return []
  try {
    const result = await TtsBridge.getVoices({ lang })
    return Array.isArray(result.voices) ? result.voices : []
  } catch {
    return []
  }
}

/**
 * Whether the engine can speak the language: "ok", "missing-data" (the
 * language's speech data must be installed first), "not-supported", or
 * "engine-unavailable" (no working engine at all).
 */
export async function ttsIsLanguageAvailable(lang: string): Promise<TtsLanguageStatus> {
  if (!isRealNativePlatform()) return 'engine-unavailable'
  try {
    const result = await TtsBridge.isLanguageAvailable({ lang })
    return result.status
  } catch {
    return 'engine-unavailable'
  }
}

/**
 * Speak text with the native engine. Resolves { started, utteranceId }
 * when the engine actually STARTED the speech (from onStart); rejects
 * with a typed TtsBridgeError (code "engine-unavailable" | "voice-missing"
 * | "missing-data" | "failed"). Completion arrives via addTtsUtteranceListener.
 */
export async function ttsSpeak(options: TtsSpeakOptions): Promise<{
  started: boolean
  utteranceId: string
}> {
  if (!isRealNativePlatform()) {
    throw new TtsBridgeError('engine-unavailable', 'TtsBridge is only available in the native app')
  }
  try {
    const result = await TtsBridge.speak(options)
    if (
      result?.started !== true ||
      typeof result.utteranceId !== 'string' ||
      result.utteranceId.length === 0
    ) {
      throw new TtsBridgeError('failed', 'unexpected TtsBridge speak response')
    }
    return result
  } catch (error) {
    throw toTtsBridgeError(error)
  }
}

/** Stop native speech. { stopped: false } when nothing could be stopped. */
export async function ttsStop(): Promise<{ stopped: boolean }> {
  if (!isRealNativePlatform()) return { stopped: false }
  try {
    return await TtsBridge.stop()
  } catch {
    return { stopped: false }
  }
}

/**
 * Whether the native engine supports pause/resume. Android's
 * TextToSpeech does NOT - the answer is an honest { supported: false };
 * a pause is never faked.
 */
export async function ttsPauseSupported(): Promise<{ supported: boolean }> {
  if (!isRealNativePlatform()) return { supported: false }
  try {
    return await TtsBridge.pauseSupported()
  } catch {
    return { supported: false }
  }
}

/**
 * Open the system text-to-speech settings so the user can install/enable
 * an engine or language data. False on web or when no settings screen
 * could be opened.
 */
export async function ttsOpenTtsSettings(): Promise<{ opened: boolean }> {
  if (!isRealNativePlatform()) return { opened: false }
  try {
    return await TtsBridge.openTtsSettings()
  } catch {
    return { opened: false }
  }
}

/**
 * Subscribe to native utterance events ("done" | "error") so the engine
 * can advance sequential narration. Returns an unsubscribe function; on
 * web it is a no-op (the web path uses the utterance's own events).
 */
export async function addTtsUtteranceListener(
  callback: (event: TtsUtteranceEvent) => void,
): Promise<() => void> {
  if (!isRealNativePlatform()) return () => undefined
  try {
    const handle = await TtsBridge.addListener('ttsUtterance', callback)
    return () => {
      void handle.remove()
    }
  } catch {
    return () => undefined
  }
}

export { TtsBridge }
