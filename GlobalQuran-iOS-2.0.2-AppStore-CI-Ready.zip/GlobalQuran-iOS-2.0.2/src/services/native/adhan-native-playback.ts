/**
 * Global Quran - iOS foreground Adhan native playback helper.
 *
 * WKWebView cannot control HTMLAudioElement volume (audio.volume is a
 * read-only no-op on iOS WebKit), so the user's Adhan volume slider
 * would have no effect through the shared web player. The iOS native
 * plugin (AdhanSchedulerPlugin.playMirrored) plays the VERIFIED native
 * mirror with real per-stream volume; this module is the typed, guarded
 * wrapper used by the shared foreground-fire path.
 *
 * Platform gating: every helper is a no-op/false on Android and web —
 * the Android app keeps its existing WebView playback exactly as
 * shipped in 2.0.2 (no behavioral change), and the web/PWA keeps the
 * web player.
 */

import { Capacitor } from '@capacitor/core'

import { isRealNativePlatform } from '@/services/platform/native-mode'
import { AdhanScheduler } from '@/services/native/adhan-scheduler-plugin'

/** True only on the iOS native app (the one platform needing the bridge). */
export function isAdhanNativePlaybackPlatform(): boolean {
  if (typeof window === 'undefined') return false
  if (!isRealNativePlatform()) return false
  try {
    return Capacitor.getPlatform() === 'ios'
  } catch {
    return false
  }
}

/**
 * Start native foreground playback of a verified mirror.
 * Returns false on any other platform, when no usable mirror exists, or
 * when the plugin call fails — the caller then falls back to the shared
 * web player (its volume limitation is documented honestly).
 */
export async function nativePlayAdhanMirror(adhanId: string, volume: number): Promise<boolean> {
  if (!isAdhanNativePlaybackPlatform()) return false
  try {
    const result = await AdhanScheduler.playMirrored({ adhanId, volume })
    return result?.playing === true
  } catch {
    return false
  }
}

/**
 * Stop native foreground playback (no-op on other platforms; the web
 * player is stopped separately by the caller).
 */
export async function nativeStopAdhanPlayback(): Promise<void> {
  if (!isAdhanNativePlaybackPlatform()) return
  try {
    await AdhanScheduler.stopMirroredPlayback()
  } catch {
    /* nothing was playing - honest no-op. */
  }
}

/**
 * Subscribe to native playback completion (the banner auto-dismisses on
 * it, mirroring the web player's onEnded path). Returns an unsubscribe
 * function; a no-op on other platforms.
 */
export async function onAdhanNativePlaybackEnded(callback: () => void): Promise<() => void> {
  if (!isAdhanNativePlaybackPlatform()) return () => undefined
  try {
    const handle = await AdhanScheduler.addListener('playbackEnded', () => callback())
    return () => {
      void handle.remove()
    }
  } catch {
    return () => undefined
  }
}
