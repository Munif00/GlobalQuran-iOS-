/**
 * Global Quran - Native prayer cache backend (IndexedDB).
 *
 * The hybrid prayer resolver caches successful upstream payloads so live
 * data is served read-through (< 24 h) and stale data remains available
 * when every live tier fails. On the web server the backend is Prisma
 * (src/server/prayer/cache.ts); inside the native app it is this IndexedDB
 * store, registered through the platform-agnostic port
 * (src/lib/prayer-engine/cache-port.ts) when the native adapter boots.
 *
 * If IndexedDB is unavailable (private mode, storage quota, ...), the port
 * keeps its built-in in-memory fallback cache - the resolver stays
 * functional, results simply are not persisted.
 */

import { setPrayerCache, type CacheReadResult, type CachedPrayerPayload, type PrayerCachePort } from '@/lib/prayer-engine/cache-port'

const DB_NAME = 'global-quran-native'
const DB_VERSION = 1
const STORE = 'prayer-cache'

interface StoredEntry {
  cacheKey: string
  kind: 'day' | 'month' | 'year'
  dateLabel: string
  sourceType: string
  sourceName: string
  payload: CachedPrayerPayload
  fetchedAt: string
}

function openDb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (typeof indexedDB === 'undefined') {
      resolve(null)
      return
    }
    let request: IDBOpenDBRequest
    try {
      request = indexedDB.open(DB_NAME, DB_VERSION)
    } catch {
      resolve(null)
      return
    }
    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'cacheKey' })
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => resolve(null)
    request.onblocked = () => resolve(null)
  })
}

/** Bounded entry count - old entries are evicted first (fetchedAt asc). */
const MAX_ENTRIES = 400

class IndexedDbPrayerCache implements PrayerCachePort {
  private dbPromise: Promise<IDBDatabase | null>

  constructor() {
    this.dbPromise = openDb()
  }

  private async run<T>(
    operation: (store: IDBObjectStore) => IDBRequest<T>,
  ): Promise<T | null> {
    const db = await this.dbPromise
    if (!db) return null
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE, 'readwrite')
        const request = operation(tx.objectStore(STORE))
        request.onsuccess = () => resolve(request.result)
        request.onerror = () => resolve(null)
        tx.onabort = () => resolve(null)
      } catch {
        resolve(null)
      }
    })
  }

  async read(key: string): Promise<CacheReadResult | null> {
    const entry = (await this.run<IDBValidKey | undefined>((store) => store.get(key))) as
      | StoredEntry
      | undefined
      | null
    if (!entry || entry === null) return null
    const stored = entry as StoredEntry
    if (!stored || typeof stored !== 'object' || !stored.payload) return null
    return {
      days: stored.payload.days,
      meta: stored.payload.meta,
      sourceName: stored.payload.sourceName,
      fetchedAt: stored.fetchedAt,
      isCached: true,
    }
  }

  async write(entry: {
    cacheKey: string
    kind: 'day' | 'month' | 'year'
    dateLabel: string
    sourceType: string
    sourceName: string
    payload: CachedPrayerPayload
  }): Promise<void> {
    const record: StoredEntry = {
      cacheKey: entry.cacheKey,
      kind: entry.kind,
      dateLabel: entry.dateLabel,
      sourceType: entry.sourceType,
      sourceName: entry.sourceName,
      payload: entry.payload,
      fetchedAt: new Date().toISOString(),
    }
    await this.run((store) => store.put(record))
    // Opportunistic eviction: keep the store bounded.
    const count = (await this.run<number>((store) => store.count())) as number | null
    if (typeof count === 'number' && count > MAX_ENTRIES) {
      const all = (await this.run<StoredEntry[]>((store) => store.getAll())) as
        | StoredEntry[]
        | null
      if (Array.isArray(all)) {
        const excess = all
          .slice()
          .sort((a, b) => String(a.fetchedAt).localeCompare(String(b.fetchedAt)))
          .slice(0, count - MAX_ENTRIES)
        for (const victim of excess) {
          await this.run((store) => store.delete(victim.cacheKey))
        }
      }
    }
  }
}

let registered = false

/**
 * Register the IndexedDB prayer cache once (native adapter boot).
 * Idempotent; a failed registration leaves the in-memory fallback active.
 */
export function registerNativePrayerCache(): void {
  if (registered) return
  registered = true
  if (typeof indexedDB === 'undefined') return
  setPrayerCache(new IndexedDbPrayerCache())
}
