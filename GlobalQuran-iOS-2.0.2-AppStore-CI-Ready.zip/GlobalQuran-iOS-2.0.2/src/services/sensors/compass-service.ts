/**
 * Compass (device orientation) service.
 *
 * Platform-aware heading pipeline built on the browser DeviceOrientation
 * APIs, with honest semantics at every step:
 *
 * Sources, in priority order:
 * 1. iOS `webkitCompassHeading` - a tilt-compensated compass heading of the
 *    device's top edge relative to MAGNETIC north (WebKit/Safari, CoreMotion
 *    based). A magnetic reading: it is corrected to true north with the
 *    WMM2025 declination for the user's location when that is available.
 * 2. `deviceorientationabsolute` (and absolute `deviceorientation`) events -
 *    the W3C-specified absolute orientation referenced to the EARTH frame
 *    with true north (Chrome/Android, Android rotation-vector sensors).
 *    The heading is computed from the full alpha/beta/gamma rotation matrix
 *    so it works at any device tilt, then compensated for screen rotation.
 * 3. Relative-only orientation events - NOT trustworthy as a compass. They
 *    are reported as `heading: null` with `source: 'relative-orientation'`
 *    so the UI can offer the manual fallback instead of a fake needle.
 *
 * Screen rotation: the heading always describes where the TOP OF THE SCREEN
 * (as the content is displayed) points, not the physical device top. The
 * compensation uses `screen.orientation.angle` (standard) with a legacy
 * `window.orientation` fallback.
 *
 * No value is ever invented: a heading exists only when a real sensor event
 * produced it. Every function is server-safe (no `window` -> unavailable,
 * no listeners registered).
 *
 * Native (Capacitor) note: these WebView-standard APIs work unchanged inside
 * Capacitor's Android WebView and iOS WKWebView, which is the primary native
 * path. The inspected plugin landscape and the prepared custom-plugin seam
 * are documented in agent-ctx/5-qibla-capacitor-preparation.md. No native
 * sensor behavior is claimed without physical-device testing.
 */

import { magneticDeclination, type DeclinationResult } from '@/lib/geomagnetism'

/** A single compass reading derived from real orientation events. */
export interface CompassReading {
  /**
   * Heading of the top of the displayed screen, degrees clockwise from
   * north - true north when `reference === 'true_north'`, magnetic north
   * when uncorrected. Null until a compass-grade reading exists.
   */
  heading: number | null
  /** What the heading is referenced to. */
  reference: 'true_north' | 'magnetic'
  /** True when the WMM declination correction was applied to this reading. */
  declinationApplied: boolean
  /** Where this reading came from. */
  source: 'webkit-compass' | 'absolute-orientation' | 'relative-orientation'
  /** Event-reported accuracy in degrees (iOS webkitCompassAccuracy); null when unknown. */
  accuracy: number | null
  /**
   * Device tilt away from flat (screen-up), in degrees 0-90. The
   * screen-top heading degenerates when the device is vertical; the UI
   * uses this to suggest holding the device flatter. Null for the iOS
   * path (CoreMotion already tilt-compensates; tilt is not exposed).
   */
  tilt: number | null
  /** Wall-clock timestamp of the reading (Date.now() at event time). */
  timestamp: number
}

/** Options for startCompassListening. */
export interface CompassListenOptions {
  /**
   * Supplies the current user location (or null) so magnetic readings can
   * be corrected to true north with the WMM2025 declination. Called on
   * every event, so the correction always reflects the latest location.
   */
  getLocation: () => { latitude: number; longitude: number } | null
}

/**
 * Locally extended view of DeviceOrientationEvent. Every field is optional:
 * browsers ship partial implementations, and `webkitCompassHeading` /
 * `webkitCompassAccuracy` are non-standard iOS extensions absent from DOM typings.
 */
interface CompassOrientationEvent {
  readonly alpha?: number | null
  readonly beta?: number | null
  readonly gamma?: number | null
  readonly absolute?: boolean
  readonly webkitCompassHeading?: number | null
  readonly webkitCompassAccuracy?: number | null
}

/** The DeviceOrientationEvent constructor, with the optional iOS 13+ permission API. */
interface OrientationEventConstructor {
  requestPermission?: () => Promise<'granted' | 'denied'>
}

/** Normalize any angle into [0, 360). */
function normalizeDegrees(value: number): number {
  return ((value % 360) + 360) % 360
}

/** Server-safe access to the DeviceOrientationEvent constructor on window. */
function getOrientationEventConstructor(): OrientationEventConstructor | null {
  if (typeof window === 'undefined') return null
  const constructor = (window as unknown as { DeviceOrientationEvent?: OrientationEventConstructor })
    .DeviceOrientationEvent
  return constructor ?? null
}

/** Whether the browser exposes the DeviceOrientation API at all. */
export function isCompassApiAvailable(): boolean {
  if (typeof window === 'undefined') return false
  return 'DeviceOrientationEvent' in window
}

/** Whether iOS-style explicit permission is required before listening. */
export function compassRequiresExplicitPermission(): boolean {
  const constructor = getOrientationEventConstructor()
  return constructor !== null && typeof constructor.requestPermission === 'function'
}

/**
 * Request compass permission (iOS 13+). Must be triggered by a user gesture.
 *
 * - 'unsupported' when the DeviceOrientation API is missing entirely
 * - 'granted' when no explicit request is needed, or the user allowed it
 * - 'denied' when the user refused (or the request threw)
 */
export async function requestCompassPermission(): Promise<'granted' | 'denied' | 'unsupported'> {
  const constructor = getOrientationEventConstructor()
  if (!constructor) return 'unsupported'

  const requestPermission = constructor.requestPermission
  if (typeof requestPermission !== 'function') return 'granted'

  try {
    const result = await requestPermission.call(constructor)
    return result === 'granted' ? 'granted' : 'denied'
  } catch {
    return 'denied'
  }
}

/**
 * The current screen-orientation angle in degrees (0/90/180/270):
 * how far the displayed content is rotated relative to the device's
 * natural orientation. Standard API first; legacy iOS `window.orientation`
 * fallback (same convention as screen.orientation.angle).
 */
export function getScreenOrientationAngle(): number {
  if (typeof window === 'undefined' || typeof screen === 'undefined') return 0
  const orientation = (screen as Screen & { orientation?: { angle?: number } }).orientation
  if (orientation && typeof orientation.angle === 'number') {
    return ((orientation.angle % 360) + 360) % 360
  }
  const legacy = (window as unknown as { orientation?: number }).orientation
  if (typeof legacy === 'number') {
    return ((legacy % 360) + 360) % 360
  }
  return 0
}

/**
 * Heading of the top of the screen from an absolute device orientation
 * (alpha/beta/gamma), valid at any tilt.
 *
 * Math: the W3C deviceorientation spec builds the rotation matrix that
 * maps DEVICE-frame vectors to EARTH-frame vectors,
 * R = Rz(alpha)·Rx(beta)·Ry(gamma) (intrinsic Z-X-Y, earth frame
 * x=East, y=North, z=Up; spec worked example: flat device with the top
 * pointing East has alpha=270, and the top-edge heading is 360-alpha).
 * The displayed-content up direction in the DEVICE frame is the natural
 * top edge (0,1,0) rotated by -screenAngle about the device z-axis:
 * (sin A, cos A, 0). Mapping it to the earth frame (v_e = R · v_d) and
 * projecting onto the horizon gives the azimuth:
 *   east  = sinA·R11 + cosA·R12
 *   north = sinA·R21 + cosA·R22
 *   heading = atan2(east, north)
 * (Rij = row i, column j of R.) At beta=gamma=0 this reduces exactly to
 * the flat-device formula 360 - alpha + screenAngle, which the fallback
 * path below uses - the two paths are consistent by construction.
 * The horizontal projection length also yields the effective tilt.
 */
function absoluteOrientationToHeading(
  alpha: number,
  beta: number,
  gamma: number,
  screenAngle: number,
): { heading: number; horizontalProjection: number } {
  const a = (alpha * Math.PI) / 180
  const b = (beta * Math.PI) / 180
  const g = (gamma * Math.PI) / 180
  const sa = (screenAngle * Math.PI) / 180
  const sinA = Math.sin(sa)
  const cosA = Math.cos(sa)

  const ca = Math.cos(a)
  const sa2 = Math.sin(a)
  const cb = Math.cos(b)
  const sb = Math.sin(b)
  const cg = Math.cos(g)
  const sg = Math.sin(g)

  // Rows of R = Rz(alpha)·Rx(beta)·Ry(gamma) (device -> earth):
  //   row 1 (East components):  [ca·cg − sa·sb·sg,  −sa·cb, ca·sg + sa·sb·cg]
  //   row 2 (North components): [sa·cg + ca·sb·sg,   ca·cb, sa·sg − ca·sb·cg]
  const r11 = ca * cg - sa2 * sb * sg
  const r21 = sa2 * cg + ca * sb * sg
  const r12 = -sa2 * cb
  const r22 = ca * cb

  // v_e = R · v_d for v_d = (sinA, cosA, 0): take the corresponding
  // elements of rows 1 (East) and 2 (North).
  const east = sinA * r11 + cosA * r12
  const north = sinA * r21 + cosA * r22
  const horizontal = Math.sqrt(east * east + north * north)

  const heading = normalizeDegrees((Math.atan2(east, north) * 180) / Math.PI)
  return { heading, horizontalProjection: horizontal }
}

/** Cached declination lookups (per rounded location) - WMM is deterministic. */
const declinationCache = new Map<string, DeclinationResult>()

function lookupDeclination(latitude: number, longitude: number): DeclinationResult | null {
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return null
  const key = `${latitude.toFixed(3)},${longitude.toFixed(3)}`
  const cached = declinationCache.get(key)
  if (cached) return cached
  try {
    const result = magneticDeclination(latitude, longitude, 0, new Date())
    if (declinationCache.size > 32) declinationCache.clear()
    declinationCache.set(key, result)
    return result
  } catch {
    return null
  }
}

/**
 * Start listening to device orientation events for compass readings.
 * See the module header for the source priority and semantics.
 *
 * Returns a cleanup function that removes both listeners.
 */
export function startCompassListening(
  onReading: (reading: CompassReading) => void,
  options?: CompassListenOptions,
): () => void {
  if (typeof window === 'undefined') return () => undefined

  const getLocation = options?.getLocation ?? (() => null)

  const handleOrientation = (event: Event): void => {
    const data = event as unknown as CompassOrientationEvent
    const timestamp = Date.now()
    const screenAngle = getScreenOrientationAngle()

    /* Source 1: iOS explicit compass heading (magnetic, tilt-compensated). */
    if (data.webkitCompassHeading != null && Number.isFinite(data.webkitCompassHeading)) {
      const magnetic = normalizeDegrees(data.webkitCompassHeading)
      // The displayed-content top azimuth = device-top azimuth + screenAngle
      // (rotating the device counterclockwise moves the UI top clockwise
      // relative to the physical top edge).
      const screenMagnetic = normalizeDegrees(magnetic + screenAngle)

      const location = getLocation()
      const declination = location ? lookupDeclination(location.latitude, location.longitude) : null
      if (declination) {
        onReading({
          heading: normalizeDegrees(screenMagnetic + declination.declination),
          reference: 'true_north',
          declinationApplied: true,
          source: 'webkit-compass',
          accuracy:
            data.webkitCompassAccuracy != null && Number.isFinite(data.webkitCompassAccuracy)
              ? data.webkitCompassAccuracy
              : null,
          tilt: null,
          timestamp,
        })
      } else {
        // No location -> cannot compute declination. Report the magnetic
        // heading honestly; the UI must label it as uncorrected.
        onReading({
          heading: screenMagnetic,
          reference: 'magnetic',
          declinationApplied: false,
          source: 'webkit-compass',
          accuracy:
            data.webkitCompassAccuracy != null && Number.isFinite(data.webkitCompassAccuracy)
              ? data.webkitCompassAccuracy
              : null,
          tilt: null,
          timestamp,
        })
      }
      return
    }

    /* Source 2/3: alpha-based orientation. */
    if (data.alpha != null && Number.isFinite(data.alpha)) {
      const isAbsolute =
        data.absolute === true || event.type === 'deviceorientationabsolute'

      if (isAbsolute && data.beta != null && Number.isFinite(data.beta) && data.gamma != null && Number.isFinite(data.gamma)) {
        // Full absolute orientation: compute a tilt-independent heading.
        const { heading, horizontalProjection } = absoluteOrientationToHeading(
          data.alpha,
          data.beta,
          data.gamma,
          screenAngle,
        )
        // Tilt from flat: 0 = screen up, 90 = vertical.
        const tilt = (Math.acos(Math.min(1, Math.max(0, horizontalProjection))) * 180) / Math.PI
        onReading({
          heading,
          reference: 'true_north',
          declinationApplied: false,
          source: 'absolute-orientation',
          accuracy: null,
          tilt,
          timestamp,
        })
        return
      }

      if (isAbsolute) {
        // Absolute flag but no usable beta/gamma: fall back to the flat-device
        // approximation heading = 360 - alpha + screenAngle. Only meaningful
        // while the device is roughly level; report the tilt as unknown.
        const heading = normalizeDegrees(360 - data.alpha + screenAngle)
        onReading({
          heading,
          reference: 'true_north',
          declinationApplied: false,
          source: 'absolute-orientation',
          accuracy: null,
          tilt: null,
          timestamp,
        })
        return
      }

      // Relative orientation only: not trustworthy as a compass heading.
      onReading({
        heading: null,
        reference: 'magnetic',
        declinationApplied: false,
        source: 'relative-orientation',
        accuracy: null,
        tilt: null,
        timestamp,
      })
      return
    }

    // No usable orientation data in this event: emit nothing.
  }

  window.addEventListener('deviceorientationabsolute', handleOrientation)
  window.addEventListener('deviceorientation', handleOrientation)

  return () => {
    window.removeEventListener('deviceorientationabsolute', handleOrientation)
    window.removeEventListener('deviceorientation', handleOrientation)
  }
}

/* ------------------------------------------------------------------ */
/* Reading stability analysis                                          */
/* ------------------------------------------------------------------ */

/** Rolling-window heading samples used to judge sensor stability. */
export class HeadingStabilityMonitor {
  private readonly samples: Array<{ heading: number | null; timestamp: number }> = []
  private readonly windowMs: number
  private readonly maxSamples: number

  constructor(windowMs = 3000, maxSamples = 60) {
    this.windowMs = windowMs
    this.maxSamples = maxSamples
  }

  /** Push a heading sample (null = event without a usable heading). */
  push(heading: number | null, timestamp: number): void {
    this.samples.push({ heading, timestamp })
    if (this.samples.length > this.maxSamples) this.samples.shift()
    // Drop samples older than the window.
    while (this.samples.length > 0 && timestamp - this.samples[0].timestamp > this.windowMs) {
      this.samples.shift()
    }
  }

  /**
   * Assess stability over the window.
   * - 'no-data': not enough samples yet.
   * - 'stale': no fresh sample within the last 2 s (sensor stopped/paused).
   * - 'unstable': excessive jitter - mean absolute heading change per
   *   reading above 12°/s sustained, typical near magnetic interference.
   *   (Genuine alignment claims require 'steady'; see the Qibla screen.)
   * - 'steady': trustworthy stream.
   */
  assess(now: number): 'no-data' | 'stale' | 'unstable' | 'steady' {
    const withHeading = this.samples.filter(
      (sample) => sample.heading != null && now - sample.timestamp <= this.windowMs,
    )
    if (this.samples.length === 0 || withHeading.length === 0) return 'no-data'

    const newest = this.samples[this.samples.length - 1]
    if (newest.heading == null || now - newest.timestamp > 2000) return 'stale'
    if (withHeading.length < 6) return 'no-data'

    // Total angular travel within the window (degree magnitude per second).
    let travel = 0
    let spanMs = 0
    for (let i = 1; i < withHeading.length; i++) {
      const prev = withHeading[i - 1].heading as number
      const cur = withHeading[i].heading as number
      let delta = Math.abs(cur - prev) % 360
      if (delta > 180) delta = 360 - delta
      travel += delta
      spanMs = Math.max(spanMs, withHeading[i].timestamp - withHeading[0].timestamp)
    }
    if (spanMs < 500) return 'no-data'

    const travelPerSecond = travel / (spanMs / 1000)
    return travelPerSecond > 12 ? 'unstable' : 'steady'
  }

  reset(): void {
    this.samples.length = 0
  }
}
