/**
 * Size probes - the exact download size of every option, BEFORE the user
 * downloads anything.
 *
 * Three probes back the size labels in the translation details dialog:
 * - `probePackSize`     HEAD /api/quran/offline-pack/{key}         (in-app pack)
 * - `probeFileSize`     HEAD /api/downloads/{key}/{fileId}         (source files)
 * - `probeExportSizes`  GET  /api/quran/export/{key}?probe=1       (generated files)
 *
 * Every number these return is measured, never estimated: the pack size is
 * the byte length of the exact payload the download would stream, the file
 * size comes from the file host itself, and the export sizes are the byte
 * lengths of the documents the server actually builds.
 *
 * Results are cached for the whole session (keyed per target), and in-flight
 * requests are shared, so opening the dialog repeatedly or rendering several
 * rows never duplicates a probe. Failed probes are not cached - the next
 * call retries (e.g. after the connection comes back).
 */

import { platformFetch } from '@/services/platform/fetch'

/** Exact byte sizes of every generated export format. */
export interface ExportSizeProbe {
  docx: number
  txt: number
  json: number
  html: number
}

/**
 * The pack route aggregates all 114 suras on the first request (afterwards
 * the 24-hour server cache answers) - allow a long probe.
 */
const PACK_PROBE_TIMEOUT_MS = 180_000
/** File size probes are a quick upstream HEAD (with a range fallback). */
const FILE_PROBE_TIMEOUT_MS = 20_000
/** Export probes aggregate like a real export on first request. */
const EXPORT_PROBE_TIMEOUT_MS = 300_000

/** Session cache: translation key -> exact pack size in bytes. */
const packSizeCache = new Map<string, Promise<number | null>>()
/** Session cache: `translationKey/fileId` -> exact file size in bytes. */
const fileSizeCache = new Map<string, Promise<number | null>>()
/** Session cache: translation key -> exact sizes of every export format. */
const exportSizeCache = new Map<string, Promise<ExportSizeProbe | null>>()

/** Read a safe positive integer from a Content-Length header. */
function readContentLength(response: Response): number | null {
  const raw = response.headers.get('content-length')
  if (raw === null) return null
  const value = Number(raw)
  return Number.isSafeInteger(value) && value >= 0 ? value : null
}

/**
 * Run a cached probe: the promise is shared while in flight and removed again
 * when it fails, so failures are retried on the next call.
 */
function cachedProbe<T>(
  cache: Map<string, Promise<T | null>>,
  key: string,
  run: () => Promise<T | null>,
): Promise<T | null> {
  const existing = cache.get(key)
  if (existing) return existing
  const promise = run().catch(() => null)
  promise
    .then((value) => {
      if (value === null) cache.delete(key)
    })
    .catch(() => cache.delete(key))
  cache.set(key, promise)
  return promise
}

/**
 * The exact size in bytes of one translation's offline pack - the payload
 * the "Download for offline reading" action would stream and store.
 */
export function probePackSize(translationKey: string): Promise<number | null> {
  return cachedProbe(packSizeCache, translationKey, async () => {
    const response = await platformFetch(
      `/api/quran/offline-pack/${encodeURIComponent(translationKey)}`,
      { method: 'HEAD', signal: AbortSignal.timeout(PACK_PROBE_TIMEOUT_MS) },
    )
    if (!response.ok) return null
    return readContentLength(response)
  })
}

/**
 * The exact size in bytes of one source-published document file (PDF, EPUB,
 * SQLite) - measured from the file host, for formats whose size the catalog
 * does not publish.
 */
export function probeFileSize(translationKey: string, fileId: string): Promise<number | null> {
  const cacheKey = `${translationKey}/${fileId}`
  return cachedProbe(fileSizeCache, cacheKey, async () => {
    const response = await platformFetch(
      `/api/downloads/${encodeURIComponent(translationKey)}/${encodeURIComponent(fileId)}`,
      { method: 'HEAD', signal: AbortSignal.timeout(FILE_PROBE_TIMEOUT_MS) },
    )
    if (!response.ok) return null
    return readContentLength(response)
  })
}

/**
 * The exact sizes in bytes of every generated export format (Word, Text,
 * JSON and the print document). One request builds all formats once through
 * the shared server-side sura cache.
 */
export function probeExportSizes(
  translationKey: string,
  localization: string,
): Promise<ExportSizeProbe | null> {
  return cachedProbe(exportSizeCache, translationKey, async () => {
    const response = await platformFetch(
      `/api/quran/export/${encodeURIComponent(translationKey)}?probe=1&localization=${encodeURIComponent(localization)}`,
      { signal: AbortSignal.timeout(EXPORT_PROBE_TIMEOUT_MS) },
    )
    if (!response.ok) return null
    const data: unknown = await response.json()
    if (data === null || typeof data !== 'object' || !('sizes' in data)) return null
    const sizes = (data as { sizes?: unknown }).sizes
    if (sizes === null || typeof sizes !== 'object') return null
    const record = sizes as Record<string, unknown>
    const result: ExportSizeProbe = {
      docx: Number(record.docx),
      txt: Number(record.txt),
      json: Number(record.json),
      html: Number(record.html),
    }
    const valid = (value: number) => Number.isSafeInteger(value) && value > 0
    return valid(result.docx) && valid(result.txt) && valid(result.json) && valid(result.html)
      ? result
      : null
  })
}
