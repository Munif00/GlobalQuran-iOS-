/**
 * Recitation audio download engine (PROMPT 9).
 *
 * Downloads VERIFIED recitation audio (one ayah = one MP3) into the local
 * audio library for offline playback. A batch can cover:
 *
 * - one ayah,
 * - one sura,
 * - a selected ayah range within a sura,
 * - one juz, or
 * - the complete Quran package of a reciter - offered ONLY when the
 *   verified source inventory actually contains all 6236 ayat.
 *
 * The file list and the EXACT per-file byte sizes always come from the
 * server's verified plan (/api/quran/audio/batch) - never assumed. Files
 * the source does not have are reported as missing and never downloaded.
 *
 * Robustness contract:
 * - Progress: byte-accurate against the plan's exact sizes, plus a
 *   per-file counter (filesCompleted / filesTotal).
 * - Pause/resume: an aborted file keeps its partial payload (byte-range
 *   resume); completed files are skipped on resume. Survives app restarts.
 * - Retry: a failed/interrupted batch resumes with only the missing or
 *   failed files.
 * - Cancel: stops the transfer and drops the partial data (stored files
 *   stay stored - they were verified).
 * - Verification: every completed file must match its planned exact size;
 *   a SHA-256 checksum is computed and recorded in the manifest.
 * - Duplicate prevention: one active batch per (style + kind + params);
 *   a batch whose every file is already stored is reported as
 *   already-downloaded instead of enqueued.
 * - Storage: quota preflight before each file; a quota failure marks the
 *   batch `insufficient-storage` without corrupting anything.
 * - Honesty: a batch only completes when every planned file is stored and
 *   verified - an incomplete sura/package is never reported as complete.
 */

import { platformFetch } from '@/services/platform/fetch'
import { getAudioLibrary, audioEntryId } from '@/services/storage/audio-library'
import { getFileStorage, getStorageEstimate, requestPersistentStorage } from '@/services/storage/local-file-storage'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { sha256Hex } from '@/utils/checksum'
import { getStyleDefinition } from '@/data/audio-styles'
import { everyAyahFileUrl } from '@/lib/audio/urls'
import type {
  AudioBatchDescriptor,
  AudioBatchKind,
  AudioBatchPlanFile,
  AudioBatchPlanResponse,
  AudioManifestEntry,
  DownloadJobRecord,
} from '@/types'

/** Audio batches are file-heavy - at most two run at the same time. */
const MAX_CONCURRENT_BATCHES = 2
/** Safety margin applied to quota preflight. */
const QUOTA_MARGIN_BYTES = 64 * 1024 * 1024

export type AudioBatchSpec =
  | { styleId: string; kind: 'ayah'; sura: number; ayah: number }
  | { styleId: string; kind: 'sura'; sura: number }
  | { styleId: string; kind: 'range'; sura: number; from: number; to: number }
  | { styleId: string; kind: 'juz'; juz: number }
  | { styleId: string; kind: 'complete' }

export type EnqueueAudioBatchResult =
  | { ok: true; jobId: string }
  | { ok: false; reason: 'duplicate-active' | 'already-downloaded' | 'plan-unavailable' | 'invalid-style' | 'incomplete-source' }

interface EngineBatch {
  record: DownloadJobRecord
  /** Verified plan file list (re-fetched on demand after a restart). */
  planFiles: AudioBatchPlanFile[] | null
  controller: AbortController | null
}

const batches = new Map<string, EngineBatch>()

function nowIso(): string {
  return new Date().toISOString()
}

function makeJobId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `ab-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}

function ui() {
  return useDownloadManagerStore.getState()
}

async function commit(record: DownloadJobRecord, skipPersist = false): Promise<void> {
  if (!skipPersist) {
    try {
      await getFileStorage().putJob(record)
    } catch {
      // Job persistence is best-effort; the engine keeps running.
    }
  }
  ui().setJob(record)
}

function batchSignature(spec: AudioBatchSpec): string {
  switch (spec.kind) {
    case 'ayah':
      return `${spec.styleId}|ayah|${spec.sura}|${spec.ayah}`
    case 'sura':
      return `${spec.styleId}|sura|${spec.sura}`
    case 'range':
      return `${spec.styleId}|range|${spec.sura}|${spec.from}|${spec.to}`
    case 'juz':
      return `${spec.styleId}|juz|${spec.juz}`
    case 'complete':
      return `${spec.styleId}|complete`
  }
}

function descriptorSignature(descriptor: AudioBatchDescriptor): string {
  return `${descriptor.styleId}|${descriptor.batchKind}|${descriptor.sura ?? ''}|${descriptor.ayahFrom ?? ''}|${descriptor.ayahTo ?? ''}|${descriptor.juz ?? ''}`
}

function planUrlForDescriptor(descriptor: AudioBatchDescriptor): string {
  const params = new URLSearchParams({ styleId: descriptor.styleId, kind: descriptor.batchKind })
  if (descriptor.sura !== null) params.set('sura', String(descriptor.sura))
  if (descriptor.ayahFrom !== null) params.set(descriptor.batchKind === 'ayah' ? 'ayah' : 'from', String(descriptor.ayahFrom))
  if (descriptor.batchKind === 'range' && descriptor.ayahTo !== null) params.set('to', String(descriptor.ayahTo))
  if (descriptor.juz !== null) params.set('juz', String(descriptor.juz))
  return `/api/quran/audio/batch?${params.toString()}`
}

async function fetchPlan(descriptor: AudioBatchDescriptor): Promise<AudioBatchPlanResponse | null> {
  try {
    const response = await platformFetch(planUrlForDescriptor(descriptor), { credentials: 'same-origin' })
    if (!response.ok) return null
    return (await response.json()) as AudioBatchPlanResponse
  } catch {
    return null
  }
}

/** True when the batch job is in flight (not terminal). */
function isActiveRecord(record: DownloadJobRecord): boolean {
  return !['completed', 'failed', 'canceled', 'corrupted'].includes(record.status)
}

/* ------------------------------------------------------------------ */
/* Enqueue                                                             */
/* ------------------------------------------------------------------ */

/**
 * Enqueue one recitation audio batch. The verified plan is fetched first
 * (exact file list + sizes); the batch is only created when the plan is
 * available. A complete package is only allowed when the source inventory
 * actually covers every ayah (completePackageOfferable).
 */
export async function enqueueAudioBatch(spec: AudioBatchSpec): Promise<EnqueueAudioBatchResult> {
  const style = getStyleDefinition(spec.styleId)
  if (!style) return { ok: false, reason: 'invalid-style' }

  const descriptorSeed: AudioBatchDescriptor = {
    styleId: spec.styleId,
    reciterName: style.reciterName,
    styleLabel: style.styleLabel,
    batchKind: spec.kind,
    sura: spec.kind === 'ayah' || spec.kind === 'sura' || spec.kind === 'range' ? spec.sura : null,
    ayahFrom: spec.kind === 'ayah' ? spec.ayah : spec.kind === 'range' ? spec.from : null,
    ayahTo: spec.kind === 'ayah' ? spec.ayah : spec.kind === 'range' ? spec.to : null,
    juz: spec.kind === 'juz' ? spec.juz : null,
    filesTotal: 0,
    filesCompleted: 0,
    filesFailed: 0,
    bytesTotal: 0,
  }

  // A complete package may only be offered when the verified source
  // inventory covers every ayah - checked again here, at enqueue time.
  if (spec.kind === 'complete') {
    const plan = await fetchPlan(descriptorSeed)
    if (!plan) return { ok: false, reason: 'plan-unavailable' }
    if (!plan.completePackageOfferable) return { ok: false, reason: 'incomplete-source' }
    return finishEnqueue(plan)
  }

  return finishEnqueue(null)

  async function finishEnqueue(completePlan: AudioBatchPlanResponse | null): Promise<EnqueueAudioBatchResult> {
    // Duplicate prevention: one active batch with the same signature.
    const signature = batchSignature(spec)
    const activeDuplicates = Object.values(ui().jobs).filter(
      (job) =>
        job.kind === 'audio-batch' &&
        job.audioBatch !== undefined &&
        isActiveRecord(job) &&
        descriptorSignature(job.audioBatch) === signature,
    )
    if (activeDuplicates.length > 0) return { ok: false, reason: 'duplicate-active' }

    // The verified plan (fetched fresh unless the complete check already did).
    const plan = completePlan ?? (await fetchPlan(descriptorSeed))
    if (!plan || plan.files.length === 0) return { ok: false, reason: 'plan-unavailable' }
    if (plan.styleId !== spec.styleId) return { ok: false, reason: 'plan-unavailable' }

    // Skip files already stored + verified; if everything is already there,
    // report it instead of enqueueing a no-op batch.
    const library = getAudioLibrary()
    const pending: AudioBatchPlanFile[] = []
    let alreadyStored = 0
    let alreadyBytes = 0
    for (const file of plan.files) {
      const entry = await library.getEntry(spec.styleId, file.sura, file.ayah).catch(() => null)
      if (entry && entry.verification === 'verified') {
        alreadyStored += 1
        alreadyBytes += entry.fileSize
      } else {
        pending.push(file)
      }
    }
    if (pending.length === 0) return { ok: false, reason: 'already-downloaded' }

    const descriptor: AudioBatchDescriptor = {
      ...descriptorSeed,
      filesTotal: plan.files.length,
      filesCompleted: alreadyStored,
      filesFailed: 0,
      bytesTotal: plan.totalBytes,
    }

    const record: DownloadJobRecord = {
      id: makeJobId(),
      kind: 'audio-batch',
      translationKey: null,
      translationTitle: `${plan.reciterName} — ${plan.styleLabel}`,
      languageName: null,
      fileId: `audio-${signature}`,
      fileName: batchLabel(descriptor),
      format: 'mp3',
      sourceUrl: planUrlForDescriptor(descriptor),
      expectedSize: plan.totalBytes,
      sourceVersion: null,
      status: 'queued',
      bytesReceived: alreadyBytes,
      totalBytes: plan.totalBytes,
      errorCode: null,
      checksum: null,
      storedFileId: null,
      rangeSupported: null,
      createdAt: nowIso(),
      updatedAt: nowIso(),
      completedAt: null,
      audioBatch: descriptor,
    }

    batches.set(record.id, { record, planFiles: plan.files, controller: null })
    await commit(record)
    void requestPersistentStorage()
    pumpQueue()
    return { ok: true, jobId: record.id }
  }
}

/** Short human-readable batch label (fallback display). */
function batchLabel(descriptor: AudioBatchDescriptor): string {
  switch (descriptor.batchKind) {
    case 'ayah':
      return `Surah ${descriptor.sura} · Ayah ${descriptor.ayahFrom} (audio)`
    case 'sura':
      return `Surah ${descriptor.sura} (audio)`
    case 'range':
      return `Surah ${descriptor.sura} · Ayat ${descriptor.ayahFrom}–${descriptor.ayahTo} (audio)`
    case 'juz':
      return `Juz ${descriptor.juz} (audio)`
    case 'complete':
      return 'Complete Quran (audio)'
  }
}

/* ------------------------------------------------------------------ */
/* Engine loop                                                         */
/* ------------------------------------------------------------------ */

function countRunning(): number {
  let running = 0
  for (const batch of batches.values()) {
    if (batch.record.status === 'downloading' || batch.record.status === 'verifying') running += 1
  }
  return running
}

function pumpQueue(): void {
  const queued = [...batches.values()]
    .filter((batch) => batch.record.status === 'queued')
    .sort((a, b) => a.record.createdAt.localeCompare(b.record.createdAt))
  for (const batch of queued) {
    if (countRunning() >= MAX_CONCURRENT_BATCHES) break
    void runBatch(batch)
  }
}

/** Pause an active audio batch (the current file's partial is persisted). */
export async function pauseAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (!batch) return
  if (batch.record.status === 'downloading') {
    batch.controller?.abort()
    // The abort handler persists the partial and flips the record.
    return
  }
  if (batch.record.status === 'queued' || batch.record.status === 'verifying') {
    const updated = { ...batch.record, status: 'paused' as const, updatedAt: nowIso() }
    batch.record = updated
    await commit(updated)
  }
}

/** Resume / retry a paused, interrupted or failed audio batch. */
export async function resumeAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (!batch) return
  if (!['paused', 'interrupted', 'failed', 'canceled', 'corrupted'].includes(batch.record.status)) return
  const descriptor = batch.record.audioBatch
  const updated: DownloadJobRecord = {
    ...batch.record,
    status: 'queued',
    errorCode: null,
    // A failed batch retried: failed files are attempted again.
    updatedAt: nowIso(),
  }
  if (descriptor) descriptor.filesFailed = 0
  batch.record = updated
  await commit(updated)
  pumpQueue()
}

export function retryAudioBatch(jobId: string): Promise<void> {
  return resumeAudioBatch(jobId)
}

/** Cancel: stop the transfer and drop the partial data (stored files stay). */
export async function cancelAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (!batch) return
  if (batch.record.status === 'downloading') {
    batch.controller?.abort('cancel')
    return
  }
  await getAudioLibrary().deletePartialsForBatch(jobId).catch(() => undefined)
  batches.delete(jobId)
  ui().removeJob(jobId)
  await getFileStorage().deleteJob(jobId).catch(() => undefined)
}

/** Dismiss a finished audio batch record (stored files are kept). */
export async function dismissAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (batch && isActiveRecord(batch.record)) return
  batches.delete(jobId)
  ui().removeJob(jobId)
  await getFileStorage().deleteJob(jobId).catch(() => undefined)
}

class AudioDownloadError extends Error {
  readonly code: string
  constructor(code: string) {
    super(code)
    this.code = code
  }
}

function classifyError(error: unknown): string {
  if (error instanceof AudioDownloadError) return error.code
  if (error instanceof DOMException && error.name === 'AbortError') return 'aborted'
  if (error instanceof TypeError) return 'network-error'
  if (error instanceof Error && error.name === 'QuotaExceededError') return 'insufficient-storage'
  return 'unknown-error'
}

/**
 * Download one verified file of the batch. Returns the stored manifest
 * entry, or null when the file was already stored (skipped).
 */
async function downloadOneFile(
  batch: EngineBatch,
  file: AudioBatchPlanFile,
): Promise<void> {
  const descriptor = batch.record.audioBatch!
  const library = getAudioLibrary()
  const style = getStyleDefinition(descriptor.styleId)
  if (!style) throw new AudioDownloadError('invalid-style')

  // Skip files that became stored while this batch was queued (another
  // batch may have covered them).
  const existing = await library.getEntry(descriptor.styleId, file.sura, file.ayah).catch(() => null)
  if (existing && existing.verification === 'verified') return

  // Quota preflight: fail fast before transferring when the estimate says
  // the remaining batch cannot fit.
  try {
    const estimate = await getStorageEstimate()
    if (
      estimate.quota !== null &&
      estimate.usage !== null &&
      estimate.usage + file.sizeBytes + QUOTA_MARGIN_BYTES > estimate.quota
    ) {
      throw new AudioDownloadError('insufficient-storage')
    }
  } catch (error) {
    if (error instanceof AudioDownloadError) throw error
    // Estimates are informational.
  }

  const partialKey = `${batch.record.id}:${audioEntryId(descriptor.styleId, file.sura, file.ayah)}`
  const resume = await library.getPartial(partialKey).catch(() => null)
  const chunks: Blob[] = resume && resume.size > 0 ? [resume] : []
  let bytesReceived = resume?.size ?? 0
  const resumeFrom = bytesReceived

  const url = `/api/quran/audio/file/${encodeURIComponent(descriptor.styleId)}/${file.sura}/${file.ayah}`
  const headers: Record<string, string> = {}
  if (resumeFrom > 0) headers.Range = `bytes=${resumeFrom}-`

  const response = await platformFetch(url, {
    credentials: 'same-origin',
    signal: batch.controller?.signal,
    headers,
  })

  if (response.status === 404) {
    // The verified file is not served right now - count it failed and let
    // the batch continue with the rest (honest per-file accounting).
    await library.deletePartial(partialKey).catch(() => undefined)
    throw new AudioDownloadError('not-available')
  }
  if (!response.ok && response.status !== 206) {
    throw new AudioDownloadError(response.status === 429 ? 'rate-limited' : 'source-unreachable')
  }

  const resumedByServer = response.status === 206 && resumeFrom > 0
  if (!resumedByServer && resumeFrom > 0) {
    chunks.length = 0
    bytesReceived = 0
  }

  const reader = response.body?.getReader()
  if (!reader) throw new AudioDownloadError('no-stream')

  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    if (value && value.byteLength > 0) {
      chunks.push(new Blob([value]))
      bytesReceived += value.byteLength
    }
  }

  const blob = new Blob(chunks)

  // Verification: the received size must exactly match the verified plan.
  if (blob.size !== file.sizeBytes) {
    await library.putPartial(partialKey, blob).catch(() => undefined)
    throw new AudioDownloadError('size-mismatch')
  }

  // Integrity checksum (recorded in the manifest; the source publishes none).
  let checksum: string | null = null
  try {
    checksum = await sha256Hex(await blob.arrayBuffer())
  } catch {
    checksum = null
  }

  const sourceUrl = everyAyahFileUrl(style.folder, file.sura, file.ayah)
  const entry: AudioManifestEntry = {
    id: audioEntryId(descriptor.styleId, file.sura, file.ayah),
    styleId: descriptor.styleId,
    sura: file.sura,
    ayah: file.ayah,
    storageKey: audioEntryId(descriptor.styleId, file.sura, file.ayah),
    fileName: `${String(file.sura).padStart(3, '0')}${String(file.ayah).padStart(3, '0')}.mp3`,
    fileSize: blob.size,
    checksum,
    verification: 'verified',
    sourceUrl: sourceUrl ?? '',
    sourceName: style.sourceName,
    downloadedAt: nowIso(),
  }

  // Atomic manifest + blob write (a crash can never split them).
  await library.putVerifiedFile(entry, blob)
  await library.deletePartial(partialKey).catch(() => undefined)
}

/** The main batch loop: files are processed strictly one at a time. */
async function runBatch(batch: EngineBatch): Promise<void> {
  const record = batch.record
  const descriptor = record.audioBatch
  if (!descriptor) return

  batch.record = { ...record, status: 'downloading', errorCode: null, updatedAt: nowIso() }
  await commit(batch.record)
  batch.controller = new AbortController()

  // Plan (re-fetch after a restart; the params come from the descriptor).
  if (!batch.planFiles) {
    const plan = await fetchPlan(descriptor)
    if (!plan || plan.files.length === 0) {
      batch.record = { ...batch.record, status: 'failed', errorCode: 'plan-unavailable', updatedAt: nowIso() }
      await commit(batch.record)
      batches.delete(batch.record.id)
      return
    }
    batch.planFiles = plan.files
    batch.record = {
      ...batch.record,
      totalBytes: plan.totalBytes,
      expectedSize: plan.totalBytes,
      audioBatch: { ...descriptor, filesTotal: plan.files.length, bytesTotal: plan.totalBytes },
    }
    await commit(batch.record)
  }

  const files = batch.planFiles
  let filesCompleted = batch.record.audioBatch?.filesCompleted ?? 0
  let filesFailed = 0
  let bytesCompleted = batch.record.bytesReceived

  let aborted: 'pause' | 'cancel' | null = null
  let interruptCode: string | null = null

  for (const file of files) {
    // Stop conditions between files.
    const currentStatus = batch.record.status
    if (currentStatus === 'paused' || currentStatus === 'canceled') return

    try {
      await downloadOneFile(batch, file)
      filesCompleted += 1
      const entry = batch.record.audioBatch
      bytesCompleted += file.sizeBytes
      batch.record = {
        ...batch.record,
        bytesReceived: bytesCompleted,
        audioBatch: entry ? { ...entry, filesCompleted, filesFailed } : undefined,
        updatedAt: nowIso(),
      }
      await commit(batch.record, true)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        aborted = batch.controller?.signal.reason === 'cancel' ? 'cancel' : 'pause'
        break
      }
      const code = classifyError(error)
      if (code === 'not-available' || code === 'size-mismatch') {
        // Per-file failure: record it honestly and continue with the rest.
        filesFailed += 1
        const entry = batch.record.audioBatch
        batch.record = {
          ...batch.record,
          audioBatch: entry ? { ...entry, filesCompleted, filesFailed } : undefined,
          updatedAt: nowIso(),
        }
        await commit(batch.record, true)
        continue
      }
      if (code === 'insufficient-storage') {
        interruptCode = 'insufficient-storage'
        break
      }
      // Network/unknown failure mid-batch: keep what completed, mark the
      // batch interrupted (resumable from exactly here).
      interruptCode = code
      break
    }
  }

  if (aborted === 'cancel') {
    await getAudioLibrary().deletePartialsForBatch(batch.record.id).catch(() => undefined)
    const canceled: DownloadJobRecord = { ...batch.record, status: 'canceled', updatedAt: nowIso() }
    batch.record = canceled
    await commit(canceled)
    batches.delete(batch.record.id)
    await getFileStorage().deleteJob(batch.record.id).catch(() => undefined)
    pumpQueue()
    return
  }

  if (aborted === 'pause' || interruptCode !== null) {
    const status = aborted === 'pause' ? ('paused' as const) : interruptCode === 'insufficient-storage' ? ('failed' as const) : ('interrupted' as const)
    const entry = batch.record.audioBatch
    const updated: DownloadJobRecord = {
      ...batch.record,
      status,
      errorCode: interruptCode ?? null,
      bytesReceived: bytesCompleted,
      audioBatch: entry ? { ...entry, filesCompleted, filesFailed } : undefined,
      updatedAt: nowIso(),
    }
    batch.record = updated
    await commit(updated)
    pumpQueue()
    return
  }

  // End of batch: completed only when EVERY planned file is stored and
  // verified - anything less is reported honestly.
  const allDone = filesCompleted >= files.length
  const finalStatus: DownloadJobRecord['status'] = allDone && filesFailed === 0 ? 'completed' : 'failed'
  const entry = batch.record.audioBatch
  const updated: DownloadJobRecord = {
    ...batch.record,
    status: finalStatus,
    errorCode: allDone && filesFailed === 0 ? null : filesFailed > 0 ? 'some-files-failed' : 'incomplete-batch',
    bytesReceived: bytesCompleted,
    audioBatch: entry ? { ...entry, filesCompleted, filesFailed } : undefined,
    updatedAt: nowIso(),
    completedAt: allDone ? nowIso() : null,
  }
  batch.record = updated
  await commit(updated)
  batches.delete(batch.record.id)
  pumpQueue()
}

/**
 * Restore persisted audio-batch jobs at startup. Live transfers cannot
 * continue mid-stream, so in-flight batches become `interrupted`; their
 * stored files and partial payloads are kept, so a resume continues from
 * exactly where the batch stopped (skipping verified files).
 */
export async function restorePersistedAudioBatches(): Promise<void> {
  try {
    const jobs = await getFileStorage().listJobs()
    for (const job of jobs) {
      if (job.kind !== 'audio-batch') continue
      if (job.status === 'downloading' || job.status === 'verifying' || job.status === 'queued') {
        const updated: DownloadJobRecord = {
          ...job,
          status: 'interrupted',
          errorCode: 'interrupted',
          updatedAt: nowIso(),
        }
        batches.set(updated.id, { record: updated, planFiles: null, controller: null })
        await commit(updated)
      } else if (['paused', 'interrupted', 'failed'].includes(job.status)) {
        // Re-attach paused/failed batches so resume/cancel work after a
        // restart (the plan is re-fetched on demand).
        batches.set(job.id, { record: job, planFiles: null, controller: null })
        ui().setJob(job)
      }
      // Terminal records (completed) are surfaced by the file engine's
      // restore path - nothing to re-attach.
    }
  } catch {
    // Restoring is best-effort.
  }
}

/** Whether an audio batch with this signature is currently in flight. */
export function hasActiveAudioBatch(spec: AudioBatchSpec): boolean {
  const signature = batchSignature(spec)
  for (const batch of batches.values()) {
    if (batch.record.audioBatch && isActiveRecord(batch.record) && descriptorSignature(batch.record.audioBatch) === signature) {
      return true
    }
  }
  return false
}
