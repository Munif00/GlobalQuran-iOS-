/**
 * Translation narration audio download engine (PROMPT 10).
 *
 * Downloads VERIFIED human-recorded translation narration (one ayah = one
 * MP3) from the QuranEnc audio CDN into the local translation audio
 * library for offline playback. A batch can cover one ayah, one sura, a
 * selected ayah range, one juz, or the complete narration package of a
 * translation - offered ONLY when the source manifest covers every ayah.
 *
 * The file list always comes from the server's verified plan
 * (/api/quran/translation-audio/batch) - never assumed. Files the source
 * does not have are reported as missing and never downloaded.
 *
 * Robustness contract (same as the recitation engine):
 * - Progress: byte-accurate (exact plan sizes; per-file exact sizes are
 *   HEAD-probed when the plan only carries an estimate), plus per-file
 *   counters.
 * - Pause/resume: an aborted file keeps its partial payload (byte-range
 *   resume); completed files are skipped on resume. Survives restarts.
 * - Retry: a failed/interrupted batch resumes with only the missing or
 *   failed files.
 * - Cancel: stops the transfer and drops the partial data (stored files
 *   stay stored - they were verified).
 * - Verification: every completed file must match its exact expected size;
 *   a SHA-256 checksum is computed and recorded in the manifest.
 * - Duplicate prevention: one active batch per (translation + kind + params).
 * - Storage: quota preflight before each file; a quota failure marks the
 *   batch `insufficient-storage` without corrupting anything.
 * - Honesty: a batch only completes when every planned file is stored and
 *   verified - an incomplete sura/package is never reported as complete.
 *
 * Everything lives in the DEDICATED translation audio library, fully
 * separate from recitation audio, Quran text and document downloads.
 */

import { platformFetch } from '@/services/platform/fetch'
import {
  getTranslationAudioLibrary,
  translationAudioEntryId,
} from '@/services/storage/translation-audio-library'
import { getFileStorage, getStorageEstimate, requestPersistentStorage } from '@/services/storage/local-file-storage'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { sha256Hex } from '@/utils/checksum'
import { QURANENC_AUDIO_SOURCE_NAME } from '@/server/audio/translation-audio'
import type {
  DownloadJobRecord,
  TranslationAudioBatchDescriptor,
  TranslationAudioBatchPlanFile,
  TranslationAudioBatchPlanResponse,
  TranslationAudioManifestEntry,
} from '@/types'

/** Translation audio batches are file-heavy - at most two run at once. */
const MAX_CONCURRENT_BATCHES = 2
/** Safety margin applied to quota preflight. */
const QUOTA_MARGIN_BYTES = 64 * 1024 * 1024

export type TranslationAudioBatchSpec =
  | { translationKey: string; kind: 'ayah'; sura: number; ayah: number }
  | { translationKey: string; kind: 'sura'; sura: number }
  | { translationKey: string; kind: 'range'; sura: number; from: number; to: number }
  | { translationKey: string; kind: 'juz'; juz: number }
  | { translationKey: string; kind: 'complete' }

export type EnqueueTranslationAudioBatchResult =
  | { ok: true; jobId: string }
  | { ok: false; reason: 'duplicate-active' | 'already-downloaded' | 'plan-unavailable' | 'incomplete-source' }

interface EngineBatch {
  record: DownloadJobRecord
  planFiles: TranslationAudioBatchPlanFile[] | null
  controller: AbortController | null
}

const batches = new Map<string, EngineBatch>()

function nowIso(): string {
  return new Date().toISOString()
}

function makeJobId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `tab-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}

function ui() {
  return useDownloadManagerStore.getState()
}

async function commit(record: DownloadJobRecord, skipPersist = false): Promise<void> {
  if (!skipPersist) {
    try {
      await getFileStorage().putJob(record)
    } catch {
      // Job persistence is best-effort; the engine keeps running.
    }
  }
  ui().setJob(record)
}

function batchSignature(spec: TranslationAudioBatchSpec): string {
  switch (spec.kind) {
    case 'ayah':
      return `${spec.translationKey}|ayah|${spec.sura}|${spec.ayah}`
    case 'sura':
      return `${spec.translationKey}|sura|${spec.sura}`
    case 'range':
      return `${spec.translationKey}|range|${spec.sura}|${spec.from}|${spec.to}`
    case 'juz':
      return `${spec.translationKey}|juz|${spec.juz}`
    case 'complete':
      return `${spec.translationKey}|complete`
  }
}

function descriptorSignature(descriptor: TranslationAudioBatchDescriptor): string {
  return `${descriptor.translationKey}|${descriptor.batchKind}|${descriptor.sura ?? ''}|${descriptor.ayahFrom ?? ''}|${descriptor.ayahTo ?? ''}|${descriptor.juz ?? ''}`
}

function planUrlForDescriptor(descriptor: TranslationAudioBatchDescriptor): string {
  const params = new URLSearchParams({
    translationKey: descriptor.translationKey,
    kind: descriptor.batchKind,
  })
  if (descriptor.sura !== null) params.set('sura', String(descriptor.sura))
  if (descriptor.ayahFrom !== null) {
    params.set(descriptor.batchKind === 'ayah' ? 'ayah' : 'from', String(descriptor.ayahFrom))
  }
  if (descriptor.batchKind === 'range' && descriptor.ayahTo !== null) {
    params.set('to', String(descriptor.ayahTo))
  }
  if (descriptor.juz !== null) params.set('juz', String(descriptor.juz))
  return `/api/quran/translation-audio/batch?${params.toString()}`
}

async function fetchPlan(
  descriptor: TranslationAudioBatchDescriptor,
): Promise<TranslationAudioBatchPlanResponse | null> {
  try {
    const response = await platformFetch(planUrlForDescriptor(descriptor), {
      credentials: 'same-origin',
    })
    if (!response.ok) return null
    return (await response.json()) as TranslationAudioBatchPlanResponse
  } catch {
    return null
  }
}

/** True when the batch job is in flight (not terminal). */
function isActiveRecord(record: DownloadJobRecord): boolean {
  return !['completed', 'failed', 'canceled', 'corrupted'].includes(record.status)
}

/* ------------------------------------------------------------------ */
/* Enqueue                                                             */
/* ------------------------------------------------------------------ */

export async function enqueueTranslationAudioBatch(
  spec: TranslationAudioBatchSpec,
): Promise<EnqueueTranslationAudioBatchResult> {
  const descriptorSeed: TranslationAudioBatchDescriptor = {
    translationKey: spec.translationKey,
    audioName: '',
    translationTitle: null,
    batchKind: spec.kind,
    sura: spec.kind === 'ayah' || spec.kind === 'sura' || spec.kind === 'range' ? spec.sura : null,
    ayahFrom: spec.kind === 'ayah' ? spec.ayah : spec.kind === 'range' ? spec.from : null,
    ayahTo: spec.kind === 'ayah' ? spec.ayah : spec.kind === 'range' ? spec.to : null,
    juz: spec.kind === 'juz' ? spec.juz : null,
    filesTotal: 0,
    filesCompleted: 0,
    filesFailed: 0,
    bytesTotal: 0,
    sizeEstimated: false,
  }

  // A complete package may only be offered when the verified source
  // manifest covers every ayah - checked again here, at enqueue time.
  if (spec.kind === 'complete') {
    const plan = await fetchPlan(descriptorSeed)
    if (!plan) return { ok: false, reason: 'plan-unavailable' }
    if (!plan.completePackageOfferable) return { ok: false, reason: 'incomplete-source' }
    return finishEnqueue(plan)
  }

  return finishEnqueue(null)

  async function finishEnqueue(
    completePlan: TranslationAudioBatchPlanResponse | null,
  ): Promise<EnqueueTranslationAudioBatchResult> {
    // Duplicate prevention: one active batch with the same signature.
    const signature = batchSignature(spec)
    const activeDuplicates = Object.values(ui().jobs).filter(
      (job) =>
        job.kind === 'translation-audio-batch' &&
        job.translationAudioBatch !== undefined &&
        isActiveRecord(job) &&
        descriptorSignature(job.translationAudioBatch) === signature,
    )
    if (activeDuplicates.length > 0) return { ok: false, reason: 'duplicate-active' }

    // The verified plan (fetched fresh unless the complete check already did).
    const plan = completePlan ?? (await fetchPlan(descriptorSeed))
    if (!plan || plan.files.length === 0) return { ok: false, reason: 'plan-unavailable' }
    if (plan.translationKey !== spec.translationKey) {
      return { ok: false, reason: 'plan-unavailable' }
    }

    // Skip files already stored + verified; if everything is already there,
    // report it instead of enqueueing a no-op batch.
    const library = getTranslationAudioLibrary()
    const pending: TranslationAudioBatchPlanFile[] = []
    let alreadyStored = 0
    let alreadyBytes = 0
    for (const file of plan.files) {
      const entry = await library
        .getEntry(spec.translationKey, file.sura, file.ayah)
        .catch(() => null)
      if (entry && entry.verification === 'verified') {
        alreadyStored += 1
        alreadyBytes += entry.fileSize
      } else {
        pending.push(file)
      }
    }
    if (pending.length === 0) return { ok: false, reason: 'already-downloaded' }

    const descriptor: TranslationAudioBatchDescriptor = {
      ...descriptorSeed,
      audioName: plan.audioName,
      translationTitle: plan.translationTitle,
      filesTotal: plan.files.length,
      filesCompleted: alreadyStored,
      filesFailed: 0,
      bytesTotal: plan.totalBytes,
      sizeEstimated: plan.sizeEstimated,
    }

    const record: DownloadJobRecord = {
      id: makeJobId(),
      kind: 'translation-audio-batch',
      translationKey: spec.translationKey,
      translationTitle: plan.audioName,
      languageName: plan.languageName,
      fileId: `translation-audio-${signature}`,
      fileName: batchLabel(descriptor),
      format: 'mp3',
      sourceUrl: planUrlForDescriptor(descriptor),
      expectedSize: plan.totalBytes,
      sourceVersion: null,
      status: 'queued',
      bytesReceived: alreadyBytes,
      totalBytes: plan.totalBytes,
      errorCode: null,
      checksum: null,
      storedFileId: null,
      rangeSupported: null,
      createdAt: nowIso(),
      updatedAt: nowIso(),
      completedAt: null,
      translationAudioBatch: descriptor,
    }

    batches.set(record.id, { record, planFiles: plan.files, controller: null })
    await commit(record)
    void requestPersistentStorage()
    pumpQueue()
    return { ok: true, jobId: record.id }
  }
}

/** Short human-readable batch label (fallback display). */
function batchLabel(descriptor: TranslationAudioBatchDescriptor): string {
  switch (descriptor.batchKind) {
    case 'ayah':
      return `Surah ${descriptor.sura} · Ayah ${descriptor.ayahFrom} (narration)`
    case 'sura':
      return `Surah ${descriptor.sura} (narration)`
    case 'range':
      return `Surah ${descriptor.sura} · Ayat ${descriptor.ayahFrom}–${descriptor.ayahTo} (narration)`
    case 'juz':
      return `Juz ${descriptor.juz} (narration)`
    case 'complete':
      return 'Complete narration (translation audio)'
  }
}

/* ------------------------------------------------------------------ */
/* Engine loop                                                         */
/* ------------------------------------------------------------------ */

function countRunning(): number {
  let running = 0
  for (const batch of batches.values()) {
    if (batch.record.status === 'downloading' || batch.record.status === 'verifying') running += 1
  }
  return running
}

function pumpQueue(): void {
  const queued = [...batches.values()]
    .filter((batch) => batch.record.status === 'queued')
    .sort((a, b) => a.record.createdAt.localeCompare(b.record.createdAt))
  for (const batch of queued) {
    if (countRunning() >= MAX_CONCURRENT_BATCHES) break
    void runBatch(batch)
  }
}

/** Pause an active batch (the current file's partial is persisted). */
export async function pauseTranslationAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (!batch) return
  if (batch.record.status === 'downloading') {
    batch.controller?.abort()
    return
  }
  if (batch.record.status === 'queued' || batch.record.status === 'verifying') {
    const updated = { ...batch.record, status: 'paused' as const, updatedAt: nowIso() }
    batch.record = updated
    await commit(updated)
  }
}

/** Resume / retry a paused, interrupted or failed batch. */
export async function resumeTranslationAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (!batch) return
  if (
    !['paused', 'interrupted', 'failed', 'canceled', 'corrupted'].includes(batch.record.status)
  ) {
    return
  }
  const descriptor = batch.record.translationAudioBatch
  const updated: DownloadJobRecord = {
    ...batch.record,
    status: 'queued',
    errorCode: null,
    updatedAt: nowIso(),
  }
  if (descriptor) descriptor.filesFailed = 0
  batch.record = updated
  await commit(updated)
  pumpQueue()
}

export function retryTranslationAudioBatch(jobId: string): Promise<void> {
  return resumeTranslationAudioBatch(jobId)
}

/** Cancel: stop the transfer and drop the partial data (stored files stay). */
export async function cancelTranslationAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (!batch) return
  if (batch.record.status === 'downloading') {
    batch.controller?.abort('cancel')
    return
  }
  await getTranslationAudioLibrary().deletePartialsForBatch(jobId).catch(() => undefined)
  batches.delete(jobId)
  ui().removeJob(jobId)
  await getFileStorage().deleteJob(jobId).catch(() => undefined)
}

/** Dismiss a finished batch record (stored files are kept). */
export async function dismissTranslationAudioBatch(jobId: string): Promise<void> {
  const batch = batches.get(jobId)
  if (batch && isActiveRecord(batch.record)) return
  batches.delete(jobId)
  ui().removeJob(jobId)
  await getFileStorage().deleteJob(jobId).catch(() => undefined)
}

class TranslationAudioDownloadError extends Error {
  readonly code: string
  constructor(code: string) {
    super(code)
    this.code = code
  }
}

function classifyError(error: unknown): string {
  if (error instanceof TranslationAudioDownloadError) return error.code
  if (error instanceof DOMException && error.name === 'AbortError') return 'aborted'
  if (error instanceof TypeError) return 'network-error'
  if (error instanceof Error && error.name === 'QuotaExceededError') return 'insufficient-storage'
  return 'unknown-error'
}

function fileUrl(translationKey: string, sura: number, ayah: number): string {
  return `/api/quran/translation-audio/file/${encodeURIComponent(translationKey)}/${sura}/${ayah}`
}

/**
 * The exact expected size of one file. Plans with exact sizes use them;
 * estimated plans (complete package) HEAD-probe the file through the app
 * proxy (the probe is cached at the CDN).
 */
async function resolveExactSize(
  translationKey: string,
  file: TranslationAudioBatchPlanFile,
): Promise<number> {
  if (file.sizeBytes > 0) return file.sizeBytes
  try {
    const response = await platformFetch(
      fileUrl(translationKey, file.sura, file.ayah),
      { method: 'HEAD', credentials: 'same-origin' },
    )
    if (!response.ok) {
      throw new TranslationAudioDownloadError('not-available')
    }
    const length = Number(response.headers.get('content-length'))
    if (!Number.isFinite(length) || length <= 0) {
      throw new TranslationAudioDownloadError('not-available')
    }
    return length
  } catch (error) {
    if (error instanceof TranslationAudioDownloadError) throw error
    throw new TranslationAudioDownloadError('source-unreachable')
  }
}

/** Download one verified narration file of the batch. */
async function downloadOneFile(
  batch: EngineBatch,
  file: TranslationAudioBatchPlanFile,
): Promise<{ sizeBytes: number }> {
  const descriptor = batch.record.translationAudioBatch!
  const library = getTranslationAudioLibrary()

  // Skip files that became stored while this batch was queued.
  const existing = await library
    .getEntry(descriptor.translationKey, file.sura, file.ayah)
    .catch(() => null)
  if (existing && existing.verification === 'verified') return { sizeBytes: existing.fileSize }

  const exactSize = await resolveExactSize(descriptor.translationKey, file)

  // Quota preflight: fail fast when the estimate says it cannot fit.
  try {
    const estimate = await getStorageEstimate()
    if (
      estimate.quota !== null &&
      estimate.usage !== null &&
      estimate.usage + exactSize + QUOTA_MARGIN_BYTES > estimate.quota
    ) {
      throw new TranslationAudioDownloadError('insufficient-storage')
    }
  } catch (error) {
    if (error instanceof TranslationAudioDownloadError) throw error
    // Estimates are informational.
  }

  const partialKey = `${batch.record.id}:${translationAudioEntryId(descriptor.translationKey, file.sura, file.ayah)}`
  const resume = await library.getPartial(partialKey).catch(() => null)
  const chunks: Blob[] = resume && resume.size > 0 && resume.size < exactSize ? [resume] : []
  let bytesReceived = chunks.length > 0 ? resume!.size : 0
  const resumeFrom = bytesReceived

  const headers: Record<string, string> = {}
  if (resumeFrom > 0) headers.Range = `bytes=${resumeFrom}-`

  const response = await platformFetch(fileUrl(descriptor.translationKey, file.sura, file.ayah), {
    credentials: 'same-origin',
    signal: batch.controller?.signal,
    headers,
  })

  if (response.status === 404) {
    // The verified file is not served right now - honest per-file failure.
    await library.deletePartial(partialKey).catch(() => undefined)
    throw new TranslationAudioDownloadError('not-available')
  }
  if (!response.ok && response.status !== 206) {
    throw new TranslationAudioDownloadError(
      response.status === 429 ? 'rate-limited' : 'source-unreachable',
    )
  }

  const resumedByServer = response.status === 206 && resumeFrom > 0
  if (!resumedByServer && resumeFrom > 0) {
    chunks.length = 0
    bytesReceived = 0
  }

  const reader = response.body?.getReader()
  if (!reader) throw new TranslationAudioDownloadError('no-stream')

  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    if (value && value.byteLength > 0) {
      chunks.push(new Blob([value]))
      bytesReceived += value.byteLength
    }
  }

  const blob = new Blob(chunks)

  // Verification: the received size must exactly match the exact size.
  if (blob.size !== exactSize) {
    await library.putPartial(partialKey, blob).catch(() => undefined)
    throw new TranslationAudioDownloadError('size-mismatch')
  }

  // Integrity checksum (recorded in the manifest; the source publishes none).
  let checksum: string | null = null
  try {
    checksum = await sha256Hex(await blob.arrayBuffer())
  } catch {
    checksum = null
  }

  const fileName = `${String(file.sura).padStart(3, '0')}${String(file.ayah).padStart(3, '0')}.mp3`
  const entry: TranslationAudioManifestEntry = {
    id: translationAudioEntryId(descriptor.translationKey, file.sura, file.ayah),
    translationKey: descriptor.translationKey,
    sura: file.sura,
    ayah: file.ayah,
    storageKey: translationAudioEntryId(descriptor.translationKey, file.sura, file.ayah),
    fileName,
    fileSize: blob.size,
    checksum,
    verification: 'verified',
    sourceUrl: `https://d.quranenc.com/data/audio/${descriptor.translationKey}/${fileName}`,
    sourceName: QURANENC_AUDIO_SOURCE_NAME,
    downloadedAt: nowIso(),
  }

  // Atomic manifest + blob write (a crash can never split them).
  await library.putVerifiedFile(entry, blob)
  await library.deletePartial(partialKey).catch(() => undefined)
  return { sizeBytes: blob.size }
}

/** The main batch loop: files are processed strictly one at a time. */
async function runBatch(batch: EngineBatch): Promise<void> {
  const record = batch.record
  const descriptor = record.translationAudioBatch
  if (!descriptor) return

  batch.record = { ...record, status: 'downloading', errorCode: null, updatedAt: nowIso() }
  await commit(batch.record)
  batch.controller = new AbortController()

  // Plan (re-fetch after a restart; the params come from the descriptor).
  if (!batch.planFiles) {
    const plan = await fetchPlan(descriptor)
    if (!plan || plan.files.length === 0) {
      batch.record = {
        ...batch.record,
        status: 'failed',
        errorCode: 'plan-unavailable',
        updatedAt: nowIso(),
      }
      await commit(batch.record)
      batches.delete(batch.record.id)
      return
    }
    batch.planFiles = plan.files
    batch.record = {
      ...batch.record,
      totalBytes: plan.totalBytes,
      expectedSize: plan.totalBytes,
      translationAudioBatch: {
        ...descriptor,
        filesTotal: plan.files.length,
        bytesTotal: plan.totalBytes,
        sizeEstimated: plan.sizeEstimated,
      },
    }
    await commit(batch.record)
  }

  const files = batch.planFiles
  let filesCompleted = batch.record.translationAudioBatch?.filesCompleted ?? 0
  let filesFailed = 0
  let bytesCompleted = batch.record.bytesReceived

  let aborted: 'pause' | 'cancel' | null = null
  let interruptCode: string | null = null

  for (const file of files) {
    // Stop conditions between files.
    const currentStatus = batch.record.status
    if (currentStatus === 'paused' || currentStatus === 'canceled') return

    try {
      const { sizeBytes } = await downloadOneFile(batch, file)
      filesCompleted += 1
      const entry = batch.record.translationAudioBatch
      bytesCompleted += sizeBytes
      batch.record = {
        ...batch.record,
        bytesReceived: bytesCompleted,
        translationAudioBatch: entry
          ? { ...entry, filesCompleted, filesFailed }
          : undefined,
        updatedAt: nowIso(),
      }
      await commit(batch.record, true)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        aborted = batch.controller?.signal.reason === 'cancel' ? 'cancel' : 'pause'
        break
      }
      const code = classifyError(error)
      if (code === 'not-available' || code === 'size-mismatch') {
        // Per-file failure: record it honestly and continue with the rest.
        filesFailed += 1
        const entry = batch.record.translationAudioBatch
        batch.record = {
          ...batch.record,
          translationAudioBatch: entry
            ? { ...entry, filesCompleted, filesFailed }
            : undefined,
          updatedAt: nowIso(),
        }
        await commit(batch.record, true)
        continue
      }
      if (code === 'insufficient-storage') {
        interruptCode = 'insufficient-storage'
        break
      }
      interruptCode = code
      break
    }
  }

  if (aborted === 'cancel') {
    await getTranslationAudioLibrary().deletePartialsForBatch(batch.record.id).catch(() => undefined)
    const canceled: DownloadJobRecord = { ...batch.record, status: 'canceled', updatedAt: nowIso() }
    batch.record = canceled
    await commit(canceled)
    batches.delete(batch.record.id)
    await getFileStorage().deleteJob(batch.record.id).catch(() => undefined)
    pumpQueue()
    return
  }

  if (aborted === 'pause' || interruptCode !== null) {
    const status =
      aborted === 'pause'
        ? ('paused' as const)
        : interruptCode === 'insufficient-storage'
          ? ('failed' as const)
          : ('interrupted' as const)
    const entry = batch.record.translationAudioBatch
    const updated: DownloadJobRecord = {
      ...batch.record,
      status,
      errorCode: interruptCode ?? null,
      bytesReceived: bytesCompleted,
      translationAudioBatch: entry ? { ...entry, filesCompleted, filesFailed } : undefined,
      updatedAt: nowIso(),
    }
    batch.record = updated
    await commit(updated)
    pumpQueue()
    return
  }

  // End of batch: completed only when EVERY planned file is stored and
  // verified - anything less is reported honestly.
  const allDone = filesCompleted >= files.length
  const finalStatus: DownloadJobRecord['status'] =
    allDone && filesFailed === 0 ? 'completed' : 'failed'
  const entry = batch.record.translationAudioBatch
  const updated: DownloadJobRecord = {
    ...batch.record,
    status: finalStatus,
    errorCode:
      allDone && filesFailed === 0 ? null : filesFailed > 0 ? 'some-files-failed' : 'incomplete-batch',
    bytesReceived: bytesCompleted,
    translationAudioBatch: entry ? { ...entry, filesCompleted, filesFailed } : undefined,
    updatedAt: nowIso(),
    completedAt: allDone ? nowIso() : null,
  }
  batch.record = updated
  await commit(updated)
  batches.delete(batch.record.id)
  pumpQueue()
}

/**
 * Restore persisted translation-audio batch jobs at startup. In-flight
 * batches become `interrupted`; their stored files and partial payloads
 * are kept, so a resume continues from exactly where they stopped.
 */
export async function restorePersistedTranslationAudioBatches(): Promise<void> {
  try {
    const jobs = await getFileStorage().listJobs()
    for (const job of jobs) {
      if (job.kind !== 'translation-audio-batch') continue
      if (
        job.status === 'downloading' ||
        job.status === 'verifying' ||
        job.status === 'queued'
      ) {
        const updated: DownloadJobRecord = {
          ...job,
          status: 'interrupted',
          errorCode: 'interrupted',
          updatedAt: nowIso(),
        }
        batches.set(updated.id, { record: updated, planFiles: null, controller: null })
        await commit(updated)
      } else if (['paused', 'interrupted', 'failed'].includes(job.status)) {
        batches.set(job.id, { record: job, planFiles: null, controller: null })
        ui().setJob(job)
      }
    }
  } catch {
    // Restoring is best-effort.
  }
}

/** Whether a translation audio batch with this signature is in flight. */
export function hasActiveTranslationAudioBatch(spec: TranslationAudioBatchSpec): boolean {
  const signature = batchSignature(spec)
  for (const batch of batches.values()) {
    if (
      batch.record.translationAudioBatch &&
      isActiveRecord(batch.record) &&
      descriptorSignature(batch.record.translationAudioBatch) === signature
    ) {
      return true
    }
  }
  return false
}
