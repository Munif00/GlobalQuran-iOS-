/**
 * Viewer chunk warming.
 *
 * The built-in viewers (PDF / EPUB / SQLite) load their heavy libraries
 * (pdfjs-dist, epubjs, sql.js + WASM) lazily through the shared loader in
 * `@/components/viewers/library-loader`. That loader is the ONLY place the
 * dynamic imports live, so a single chunk exists per library; warming it
 * while the device is online makes later offline opens work without a
 * network fetch.
 *
 * Production deployments should additionally precache the app shell with a
 * service worker so the app itself reloads offline.
 */

import {
  loadEpubjs,
  loadPdfjs,
  loadSqlJs,
  warmPdfWorker,
  warmSqlWasm,
} from '@/components/viewers/library-loader'

/** Whether a format has a built-in viewer library that can be warmed. */
function isWarmable(format: string): boolean {
  return format === 'pdf' || format === 'epub' || format === 'sql'
}

export async function warmViewerChunks(formats: Iterable<string>): Promise<void> {
  const jobs: Array<Promise<unknown>> = []
  for (const format of formats) {
    if (!isWarmable(format)) continue
    try {
      if (format === 'pdf') {
        jobs.push(loadPdfjs())
        jobs.push(warmPdfWorker())
      } else if (format === 'epub') {
        jobs.push(loadEpubjs())
      } else if (format === 'sql') {
        jobs.push(loadSqlJs())
        jobs.push(warmSqlWasm())
      }
    } catch {
      // Warming is best effort (e.g. the device is already offline).
    }
  }
  await Promise.allSettled(jobs)
}
