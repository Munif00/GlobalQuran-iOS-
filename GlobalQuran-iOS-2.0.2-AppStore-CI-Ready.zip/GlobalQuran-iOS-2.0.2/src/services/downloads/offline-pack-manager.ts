/**
 * Offline-pack engine - "download translation for offline reading".
 *
 * A pack is the complete text of one translation (every ayah of every sura
 * the source publishes, Arabic + translation + footnotes) fetched from
 * /api/quran/offline-pack/{key} in a single streamed response and stored in
 * the quran-cache (IndexedDB). Once complete, the in-app reader serves that
 * translation fully offline - reading positions and bookmarks are already
 * device-local.
 *
 * Design (mirrors the document-file download engine):
 * - Progress: byte-accurate against the response Content-Length.
 * - Pause: aborts the stream and persists the partial blob; resume continues
 *   with a byte-range request (the pack route supports ranges).
 * - Validation: the completed stream is parsed and structurally validated
 *   (translation key match, sura numbers, ayat shape) BEFORE anything is
 *   written. A failed validation marks the job `corrupted` and leaves the
 *   previously cached suras untouched.
 * - Safe updates: re-downloading after a source version change overwrites
 *   the cached suras only after the new pack fully validates - the old
 *   working copy is never removed first.
 * - Duplicate prevention: one active pack job per translation; a complete
 *   pack of the same version is reported as already downloaded.
 *
 * Jobs are persisted in the same IndexedDB store as file downloads
 * (kind: 'offline-pack') and surfaced through the same download-manager UI
 * store, so pause/resume/retry/cancel all behave identically for the user.
 */

import { getFileStorage } from '@/services/storage/local-file-storage'
import { platformFetch } from '@/services/platform/fetch'
import {
  deleteTranslationCache,
  getPackIndex,
  putCachedSuras,
  type SuraCacheInput,
} from '@/services/storage/quran-cache'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import type { DownloadJobRecord, OfflinePackStatus, Translation } from '@/types'

/** Pack downloads are heavy - one at a time. */
const MAX_CONCURRENT = 1

/** Structured payload of /api/quran/offline-pack/{key}. */
interface PackPayload {
  status: string
  translationKey: string
  translationTitle: string | null
  version: string | null
  totalSuras: number
  suraCount: number
  suras: Array<{
    sura: number
    ayahCount: number
    ayat: Array<{ sura: number; aya: number; arabicText: string; translation: string; footnotes: string | null }>
  }>
}

export type EnqueuePackResult =
  | { ok: true; jobId: string }
  | { ok: false; reason: 'duplicate-active' | 'already-downloaded' }

interface EnginePackJob {
  record: DownloadJobRecord
  controller: AbortController | null
}

const packJobs = new Map<string, EnginePackJob>()

function nowIso(): string {
  return new Date().toISOString()
}

function makeJobId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `pj-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}

function ui() {
  return useDownloadManagerStore.getState()
}

async function commit(record: DownloadJobRecord, skipPersist = false): Promise<void> {
  if (!skipPersist) {
    try {
      await getFileStorage().putJob(record)
    } catch {
      // Job persistence is best-effort; the engine keeps running.
    }
  }
  ui().setJob(record)
}

/* ------------------------------------------------------------------ */
/* Offline status                                                      */
/* ------------------------------------------------------------------ */

/**
 * The offline status of one translation, computed from the real pack index.
 * `complete` is true only when every one of the 114 suras is cached - the
 * UI may only claim full offline availability then.
 */
export async function getOfflinePackStatus(translationKey: string): Promise<OfflinePackStatus> {
  const index = await getPackIndex(translationKey)
  if (index === null) {
    return {
      translationKey,
      cachedSuras: 0,
      totalSuras: 114,
      complete: false,
      approxBytes: 0,
      version: null,
      updatedAt: null,
    }
  }
  const versions = new Set(index.entries.map((entry) => entry.version))
  return {
    translationKey,
    cachedSuras: index.entries.length,
    totalSuras: 114,
    complete: index.entries.length >= 114,
    approxBytes: index.entries.reduce((sum, entry) => sum + entry.bytes, 0),
    version: versions.size === 1 ? [...versions][0] : null,
    updatedAt: index.updatedAt,
  }
}

/** True while a pack job for the translation is in flight (non-terminal). */
export function hasActivePackJob(translationKey: string): boolean {
  for (const job of packJobs.values()) {
    if (
      job.record.translationKey === translationKey &&
      !['completed', 'failed', 'canceled', 'corrupted'].includes(job.record.status)
    ) {
      return true
    }
  }
  return false
}

/* ------------------------------------------------------------------ */
/* Engine                                                              */
/* ------------------------------------------------------------------ */

function countRunning(): number {
  let running = 0
  for (const job of packJobs.values()) {
    if (job.record.status === 'downloading' || job.record.status === 'verifying') running += 1
  }
  return running
}

function pumpQueue(): void {
  const queued = [...packJobs.values()]
    .filter((job) => job.record.status === 'queued')
    .sort((a, b) => a.record.createdAt.localeCompare(b.record.createdAt))
  for (const job of queued) {
    if (countRunning() >= MAX_CONCURRENT) break
    void runPackDownload(job)
  }
}

/** Enqueue the offline pack of one translation. */
export async function enqueueOfflinePack(translation: Translation): Promise<EnqueuePackResult> {
  // One active pack job per translation.
  if (hasActivePackJob(translation.key)) {
    return { ok: false, reason: 'duplicate-active' }
  }

  // Already fully cached at the same version? Report it (an update after a
  // source version change is allowed and keeps the old copy until the new
  // pack validates).
  try {
    const status = await getOfflinePackStatus(translation.key)
    if (status.complete && (translation.version === null || status.version === translation.version)) {
      return { ok: false, reason: 'already-downloaded' }
    }
  } catch {
    // Status check is best-effort.
  }

  const record: DownloadJobRecord = {
    id: makeJobId(),
    kind: 'offline-pack',
    translationKey: translation.key,
    translationTitle: translation.title,
    languageName: translation.languageNativeName ?? translation.languageName,
    fileId: 'offline-pack',
    fileName: `${translation.key} (offline reading)`,
    format: 'json',
    sourceUrl: `/api/quran/offline-pack/${encodeURIComponent(translation.key)}`,
    expectedSize: null,
    sourceVersion: translation.version,
    status: 'queued',
    bytesReceived: 0,
    totalBytes: null,
    errorCode: null,
    checksum: null,
    storedFileId: null,
    rangeSupported: null,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    completedAt: null,
  }
  packJobs.set(record.id, { record, controller: null })
  await commit(record)
  pumpQueue()
  return { ok: true, jobId: record.id }
}

/** Pause an active pack download (partial data is persisted for resume). */
export async function pauseOfflinePack(jobId: string): Promise<void> {
  const job = packJobs.get(jobId)
  if (!job) return
  if (job.record.status === 'downloading') {
    job.controller?.abort()
    // The abort handler persists the partial blob and flips the record.
    return
  }
  if (job.record.status === 'queued') {
    const updated = { ...job.record, status: 'paused' as const, updatedAt: nowIso() }
    job.record = updated
    await commit(updated)
  }
}

/** Resume / retry a paused, interrupted or failed pack download. */
export async function resumeOfflinePack(jobId: string): Promise<void> {
  const job = packJobs.get(jobId)
  if (!job) return
  if (!['paused', 'interrupted', 'failed', 'canceled', 'corrupted'].includes(job.record.status)) return
  const updated: DownloadJobRecord = { ...job.record, status: 'queued', errorCode: null, updatedAt: nowIso() }
  job.record = updated
  await commit(updated)
  pumpQueue()
}

/** Cancel: stop the transfer and drop the partial data. */
export async function cancelOfflinePack(jobId: string): Promise<void> {
  const job = packJobs.get(jobId)
  if (!job) return
  if (job.record.status === 'downloading') {
    job.controller?.abort('cancel')
    return
  }
  await getFileStorage().deletePartial(jobId).catch(() => undefined)
  packJobs.delete(jobId)
  ui().removeJob(jobId)
  await getFileStorage().deleteJob(jobId).catch(() => undefined)
}

/** Dismiss a finished pack job record (the cached pack stays). */
export async function dismissPackJob(jobId: string): Promise<void> {
  const job = packJobs.get(jobId)
  if (job && !['completed', 'failed', 'canceled', 'corrupted'].includes(job.record.status)) return
  packJobs.delete(jobId)
  ui().removeJob(jobId)
  await getFileStorage().deleteJob(jobId).catch(() => undefined)
}

/** Remove the cached offline copy of a translation (all its suras). */
export async function removeOfflinePack(translationKey: string): Promise<void> {
  await deleteTranslationCache(translationKey)
}

class PackError extends Error {
  readonly code: string
  constructor(code: string) {
    super(code)
    this.code = code
  }
}

async function loadResumeState(job: EnginePackJob): Promise<{ chunks: Blob[]; offset: number } | null> {
  try {
    const partial = await getFileStorage().getPartial(job.record.id)
    if (partial && partial.size > 0) return { chunks: [partial], offset: partial.size }
  } catch {
    // No resume data - start fresh.
  }
  return null
}

/** The main streaming pack download loop. */
async function runPackDownload(job: EnginePackJob): Promise<void> {
  const record = job.record
  const translationKey = record.translationKey
  if (!translationKey) return

  job.record = { ...record, status: 'downloading', errorCode: null, updatedAt: nowIso() }
  await commit(job.record)

  job.controller = new AbortController()

  const resume = await loadResumeState(job)
  const chunks: Blob[] = resume?.chunks ?? []
  let bytesReceived = resume?.offset ?? 0
  const resumeFrom = bytesReceived

  if (resume) {
    job.record = { ...job.record, bytesReceived, updatedAt: nowIso() }
    await commit(job.record)
  }

  try {
    const headers: Record<string, string> = {}
    if (resumeFrom > 0) headers.Range = `bytes=${resumeFrom}-`

    // Web: server pack route. Native: platformFetch builds the pack
    // client-side with the same streamed-response contract.
    const response = await platformFetch(record.sourceUrl, {
      credentials: 'same-origin',
      signal: job.controller.signal,
      headers,
    })

    if (!response.ok && response.status !== 206) {
      throw new PackError(
        response.status === 404 ? 'not-available' : response.status === 429 ? 'rate-limited' : 'source-unreachable',
      )
    }

    const resumedByServer = response.status === 206 && resumeFrom > 0
    if (!resumedByServer && resumeFrom > 0) {
      chunks.length = 0
      bytesReceived = 0
    }

    const contentLengthHeader = response.headers.get('content-length')
    let totalBytes: number | null = contentLengthHeader ? Number(contentLengthHeader) : null
    if (totalBytes !== null && Number.isFinite(totalBytes)) {
      totalBytes = totalBytes + (resumedByServer ? resumeFrom : 0)
    }
    job.record = { ...job.record, totalBytes }

    const reader = response.body?.getReader()
    if (!reader) throw new PackError('no-stream')

    let lastUiUpdate = 0
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      if (value && value.byteLength > 0) {
        chunks.push(new Blob([value]))
        bytesReceived += value.byteLength
        const t = Date.now()
        if (t - lastUiUpdate > 250) {
          lastUiUpdate = t
          job.record = { ...job.record, bytesReceived, totalBytes, status: 'downloading' }
          await commit(job.record, true)
        }
      }
    }

    job.record = { ...job.record, bytesReceived, status: 'verifying', updatedAt: nowIso() }
    await commit(job.record)

    await finalizePack(job, chunks, bytesReceived, totalBytes)
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      const reason = job.controller.signal.reason
      if (reason === 'cancel') {
        await getFileStorage().deletePartial(job.record.id).catch(() => undefined)
        job.record = { ...job.record, status: 'canceled', updatedAt: nowIso() }
        await commit(job.record)
        packJobs.delete(job.record.id)
        await getFileStorage().deleteJob(job.record.id).catch(() => undefined)
      } else {
        if (chunks.length > 0) {
          await getFileStorage().putPartial(job.record.id, new Blob(chunks)).catch(() => undefined)
        }
        job.record = { ...job.record, status: 'paused', bytesReceived, updatedAt: nowIso() }
        await commit(job.record)
      }
    } else {
      if (chunks.length > 0 && bytesReceived > 0) {
        await getFileStorage().putPartial(job.record.id, new Blob(chunks)).catch(() => undefined)
      }
      job.record = {
        ...job.record,
        status: 'interrupted',
        bytesReceived,
        errorCode: classifyError(error),
        updatedAt: nowIso(),
      }
      await commit(job.record)
    }
    pumpQueue()
    return
  }
  pumpQueue()
}

function classifyError(error: unknown): string {
  if (error instanceof PackError) return error.code
  if (error instanceof TypeError) return 'network-error'
  return 'unknown-error'
}

/**
 * Validate the completed pack stream and only then write it to the offline
 * cache. Structural validation: correct translation key, plausible sura
 * numbers, ayat with the required text fields. Nothing is invented - the
 * data is exactly what the source published.
 */
async function finalizePack(
  job: EnginePackJob,
  chunks: Blob[],
  bytesReceived: number,
  totalBytes: number | null,
): Promise<void> {
  const blob = new Blob(chunks)

  if (totalBytes !== null && Number.isFinite(totalBytes) && blob.size !== totalBytes) {
    job.record = { ...job.record, status: 'corrupted', errorCode: 'size-mismatch', bytesReceived: blob.size, updatedAt: nowIso() }
    await commit(job.record)
    packJobs.delete(job.record.id)
    return
  }

  let payload: PackPayload
  try {
    payload = JSON.parse(await blob.text()) as PackPayload
  } catch {
    job.record = { ...job.record, status: 'corrupted', errorCode: 'invalid-pack', updatedAt: nowIso() }
    await commit(job.record)
    packJobs.delete(job.record.id)
    return
  }

  const translationKey = job.record.translationKey
  const isValid =
    payload !== null &&
    typeof payload === 'object' &&
    payload.translationKey === translationKey &&
    Array.isArray(payload.suras) &&
    payload.suras.length > 0 &&
    payload.suras.every(
      (sura) =>
        Number.isInteger(sura.sura) &&
        sura.sura >= 1 &&
        sura.sura <= 114 &&
        Number.isInteger(sura.ayahCount) &&
        Array.isArray(sura.ayat) &&
        sura.ayat.length > 0 &&
        sura.ayat.every(
          (aya) =>
            Number.isInteger(aya.sura) &&
            Number.isInteger(aya.aya) &&
            typeof aya.arabicText === 'string' &&
            aya.arabicText.length > 0 &&
            typeof aya.translation === 'string',
        ),
    )

  if (!isValid || payload.suras.length !== payload.suraCount) {
    job.record = { ...job.record, status: 'corrupted', errorCode: 'invalid-pack', updatedAt: nowIso() }
    await commit(job.record)
    packJobs.delete(job.record.id)
    return
  }

  try {
    const entries: SuraCacheInput[] = payload.suras.map((sura) => ({
      translationKey: translationKey!,
      sura: sura.sura,
      version: payload.version ?? null,
      ayahCount: sura.ayahCount,
      ayat: sura.ayat.map((aya) => ({
        sura: aya.sura,
        aya: aya.aya,
        arabicText: aya.arabicText,
        translation: aya.translation,
        footnotes: aya.footnotes ?? null,
      })),
    }))
    await putCachedSuras(entries)
    await getFileStorage().deletePartial(job.record.id).catch(() => undefined)

    job.record = {
      ...job.record,
      status: 'completed',
      bytesReceived: blob.size,
      totalBytes: blob.size,
      storedFileId: null,
      errorCode: null,
      updatedAt: nowIso(),
      completedAt: nowIso(),
    }
    await commit(job.record)
  } catch (error) {
    job.record = {
      ...job.record,
      status: 'failed',
      errorCode: error instanceof Error && error.name === 'QuotaExceededError' ? 'insufficient-storage' : 'storage-error',
      updatedAt: nowIso(),
    }
    await commit(job.record)
  }
}

/**
 * Restore persisted pack jobs at startup (file jobs are restored by the
 * file engine). Live transfers become `interrupted`; their partial data is
 * kept so a resume continues from the last persisted byte offset.
 */
export async function restorePersistedPackJobs(): Promise<void> {
  try {
    const jobs = await getFileStorage().listJobs()
    for (const job of jobs) {
      if (job.kind !== 'offline-pack') continue
      if (job.status === 'downloading' || job.status === 'verifying' || job.status === 'queued') {
        const updated: DownloadJobRecord = {
          ...job,
          status: 'interrupted',
          errorCode: 'interrupted',
          updatedAt: nowIso(),
        }
        await commit(updated)
      } else {
        ui().setJob(job)
      }
    }
  } catch {
    // Restoring is best-effort.
  }
}
