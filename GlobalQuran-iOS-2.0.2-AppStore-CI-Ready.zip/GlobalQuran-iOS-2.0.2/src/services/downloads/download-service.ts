/**
 * Download URL policy - the security boundary for library downloads.
 *
 * The download engine (download-manager.ts) routes every transfer through
 * the app's same-origin proxy route, which only serves fixed catalog file
 * ids for translations that exist in the live QuranEnc catalog. This module
 * keeps the host allow-list used by both the client engine and (mirrored
 * server-side) by the proxy route itself.
 */

/** Hosts allowed for library downloads (the only file source). */
const ALLOWED_DOWNLOAD_HOSTS = new Set(['quranenc.com', 'www.quranenc.com'])

/**
 * Validate that a catalog URL points at the permitted source host over
 * HTTPS. Applied as defense in depth: the proxy re-validates server-side,
 * the engine validates client-side before enqueueing.
 */
export function isAllowedDownloadUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl)
    return url.protocol === 'https:' && ALLOWED_DOWNLOAD_HOSTS.has(url.hostname)
  } catch {
    return false
  }
}
