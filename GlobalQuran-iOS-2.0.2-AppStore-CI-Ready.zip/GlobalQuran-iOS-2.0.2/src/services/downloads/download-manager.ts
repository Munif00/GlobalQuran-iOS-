/**
 * Download engine - managed downloads with progress, pause/resume,
 * retry, dedupe, validation and safe finalization.
 *
 * Design:
 * - Jobs are enqueued with catalog data only (translation key + catalog file
 *   id); the source URL never comes from user input.
 * - Downloads stream through the app's same-origin proxy route
 *   (/api/downloads/...) which forwards byte ranges, so pause + resume work
 *   when the source supports them (verified: quranenc.com answers 206).
 * - Chunks accumulate in memory during a live stream; on pause or
 *   interruption the partial blob is persisted to IndexedDB so a resume can
 *   continue after an app restart.
 * - Files are finalized (moved from "partial" to the completed library)
 *   only after: byte-size verification against the stream length and the
 *   catalog size, plus a locally computed SHA-256. A mismatch marks the job
 *   `corrupted` and nothing is written to the library.
 * - Duplicate prevention: one active job per (translationKey, fileId); a
 *   completed file with the same version is reported as already downloaded.
 * - Version updates: when a newer source version exists, `enqueueDownload`
 *   with `replaceStoredFileId` downloads the new file first and deletes the
 *   old stored file only after the new one is validated.
 *
 * The engine never throws to callers; failures are reported in the job
 * record with stable, human-safe error codes.
 */

import { getFileStorage, getStorageEstimate, requestPersistentStorage, type StoredFileMetadata } from '@/services/storage/local-file-storage'
import { platformFetch } from '@/services/platform/fetch'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import { sha256Hex } from '@/utils/checksum'
import { isAllowedDownloadUrl } from './download-service'
import type { DownloadFormat, DownloadJobRecord, Translation, TranslationFile } from '@/types'

/** How many downloads run at the same time. */
const MAX_CONCURRENT = 2
/** Safety margin applied to quota checks. */
const QUOTA_MARGIN_BYTES = 64 * 1024 * 1024

export type EnqueueResult =
  | { ok: true; jobId: string }
  | { ok: false; reason: 'duplicate-active' | 'already-downloaded' | 'blocked-url' }

interface EngineJob {
  record: DownloadJobRecord
  controller: AbortController | null
}

const engineJobs = new Map<string, EngineJob>()

function nowIso(): string {
  return new Date().toISOString()
}

function makeJobId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `dj-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}

function store() {
  return getFileStorage()
}

function ui() {
  return useDownloadManagerStore.getState()
}

/** Persist a job record to IndexedDB and mirror it into the UI store. */
async function commit(record: DownloadJobRecord, skipPersist = false): Promise<void> {
  if (!skipPersist) {
    try {
      await store().putJob(record)
    } catch {
      // Job persistence is best-effort; the engine keeps running.
    }
  }
  ui().setJob(record)
}

/**
 * Restore persisted jobs at startup. Live transfers cannot be resumed
 * mid-stream (the HTTP response is gone), so jobs that were `downloading` or
 * `verifying` become `interrupted` - their partial data is kept so a resume
 * can continue from the last persisted byte offset.
 */
export async function restorePersistedJobs(): Promise<void> {
  try {
    const jobs = await store().listJobs()
    for (const job of jobs) {
      // Offline-pack and audio-batch jobs are restored by their own engines.
      if (job.kind === 'offline-pack' || job.kind === 'audio-batch') continue
      if (job.status === 'downloading' || job.status === 'verifying' || job.status === 'queued') {
        const updated: DownloadJobRecord = {
          ...job,
          status: 'interrupted',
          errorCode: job.status === 'verifying' ? 'interrupted-while-verifying' : 'interrupted',
          updatedAt: nowIso(),
        }
        await commit(updated)
      } else {
        ui().setJob(job)
      }
    }
  } catch {
    // Restoring is best-effort.
  } finally {
    ui().setRestored(true)
  }
}

function countRunning(): number {
  let running = 0
  for (const job of engineJobs.values()) {
    if (job.record.status === 'downloading' || job.record.status === 'verifying') running += 1
  }
  return running
}

/** Kick queued jobs as capacity frees up. */
function pumpQueue(): void {
  const queued = [...engineJobs.values()]
    .filter((job) => job.record.status === 'queued')
    .sort((a, b) => a.record.createdAt.localeCompare(b.record.createdAt))
  for (const job of queued) {
    if (countRunning() >= MAX_CONCURRENT) break
    void runDownload(job)
  }
}

/**
 * Enqueue a download for one published catalog file.
 * Returns the outcome without ever starting a second identical transfer.
 */
export async function enqueueDownload(
  translation: Translation,
  file: TranslationFile,
  options?: { replaceStoredFileId?: string },
): Promise<EnqueueResult> {
  if (!isAllowedDownloadUrl(file.url)) {
    return { ok: false, reason: 'blocked-url' }
  }

  // Duplicate prevention: one active job per translation+file.
  for (const job of engineJobs.values()) {
    if (
      job.record.translationKey === translation.key &&
      job.record.fileId === file.id &&
      !['completed', 'failed', 'canceled', 'corrupted'].includes(job.record.status)
    ) {
      return { ok: false, reason: 'duplicate-active' }
    }
  }

  // Already downloaded the same version? Report it (unless this is an
  // explicit update, which is allowed with the old file preserved until
  // the new one validates).
  if (!options?.replaceStoredFileId) {
    try {
      const existing = await store().findForTranslationFile(translation.key, file.id)
      if (existing && existing.version === translation.version) {
        return { ok: false, reason: 'already-downloaded' }
      }
    } catch {
      // Dedupe check is best-effort.
    }
  }

  // Quota preflight: fail fast with a clear code instead of a mid-stream
  // quota error when the estimate already says it cannot fit.
  try {
    const estimate = await getStorageEstimate()
    if (
      estimate.quota !== null &&
      estimate.usage !== null &&
      file.size !== null &&
      estimate.usage + file.size + QUOTA_MARGIN_BYTES > estimate.quota
    ) {
      const record = makeRecord(translation, file, 'failed', 'insufficient-storage')
      await commit(record)
      return { ok: true, jobId: record.id }
    }
  } catch {
    // Estimates are informational.
  }

  // Ask for persistent storage once per session (best effort).
  void requestPersistentStorage()

  const record = makeRecord(translation, file, 'queued', null)
  engineJobs.set(record.id, { record, controller: null })
  await commit(record)
  pumpQueue()
  return { ok: true, jobId: record.id }
}

function makeRecord(
  translation: Translation,
  file: TranslationFile,
  status: DownloadJobRecord['status'],
  errorCode: string | null,
): DownloadJobRecord {
  return {
    id: makeJobId(),
    translationKey: translation.key,
    translationTitle: translation.title,
    languageName: translation.languageNativeName ?? translation.languageName,
    fileId: file.id,
    fileName: fileNameFromUrl(file.url),
    format: file.format,
    sourceUrl: file.url,
    expectedSize: file.size,
    sourceVersion: translation.version,
    status,
    bytesReceived: 0,
    totalBytes: file.size,
    errorCode,
    checksum: null,
    storedFileId: null,
    rangeSupported: null,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    completedAt: null,
  }
}

function fileNameFromUrl(rawUrl: string): string {
  try {
    const url = new URL(rawUrl)
    const segments = url.pathname.split('/').filter(Boolean)
    return segments.length > 0 ? segments[segments.length - 1] : 'download'
  } catch {
    return 'download'
  }
}

/** Pause an active download: abort the stream and persist the partial data. */
export async function pauseDownload(jobId: string): Promise<void> {
  const job = engineJobs.get(jobId)
  if (!job) return
  if (job.record.status === 'downloading') {
    job.controller?.abort()
    // The abort handler persists the partial blob and flips the record.
    return
  }
  if (job.record.status === 'queued') {
    const updated = { ...job.record, status: 'paused' as const, updatedAt: nowIso() }
    job.record = updated
    await commit(updated)
  }
}

/** Resume a paused/interrupted/failed job from the last persisted offset. */
export async function resumeDownload(jobId: string): Promise<void> {
  const job = engineJobs.get(jobId)
  if (!job) return
  if (!['paused', 'interrupted', 'failed', 'canceled'].includes(job.record.status)) return

  const updated: DownloadJobRecord = {
    ...job.record,
    status: 'queued',
    errorCode: null,
    updatedAt: nowIso(),
  }
  job.record = updated
  await commit(updated)
  pumpQueue()
}

/** Retry is an alias of resume for failed/corrupted/interrupted jobs. */
export function retryDownload(jobId: string): Promise<void> {
  return resumeDownload(jobId)
}

/** Cancel: stop the transfer and drop the partial data. */
export async function cancelDownload(jobId: string): Promise<void> {
  const job = engineJobs.get(jobId)
  if (!job) return
  if (job.record.status === 'downloading') {
    job.controller?.abort('cancel')
    return
  }
  const updated: DownloadJobRecord = {
    ...job.record,
    status: 'canceled',
    updatedAt: nowIso(),
  }
  job.record = updated
  await commit(updated)
  await store().deletePartial(jobId).catch(() => undefined)
  engineJobs.delete(jobId)
  ui().removeJob(jobId)
  await store().deleteJob(jobId).catch(() => undefined)
  pumpQueue()
}

/** Remove a finished job record from the manager (does not touch stored files). */
export async function dismissJob(jobId: string): Promise<void> {
  const job = engineJobs.get(jobId)
  if (job && !['completed', 'failed', 'canceled', 'corrupted'].includes(job.record.status)) return
  engineJobs.delete(jobId)
  ui().removeJob(jobId)
  await store().deleteJob(jobId).catch(() => undefined)
}

/** Whether a byte-range resume can be attempted for a job. */
async function loadResumeState(job: EngineJob): Promise<{ chunks: Blob[]; offset: number } | null> {
  try {
    const partial = await store().getPartial(job.record.id)
    if (partial && partial.size > 0) {
      return { chunks: [partial], offset: partial.size }
    }
  } catch {
    // No resume data - start fresh.
  }
  return null
}

/** The main streaming download loop. */
async function runDownload(job: EngineJob): Promise<void> {
  const record = job.record
  if (!record.translationKey) return

  let status: DownloadJobRecord['status'] = 'downloading'
  let updated: DownloadJobRecord = { ...record, status, errorCode: null, updatedAt: nowIso() }
  job.record = updated
  await commit(updated)

  job.controller = new AbortController()

  // Resume support: if partial data exists, continue from its byte offset.
  const resume = await loadResumeState(job)
  const chunks: Blob[] = resume?.chunks ?? []
  let bytesReceived = resume?.offset ?? 0
  const resumeFrom = bytesReceived

  if (resume) {
    updated = { ...job.record, bytesReceived, updatedAt: nowIso() }
    job.record = updated
    await commit(updated)
  }

  try {
    const url = `/api/downloads/${encodeURIComponent(record.translationKey)}/${encodeURIComponent(record.fileId)}`
    const headers: Record<string, string> = {}
    if (resumeFrom > 0) headers.Range = `bytes=${resumeFrom}-`

    // Web: same-origin proxy route. Native: platformFetch routes this to
    // the chunked CapacitorHttp downloader with the same streaming contract.
    const response = await platformFetch(url, {
      credentials: 'same-origin',
      signal: job.controller.signal,
      headers,
    })

    if (!response.ok && response.status !== 206) {
      throw new DownloadError(response.status === 404 ? 'not-available' : response.status === 502 ? 'source-unreachable' : 'http-error')
    }

    const resumedByServer = response.status === 206 && resumeFrom > 0
    if (!resumedByServer && resumeFrom > 0) {
      // Server ignored the range - restart from zero with the full body.
      chunks.length = 0
      bytesReceived = 0
    }

    // Total size: prefer content-length of the range (add resume offset),
    // fall back to the catalog-published size.
    const contentLengthHeader = response.headers.get('content-length')
    let totalBytes: number | null = contentLengthHeader ? Number(contentLengthHeader) : null
    if (totalBytes !== null && Number.isFinite(totalBytes)) {
      totalBytes = totalBytes + (resumedByServer ? resumeFrom : 0)
    } else {
      totalBytes = record.expectedSize
    }

    job.record = { ...job.record, totalBytes, rangeSupported: response.status === 206 || response.headers.get('accept-ranges') === 'bytes' }

    const reader = response.body?.getReader()
    if (!reader) throw new DownloadError('no-stream')

    let lastUiUpdate = 0
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      if (value && value.byteLength > 0) {
        chunks.push(new Blob([value]))
        bytesReceived += value.byteLength

        // Throttle UI + persistence updates to ~4/s.
        const t = Date.now()
        if (t - lastUiUpdate > 250) {
          lastUiUpdate = t
          job.record = { ...job.record, bytesReceived, totalBytes, status: 'downloading' }
          await commit(job.record, true)
        }
      }
    }

    job.record = { ...job.record, bytesReceived, totalBytes, status: 'verifying', updatedAt: nowIso() }
    await commit(job.record)

    await finalizeJob(job, chunks, bytesReceived, totalBytes)
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      // Pause or cancel: the caller (pauseDownload/cancelDownload) decides
      // the final state via the abort reason.
      const reason = job.controller.signal.reason
      if (reason === 'cancel') {
        await store().deletePartial(job.record.id).catch(() => undefined)
        const canceled: DownloadJobRecord = { ...job.record, status: 'canceled', updatedAt: nowIso() }
        job.record = canceled
        await commit(canceled)
        engineJobs.delete(job.record.id)
        await store().deleteJob(job.record.id).catch(() => undefined)
      } else {
        // Pause: persist partial data for a future resume.
        if (chunks.length > 0) {
          try {
            await store().putPartial(job.record.id, new Blob(chunks))
          } catch {
            // If persisting fails, resume restarts from scratch.
          }
        }
        const paused: DownloadJobRecord = {
          ...job.record,
          status: 'paused',
          bytesReceived,
          updatedAt: nowIso(),
        }
        job.record = paused
        await commit(paused)
      }
    } else {
      // Unexpected failure (network drop, quota, malformed stream).
      if (chunks.length > 0 && bytesReceived > 0) {
        try {
          await store().putPartial(job.record.id, new Blob(chunks))
        } catch {
          // Best effort.
        }
      }
      const interrupted: DownloadJobRecord = {
        ...job.record,
        status: 'interrupted',
        bytesReceived,
        errorCode: classifyError(error),
        updatedAt: nowIso(),
      }
      job.record = interrupted
      await commit(interrupted)
    }
    pumpQueue()
    return
  }

  status = 'completed'
  void status
  pumpQueue()
}

/** Human-safe error classification. */
function classifyError(error: unknown): string {
  if (error instanceof DownloadError) return error.code
  if (error instanceof DOMException && error.name === 'AbortError') return 'aborted'
  if (error instanceof TypeError) return 'network-error'
  return 'unknown-error'
}

class DownloadError extends Error {
  readonly code: string
  constructor(code: string) {
    super(code)
    this.code = code
  }
}

/**
 * Validate and finalize a finished stream into the offline library.
 * The file only becomes visible as a stored download after validation.
 */
async function finalizeJob(
  job: EngineJob,
  chunks: Blob[],
  bytesReceived: number,
  totalBytes: number | null,
): Promise<void> {
  const blob = new Blob(chunks)

  // Size validation: the stream length must match the announced total, and
  // when the catalog published a size, it must match too.
  if (totalBytes !== null && Number.isFinite(totalBytes) && blob.size !== totalBytes) {
    const corrupted: DownloadJobRecord = {
      ...job.record,
      status: 'corrupted',
      errorCode: 'size-mismatch',
      bytesReceived: blob.size,
      updatedAt: nowIso(),
    }
    job.record = corrupted
    await commit(corrupted)
    engineJobs.delete(job.record.id)
    return
  }
  if (job.record.expectedSize !== null && blob.size !== job.record.expectedSize) {
    const corrupted: DownloadJobRecord = {
      ...job.record,
      status: 'corrupted',
      errorCode: 'size-mismatch',
      bytesReceived: blob.size,
      updatedAt: nowIso(),
    }
    job.record = corrupted
    await commit(corrupted)
    engineJobs.delete(job.record.id)
    return
  }

  // Locally computed integrity checksum (the source publishes none).
  let checksum: string | null = null
  try {
    checksum = await sha256Hex(await blob.arrayBuffer())
  } catch {
    checksum = null
  }

  try {
    // Capture the previous copy (same translation + catalog file id) BEFORE
    // saving, so the update flow can remove the old version only after the
    // new one is validated and stored.
    const previous = job.record.translationKey
      ? await store().findForTranslationFile(job.record.translationKey, job.record.fileId).catch(() => null)
      : null

    const stored = await store().saveFile(
      {
        fileName: job.record.fileName,
        format: job.record.format,
        fileSize: blob.size,
        storedAt: nowIso(),
        checksum,
        origin: 'downloaded',
        translationId: job.record.translationKey,
        version: job.record.sourceVersion,
        fileId: job.record.fileId,
      },
      blob,
    )

    // Version-update replacement: delete the previous stored copy only now,
    // after the new file has been validated and stored.
    if (previous && previous.id !== stored.id) {
      await store().deleteFile(previous.id).catch(() => undefined)
    }

    await store().deletePartial(job.record.id).catch(() => undefined)

    const completed: DownloadJobRecord = {
      ...job.record,
      status: 'completed',
      bytesReceived: blob.size,
      totalBytes: blob.size,
      checksum,
      storedFileId: stored.id,
      errorCode: null,
      updatedAt: nowIso(),
      completedAt: nowIso(),
    }
    job.record = completed
    await commit(completed)
  } catch (error) {
    const failed: DownloadJobRecord = {
      ...job.record,
      status: 'failed',
      errorCode: error instanceof Error && error.name === 'QuotaExceededError' ? 'insufficient-storage' : 'storage-error',
      updatedAt: nowIso(),
    }
    job.record = failed
    await commit(failed)
  } finally {
    // The engine entry exists for pause/cancel control only - once the job
    // is terminal it is dead weight (the UI record persists in the store).
    engineJobs.delete(job.record.id)
  }
}

/** List current jobs (restored + engine-owned), newest first. */
export function listEngineJobs(): DownloadJobRecord[] {
  const uiJobs = Object.values(useDownloadManagerStore.getState().jobs)
  return uiJobs.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
}

/** Import an already-validated file (used by the import flow). */
export async function importValidatedFile(
  metadata: Omit<StoredFileMetadata, 'id'>,
  blob: Blob,
): Promise<StoredFileMetadata> {
  return store().saveFile(metadata, blob)
}
