import { NextResponse } from 'next/server'

import { SURA_INDEX } from '@/data/sura-index'
import {
  QURANENC_SITE_URL,
  TRANSLATION_KEY_PATTERN,
  getIsoCodes,
  getSuraTranslation,
  getMergedTranslationsList,
} from '@/server/quranenc/client'
import { prettifyLanguageName } from '@/server/quranenc/mappers'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import {
  RIGHTS_NOTICE,
  buildDocxExport,
  buildFileStem,
  buildHtmlExport,
  buildJsonExport,
  buildTxtExport,
  contentDisposition,
  type ExportAya,
  type ExportMeta,
  type ExportSura,
} from '@/lib/quran-export/builders'

/**
 * GET /api/quran/export/[translationKey]?format=docx|txt|json|html
 * GET /api/quran/export/[translationKey]?probe=1
 *
 * Generates a complete export of one QuranEnc translation: all 114 suras with
 * the source-verbatim Arabic text (Uthmanic Hafs) and the translation text.
 *
 * - The translation key is validated against the pattern AND against the live
 *   catalog - user-supplied URLs are never accepted, only catalog keys.
 * - All 114 suras are aggregated through the shared QuranEnc client in batches
 *   of 6 concurrent requests (the client caches each sura for 24 hours, so
 *   repeat exports are fast). A sura that comes back empty aborts the export
 *   with a clean 502 - partial exports are never served silently.
 * - `format=html` returns a self-contained print-optimized document: the
 *   client writes it into a hidden iframe and calls print(), which is the
 *   honest PDF path (the browser print dialog produces the PDF).
 * - `probe=1` builds every format once and returns the exact byte size of
 *   each generated document as JSON - without downloading any of them. This
 *   powers the size labels shown next to every download option before the
 *   user generates anything. The probe shares the 24-hour per-sura cache
 *   with the real exports, so probe + download together cost one upstream
 *   aggregation, never two.
 *
 * The document builders are shared with the native app adapter
 * (src/lib/quran-export/builders.ts) so both platforms generate identical
 * files. Arabic text is passed through verbatim; only structural markers
 * (ayah numbers, headings, separators) are added around it.
 */

export const dynamic = 'force-dynamic'

const EXPORT_FORMATS = ['docx', 'txt', 'json', 'html'] as const
type ExportFormat = (typeof EXPORT_FORMATS)[number]

/** Exact byte sizes of every generated format (the `?probe=1` response). */
interface ExportSizeProbe {
  docx: number
  txt: number
  json: number
  html: number
}

const TOTAL_SURA_COUNT = 114
/** Concurrent upstream requests per batch. */
const BATCH_SIZE = 6
/** Total wall-clock guard for the whole aggregation. */
const TIME_LIMIT_MS = 4 * 60 * 1000

/* ------------------------------------------------------------------ */
/* Errors                                                              */
/* ------------------------------------------------------------------ */

class ExportTimeoutError extends Error {
  constructor() {
    super('Export deadline exceeded')
    this.name = 'ExportTimeoutError'
  }
}

class ExportIncompleteError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'ExportIncompleteError'
  }
}

/* ------------------------------------------------------------------ */
/* Shared aggregation                                                  */
/* ------------------------------------------------------------------ */

/** Aggregated export content: the catalog record plus all 114 suras. */
interface AggregatedExport {
  meta: ExportMeta
  suras: ExportSura[]
  stem: string
}

/**
 * Aggregate all suras of one translation through the shared (24-hour cached)
 * QuranEnc client. Used by both the real exports and the size probe, so a
 * probe followed by a download reads the upstream exactly once.
 */
async function aggregateTranslationExport(
  translationKey: string,
  localization: string,
): Promise<AggregatedExport> {
  const [{ translations }, isoCodes] = await Promise.all([
    getMergedTranslationsList(localization),
    getIsoCodes(),
  ])
  const catalogItem = translations.find((item) => item.key === translationKey)
  if (!catalogItem) {
    throw new NotFoundError()
  }

  const languageName = prettifyLanguageName(
    isoCodes.codeToName[catalogItem.language_iso_code] ?? catalogItem.language_iso_code,
  )
  const lastUpdate =
    typeof catalogItem.last_update === 'number'
      ? new Date(catalogItem.last_update * 1000).toISOString()
      : null

  /* Aggregate all 114 suras in batches of 6 concurrent requests. */
  const deadline = Date.now() + TIME_LIMIT_MS
  const suras: ExportSura[] = []

  for (let start = 1; start <= TOTAL_SURA_COUNT; start += BATCH_SIZE) {
    if (Date.now() > deadline) throw new ExportTimeoutError()
    const batchNumbers: number[] = []
    for (let n = start; n < Math.min(start + BATCH_SIZE, TOTAL_SURA_COUNT + 1); n++) {
      batchNumbers.push(n)
    }
    const results = await Promise.all(
      batchNumbers.map((n) => getSuraTranslation(translationKey, n)),
    )
    for (let index = 0; index < results.length; index++) {
      const suraNumber = batchNumbers[index]
      const result = results[index]
      if (result.ayat.length === 0) {
        throw new ExportIncompleteError(`Sura ${suraNumber} returned no ayat at the source.`)
      }
      const suraMeta = SURA_INDEX[suraNumber - 1]
      if (result.ayat.length !== suraMeta.ayahCount) {
        console.warn(
          `[export] sura ${suraNumber}: expected ${suraMeta.ayahCount} ayat, received ${result.ayat.length}`,
        )
      }
      suras.push({
        number: suraNumber,
        nameArabic: suraMeta.nameArabic,
        nameEnglish: suraMeta.nameEnglish,
        ayahCount: result.ayat.length,
        ayat: result.ayat.map((aya): ExportAya => ({
          number: aya.aya,
          arabicText: aya.arabicText,
          translation: aya.translation,
          footnotes: aya.footnotes,
        })),
      })
    }
  }
  if (Date.now() > deadline) throw new ExportTimeoutError()

  const meta: ExportMeta = {
    key: translationKey,
    title: catalogItem.title ?? translationKey,
    languageCode: catalogItem.language_iso_code,
    languageName,
    direction: catalogItem.direction === 'rtl' ? 'rtl' : 'ltr',
    version: catalogItem.version ?? null,
    lastUpdate,
    exportedAt: new Date().toISOString(),
    source: QURANENC_SITE_URL,
    suraCount: suras.length,
    ayahCount: suras.reduce((total, sura) => total + sura.ayat.length, 0),
    rightsNotice: RIGHTS_NOTICE,
  }

  return { meta, suras, stem: buildFileStem(translationKey) }
}

/** Raised when the translation key is valid-shaped but absent from the catalog. */
class NotFoundError extends Error {
  constructor() {
    super('Translation not found in the catalog')
    this.name = 'NotFoundError'
  }
}

/** Build every export format once and measure its exact byte size. */
async function buildSizeProbe({ meta, suras }: AggregatedExport): Promise<ExportSizeProbe> {
  const [json, txt, html, docx] = await Promise.all([
    Promise.resolve(buildJsonExport(meta, suras)),
    Promise.resolve(buildTxtExport(meta, suras)),
    Promise.resolve(buildHtmlExport(meta, suras)),
    buildDocxExport(meta, suras),
  ])
  return {
    json: Buffer.byteLength(json, 'utf8'),
    txt: Buffer.byteLength(txt, 'utf8'),
    html: Buffer.byteLength(html, 'utf8'),
    docx: docx.size,
  }
}

/* ------------------------------------------------------------------ */
/* Route handler                                                       */
/* ------------------------------------------------------------------ */

export async function GET(
  request: Request,
  context: { params: Promise<{ translationKey: string }> },
) {
  const { translationKey } = await context.params
  const url = new URL(request.url)
  const requestedFormat = url.searchParams.get('format') ?? ''
  const localization = url.searchParams.get('localization') ?? 'en'
  const isProbe = url.searchParams.get('probe') === '1'

  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key.' }, { status: 400 })
  }

  // The probe is a read-only size measurement with the same upstream cost as
  // one export (shared cache afterwards). It gets its own generous budget so
  // opening a details dialog never blocks a real export.
  const limit = isProbe
    ? checkRateLimit(request, { name: 'quran-export-probe', limit: 8, windowMs: 60_000 })
    : checkRateLimit(request, { name: 'quran-export', limit: 6, windowMs: 60_000 })
  if (!limit.ok) return rateLimitResponse(limit)

  const format = (EXPORT_FORMATS as readonly string[]).includes(requestedFormat)
    ? (requestedFormat as ExportFormat)
    : null
  if (!isProbe && !format) {
    return NextResponse.json(
      { message: `Unsupported format. Available formats: ${EXPORT_FORMATS.join(', ')}.` },
      { status: 400 },
    )
  }

  try {
    // Only real catalog keys are accepted - never a user-supplied URL.
    const aggregated = await aggregateTranslationExport(translationKey, localization)
    const { meta, suras, stem } = aggregated

    if (isProbe) {
      const sizes = await buildSizeProbe(aggregated)
      return NextResponse.json(
        {
          translationKey,
          title: meta.title,
          version: meta.version,
          sizes,
        },
        { headers: { 'cache-control': 'no-store' } },
      )
    }

    if (format === 'json') {
      return new NextResponse(buildJsonExport(meta, suras), {
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Disposition': contentDisposition(true, `${stem}.json`),
        },
      })
    }

    if (format === 'txt') {
      return new NextResponse(buildTxtExport(meta, suras), {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'Content-Disposition': contentDisposition(true, `${stem}.txt`),
        },
      })
    }

    if (format === 'docx') {
      const blob = await buildDocxExport(meta, suras)
      return new NextResponse(blob, {
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'Content-Disposition': contentDisposition(true, `${stem}.docx`),
        },
      })
    }

    // format === 'html' - inline document for the iframe print pipeline.
    return new NextResponse(buildHtmlExport(meta, suras), {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': contentDisposition(false, `${stem}.html`),
      },
    })
  } catch (error) {
    if (error instanceof NotFoundError) {
      return NextResponse.json(
        { message: 'This translation does not exist in the QuranEnc catalog.' },
        { status: 404 },
      )
    }
    if (error instanceof ExportTimeoutError) {
      return NextResponse.json(
        {
          message:
            'The export took too long to fetch from the source and was aborted. Please try again - repeat exports are served from the 24-hour cache.',
        },
        { status: 502 },
      )
    }
    if (error instanceof ExportIncompleteError) {
      console.error('[export] incomplete source data', error.message)
      return NextResponse.json(
        {
          message:
            'The export could not be completed because the source returned incomplete content. No partial file was generated.',
        },
        { status: 502 },
      )
    }
    if (error instanceof Error && error.name === 'QuranEncUpstreamError') {
      return NextResponse.json(
        {
          message:
            'The translation content could not be fetched from QuranEnc. Please check your connection and try again shortly.',
        },
        { status: 502 },
      )
    }
    console.error('[export] unexpected error', error)
    return NextResponse.json({ message: 'The export could not be generated.' }, { status: 500 })
  }
}
