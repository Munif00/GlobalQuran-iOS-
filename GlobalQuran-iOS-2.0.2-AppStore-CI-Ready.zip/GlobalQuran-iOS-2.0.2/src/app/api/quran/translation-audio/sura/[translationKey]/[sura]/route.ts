import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import {
  getTranslationAudioInventory,
  getTranslationFilesManifest,
  quranEncTranslationAudioUrl,
  verifyTranslationAudioLive,
} from '@/server/audio/translation-audio'
import { getSuraAyahCount } from '@/lib/audio/urls'

/**
 * GET /api/quran/translation-audio/sura/[translationKey]/[sura]
 *
 * The VERIFIED per-ayah availability inventory of one sura's recorded
 * translation narration. Every listed ayah comes from the translation's
 * real files.json manifest - an ayah the source does not have is reported
 * in missingAyat and is never offered as playable or downloadable.
 *
 * A live reachability check of the first listed file guards against a
 * stale manifest; sizes are deliberately NOT probed here (the player does
 * not need them; exact sizes belong to the batch plan).
 */

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: { params: Promise<{ translationKey: string; sura: string }> },
) {
  const rl = checkRateLimit(request, { name: 'translation-audio-sura', limit: 120, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { translationKey, sura: suraRaw } = await context.params
  const sura = Number(suraRaw)

  if (!/^[a-z0-9_]+$/.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key.' }, { status: 400 })
  }
  if (getSuraAyahCount(sura) === 0) {
    return NextResponse.json({ message: 'Invalid sura number.' }, { status: 400 })
  }

  const manifest = await getTranslationFilesManifest(translationKey)
  if (!manifest) {
    // This translation has no verified recorded audio at the source.
    return NextResponse.json({ message: 'No recorded audio for this translation.' }, { status: 404 })
  }

  const inventory = await getTranslationAudioInventory(translationKey)
  if (!inventory) {
    return NextResponse.json({ message: 'No recorded audio for this translation.' }, { status: 404 })
  }

  const ayahCount = getSuraAyahCount(sura)
  const available = inventory.get(sura) ?? new Set<number>()
  const files: Array<{ ayah: number; url: string }> = []
  const missingAyat: number[] = []
  for (let ayah = 1; ayah <= ayahCount; ayah += 1) {
    const url = quranEncTranslationAudioUrl(translationKey, sura, ayah)
    if (available.has(ayah) && url) {
      files.push({ ayah, url })
    } else {
      missingAyat.push(ayah)
    }
  }

  // Live check on the first available file (honest availability verdict).
  const live = files.length > 0 ? await verifyTranslationAudioLive(translationKey, sura, files[0].ayah) : {
    status: 'unavailable' as const,
    checkedAt: new Date().toISOString(),
    httpStatus: null,
  }

  return NextResponse.json({
    translationKey,
    translationTitle: null,
    audioName: manifest.translation,
    languageIso: null,
    sura,
    ayahCount,
    availableAyat: files.length,
    missingAyat,
    live,
    files,
  })
}
