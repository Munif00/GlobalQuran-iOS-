import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import {
  estimateTranslationAudioSize,
  getTranslationAudioCatalog,
  getTranslationAudioInventory,
  getTranslationFilesManifest,
  probeTranslationAudioSizes,
} from '@/server/audio/translation-audio'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { getJuzPositions } from '@/data/juz-index'
import type { TranslationAudioBatchPlanResponse } from '@/types'

/**
 * GET /api/quran/translation-audio/batch
 *
 * The VERIFIED download plan for one translation audio batch
 * (ayah / sura / range / juz / complete):
 * - the file list comes from the translation's real files.json manifest;
 *   ayat the source does not have are reported in `missing` and never
 *   offered as downloadable,
 * - ayah/sura/range/juz batches get EXACT byte sizes (live HEAD probes,
 *   cached); the complete package gets a clearly-flagged SAMPLED ESTIMATE
 *   (probing 6236 files is not a request anybody should wait for),
 * - the complete package is only offered (`completePackageOfferable`) when
 *   the manifest actually covers all 6236 ayat.
 */

export const dynamic = 'force-dynamic'

/** Batches up to this many files are probed for exact sizes. */
const EXACT_PROBE_LIMIT = 700

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'translation-audio-batch', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const translationKey = url.searchParams.get('translationKey') ?? ''
  const kind = url.searchParams.get('kind') ?? ''

  if (!/^[a-z0-9_]+$/.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key.' }, { status: 400 })
  }
  if (!['ayah', 'sura', 'range', 'juz', 'complete'].includes(kind)) {
    return NextResponse.json({ message: 'Invalid batch kind.' }, { status: 400 })
  }

  const manifest = await getTranslationFilesManifest(translationKey)
  if (!manifest) {
    return NextResponse.json(
      { message: 'No recorded audio for this translation at the source.' },
      { status: 404 },
    )
  }

  const suraParam = Number(url.searchParams.get('sura'))
  const ayahParam = Number(url.searchParams.get('ayah'))
  const fromParam = Number(url.searchParams.get('from'))
  const toParam = Number(url.searchParams.get('to'))
  const juzParam = Number(url.searchParams.get('juz'))

  let positions: Array<{ sura: number; ayah: number }> = []
  let batchSura: number | null = null
  let ayahFrom: number | null = null
  let ayahTo: number | null = null
  let juz: number | null = null

  switch (kind) {
    case 'ayah': {
      if (
        getSuraAyahCount(suraParam) === 0 ||
        !Number.isInteger(ayahParam) ||
        ayahParam < 1 ||
        ayahParam > getSuraAyahCount(suraParam)
      ) {
        return NextResponse.json({ message: 'Invalid sura or ayah.' }, { status: 400 })
      }
      positions = [{ sura: suraParam, ayah: ayahParam }]
      batchSura = suraParam
      ayahFrom = ayahParam
      ayahTo = ayahParam
      break
    }
    case 'sura': {
      if (getSuraAyahCount(suraParam) === 0) {
        return NextResponse.json({ message: 'Invalid sura.' }, { status: 400 })
      }
      positions = Array.from({ length: getSuraAyahCount(suraParam) }, (_, i) => ({
        sura: suraParam,
        ayah: i + 1,
      }))
      batchSura = suraParam
      break
    }
    case 'range': {
      if (getSuraAyahCount(suraParam) === 0) {
        return NextResponse.json({ message: 'Invalid sura.' }, { status: 400 })
      }
      const suraLast = getSuraAyahCount(suraParam)
      if (
        !Number.isInteger(fromParam) ||
        !Number.isInteger(toParam) ||
        fromParam < 1 ||
        toParam < fromParam ||
        fromParam > suraLast
      ) {
        return NextResponse.json({ message: 'Invalid ayah range.' }, { status: 400 })
      }
      const to = Math.min(toParam, suraLast)
      positions = []
      for (let ayah = fromParam; ayah <= to; ayah += 1) positions.push({ sura: suraParam, ayah })
      batchSura = suraParam
      ayahFrom = fromParam
      ayahTo = to
      break
    }
    case 'juz': {
      const juzPositions = getJuzPositions(juzParam)
      if (juzPositions.length === 0) {
        return NextResponse.json({ message: 'Invalid juz number.' }, { status: 400 })
      }
      positions = juzPositions
      juz = juzParam
      break
    }
    case 'complete': {
      positions = []
      for (let sura = 1; sura <= 114; sura += 1) {
        for (let ayah = 1; ayah <= getSuraAyahCount(sura); ayah += 1) {
          positions.push({ sura, ayah })
        }
      }
      break
    }
    default:
      return NextResponse.json({ message: 'Invalid batch kind.' }, { status: 400 })
  }

  // Verify every position against the real manifest inventory.
  const inventory = await getTranslationAudioInventory(translationKey)
  if (!inventory) {
    return NextResponse.json(
      { message: 'No recorded audio for this translation at the source.' },
      { status: 404 },
    )
  }
  const verified: Array<{ sura: number; ayah: number }> = []
  const missing: Array<{ sura: number; ayah: number }> = []
  for (const position of positions) {
    const set = inventory.get(position.sura)
    if (set && set.has(position.ayah)) verified.push(position)
    else missing.push(position)
  }
  verified.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)
  missing.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)

  // Exact sizes for ordinary batches; sampled estimate for the full package.
  let files: TranslationAudioBatchPlanResponse['files']
  let totalBytes = 0
  let sizeEstimated = false
  if (kind === 'complete' || verified.length > EXACT_PROBE_LIMIT) {
    sizeEstimated = true
    const estimate = await estimateTranslationAudioSize(translationKey, verified)
    totalBytes = estimate.estimatedBytes
    files = verified.map((position) => ({ ...position, sizeBytes: 0 }))
  } else {
    const probed = await probeTranslationAudioSizes(translationKey, verified)
    files = probed.files
    totalBytes = files.reduce((sum, file) => sum + file.sizeBytes, 0)
  }

  // Catalog metadata (best-effort; honest nulls).
  let audioName = manifest.translation
  let translationTitle: string | null = null
  let languageName: string | null = null
  try {
    const catalog = await getTranslationAudioCatalog()
    const entry = catalog.find((item) => item.translationKey === translationKey)
    if (entry) {
      audioName = entry.audioName
      translationTitle = entry.textTitle
      languageName = entry.languageName
    }
  } catch {
    /* metadata stays honest-null */
  }
  const response: TranslationAudioBatchPlanResponse = {
    translationKey,
    audioName,
    translationTitle,
    languageName,
    batchKind: kind,
    sura: batchSura,
    ayahFrom,
    ayahTo,
    juz,
    files,
    totalFiles: files.length,
    totalBytes,
    sizeEstimated,
    missing,
    sourceComplete: missing.length === 0,
    completePackageOfferable: kind === 'complete' && files.length === 6236,
    sourceName: 'QuranEnc',
  }
  return NextResponse.json(response)
}
