import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import {
  getTranslationAudioInventory,
  quranEncTranslationAudioUrl,
} from '@/server/audio/translation-audio'
import { getSuraAyahCount } from '@/lib/audio/urls'

/**
 * GET  /api/quran/translation-audio/file/[translationKey]/[sura]/[ayah]
 * HEAD /api/quran/translation-audio/file/[translationKey]/[sura]/[ayah]
 *
 * Streams ONE verified translation narration file (a single ayah, MP3) from
 * the QuranEnc audio CDN for offline downloading.
 *
 * Why a proxy: the QuranEnc MP3 responses do not carry CORS headers, so a
 * browser-side fetch of the CDN URL is not possible. The download engines
 * stream through this same-origin route (web server and native adapter),
 * with one consistent byte-range contract for pause/resume. The target URL
 * is built server-side and only AFTER the (translation, sura, ayah) was
 * verified against the translation's real files.json manifest - a file the
 * source does not have can never be requested through this route.
 *
 * - GET forwards a strict `bytes=N-` Range to the source and passes the
 *   200/206 status + Content-Length/Content-Range/Accept-Ranges through,
 *   so the download manager can pause and resume.
 * - HEAD answers from the live CDN probe (the exact byte size of the file).
 */

export const dynamic = 'force-dynamic'

const QURANENC_AUDIO_HOST = 'd.quranenc.com'

async function resolveVerifiedFile(
  translationKey: string,
  sura: number,
  ayah: number,
): Promise<string | null> {
  const inventory = await getTranslationAudioInventory(translationKey)
  if (!inventory) return null
  const set = inventory.get(sura)
  if (!set || !set.has(ayah)) return null
  return quranEncTranslationAudioUrl(translationKey, sura, ayah)
}

function isVerifiedQuranEncAudioUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl)
    return (
      url.protocol === 'https:' &&
      url.hostname === QURANENC_AUDIO_HOST &&
      /^\/data\/audio\/[a-z0-9_]+\/\d{6}\.mp3$/.test(url.pathname)
    )
  } catch {
    return false
  }
}

export async function GET(
  request: Request,
  context: { params: Promise<{ translationKey: string; sura: string; ayah: string }> },
) {
  const rl = checkRateLimit(request, {
    name: 'translation-audio-file',
    limit: 1200,
    windowMs: 60000,
  })
  if (!rl.ok) return rateLimitResponse(rl)

  const { translationKey, sura: suraRaw, ayah: ayahRaw } = await context.params
  const sura = Number(suraRaw)
  const ayah = Number(ayahRaw)

  if (!/^[a-z0-9_]+$/.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key.' }, { status: 400 })
  }
  if (
    getSuraAyahCount(sura) === 0 ||
    !Number.isInteger(ayah) ||
    ayah < 1 ||
    ayah > getSuraAyahCount(sura)
  ) {
    return NextResponse.json({ message: 'Invalid sura or ayah number.' }, { status: 400 })
  }

  const fileUrl = await resolveVerifiedFile(translationKey, sura, ayah)
  if (!fileUrl) {
    // The source manifest does not list this file - honest 404, never a
    // guessed URL.
    return NextResponse.json(
      { message: 'No recorded narration file for this ayah at the source.' },
      { status: 404 },
    )
  }
  if (!isVerifiedQuranEncAudioUrl(fileUrl)) {
    return NextResponse.json({ message: 'Blocked audio URL.' }, { status: 400 })
  }

  // Range pass-through for pause/resume (strict single form only).
  const rangeHeader = request.headers.get('range')
  const safeRange =
    rangeHeader !== null && /^bytes=\d{0,15}-(\d{0,15})?$/.test(rangeHeader.trim())
      ? rangeHeader.trim()
      : null

  let upstream: Response
  try {
    upstream = await fetch(fileUrl, {
      credentials: 'omit',
      signal: AbortSignal.timeout(120_000),
      cache: 'no-store',
      headers: {
        Accept: 'audio/mpeg, */*',
        ...(safeRange ? { Range: safeRange } : {}),
      },
    })
  } catch (error) {
    console.error(
      '[translation-audio-file] upstream failed',
      error instanceof Error ? error.message : error,
    )
    return NextResponse.json(
      { message: 'The narration file could not be fetched from the source.' },
      { status: 502 },
    )
  }

  if (!upstream.ok || !upstream.body) {
    return NextResponse.json(
      { message: 'The narration file could not be fetched from the source.' },
      { status: 502 },
    )
  }

  const fileName = `${String(sura).padStart(3, '0')}${String(ayah).padStart(3, '0')}.mp3`
  const headers = new Headers()
  headers.set('Content-Type', upstream.headers.get('content-type') ?? 'audio/mpeg')
  const contentLength = upstream.headers.get('content-length')
  if (contentLength) headers.set('Content-Length', contentLength)
  const contentRange = upstream.headers.get('content-range')
  if (contentRange) headers.set('Content-Range', contentRange)
  const acceptRanges = upstream.headers.get('accept-ranges')
  if (acceptRanges) headers.set('Accept-Ranges', acceptRanges)
  if (!safeRange) {
    headers.set('Content-Disposition', `attachment; filename="${translationKey}-${fileName}"`)
  }
  headers.set('Cache-Control', 'no-store')

  return new Response(upstream.body, { status: upstream.status === 206 ? 206 : 200, headers })
}

export async function HEAD(
  request: Request,
  context: { params: Promise<{ translationKey: string; sura: string; ayah: string }> },
) {
  const rl = checkRateLimit(request, {
    name: 'translation-audio-file-head',
    limit: 1200,
    windowMs: 60000,
  })
  if (!rl.ok) return rateLimitResponse(rl)

  const { translationKey, sura: suraRaw, ayah: ayahRaw } = await context.params
  const sura = Number(suraRaw)
  const ayah = Number(ayahRaw)

  if (
    !/^[a-z0-9_]+$/.test(translationKey) ||
    getSuraAyahCount(sura) === 0 ||
    ayah < 1 ||
    ayah > getSuraAyahCount(sura)
  ) {
    return new Response(null, { status: 400, headers: { 'cache-control': 'no-store' } })
  }

  const fileUrl = await resolveVerifiedFile(translationKey, sura, ayah)
  if (!fileUrl) {
    return new Response(null, { status: 404, headers: { 'cache-control': 'no-store' } })
  }

  // Live size probe (the manifest lists names, not sizes).
  try {
    const response = await fetch(fileUrl, {
      method: 'HEAD',
      signal: AbortSignal.timeout(15_000),
      headers: { Accept: 'audio/mpeg, */*' },
      cache: 'no-store',
    })
    const length = Number(response.headers.get('content-length'))
    if (!response.ok || !Number.isFinite(length) || length <= 0) {
      return new Response(null, { status: 502, headers: { 'cache-control': 'no-store' } })
    }
    return new Response(null, {
      status: 200,
      headers: {
        'content-length': String(length),
        'content-type': 'audio/mpeg',
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
      },
    })
  } catch {
    return new Response(null, { status: 502, headers: { 'cache-control': 'no-store' } })
  }
}
