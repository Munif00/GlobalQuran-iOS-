import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import { getMergedTranslationsList, getIsoCodes } from '@/server/quranenc/client'
import { getTranslationAudioCatalog, QURANENC_AUDIO_DASHBOARD_URL } from '@/server/audio/translation-audio'

/**
 * GET /api/quran/translation-audio/catalog
 *
 * The VERIFIED catalog of QuranEnc translations that have recorded audio:
 * - the audio folder list is DISCOVERED dynamically from QuranEnc's audio
 *   developers dashboard (no hardcoded language count),
 * - every listed translation's files.json manifest is actually fetched and
 *   validated before the translation appears here,
 * - language metadata (ISO code, name, direction, text title) comes from a
 *   cross-reference with the text translation catalog and stays null when
 *   that catalog is unreachable - availability of AUDIO is never inferred
 *   from the text catalog or vice versa.
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'translation-audio-catalog', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  try {
    // Cross-reference with the text catalog (best-effort; honest nulls on failure).
    let textLookup:
      | ((
          translationKey: string,
        ) => {
          title: string | null
          languageIso: string | null
          languageName: string | null
          direction: 'ltr' | 'rtl' | null
        } | null)
      | undefined
    try {
      const [{ translations }, isoCodes] = await Promise.all([
        getMergedTranslationsList('en'),
        getIsoCodes(),
      ])
      const byKey = new Map(translations.map((item) => [item.key, item]))
      textLookup = (translationKey: string) => {
        const item = byKey.get(translationKey)
        if (!item) return null
        return {
          title: item.title ?? null,
          languageIso: item.language_iso_code ?? null,
          languageName: isoCodes.codeToName[item.language_iso_code] ?? null,
          direction: item.direction ?? null,
        }
      }
    } catch {
      textLookup = undefined
    }

    const translations = await getTranslationAudioCatalog(textLookup)
    return NextResponse.json({
      source: 'QuranEnc audio dashboard',
      sourceUrl: QURANENC_AUDIO_DASHBOARD_URL,
      translations,
    })
  } catch (error) {
    console.error(
      '[translation-audio-catalog] discovery failed',
      error instanceof Error ? error.message : error,
    )
    return NextResponse.json(
      {
        message: 'The QuranEnc translation audio catalog could not be reached. Please try again shortly.',
        translations: [],
      },
      { status: 502 },
    )
  }
}
