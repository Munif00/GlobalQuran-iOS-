import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import {
  getSuraTranslation,
  getMergedTranslationsList,
  QuranEncUpstreamError,
  TRANSLATION_KEY_PATTERN,
} from '@/server/quranenc/client'

/**
 * GET  /api/quran/offline-pack/[translationKey]
 * HEAD /api/quran/offline-pack/[translationKey]
 *
 * A complete offline copy of one translation: every ayah of all 114 suras in
 * a single response, so the client can store it with one obvious "Download"
 * action and read it without a connection.
 *
 * - Content comes verbatim from the documented per-sura endpoint
 *   GET /translation/sura/{key}/{sura} (server-side cache: 24 h per sura).
 * - Sura are fetched with bounded concurrency; a single failing sura fails
 *   the whole pack (nothing partial is ever labeled a complete pack).
 * - The response body is fully serialized first, so Content-Length is exact
 *   and byte-range resume works (Range requests slice the same buffer) -
 *   pause/resume behaves exactly like the document-file downloads.
 * - Only suras that exist at the source are included; the response always
 *   states the real count so the client can validate completeness.
 * - HEAD answers with the exact same Content-Length (the payload is built
 *   from the same cached suras) so the UI can show the real download size
 *   BEFORE the user starts the transfer - no size is ever guessed.
 */

export const dynamic = 'force-dynamic'

/** Sura are fetched with this concurrency server-side. */
const FETCH_CONCURRENCY = 8

/** All 114 sura numbers of the Quran. */
const ALL_SURAS = Array.from({ length: 114 }, (_, index) => index + 1)

interface PackSura {
  sura: number
  ayahCount: number
  ayat: Array<{ sura: number; aya: number; arabicText: string; translation: string; footnotes: string | null }>
}

async function fetchSuraSafe(translationKey: string, sura: number): Promise<PackSura | null> {
  const { ayat } = await getSuraTranslation(translationKey, sura)
  if (ayat.length === 0) return null
  return {
    sura,
    ayahCount: ayat.length,
    ayat: ayat.map((aya) => ({
      sura: aya.sura,
      aya: aya.aya,
      arabicText: aya.arabicText,
      translation: aya.translation,
      footnotes: aya.footnotes,
    })),
  }
}

/** Map with bounded concurrency over all sura numbers. */
async function fetchAllSuras(translationKey: string): Promise<Array<PackSura | null>> {
  const results: Array<PackSura | null> = new Array(ALL_SURAS.length).fill(null)
  let cursor = 0
  const workers = Array.from({ length: Math.min(FETCH_CONCURRENCY, ALL_SURAS.length) }, async () => {
    for (;;) {
      const index = cursor++
      if (index >= ALL_SURAS.length) break
      results[index] = await fetchSuraSafe(translationKey, ALL_SURAS[index])
    }
  })
  await Promise.all(workers)
  return results
}

/** Parse a Range header of the form `bytes=start-` into a start offset. */
function parseRangeStart(header: string | null): number | null {
  if (!header) return null
  const match = /^bytes=(\d+)-/.exec(header.trim())
  if (!match) return null
  const start = Number(match[1])
  return Number.isSafeInteger(start) && start >= 0 ? start : null
}

/**
 * Shared handler core for GET and HEAD: aggregates the pack and serves it
 * (GET) or serves only its exact headers (HEAD). Both run through the same
 * 24-hour per-sura cache, so a HEAD probe followed by the real GET download
 * costs one upstream aggregation in total, never two.
 */
async function servePack(
  request: Request,
  translationKey: string,
  rateLimit: { name: string; limit: number },
  withBody: boolean,
): Promise<Response> {
  const rl = checkRateLimit(request, { name: rateLimit.name, limit: rateLimit.limit, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key' }, { status: 400 })
  }

  try {
    const listResult = await getMergedTranslationsList('en').catch(() => ({ translations: [], servedFromCache: true }))
    const meta = listResult.translations.find((item) => item.key === translationKey) ?? null
    // Only reject when the catalog actually loaded - a failed catalog fetch
    // must not 404 a valid translation (the sura fetch decides then).
    if (listResult.translations.length > 0 && meta === null) {
      return NextResponse.json(
        { message: 'This translation is not available at the source.' },
        { status: 404 },
      )
    }

    const suraResults = await fetchAllSuras(translationKey)

    if (suraResults.every((sura) => sura === null)) {
      return NextResponse.json(
        { message: 'This translation is not available at the source.' },
        { status: 404 },
      )
    }

    const suras = suraResults.filter((sura): sura is PackSura => sura !== null)
    const payload = {
      status: 'live' as const,
      source: 'QuranEnc API v1',
      translationKey,
      translationTitle: meta?.title ?? null,
      languageCode: meta?.language_iso_code ?? null,
      direction: meta?.direction === 'rtl' ? 'rtl' : 'ltr',
      version: typeof meta?.version === 'string' && meta.version.length > 0 ? meta.version : null,
      totalSuras: 114,
      suraCount: suras.length,
      suras,
    }
    const bodyBuffer = Buffer.from(JSON.stringify(payload), 'utf8')
    const totalLength = bodyBuffer.byteLength

    // HEAD: exact size, no body. The client shows this as the real download
    // size before starting the transfer.
    if (!withBody) {
      return new Response(null, {
        status: 200,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'content-length': String(totalLength),
          'accept-ranges': 'bytes',
          'cache-control': 'no-store',
        },
      })
    }

    // Byte-range resume support (pause/resume works like file downloads).
    const rangeStart = parseRangeStart(request.headers.get('range'))
    if (rangeStart !== null && rangeStart > 0 && rangeStart < totalLength) {
      const slice = bodyBuffer.subarray(rangeStart)
      return new Response(new Uint8Array(slice), {
        status: 206,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'content-length': String(slice.byteLength),
          'content-range': `bytes ${rangeStart}-${totalLength - 1}/${totalLength}`,
          'accept-ranges': 'bytes',
          'cache-control': 'no-store',
        },
      })
    }

    return new Response(new Uint8Array(bodyBuffer), {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'content-length': String(totalLength),
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
      },
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return NextResponse.json(
        { message: 'The offline copy could not be built from the source.' },
        { status: 502 },
      )
    }
    console.error('[offline-pack] unexpected error', error)
    return NextResponse.json(
      { message: 'The offline copy could not be built.' },
      { status: 500 },
    )
  }
}

export async function GET(
  request: Request,
  context: { params: Promise<{ translationKey: string }> },
) {
  // Bulk endpoint: a low per-IP budget is enough (one pack per download).
  const { translationKey } = await context.params
  return servePack(request, translationKey, { name: 'quran-offline-pack', limit: 10 }, true)
}

/**
 * HEAD - the exact download size of the pack, before the user downloads it.
 * Shares the per-sura cache with GET, so probe + download together cost one
 * upstream aggregation.
 */
export async function HEAD(
  request: Request,
  context: { params: Promise<{ translationKey: string }> },
) {
  const { translationKey } = await context.params
  return servePack(request, translationKey, { name: 'quran-offline-pack-probe', limit: 30 }, false)
}
