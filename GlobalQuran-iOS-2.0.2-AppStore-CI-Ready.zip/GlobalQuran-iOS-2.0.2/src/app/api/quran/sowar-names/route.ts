import { NextResponse } from 'next/server'

import { getSuraNames, QuranEncUpstreamError } from '@/server/quranenc/client'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

/**
 * GET /api/quran/sowar-names?locale=<locale>
 *
 * Localized sura names from the documented endpoint
 * GET /translations/sowar_names?iso_code=... The requested locale is used
 * when the source supports it; otherwise the source's English names are
 * returned and `effectiveLocale` says so honestly.
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'quran-sowar-names', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const locale = url.searchParams.get('locale') ?? 'en'

  try {
    const { names, effectiveLocale } = await getSuraNames(locale)
    return NextResponse.json({
      status: 'live',
      locale,
      effectiveLocale,
      names,
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return NextResponse.json(
        { message: 'Sura names could not be loaded from the source.' },
        { status: 502 },
      )
    }
    console.error('[sowar-names] unexpected error', error)
    return NextResponse.json({ message: 'Sura names could not be loaded.' }, { status: 500 })
  }
}
