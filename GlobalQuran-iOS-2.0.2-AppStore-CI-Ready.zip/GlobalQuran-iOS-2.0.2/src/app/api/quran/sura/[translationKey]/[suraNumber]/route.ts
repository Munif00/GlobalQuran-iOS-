import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import {
  QURANENC_API_DOCS_URL,
  getSuraTranslation,
  getMergedTranslationsList,
  QuranEncUpstreamError,
  TRANSLATION_KEY_PATTERN,
} from '@/server/quranenc/client'

/**
 * GET /api/quran/sura/[translationKey]/[suraNumber]
 *
 * Every ayah of one sura in one translation, from the documented endpoint
 * GET /translation/sura/{translation_key}/{sura_number}. The Arabic text and
 * the translation text are passed through verbatim (sanitized only for
 * control characters) - words, diacritics, ayah order and punctuation are
 * never altered.
 */

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: { params: Promise<{ translationKey: string; suraNumber: string }> },
) {
  const rl = checkRateLimit(request, { name: 'quran-sura', limit: 120, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { translationKey, suraNumber: suraNumberRaw } = await context.params
  const suraNumber = Number(suraNumberRaw)

  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key' }, { status: 400 })
  }
  if (!Number.isInteger(suraNumber) || suraNumber < 1 || suraNumber > 114) {
    return NextResponse.json({ message: 'Invalid sura number' }, { status: 400 })
  }

  try {
    const [{ ayat }, listResult] = await Promise.all([
      getSuraTranslation(translationKey, suraNumber),
      getMergedTranslationsList('en').catch(() => ({ translations: [], servedFromCache: true })),
    ])

    const meta = listResult.translations.find((item) => item.key === translationKey) ?? null

    if (ayat.length === 0) {
      return NextResponse.json(
        { message: 'This sura is not available in the selected translation.' },
        { status: 404 },
      )
    }

    return NextResponse.json({
      status: 'live',
      source: 'QuranEnc API v1',
      translationKey,
      translationTitle: meta?.title ?? null,
      languageCode: meta?.language_iso_code ?? null,
      direction: meta?.direction === 'rtl' ? 'rtl' : 'ltr',
      sura: suraNumber,
      ayahCount: ayat.length,
      version: meta?.version ?? null,
      ayat,
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      const status = error.message === 'Not found at source' ? 404 : 502
      return NextResponse.json(
        { message: 'The Quran content could not be loaded from the source.' },
        { status },
      )
    }
    console.error('[sura] unexpected error', error)
    return NextResponse.json(
      { message: 'The Quran content could not be loaded.' },
      { status: 500 },
    )
  }
}
