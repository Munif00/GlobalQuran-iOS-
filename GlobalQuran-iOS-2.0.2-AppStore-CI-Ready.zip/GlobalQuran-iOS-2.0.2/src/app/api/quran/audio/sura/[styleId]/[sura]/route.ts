import { NextResponse } from 'next/server'

import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import { getSuraAudioFiles } from '@/server/audio/catalog'
import { verifySuraLive } from '@/server/audio/everyayah'
import { getStyleDefinition, isKnownStyleId } from '@/data/audio-styles'
import { getSuraAyahCount } from '@/lib/audio/urls'

/**
 * GET /api/quran/audio/sura/[styleId]/[sura]
 *
 * Verified per-ayah audio inventory of one sura in one recitation style:
 * - every listed ayah has a seed-verified file with its EXACT byte size and
 *   the canonical EveryAyah URL,
 * - ayat without a verified file are reported in `missingAyat` (never
 *   included in `files`, so they can never be presented as playable),
 * - a live sample check of the sura's first ayah confirms the source is
 *   serving this sura's audio right now (`live.status`); when the live check
 *   does not confirm availability, `live.status` says so honestly and the
 *   client must not start playback.
 */

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: { params: Promise<{ styleId: string; sura: string }> },
) {
  const rl = checkRateLimit(request, { name: 'quran-audio-sura', limit: 120, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { styleId, sura: suraRaw } = await context.params
  const sura = Number(suraRaw)

  if (!isKnownStyleId(styleId)) {
    return NextResponse.json({ message: 'Unknown recitation style' }, { status: 400 })
  }
  if (getSuraAyahCount(sura) === 0) {
    return NextResponse.json({ message: 'Invalid sura number' }, { status: 400 })
  }

  try {
    const summary = getSuraAudioFiles(styleId, sura)
    if (!summary) {
      return NextResponse.json(
        { message: 'No verified audio inventory for this recitation style.' },
        { status: 404 },
      )
    }
    const live = await verifySuraLive(styleId, sura)
    const style = getStyleDefinition(styleId)
    return NextResponse.json({
      styleId,
      styleLabel: style?.styleLabel ?? null,
      reciterName: style?.reciterName ?? null,
      bitrate: style?.bitrate ?? null,
      folder: style?.folder ?? null,
      sourceName: style?.sourceName ?? null,
      sura: summary.sura,
      ayahCount: summary.ayahCount,
      availableAyat: summary.availableAyat,
      missingAyat: summary.missingAyat,
      totalBytes: summary.totalBytes,
      live,
      files: summary.files,
    })
  } catch (error) {
    console.error('[audio-sura] unexpected error', error)
    return NextResponse.json(
      { message: 'The sura audio inventory could not be loaded.' },
      { status: 500 },
    )
  }
}
