import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import { getSuraAudioFiles } from '@/server/audio/catalog'
import { getStyleDefinition, isKnownStyleId } from '@/data/audio-styles'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { getJuzPositions } from '@/data/juz-index'
import type { AudioBatchKind, AudioBatchPlanFile } from '@/types'

/**
 * GET /api/quran/audio/batch?styleId=...&kind=ayah|sura|range|juz|complete
 *   [&sura=N][&ayah=N][&from=N][&to=N][&juz=J]
 *
 * The verified download plan for one recitation-audio batch: the exact file
 * list (sura, ayah, sizeBytes) from the SEED-VERIFIED inventory, the exact
 * total byte size, and an honest report of every ayah in the requested
 * range the source does NOT have a verified file for (those are never
 * offered as downloadable, and a batch that misses any file is reported
 * with sourceComplete=false).
 *
 * `completePackageOfferable` is true only for kind=complete when the source
 * inventory covers all 6236 ayat - the UI may only offer the complete
 * package then (never when the source lacks files).
 */

export const dynamic = 'force-dynamic'

/** Total numbered ayat of the Quran (the complete package target). */
const TOTAL_QURAN_AYAT = 6236

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'quran-audio-batch', limit: 120, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const styleId = url.searchParams.get('styleId') ?? ''
  const kind = (url.searchParams.get('kind') ?? '') as AudioBatchKind
  const suraParam = Number(url.searchParams.get('sura'))
  const ayahParam = Number(url.searchParams.get('ayah'))
  const fromParam = Number(url.searchParams.get('from'))
  const toParam = Number(url.searchParams.get('to'))
  const juzParam = Number(url.searchParams.get('juz'))

  if (!isKnownStyleId(styleId)) {
    return NextResponse.json({ message: 'Unknown recitation style.' }, { status: 400 })
  }

  const style = getStyleDefinition(styleId)
  if (!style) {
    return NextResponse.json({ message: 'Unknown recitation style.' }, { status: 400 })
  }

  // Resolve the positions the batch covers (strict validation - a malformed
  // request never falls back to a guessed range).
  let positions: Array<{ sura: number; ayah: number }> = []
  let batchSura: number | null = null
  let ayahFrom: number | null = null
  let ayahTo: number | null = null
  let juz: number | null = null

  switch (kind) {
    case 'ayah': {
      if (
        getSuraAyahCount(suraParam) === 0 ||
        !Number.isInteger(ayahParam) ||
        ayahParam < 1 ||
        ayahParam > getSuraAyahCount(suraParam)
      ) {
        return NextResponse.json({ message: 'Invalid sura or ayah.' }, { status: 400 })
      }
      positions = [{ sura: suraParam, ayah: ayahParam }]
      batchSura = suraParam
      ayahFrom = ayahParam
      ayahTo = ayahParam
      break
    }
    case 'sura': {
      if (getSuraAyahCount(suraParam) === 0) {
        return NextResponse.json({ message: 'Invalid sura.' }, { status: 400 })
      }
      positions = Array.from({ length: getSuraAyahCount(suraParam) }, (_, i) => ({
        sura: suraParam,
        ayah: i + 1,
      }))
      batchSura = suraParam
      break
    }
    case 'range': {
      if (getSuraAyahCount(suraParam) === 0) {
        return NextResponse.json({ message: 'Invalid sura.' }, { status: 400 })
      }
      const suraLast = getSuraAyahCount(suraParam)
      if (
        !Number.isInteger(fromParam) ||
        !Number.isInteger(toParam) ||
        fromParam < 1 ||
        toParam < fromParam ||
        fromParam > suraLast
      ) {
        return NextResponse.json({ message: 'Invalid ayah range.' }, { status: 400 })
      }
      const to = Math.min(toParam, suraLast)
      positions = []
      for (let ayah = fromParam; ayah <= to; ayah += 1) positions.push({ sura: suraParam, ayah })
      batchSura = suraParam
      ayahFrom = fromParam
      ayahTo = to
      break
    }
    case 'juz': {
      const juzPositions = getJuzPositions(juzParam)
      if (juzPositions.length === 0) {
        return NextResponse.json({ message: 'Invalid juz number.' }, { status: 400 })
      }
      positions = juzPositions
      juz = juzParam
      break
    }
    case 'complete': {
      positions = []
      for (let sura = 1; sura <= 114; sura += 1) {
        for (let ayah = 1; ayah <= getSuraAyahCount(sura); ayah += 1) {
          positions.push({ sura, ayah })
        }
      }
      break
    }
    default:
      return NextResponse.json({ message: 'Invalid batch kind.' }, { status: 400 })
  }

  // Join the positions with the verified inventory, grouped per sura so the
  // seed is read once per sura (fast for the complete plan too).
  const files: AudioBatchPlanFile[] = []
  const missing: Array<{ sura: number; ayah: number }> = []

  const positionsBySura = new Map<number, number[]>()
  for (const position of positions) {
    const list = positionsBySura.get(position.sura)
    if (list) list.push(position.ayah)
    else positionsBySura.set(position.sura, [position.ayah])
  }

  for (const [sura, ayat] of positionsBySura) {
    const summary = getSuraAudioFiles(styleId, sura)
    if (!summary) {
      // No verified inventory at all for this sura: every ayah is missing.
      for (const ayah of ayat) missing.push({ sura, ayah })
      continue
    }
    for (const ayah of ayat) {
      const file = summary.files.find((entry) => entry.ayah === ayah)
      if (file) files.push({ sura, ayah, sizeBytes: file.sizeBytes })
      else missing.push({ sura, ayah })
    }
  }

  // Keep reading order (sura asc, ayah asc) regardless of map iteration.
  files.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)
  missing.sort((a, b) => a.sura - b.sura || a.ayah - b.ayah)

  const totalBytes = files.reduce((sum, file) => sum + file.sizeBytes, 0)

  return NextResponse.json({
    styleId,
    reciterName: style.reciterName,
    styleLabel: style.styleLabel,
    folder: style.folder,
    sourceName: style.sourceName,
    batchKind: kind,
    sura: batchSura,
    ayahFrom,
    ayahTo,
    juz,
    files,
    totalFiles: files.length,
    totalBytes,
    missing,
    sourceComplete: missing.length === 0,
    completePackageOfferable: kind === 'complete' && files.length === TOTAL_QURAN_AYAT,
  })
}
