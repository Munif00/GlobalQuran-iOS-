import { NextResponse } from 'next/server'

import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import { getAllStyleSummaries } from '@/server/audio/catalog'
import { verifyStyleLive } from '@/server/audio/everyayah'

/**
 * GET /api/quran/audio/reciters
 *
 * The verified recitation catalog. Every style entry carries:
 * - the reciter/style metadata (from verified sources only),
 * - the seed verification result (which files exist at the source, sizes),
 * - a LIVE reachability check result (one sample file per style),
 * - the final `available` verdict: a style is only presented as available
 *   when its file inventory is seed-verified AND the live sample confirms
 *   the source is serving the files right now. Anything else is reported
 *   honestly (unavailable / unknown) and the UI never offers such files as
 *   playable.
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'quran-audio-reciters', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  try {
    const liveResults = new Map<string, Awaited<ReturnType<typeof verifyStyleLive>>>()
    await Promise.all(
      ['husary-muallim', 'abdulbasit-murattal', 'abdulbasit-mujawwad', 'hudhaify', 'salah-budair'].map(
        async (styleId) => {
          liveResults.set(styleId, await verifyStyleLive(styleId))
        },
      ),
    )
    const styles = getAllStyleSummaries(liveResults)
    return NextResponse.json({ styles })
  } catch (error) {
    console.error('[audio-reciters] unexpected error', error)
    return NextResponse.json(
      { message: 'The recitation catalog could not be loaded.' },
      { status: 500 },
    )
  }
}
