import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import { getSuraAudioFiles } from '@/server/audio/catalog'
import { getSuraAyahCount } from '@/lib/audio/urls'
import { isKnownStyleId } from '@/data/audio-styles'

/**
 * GET  /api/quran/audio/file/[styleId]/[sura]/[ayah]
 * HEAD /api/quran/audio/file/[styleId]/[sura]/[ayah]
 *
 * Streams ONE verified recitation audio file (a single ayah, MP3) from
 * EveryAyah for offline downloading.
 *
 * Why a proxy: the download engines stream through the app's same-origin
 * routes on every platform (web dev/prod server AND the native adapter),
 * with one consistent byte-range contract for pause/resume. The URL is
 * built server-side from the VERIFIED seed inventory - never from user
 * input - so a file that the source does not have can never be requested
 * through this route (404 before any upstream call).
 *
 * - GET forwards a strict `bytes=N-` Range to the source and passes the
 *   200/206 status + Content-Length/Content-Range/Accept-Ranges through,
 *   so the download manager can pause and resume.
 * - HEAD answers from the verified seed listing: the exact byte size of
 *   the file (measured from the source's own listing at verification
 *   time) in Content-Length, with no upstream request.
 */

export const dynamic = 'force-dynamic'

const EVERYAYAH_HOST = 'everyayah.com'

function resolveVerifiedFile(
  styleId: string,
  sura: number,
  ayah: number,
): { url: string; sizeBytes: number; fileName: string } | null {
  const summary = getSuraAudioFiles(styleId, sura)
  if (!summary) return null
  const file = summary.files.find((entry) => entry.ayah === ayah)
  if (!file) return null
  return {
    url: file.url,
    sizeBytes: file.sizeBytes,
    fileName: `${String(sura).padStart(3, '0')}${String(ayah).padStart(3, '0')}.mp3`,
  }
}

function isVerifiedEveryAyahUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl)
    return (
      url.protocol === 'https:' &&
      (url.hostname === EVERYAYAH_HOST || url.hostname === `www.${EVERYAYAH_HOST}`) &&
      url.pathname.startsWith('/data/')
    )
  } catch {
    return false
  }
}

export async function GET(
  request: Request,
  context: { params: Promise<{ styleId: string; sura: string; ayah: string }> },
) {
  const rl = checkRateLimit(request, { name: 'quran-audio-file', limit: 1200, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { styleId, sura: suraRaw, ayah: ayahRaw } = await context.params
  const sura = Number(suraRaw)
  const ayah = Number(ayahRaw)

  if (!isKnownStyleId(styleId)) {
    return NextResponse.json({ message: 'Unknown recitation style.' }, { status: 400 })
  }
  if (getSuraAyahCount(sura) === 0 || !Number.isInteger(ayah) || ayah < 1 || ayah > getSuraAyahCount(sura)) {
    return NextResponse.json({ message: 'Invalid sura or ayah number.' }, { status: 400 })
  }

  const file = resolveVerifiedFile(styleId, sura, ayah)
  if (!file) {
    // The source has no verified file for this ayah - honest 404, never a
    // guessed URL.
    return NextResponse.json(
      { message: 'No verified audio file for this ayah at the source.' },
      { status: 404 },
    )
  }
  if (!isVerifiedEveryAyahUrl(file.url)) {
    return NextResponse.json({ message: 'Blocked audio URL.' }, { status: 400 })
  }

  // Range pass-through for pause/resume (strict single form only).
  const rangeHeader = request.headers.get('range')
  const safeRange =
    rangeHeader !== null && /^bytes=\d{0,15}-(\d{0,15})?$/.test(rangeHeader.trim())
      ? rangeHeader.trim()
      : null

  let upstream: Response
  try {
    upstream = await fetch(file.url, {
      credentials: 'omit',
      signal: AbortSignal.timeout(120_000),
      cache: 'no-store',
      headers: {
        Accept: 'audio/mpeg, */*',
        ...(safeRange ? { Range: safeRange } : {}),
      },
    })
  } catch (error) {
    console.error(
      '[audio-file] upstream failed',
      error instanceof Error ? error.message : error,
    )
    return NextResponse.json(
      { message: 'The audio file could not be fetched from the source.' },
      { status: 502 },
    )
  }

  if (!upstream.ok || !upstream.body) {
    return NextResponse.json(
      { message: 'The audio file could not be fetched from the source.' },
      { status: 502 },
    )
  }

  const headers = new Headers()
  headers.set('Content-Type', upstream.headers.get('content-type') ?? 'audio/mpeg')
  const contentLength = upstream.headers.get('content-length')
  if (contentLength) headers.set('Content-Length', contentLength)
  const contentRange = upstream.headers.get('content-range')
  if (contentRange) headers.set('Content-Range', contentRange)
  const acceptRanges = upstream.headers.get('accept-ranges')
  if (acceptRanges) headers.set('Accept-Ranges', acceptRanges)
  if (!safeRange) {
    headers.set('Content-Disposition', `attachment; filename="${file.fileName}"`)
  }
  headers.set('Cache-Control', 'no-store')

  return new Response(upstream.body, { status: upstream.status === 206 ? 206 : 200, headers })
}

export async function HEAD(
  request: Request,
  context: { params: Promise<{ styleId: string; sura: string; ayah: string }> },
) {
  const rl = checkRateLimit(request, { name: 'quran-audio-file-head', limit: 1200, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { styleId, sura: suraRaw, ayah: ayahRaw } = await context.params
  const sura = Number(suraRaw)
  const ayah = Number(ayahRaw)

  if (!isKnownStyleId(styleId) || getSuraAyahCount(sura) === 0 || ayah < 1 || ayah > getSuraAyahCount(sura)) {
    return new Response(null, { status: 400, headers: { 'cache-control': 'no-store' } })
  }

  const file = resolveVerifiedFile(styleId, sura, ayah)
  if (!file) {
    return new Response(null, { status: 404, headers: { 'cache-control': 'no-store' } })
  }

  // The seed listing carries the EXACT byte size - no upstream probe needed.
  return new Response(null, {
    status: 200,
    headers: {
      'content-length': String(file.sizeBytes),
      'content-type': 'audio/mpeg',
      'accept-ranges': 'bytes',
      'cache-control': 'no-store',
    },
  })
}
