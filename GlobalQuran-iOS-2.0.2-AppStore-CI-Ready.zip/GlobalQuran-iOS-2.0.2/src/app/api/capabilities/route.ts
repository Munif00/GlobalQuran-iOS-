import { NextResponse } from 'next/server'

import {
  INTERFACE_LANGUAGE_COUNT,
  RECITATION_STYLE_COUNT,
  type CapabilitySnapshotDto,
} from '@/data/capability-matrix'
import { hasTranslations } from '@/i18n'
import { SUPPORTED_LOCALES, FALLBACK_LOCALE } from '@/i18n/config'
import { getMergedTranslationsList, getIsoCodes } from '@/server/quranenc/client'
import { getTranslationAudioCatalog } from '@/server/audio/translation-audio'
import { getStyleSummary } from '@/server/audio/catalog'
import { RECITATION_STYLES } from '@/data/audio-styles'

/**
 * GET /api/capabilities
 *
 * The app's honest capability matrix (PROMPT 11 §4): the five language and
 * audio categories, each with its OWN count and source, never merged:
 *
 *  A. interface languages (the configured locale registry),
 *  B. Quran translation languages (live QuranEnc catalog),
 *  C. human-recorded translation narration (verified QuranEnc audio keys),
 *  D. device/browser TTS voices (runtime-only - this endpoint reports the
 *     category honestly as "detected on the device", never a count),
 *  E. Quran recitation (the verified EveryAyah inventory).
 *
 * B and C are best-effort live lookups: when upstream is unreachable the
 * category is reported as null (unavailable right now) rather than guessed.
 */

export const dynamic = 'force-dynamic'

/** How many sample entries per category (display only). */
const SAMPLE_LIMIT = 6

export async function GET() {
  const nowIso = new Date().toISOString()

  /* A. Interface languages - the configured registry, computed statically. */
  const untranslatedCodes = SUPPORTED_LOCALES.filter(
    (locale) => locale.code !== FALLBACK_LOCALE && !hasTranslations(locale.code),
  ).map((locale) => locale.code)

  /* B. Quran translation languages - live catalog (best-effort). */
  let translationLanguages: CapabilitySnapshotDto['translationLanguages'] = null
  try {
    const [{ translations }, isoCodes] = await Promise.all([
      getMergedTranslationsList('en'),
      getIsoCodes(),
    ])
    const languages = new Set<string>()
    const names: string[] = []
    for (const translation of translations) {
      const iso = translation.language_iso_code
      if (!languages.has(iso)) {
        languages.add(iso)
        names.push(isoCodes.codeToName[iso] ?? iso)
      }
    }
    translationLanguages = {
      datasetCount: translations.length,
      languageCount: languages.size,
      sampleLanguages: names.slice(0, SAMPLE_LIMIT),
      source: 'QuranEnc translation catalog',
      checkedAt: nowIso,
    }
  } catch {
    translationLanguages = null
  }

  /* C. Human-recorded translation narration - verified audio keys only. */
  let recordedTranslationAudio: CapabilitySnapshotDto['recordedTranslationAudio'] = null
  try {
    // Cross-reference with the text catalog (best-effort; honest empty list
    // when the catalogs cannot be joined - audio availability itself is
    // never inferred from the text catalog).
    let audioCatalog: Awaited<ReturnType<typeof getTranslationAudioCatalog>> = []
    try {
      const [{ translations }, isoCodes] = await Promise.all([
        getMergedTranslationsList('en'),
        getIsoCodes(),
      ])
      const byKey = new Map(translations.map((item) => [item.key, item]))
      audioCatalog = await getTranslationAudioCatalog((translationKey) => {
        const item = byKey.get(translationKey)
        if (!item) return null
        return {
          title: item.title ?? null,
          languageIso: item.language_iso_code ?? null,
          languageName: isoCodes.codeToName[item.language_iso_code] ?? null,
          direction: item.direction ?? null,
        }
      })
    } catch {
      audioCatalog = await getTranslationAudioCatalog()
    }
    const languageIsos = [
      ...new Set(
        audioCatalog
          .map((entry) => entry.languageIso)
          .filter((iso): iso is string => typeof iso === 'string'),
      ),
    ]
    recordedTranslationAudio = {
      translationCount: audioCatalog.length,
      languageIsos,
      sampleNames: audioCatalog.slice(0, SAMPLE_LIMIT).map((entry) => entry.audioName),
      source: 'QuranEnc audio dashboard (verified manifests)',
      checkedAt: nowIso,
    }
  } catch {
    recordedTranslationAudio = null
  }

  /* E. Quran recitation - the verified inventory (seed + definitions). */
  let completeStyles = 0
  for (const style of RECITATION_STYLES) {
    const summary = getStyleSummary(style.id, null)
    if (summary && summary.seedVerified && summary.totalAyat === 6236) completeStyles += 1
  }
  const recitation = {
    styleCount: RECITATION_STYLE_COUNT,
    ayatPerStyle: 6236,
    completeStyles,
    source: 'EveryAyah (verified inventory)',
    verifiedAt: nowIso,
  }

  const snapshot: CapabilitySnapshotDto = {
    interfaceLanguages: {
      count: INTERFACE_LANGUAGE_COUNT,
      completeCount: 1, // English is the complete fallback contract
      untranslatedCodes,
      source: 'App locale registry',
    },
    translationLanguages,
    recordedTranslationAudio,
    deviceTts: {
      runtimeOnly: true,
      note: 'Device and browser voices are detected on this device at runtime; the app never assumes a voice before it is detected.',
    },
    recitation,
    generatedAt: nowIso,
  }

  return NextResponse.json(snapshot)
}
