import { NextResponse } from 'next/server'
import { z } from 'zod'

import { db } from '@/lib/db'
import { getMergedTranslationsList, QuranEncUpstreamError, TRANSLATION_KEY_PATTERN } from '@/server/quranenc/client'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import type { VerificationStatus } from '@/types'

/**
 * Verification registry (administrator tool).
 *
 * GET    /api/translations/verification        -> all records
 * POST   /api/translations/verification        -> upsert one record
 * DELETE /api/translations/verification?key=..  -> remove one record
 *
 * Records attach documented institutional verification evidence to a
 * translation key. They are merged into the live catalog. The four statuses
 * are the app-wide verification states; `official_verified` must only be
 * set with real documentary evidence - this API cannot check that, which is
 * why the UI always shows the honesty note for administrators.
 *
 * SECURITY: all mutating requests (POST/DELETE) require the `x-admin-token`
 * header to match the ADMIN_TOKEN environment variable. When ADMIN_TOKEN is
 * not configured, writes are disabled entirely (503) - an unauthenticated
 * visitor can never mark a translation as officially verified.
 */

/** Reads the admin token without logging or echoing it. */
function isAdminAuthorized(request: Request): { ok: boolean; configured: boolean } {
  const expected = process.env.ADMIN_TOKEN
  if (!expected || expected.length < 8) return { ok: false, configured: false }
  const provided = request.headers.get('x-admin-token')
  // Constant-time-ish comparison to avoid trivial timing oracles.
  if (!provided || provided.length !== expected.length) return { ok: false, configured: true }
  let mismatch = 0
  for (let i = 0; i < expected.length; i += 1) {
    mismatch |= provided.charCodeAt(i) ^ expected.charCodeAt(i)
  }
  return { ok: mismatch === 0, configured: true }
}

export const dynamic = 'force-dynamic'

const VERIFICATION_STATUSES: VerificationStatus[] = [
  'official_verified',
  'awaiting_verification',
  'not_verified',
  'rejected',
]

const UpsertSchema = z.object({
  translationKey: z.string().regex(TRANSLATION_KEY_PATTERN),
  status: z.enum(['official_verified', 'awaiting_verification', 'not_verified', 'rejected']),
  reviewingAuthority: z.string().trim().max(300).nullish(),
  officialSource: z.string().trim().max(500).nullish(),
  documentReference: z.string().trim().max(500).nullish(),
  verifiedAt: z
    .string()
    .trim()
    .refine((value) => !value || !Number.isNaN(Date.parse(value)), 'Invalid date')
    .nullish(),
  reviewerNotes: z.string().trim().max(2000).nullish(),
})

function toIsoOrNull(value: Date | null): string | null {
  return value ? value.toISOString() : null
}

export async function GET() {
  try {
    const rows = await db.translationVerification.findMany({
      orderBy: { updatedAt: 'desc' },
    })
    return NextResponse.json({
      records: rows
        .filter((row) => (VERIFICATION_STATUSES as string[]).includes(row.status))
        .map((row) => ({
          translationKey: row.translationKey,
          status: row.status as VerificationStatus,
          reviewingAuthority: row.reviewingAuthority,
          officialSource: row.officialSource,
          documentReference: row.documentReference,
          verifiedAt: toIsoOrNull(row.verifiedAt),
          reviewerNotes: row.reviewerNotes,
          updatedAt: row.updatedAt.toISOString(),
        })),
    })
  } catch (error) {
    console.error('[verification] list failed', error)
    return NextResponse.json({ message: 'Verification records could not be loaded.' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const limit = checkRateLimit(request, { name: 'verification-write', limit: 30, windowMs: 60_000 })
  if (!limit.ok) return rateLimitResponse(limit)

  const auth = isAdminAuthorized(request)
  if (!auth.configured) {
    return NextResponse.json(
      {
        message:
          'Verification writes are disabled: no ADMIN_TOKEN is configured on the server. Set ADMIN_TOKEN (a secret of at least 8 characters) to enable administrator access.',
      },
      { status: 503 },
    )
  }
  if (!auth.ok) {
    return NextResponse.json({ message: 'Administrator token missing or invalid.' }, { status: 401 })
  }

  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({ message: 'Invalid request body.' }, { status: 400 })
  }

  const parsed = UpsertSchema.safeParse(payload)
  if (!parsed.success) {
    return NextResponse.json({ message: 'Invalid verification record.' }, { status: 400 })
  }
  const data = parsed.data

  // The translation key must exist in the real catalog - no records for
  // fictional translations can ever be created.
  try {
    const { translations } = await getMergedTranslationsList('en')
    if (!translations.some((item) => item.key === data.translationKey)) {
      return NextResponse.json(
        { message: 'This translation does not exist in the QuranEnc catalog.' },
        { status: 404 },
      )
    }
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return NextResponse.json(
        { message: 'The catalog is temporarily unreachable; please retry.' },
        { status: 502 },
      )
    }
    throw error
  }

  try {
    const row = await db.translationVerification.upsert({
      where: { translationKey: data.translationKey },
      create: {
        translationKey: data.translationKey,
        status: data.status,
        reviewingAuthority: data.reviewingAuthority ?? null,
        officialSource: data.officialSource ?? null,
        documentReference: data.documentReference ?? null,
        verifiedAt: data.verifiedAt ? new Date(data.verifiedAt) : null,
        reviewerNotes: data.reviewerNotes ?? null,
      },
      update: {
        status: data.status,
        reviewingAuthority: data.reviewingAuthority ?? null,
        officialSource: data.officialSource ?? null,
        documentReference: data.documentReference ?? null,
        verifiedAt: data.verifiedAt ? new Date(data.verifiedAt) : null,
        reviewerNotes: data.reviewerNotes ?? null,
      },
    })
    return NextResponse.json({
      record: {
        translationKey: row.translationKey,
        status: row.status as VerificationStatus,
        reviewingAuthority: row.reviewingAuthority,
        officialSource: row.officialSource,
        documentReference: row.documentReference,
        verifiedAt: toIsoOrNull(row.verifiedAt),
        reviewerNotes: row.reviewerNotes,
        updatedAt: row.updatedAt.toISOString(),
      },
    })
  } catch (error) {
    console.error('[verification] upsert failed', error)
    return NextResponse.json({ message: 'The record could not be saved.' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  const limit = checkRateLimit(request, { name: 'verification-write', limit: 30, windowMs: 60_000 })
  if (!limit.ok) return rateLimitResponse(limit)

  const auth = isAdminAuthorized(request)
  if (!auth.configured) {
    return NextResponse.json(
      { message: 'Verification writes are disabled: no ADMIN_TOKEN is configured on the server.' },
      { status: 503 },
    )
  }
  if (!auth.ok) {
    return NextResponse.json({ message: 'Administrator token missing or invalid.' }, { status: 401 })
  }

  const url = new URL(request.url)
  const key = url.searchParams.get('key') ?? ''

  if (!TRANSLATION_KEY_PATTERN.test(key)) {
    return NextResponse.json({ message: 'Invalid translation key.' }, { status: 400 })
  }

  try {
    await db.translationVerification.delete({ where: { translationKey: key } })
    return NextResponse.json({ removed: true })
  } catch {
    // Deleting a missing row is fine.
    return NextResponse.json({ removed: true })
  }
}
