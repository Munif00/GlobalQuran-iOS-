import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import { createHash } from 'node:crypto'

import { db } from '@/lib/db'
import {
  QURANENC_API_DOCS_URL,
  getIsoCodes,
  getMergedTranslationsList,
  QuranEncUpstreamError,
} from '@/server/quranenc/client'
import {
  buildLanguageSummary,
  EMPTY_VERIFICATION_OVERRIDES,
  mapTranslation,
  type VerificationOverrides,
} from '@/server/quranenc/mappers'
import type { VerificationStatus } from '@/types'

/**
 * GET /api/translations/catalog?localization=<locale>
 *
 * Live translation catalogue from the QuranEnc API v1:
 * - All records come from GET /translations/list (documented endpoint).
 * - Language names come from GET /translations/isocodes.
 * - Verification overrides from the administrator registry are merged in.
 * - Sync state (last checked / last synchronized, item + language counts,
 *   content hash for change detection) is persisted in the CatalogSync row
 *   and updated only when the upstream source is actually contacted.
 *
 * No records are ever fabricated; fields the source does not provide stay
 * null and the UI labels them "not provided by the source".
 */

export const dynamic = 'force-dynamic'

const VERIFICATION_STATUSES: VerificationStatus[] = [
  'official_verified',
  'awaiting_verification',
  'not_verified',
  'rejected',
]

function isVerificationStatus(value: string): value is VerificationStatus {
  return (VERIFICATION_STATUSES as string[]).includes(value)
}

async function loadVerificationOverrides(): Promise<VerificationOverrides> {
  try {
    const rows = await db.translationVerification.findMany()
    const byKey: VerificationOverrides['byKey'] = {}
    for (const row of rows) {
      if (!isVerificationStatus(row.status)) continue
      byKey[row.translationKey] = {
        status: row.status,
        reviewingAuthority: row.reviewingAuthority,
      }
    }
    return { byKey }
  } catch (error) {
    console.error('[catalog] failed to load verification overrides', error)
    return EMPTY_VERIFICATION_OVERRIDES
  }
}

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'translations-catalog', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const localization = url.searchParams.get('localization') ?? 'en'

  try {
    const [{ translations, servedFromCache }, isoCodes, overrides] = await Promise.all([
      getMergedTranslationsList(localization),
      getIsoCodes(),
      loadVerificationOverrides(),
    ])

    const now = new Date()
    const lastCheckedAt = now.toISOString()

    const items = translations.map((item) =>
      mapTranslation(item, isoCodes.codeToName, overrides, lastCheckedAt),
    )
    const languages = buildLanguageSummary(items, isoCodes.codeToName)

    // Content hash over identity + version fields for change detection.
    const hashInput = JSON.stringify(
      translations
        .map((item) => [item.key, item.version ?? '', item.last_update ?? 0])
        .sort((a, b) => String(a[0]).localeCompare(String(b[0]))),
    )
    const contentHash = createHash('sha256').update(hashInput).digest('hex')

    let lastSyncedAt: string | null = null
    try {
      const existing = await db.catalogSync.findUnique({ where: { id: 'singleton' } })

      if (!servedFromCache) {
        // The source was actually contacted: record the check. lastSyncedAt
        // advances only when the content actually changed.
        const changed = existing?.contentHash !== contentHash
        const row = await db.catalogSync.upsert({
          where: { id: 'singleton' },
          create: {
            id: 'singleton',
            lastCheckedAt: now,
            lastSyncedAt: now,
            itemCount: items.length,
            languageCount: languages.length,
            contentHash,
          },
          update: {
            lastCheckedAt: now,
            lastSyncedAt: changed ? now : (existing?.lastSyncedAt ?? now),
            itemCount: items.length,
            languageCount: languages.length,
            contentHash,
          },
        })
        lastSyncedAt = (row.lastSyncedAt ?? row.lastCheckedAt).toISOString()
      } else {
        lastSyncedAt = existing
          ? (existing.lastSyncedAt ?? existing.lastCheckedAt).toISOString()
          : lastCheckedAt
      }
    } catch (error) {
      console.error('[catalog] failed to update sync state', error)
      lastSyncedAt = lastCheckedAt
    }

    return NextResponse.json({
      status: 'live',
      source: 'QuranEnc API v1',
      sourceUrl: QURANENC_API_DOCS_URL,
      message: `${items.length} translations in ${languages.length} languages, synchronized from QuranEnc.`,
      items,
      languages,
      total: items.length,
      lastSyncedAt,
      lastCheckedAt,
      servedFromCache,
    })
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return NextResponse.json(
        {
          status: 'not_integrated',
          source: 'QuranEnc API v1',
          sourceUrl: QURANENC_API_DOCS_URL,
          message: 'The QuranEnc catalog is temporarily unreachable. Please try again shortly.',
          items: [],
          languages: [],
          total: 0,
          lastSyncedAt: null,
          lastCheckedAt: null,
          servedFromCache: false,
        },
        { status: 502 },
      )
    }
    console.error('[catalog] unexpected error', error)
    return NextResponse.json(
      {
        status: 'not_integrated',
        source: 'QuranEnc API v1',
        sourceUrl: QURANENC_API_DOCS_URL,
        message: 'The catalog could not be loaded. Please try again.',
        items: [],
        languages: [],
        total: 0,
        lastSyncedAt: null,
        lastCheckedAt: null,
        servedFromCache: false,
      },
      { status: 500 },
    )
  }
}
