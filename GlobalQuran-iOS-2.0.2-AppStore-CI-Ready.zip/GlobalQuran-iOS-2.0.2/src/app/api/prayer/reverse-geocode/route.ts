import { NextResponse } from 'next/server'

import { reverseGeocode } from '@/server/prayer'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

/**
 * GET /api/prayer/reverse-geocode?latitude=&longitude=
 *
 * Resolves coordinates to a city/region/country. Used after the user grants
 * location permission - the country result drives the documented method
 * default and the Malaysia authority flow. Returns "unavailable" (never a
 * guess) when both geocoding providers fail.
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'prayer-reverse-geocode', limit: 20, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const latitude = Number(url.searchParams.get('latitude'))
  const longitude = Number(url.searchParams.get('longitude'))
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
    return NextResponse.json(
      { status: 'unavailable', city: null, region: null, countryName: null, countryCode: null },
      { status: 400 },
    )
  }
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    return NextResponse.json(
      { status: 'unavailable', city: null, region: null, countryName: null, countryCode: null },
      { status: 400 },
    )
  }
  const outcome = await reverseGeocode(latitude, longitude)
  return NextResponse.json(outcome, { status: outcome.status === 'live' ? 200 : 503 })
}
