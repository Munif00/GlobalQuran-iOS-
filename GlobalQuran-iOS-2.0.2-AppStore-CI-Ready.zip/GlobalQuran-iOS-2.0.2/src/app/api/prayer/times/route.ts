import { NextResponse } from 'next/server'

import { parsePrayerQuery } from '@/server/prayer'
import { resolvePrayerDay } from '@/server/prayer'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

/**
 * GET /api/prayer/times
 *
 * Hybrid source resolution for one day:
 *   Priority 1 - verified official authority (JAKIM e-Solat, Malaysia).
 *   Priority 2 - AlAdhan API with the documented method for the country
 *                (or the user's manual choice).
 *   Priority 3 - validated local astronomical engine.
 *   Priority 4 - clearly-labeled cached data.
 *   Otherwise   - an honest "unavailable" explanation (never invented times).
 *
 * Query parameters:
 *   date=YYYY-MM-DD        (required)
 *   latitude, longitude    (required)
 *   timeZone               (optional IANA id; auto-detected when omitted)
 *   countryCode            (optional ISO alpha-2, drives the method default)
 *   methodMode=auto|manual (default auto)
 *   methodId               (when manual; a verified AlAdhan method id)
 *   madhhab=standard|hanafi
 *   highLatitudeRule=auto|middle_of_night|one_seventh|angle_based
 *   adjustments=fajr:5,sunrise:0,... (compact per-prayer minutes)
 *   jakimZone              (verified JAKIM zone code, Malaysia)
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'prayer-times', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const parsed = parsePrayerQuery(url.searchParams)
  if (!parsed.ok) {
    return NextResponse.json(
      {
        status: 'unavailable',
        message: null,
        messageKey: parsed.errorKey,
        record: null,
        source: null,
      },
      { status: 400 },
    )
  }

  const { date, ctx } = parsed.value
  if (!date) {
    return NextResponse.json(
      {
        status: 'unavailable',
        message: null,
        messageKey: 'prayer.error.badRequest',
        record: null,
        source: null,
      },
      { status: 400 },
    )
  }

  const response = await resolvePrayerDay(date, ctx)
  return NextResponse.json(response, { status: response.status === 'live' ? 200 : 503 })
}
