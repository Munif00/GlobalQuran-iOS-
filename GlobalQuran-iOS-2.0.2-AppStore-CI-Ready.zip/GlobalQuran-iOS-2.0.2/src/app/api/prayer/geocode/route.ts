import { NextResponse } from 'next/server'

import { searchCities } from '@/server/prayer'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

/**
 * GET /api/prayer/geocode?q={query}
 *
 * City search: curated bundled dataset (always available) merged with live
 * Nominatim geocoding (throttled per the OSM usage policy). Degraded status
 * means live geocoding was unavailable and only bundled results returned.
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'prayer-geocode', limit: 20, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const query = url.searchParams.get('q') ?? ''
  if (query.length > 100) {
    return NextResponse.json({ status: 'degraded', messageKey: 'prayer.search.degraded', results: [] })
  }
  const outcome = await searchCities(query)
  return NextResponse.json(outcome)
}
