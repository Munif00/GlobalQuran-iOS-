import { NextResponse } from 'next/server'

import { parsePrayerQuery } from '@/server/prayer'
import { resolvePrayerMonth } from '@/server/prayer'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

/**
 * GET /api/prayer/calendar?month=YYYY-MM&...
 *
 * A monthly timetable where EVERY date is calculated or retrieved
 * individually (JAKIM per-day official data / AlAdhan calendar endpoint /
 * local engine per-day computation) - never extrapolated from one day.
 *
 * Accepts the same parameters as /api/prayer/times, with `month=YYYY-MM`
 * instead of `date`.
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'prayer-calendar', limit: 30, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const url = new URL(request.url)
  const parsed = parsePrayerQuery(url.searchParams)
  if (!parsed.ok) {
    return NextResponse.json(
      {
        status: 'unavailable',
        message: null,
        messageKey: parsed.errorKey,
        month: url.searchParams.get('month') ?? '',
        days: [],
        source: null,
      },
      { status: 400 },
    )
  }

  const { month, ctx } = parsed.value
  if (!month) {
    return NextResponse.json(
      {
        status: 'unavailable',
        message: null,
        messageKey: 'prayer.error.badRequest',
        month: '',
        days: [],
        source: null,
      },
      { status: 400 },
    )
  }

  const response = await resolvePrayerMonth(month, ctx)
  return NextResponse.json(response, { status: response.status === 'live' ? 200 : 503 })
}
