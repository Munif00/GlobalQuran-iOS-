import { NextResponse } from 'next/server'

import { JAKIM_ZONES, OFFICIAL_AUTHORITY_REGISTRY, REGISTRY_SUMMARY } from '@/lib/prayer/authorities'

/**
 * GET /api/prayer/registry
 *
 * The structured registry of official prayer-time authorities: who they
 * are, what was verified, whether a public endpoint exists, and the honest
 * implementation status. No partnership or approval is implied anywhere.
 */

export const dynamic = 'force-dynamic'

export function GET() {
  return NextResponse.json({
    status: 'live',
    registry: OFFICIAL_AUTHORITY_REGISTRY,
    jakimZones: JAKIM_ZONES,
    summary: REGISTRY_SUMMARY,
  })
}
