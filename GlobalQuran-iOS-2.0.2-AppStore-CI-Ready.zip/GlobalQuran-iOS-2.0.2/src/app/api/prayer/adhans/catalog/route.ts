import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import {
  ADHAN_CATALOG,
  ADHAN_LICENSE_NOTE,
  ADHAN_SOURCE_PAGE,
  probeAdhanSize,
} from '@/server/audio/adhan-catalog'

/**
 * GET /api/prayer/adhans/catalog
 *
 * The verified muezzin recording catalog for Adhan reminders (PROMPT 13).
 * Returns the six hand-verified recordings with their exact byte sizes and
 * durations. A live HEAD probe of the source CDN is attempted for every
 * recording; when a probe succeeds its fresh size overrides the seed value,
 * and overall reachability is reported honestly (`sourceReachable`).
 */

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const rl = checkRateLimit(request, { name: 'adhan-catalog', limit: 120, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  let reachable = true
  const recordings = await Promise.all(
    ADHAN_CATALOG.map(async (entry) => {
      const liveSize = await probeAdhanSize(entry.url)
      if (liveSize === null) {
        reachable = false
        return entry
      }
      return { ...entry, sizeBytes: liveSize }
    }),
  )

  return NextResponse.json(
    {
      status: 'live',
      source: 'AlAdhan',
      sourceUrl: ADHAN_SOURCE_PAGE,
      licenseNote: ADHAN_LICENSE_NOTE,
      sourceReachable: reachable,
      recordings,
    },
    { headers: { 'cache-control': 'no-store' } },
  )
}
