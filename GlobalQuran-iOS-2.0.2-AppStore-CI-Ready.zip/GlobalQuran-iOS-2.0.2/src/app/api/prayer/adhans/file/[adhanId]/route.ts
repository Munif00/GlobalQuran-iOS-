import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'
import { getAdhanById, isVerifiedAdhanUrl } from '@/server/audio/adhan-catalog'

/**
 * GET  /api/prayer/adhans/file/[adhanId]
 * HEAD /api/prayer/adhans/file/[adhanId]
 *
 * Streams ONE verified Adhan recording (MP3) from the approved source for
 * offline downloading and preview playback.
 *
 * Why a proxy: the CDN serves no CORS headers, so browsers and the native
 * WebView cannot fetch it directly. All downloads therefore go through the
 * app's same-origin routes on every platform, with a consistent byte-range
 * contract. The URL is resolved server-side from the VERIFIED catalog - a
 * recording that does not exist there can never be requested through this
 * route (404 before any upstream call).
 *
 * - GET forwards a strict `bytes=N-` Range to the source and passes the
 *   200/206 status and Content-Length/Content-Range/Accept-Ranges through,
 *   so the download manager can show progress and verify integrity.
 * - HEAD answers from the verified catalog without an upstream request.
 */

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  context: { params: Promise<{ adhanId: string }> },
) {
  const rl = checkRateLimit(request, { name: 'adhan-file', limit: 300, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { adhanId } = await context.params
  const entry = getAdhanById(adhanId)
  if (!entry) {
    return NextResponse.json(
      { message: 'No verified Adhan recording with this id.' },
      { status: 404 },
    )
  }
  if (!isVerifiedAdhanUrl(entry.url)) {
    return NextResponse.json({ message: 'Blocked audio URL.' }, { status: 400 })
  }

  // Range pass-through (strict single form only).
  const rangeHeader = request.headers.get('range')
  const safeRange =
    rangeHeader !== null && /^bytes=\d{0,15}-(\d{0,15})?$/.test(rangeHeader.trim())
      ? rangeHeader.trim()
      : null

  let upstream: Response
  try {
    upstream = await fetch(entry.url, {
      credentials: 'omit',
      signal: AbortSignal.timeout(180_000),
      cache: 'no-store',
      headers: {
        Accept: 'audio/mpeg, */*',
        ...(safeRange ? { Range: safeRange } : {}),
      },
    })
  } catch (error) {
    console.error(
      '[adhan-file] upstream failed',
      error instanceof Error ? error.message : error,
    )
    return NextResponse.json(
      { message: 'The Adhan audio file could not be fetched from the source.' },
      { status: 502 },
    )
  }

  if (!upstream.ok || !upstream.body) {
    return NextResponse.json(
      { message: 'The Adhan audio file could not be fetched from the source.' },
      { status: 502 },
    )
  }

  const headers = new Headers()
  headers.set('Content-Type', upstream.headers.get('content-type') ?? 'audio/mpeg')
  const contentLength = upstream.headers.get('content-length')
  if (contentLength) headers.set('Content-Length', contentLength)
  const contentRange = upstream.headers.get('content-range')
  if (contentRange) headers.set('Content-Range', contentRange)
  const acceptRanges = upstream.headers.get('accept-ranges')
  if (acceptRanges) headers.set('Accept-Ranges', acceptRanges)
  if (!safeRange) {
    headers.set('Content-Disposition', `attachment; filename="${entry.fileName}"`)
  }
  headers.set('Cache-Control', 'no-store')

  return new Response(upstream.body, { status: upstream.status === 206 ? 206 : 200, headers })
}

export async function HEAD(
  request: Request,
  context: { params: Promise<{ adhanId: string }> },
) {
  const rl = checkRateLimit(request, { name: 'adhan-file-head', limit: 300, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { adhanId } = await context.params
  const entry = getAdhanById(adhanId)
  if (!entry) {
    return new Response(null, { status: 404, headers: { 'cache-control': 'no-store' } })
  }

  // The verified catalog carries the EXACT byte size - no upstream probe.
  return new Response(null, {
    status: 200,
    headers: {
      'content-length': String(entry.sizeBytes),
      'content-type': 'audio/mpeg',
      'accept-ranges': 'bytes',
      'cache-control': 'no-store',
    },
  })
}
