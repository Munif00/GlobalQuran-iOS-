import { NextResponse } from 'next/server'

import { countryDefaultsForApi } from '@/lib/prayer/country-methods'
import { METHODS_VERIFIED_AT, METHODS_VERIFIED_FROM, PRAYER_METHODS } from '@/lib/prayer/methods'

/**
 * GET /api/prayer/meta
 *
 * The verified calculation-method registry (live-checked against
 * GET https://api.aladhan.com/v1/methods on the date below) plus the
 * documented country defaults. The UI uses this to distinguish official
 * national settings from recommended defaults.
 */

export const dynamic = 'force-dynamic'

export function GET() {
  return NextResponse.json({
    status: 'live',
    methods: PRAYER_METHODS.map((method) => ({
      id: method.id,
      numericId: method.numericId,
      name: method.name,
      paramsSummary: method.paramsSummary,
      experimental: method.experimental,
      localEngineSupported: method.localEngineSupported,
    })),
    countryDefaults: countryDefaultsForApi(),
    verifiedAt: METHODS_VERIFIED_AT,
    verifiedFrom: METHODS_VERIFIED_FROM,
  })
}
