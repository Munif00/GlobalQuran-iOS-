import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitResponse } from '@/server/rate-limit'

import {
  getMergedTranslationsList,
  QuranEncUpstreamError,
  TRANSLATION_KEY_PATTERN,
} from '@/server/quranenc/client'

/**
 * GET  /api/downloads/[translationKey]/[fileId]
 * HEAD /api/downloads/[translationKey]/[fileId]
 *
 * Streams one download file (SQLite database, PDF, EPUB) for a translation
 * from the QuranEnc catalog.
 *
 * Why a proxy: the QuranEnc API endpoints send `Access-Control-Allow-Origin: *`
 * (documented in the API description), but the file-download host does not
 * send CORS headers, so the browser cannot fetch those files directly. This
 * route relays the exact file the catalog publishes.
 *
 * Security - this is NOT an open proxy:
 * - `translationKey` must match the source key pattern and exist in the
 *   live catalog.
 * - `fileId` must be one of the fixed catalog file ids; the URL is taken
 *   from the catalog data, never from the request.
 * - The upstream URL must be HTTPS on the quranenc.com host.
 * - The response is streamed through, never cached or modified.
 *
 * HEAD resolves the same catalog file and asks the source for its size only
 * (HEAD, with a 1-byte Range fallback for servers that omit Content-Length
 * on HEAD). The exact byte count is returned in Content-Length so the UI can
 * display the real download size for every published file - including the
 * formats whose size the source does not publish in the catalog.
 */

export const dynamic = 'force-dynamic'

/** Hosts allowed for upstream file downloads. */
const ALLOWED_DOWNLOAD_HOSTS = new Set(['quranenc.com', 'www.quranenc.com'])

function isAllowedDownloadUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl)
    return url.protocol === 'https:' && ALLOWED_DOWNLOAD_HOSTS.has(url.hostname)
  } catch {
    return false
  }
}

function fileNameFromUrl(rawUrl: string): string {
  try {
    const url = new URL(rawUrl)
    const segments = url.pathname.split('/').filter(Boolean)
    return segments.length > 0 ? segments[segments.length - 1] : 'download'
  } catch {
    return 'download'
  }
}

/** Extract the total size from a `content-range: bytes 0-0/12345` header. */
function totalFromContentRange(header: string | null): number | null {
  if (!header) return null
  const match = /\/\s*(\d+)\s*$/.exec(header.trim())
  if (!match) return null
  const total = Number(match[1])
  return Number.isSafeInteger(total) && total >= 0 ? total : null
}

/**
 * Resolve the upstream file URL for a catalog translation + file id.
 * Returns null (with the response already built) on any validation failure.
 */
async function resolveCatalogFileUrl(
  translationKey: string,
  fileId: string,
): Promise<{ fileUrl: string } | { error: Response }> {
  try {
    const { translations } = await getMergedTranslationsList('en')
    const item = translations.find((entry) => entry.key === translationKey)
    if (!item) {
      return { error: NextResponse.json({ message: 'Translation not found.' }, { status: 404 }) }
    }

    const files: Record<string, string | null | undefined> = {
      'sql-database': item.database_url,
      'sql-database-uncompressed': item.database_uncompressed_url,
      'pdf-standard': item.pdf_url,
      'pdf-pure': item.pdf_pure_url,
      'pdf-mobile': item.pdf_mobile_url,
      epub: item.epub_url,
    }

    const candidate = files[fileId]
    if (typeof candidate !== 'string' || !candidate.startsWith('https://')) {
      return {
        error: NextResponse.json({ message: 'File not available for this translation.' }, { status: 404 }),
      }
    }
    return { fileUrl: candidate }
  } catch (error) {
    if (error instanceof QuranEncUpstreamError) {
      return {
        error: NextResponse.json({ message: 'Catalog temporarily unreachable.' }, { status: 502 }),
      }
    }
    throw error
  }
}

export async function GET(
  request: Request,
  context: { params: Promise<{ translationKey: string; fileId: string }> },
) {
  const rl = checkRateLimit(request, { name: 'downloads-proxy', limit: 30, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { translationKey, fileId } = await context.params

  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return NextResponse.json({ message: 'Invalid translation key.' }, { status: 400 })
  }

  // Forward byte-range requests so the download manager can pause and
  // resume downloads (the upstream host supports ranges; verified 206).
  // Only a single strict "bytes=N-" / "bytes=N-M" form is accepted.
  const rangeHeader = request.headers.get('range')
  const safeRange = rangeHeader !== null && /^bytes=\d{0,15}-(\d{0,15})?$/.test(rangeHeader.trim())
    ? rangeHeader.trim()
    : null

  const resolved = await resolveCatalogFileUrl(translationKey, fileId)
  if ('error' in resolved) return resolved.error
  const fileUrl = resolved.fileUrl

  if (!isAllowedDownloadUrl(fileUrl)) {
    return NextResponse.json({ message: 'Blocked download URL.' }, { status: 400 })
  }

  let upstream: Response
  try {
    upstream = await fetch(fileUrl, {
      credentials: 'omit',
      signal: AbortSignal.timeout(120_000),
      cache: 'no-store',
      // Range pass-through for pause/resume (validated shape above).
      ...(safeRange ? { headers: { Range: safeRange } } : {}),
    })
  } catch (error) {
    console.error(
      '[download-proxy] upstream failed',
      error instanceof Error ? error.message : error,
    )
    return NextResponse.json({ message: 'The file could not be fetched from the source.' }, { status: 502 })
  }

  if (!upstream.ok || !upstream.body) {
    return NextResponse.json({ message: 'The file could not be fetched from the source.' }, { status: 502 })
  }

  const headers = new Headers()
  headers.set('Content-Type', upstream.headers.get('content-type') ?? 'application/octet-stream')
  const contentLength = upstream.headers.get('content-length')
  if (contentLength) headers.set('Content-Length', contentLength)
  const contentRange = upstream.headers.get('content-range')
  if (contentRange) headers.set('Content-Range', contentRange)
  const acceptRanges = upstream.headers.get('accept-ranges')
  if (acceptRanges) headers.set('Accept-Ranges', acceptRanges)
  // Surface the actual upstream status (200 or 206) so the manager can tell
  // whether the server honored the range request.
  const status = upstream.status === 206 ? 206 : 200
  if (!safeRange) {
    headers.set('Content-Disposition', `attachment; filename="${fileNameFromUrl(fileUrl)}"`)
  }
  headers.set('Cache-Control', 'no-store')

  return new Response(upstream.body, { status, headers })
}

/**
 * HEAD - the exact size of one published file, before it is downloaded.
 *
 * The source does not publish sizes for every format in the catalog (the
 * SQLite databases have no size field, for example), so this handler asks
 * the file host directly:
 * 1. a plain HEAD request - answered with Content-Length by the host;
 * 2. if the host omits Content-Length on HEAD, a 1-byte Range GET whose
 *    `content-range` header carries the total size.
 *
 * The resolved byte count is returned as this route's own Content-Length (a
 * HEAD response has no body by definition), so the UI can display the real
 * download size for every available format. The number is measured from the
 * actual file - never estimated.
 */
export async function HEAD(
  request: Request,
  context: { params: Promise<{ translationKey: string; fileId: string }> },
) {
  const rl = checkRateLimit(request, { name: 'downloads-probe', limit: 60, windowMs: 60000 })
  if (!rl.ok) return rateLimitResponse(rl)

  const { translationKey, fileId } = await context.params

  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    return new Response(null, { status: 400, headers: { 'cache-control': 'no-store' } })
  }

  const resolved = await resolveCatalogFileUrl(translationKey, fileId)
  if ('error' in resolved) {
    return new Response(null, { status: resolved.error.status, headers: { 'cache-control': 'no-store' } })
  }
  const fileUrl = resolved.fileUrl

  if (!isAllowedDownloadUrl(fileUrl)) {
    return new Response(null, { status: 400, headers: { 'cache-control': 'no-store' } })
  }

  let size: number | null = null

  // 1. Plain HEAD against the file host.
  try {
    const head = await fetch(fileUrl, {
      method: 'HEAD',
      credentials: 'omit',
      signal: AbortSignal.timeout(15_000),
      cache: 'no-store',
    })
    if (head.ok) {
      const length = Number(head.headers.get('content-length'))
      if (Number.isSafeInteger(length) && length >= 0) size = length
    }
  } catch {
    // Fall through to the range probe.
  }

  // 2. Range fallback: servers that omit Content-Length on HEAD usually
  //    answer a 1-byte range request with a content-range total.
  if (size === null) {
    try {
      const ranged = await fetch(fileUrl, {
        method: 'GET',
        credentials: 'omit',
        signal: AbortSignal.timeout(15_000),
        cache: 'no-store',
        headers: { Range: 'bytes=0-0' },
      })
      if (ranged.ok || ranged.status === 206) {
        // Consume/discard the single byte so the socket is released.
        await ranged.arrayBuffer().catch(() => undefined)
        size = totalFromContentRange(ranged.headers.get('content-range'))
        if (size === null) {
          const length = Number(ranged.headers.get('content-length'))
          if (ranged.status === 200 && Number.isSafeInteger(length) && length >= 0) {
            // Full-body answer (range ignored): the length is still exact.
            size = length
          }
        }
      }
    } catch {
      // Both probes failed - report no size (the UI falls back honestly).
    }
  }

  if (size === null) {
    return new Response(null, {
      status: 503,
      headers: { 'cache-control': 'no-store', 'x-size-resolved': 'false' },
    })
  }

  return new Response(null, {
    status: 200,
    headers: {
      'content-length': String(size),
      'x-size-resolved': 'true',
      'cache-control': 'no-store',
    },
  })
}
