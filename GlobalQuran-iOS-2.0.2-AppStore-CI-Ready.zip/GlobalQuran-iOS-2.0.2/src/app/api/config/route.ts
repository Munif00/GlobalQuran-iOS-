import { NextResponse } from 'next/server'

import { buildAppConfigPayload } from '@/lib/app-config-payload'

/**
 * GET /api/config
 * Application configuration exposed to the client: version, supported
 * languages, and the honest integration status of every external service.
 *
 * The payload builder is shared with the native app adapter so both
 * platforms report identical configuration.
 */

export const dynamic = 'force-dynamic'

export function GET() {
  return NextResponse.json(buildAppConfigPayload())
}
