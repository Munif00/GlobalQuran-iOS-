import { AppShell } from "@/components/app/app-shell";

/**
 * Global Quran - the single user-facing page (`/`).
 * All six sections (Home, Quran & Translations, Downloads, Prayer Times,
 * Qibla, Settings) render inside the AppShell with client-side navigation.
 */
export default function Page() {
  return <AppShell />;
}
