import type { Metadata, Viewport } from "next";

import "./globals.css";

import { Providers } from "@/components/app/providers";
import { AppleSplashScreens } from "@/components/app/apple-splash-screens";

/**
 * Global Quran - root layout.
 *
 * - Fonts load from Google Fonts at runtime (graceful fallback to system
 *   stacks if unreachable); Inter for Latin scripts, Noto Naskh Arabic for
 *   Arabic-script interfaces, Noto Nastaliq Urdu for Urdu, and Amiri for
 *   Quranic display text.
 * - The html element starts LTR/English and is updated client-side by the
 *   i18n bootstrap when the user language resolves.
 */

export const metadata: Metadata = {
  title: "Global Quran — القرآن الكريم وترجمات معانيه",
  description:
    "A trustworthy international application for the Holy Quran, worldwide translations, prayer times, and the Qibla direction.",
  applicationName: "Global Quran",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  appleWebApp: {
    capable: true,
    // "black-translucent" + viewport-fit=cover (see `viewport` below) give
    // the installed iOS app a native full-bleed status bar: the page renders
    // underneath the clock/notch and the app header pads itself with
    // env(safe-area-inset-top) - exactly how a native app behaves.
    statusBarStyle: "black-translucent",
    title: "Global Quran",
  },
  formatDetection: {
    telephone: false,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#faf8f3" },
    { media: "(prefers-color-scheme: dark)", color: "#171d1a" },
  ],
};

const FONTS_HREF =
  "https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Inter:wght@400;500;600;700&family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Noto+Nastaliq+Urdu:wght@400;600&display=swap";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <body className="bg-background text-foreground antialiased">
        {/* React 19 hoists these into <head> */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href={FONTS_HREF} precedence="default" />
        {/* iOS launch screens (React hoists these into <head>) */}
        <AppleSplashScreens />
        {/* Classic iOS standalone marker (Next.js only emits the modern
         * "mobile-web-app-capable" name; older iOS versions look for this
         * one, and it does not conflict with the manifest). */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
