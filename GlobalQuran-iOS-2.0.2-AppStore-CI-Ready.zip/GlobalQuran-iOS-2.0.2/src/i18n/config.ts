/**
 * Global Quran - i18n configuration
 *
 * Registry of all supported interface languages (exactly 80 distinct locale
 * codes), device-language detection with sensible fallbacks, and direction
 * handling.
 *
 * Translation completeness is tracked per language in the locale resources
 * themselves (see src/i18n/index.ts). English is the fallback locale and no
 * language is ever presented as fully translated when it is not.
 */

export type Direction = 'ltr' | 'rtl'

export interface LocaleDefinition {
  /** Canonical code used across the app (BCP 47, e.g. `zh-Hans`, `fil`, `nb`). */
  code: string
  /** Language name in English. */
  englishName: string
  /** Language name in its own script - always shown in native form. */
  nativeName: string
  direction: Direction
}

/** Locale codes rendered right-to-left. */
export const RTL_LOCALES: readonly string[] = ['ar', 'fa', 'ur', 'ps', 'ku', 'ug']

export const FALLBACK_LOCALE = 'en'

/**
 * The 80 supported interface languages (exactly 80 distinct codes, unique
 * by code - duplicates are never counted).
 */
export const SUPPORTED_LOCALES: readonly LocaleDefinition[] = [
  { code: 'ar', englishName: 'Arabic', nativeName: 'العربية', direction: 'rtl' },
  { code: 'en', englishName: 'English', nativeName: 'English', direction: 'ltr' },
  { code: 'fr', englishName: 'French', nativeName: 'Français', direction: 'ltr' },
  { code: 'es', englishName: 'Spanish', nativeName: 'Español', direction: 'ltr' },
  { code: 'pt', englishName: 'Portuguese', nativeName: 'Português', direction: 'ltr' },
  { code: 'de', englishName: 'German', nativeName: 'Deutsch', direction: 'ltr' },
  { code: 'it', englishName: 'Italian', nativeName: 'Italiano', direction: 'ltr' },
  { code: 'nl', englishName: 'Dutch', nativeName: 'Nederlands', direction: 'ltr' },
  { code: 'ru', englishName: 'Russian', nativeName: 'Русский', direction: 'ltr' },
  { code: 'uk', englishName: 'Ukrainian', nativeName: 'Українська', direction: 'ltr' },
  { code: 'tr', englishName: 'Turkish', nativeName: 'Türkçe', direction: 'ltr' },
  { code: 'fa', englishName: 'Persian', nativeName: 'فارسی', direction: 'rtl' },
  { code: 'ur', englishName: 'Urdu', nativeName: 'اردو', direction: 'rtl' },
  { code: 'bn', englishName: 'Bengali', nativeName: 'বাংলা', direction: 'ltr' },
  { code: 'id', englishName: 'Indonesian', nativeName: 'Bahasa Indonesia', direction: 'ltr' },
  { code: 'ms', englishName: 'Malay', nativeName: 'Bahasa Melayu', direction: 'ltr' },
  { code: 'hi', englishName: 'Hindi', nativeName: 'हिन्दी', direction: 'ltr' },
  { code: 'ta', englishName: 'Tamil', nativeName: 'தமிழ்', direction: 'ltr' },
  { code: 'te', englishName: 'Telugu', nativeName: 'తెలుగు', direction: 'ltr' },
  { code: 'ml', englishName: 'Malayalam', nativeName: 'മലയാളം', direction: 'ltr' },
  { code: 'kn', englishName: 'Kannada', nativeName: 'ಕನ್ನಡ', direction: 'ltr' },
  { code: 'mr', englishName: 'Marathi', nativeName: 'मराठी', direction: 'ltr' },
  { code: 'gu', englishName: 'Gujarati', nativeName: 'ગુજરાતી', direction: 'ltr' },
  { code: 'pa', englishName: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', direction: 'ltr' },
  { code: 'zh-Hans', englishName: 'Chinese (Simplified)', nativeName: '简体中文', direction: 'ltr' },
  { code: 'zh-Hant', englishName: 'Chinese (Traditional)', nativeName: '繁體中文', direction: 'ltr' },
  { code: 'ja', englishName: 'Japanese', nativeName: '日本語', direction: 'ltr' },
  { code: 'ko', englishName: 'Korean', nativeName: '한국어', direction: 'ltr' },
  { code: 'th', englishName: 'Thai', nativeName: 'ไทย', direction: 'ltr' },
  { code: 'vi', englishName: 'Vietnamese', nativeName: 'Tiếng Việt', direction: 'ltr' },
  { code: 'fil', englishName: 'Filipino', nativeName: 'Filipino', direction: 'ltr' },
  { code: 'sw', englishName: 'Swahili', nativeName: 'Kiswahili', direction: 'ltr' },
  { code: 'ha', englishName: 'Hausa', nativeName: 'Hausa', direction: 'ltr' },
  { code: 'so', englishName: 'Somali', nativeName: 'Soomaali', direction: 'ltr' },
  { code: 'am', englishName: 'Amharic', nativeName: 'አማርኛ', direction: 'ltr' },
  { code: 'yo', englishName: 'Yoruba', nativeName: 'Yorùbá', direction: 'ltr' },
  { code: 'ku', englishName: 'Kurdish', nativeName: 'کوردی', direction: 'rtl' },
  { code: 'ps', englishName: 'Pashto', nativeName: 'پښتو', direction: 'rtl' },
  { code: 'kk', englishName: 'Kazakh', nativeName: 'Қазақша', direction: 'ltr' },
  { code: 'uz', englishName: 'Uzbek', nativeName: 'Oʻzbekcha', direction: 'ltr' },
  { code: 'az', englishName: 'Azerbaijani', nativeName: 'Azərbaycanca', direction: 'ltr' },
  { code: 'sq', englishName: 'Albanian', nativeName: 'Shqip', direction: 'ltr' },
  { code: 'bs', englishName: 'Bosnian', nativeName: 'Bosanski', direction: 'ltr' },
  { code: 'sr', englishName: 'Serbian', nativeName: 'Српски', direction: 'ltr' },
  { code: 'hr', englishName: 'Croatian', nativeName: 'Hrvatski', direction: 'ltr' },
  { code: 'ro', englishName: 'Romanian', nativeName: 'Română', direction: 'ltr' },
  { code: 'pl', englishName: 'Polish', nativeName: 'Polski', direction: 'ltr' },
  { code: 'sv', englishName: 'Swedish', nativeName: 'Svenska', direction: 'ltr' },
  { code: 'da', englishName: 'Danish', nativeName: 'Dansk', direction: 'ltr' },
  { code: 'nb', englishName: 'Norwegian Bokmål', nativeName: 'Norsk bokmål', direction: 'ltr' },
  { code: 'si', englishName: 'Sinhala', nativeName: 'සිංහල', direction: 'ltr' },
  { code: 'fi', englishName: 'Finnish', nativeName: 'suomi', direction: 'ltr' },
  { code: 'el', englishName: 'Greek', nativeName: 'Ελληνικά', direction: 'ltr' },
  { code: 'hu', englishName: 'Hungarian', nativeName: 'magyar', direction: 'ltr' },
  { code: 'cs', englishName: 'Czech', nativeName: 'čeština', direction: 'ltr' },
  { code: 'sk', englishName: 'Slovak', nativeName: 'slovenčina', direction: 'ltr' },
  { code: 'bg', englishName: 'Bulgarian', nativeName: 'български', direction: 'ltr' },
  { code: 'et', englishName: 'Estonian', nativeName: 'eesti', direction: 'ltr' },
  { code: 'lv', englishName: 'Latvian', nativeName: 'latviešu', direction: 'ltr' },
  { code: 'lt', englishName: 'Lithuanian', nativeName: 'lietuvių', direction: 'ltr' },
  { code: 'sl', englishName: 'Slovenian', nativeName: 'slovenščina', direction: 'ltr' },
  { code: 'ca', englishName: 'Catalan', nativeName: 'català', direction: 'ltr' },
  { code: 'af', englishName: 'Afrikaans', nativeName: 'Afrikaans', direction: 'ltr' },
  { code: 'jv', englishName: 'Javanese', nativeName: 'Basa Jawa', direction: 'ltr' },
  { code: 'su', englishName: 'Sundanese', nativeName: 'Basa Sunda', direction: 'ltr' },
  { code: 'ceb', englishName: 'Cebuano', nativeName: 'Cebuano', direction: 'ltr' },
  { code: 'km', englishName: 'Khmer', nativeName: 'ខ្មែរ', direction: 'ltr' },
  { code: 'lo', englishName: 'Lao', nativeName: 'ລາວ', direction: 'ltr' },
  { code: 'my', englishName: 'Burmese', nativeName: 'မြန်မာ', direction: 'ltr' },
  { code: 'ne', englishName: 'Nepali', nativeName: 'नेपाली', direction: 'ltr' },
  { code: 'ky', englishName: 'Kyrgyz', nativeName: 'Кыргызча', direction: 'ltr' },
  { code: 'tg', englishName: 'Tajik', nativeName: 'Тоҷикӣ', direction: 'ltr' },
  { code: 'ug', englishName: 'Uyghur', nativeName: 'ئۇيغۇرچە', direction: 'rtl' },
  { code: 'tk', englishName: 'Turkmen', nativeName: 'Türkmen', direction: 'ltr' },
  { code: 'tt', englishName: 'Tatar', nativeName: 'Татарча', direction: 'ltr' },
  { code: 'be', englishName: 'Belarusian', nativeName: 'Беларуская', direction: 'ltr' },
  { code: 'zu', englishName: 'Zulu', nativeName: 'isiZulu', direction: 'ltr' },
  { code: 'sn', englishName: 'Shona', nativeName: 'chiShona', direction: 'ltr' },
  { code: 'ny', englishName: 'Chichewa', nativeName: 'Chichewa', direction: 'ltr' },
  { code: 'mg', englishName: 'Malagasy', nativeName: 'Malagasy', direction: 'ltr' },
] as const

const LOCALE_LOOKUP: ReadonlyMap<string, LocaleDefinition> = new Map(
  SUPPORTED_LOCALES.map((locale) => [locale.code.toLowerCase(), locale]),
)

/** Regions that use Traditional Chinese. */
const ZH_HANT_REGIONS = new Set(['tw', 'hk', 'mo'])
/** Regions that use Simplified Chinese. */
const ZH_HANS_REGIONS = new Set(['cn', 'sg', 'my'])

export function getLocaleDefinition(code: string): LocaleDefinition {
  return (
    LOCALE_LOOKUP.get(code.toLowerCase()) ?? {
      code: FALLBACK_LOCALE,
      englishName: 'English',
      nativeName: 'English',
      direction: 'ltr',
    }
  )
}

export function isRTL(code: string): boolean {
  return RTL_LOCALES.includes(code)
}

export function getDirection(code: string): Direction {
  return isRTL(code) ? 'rtl' : 'ltr'
}

/**
 * Match a single BCP 47 language tag (e.g. `fr-CA`, `zh-TW`, `pt-BR`)
 * against the supported locales.
 *
 * Matching order:
 *  1. Special Chinese rules (`zh-TW` -> `zh-Hant`, `zh-CN` -> `zh-Hans`).
 *  2. Special aliases: `tl` -> `fil`, `no` -> `nb`.
 *  3. Exact case-insensitive match (`FR` -> `fr`, `zh-hans` -> `zh-Hans`).
 *  4. Base-language match (`fr-CA` -> `fr`, `pt-BR` -> `pt`).
 *  5. Script-less match (`sr-Cyrl-RS` -> `sr`).
 */
export function matchLocaleTag(tag: string): string | null {
  if (!tag) return null
  const normalized = tag.trim().toLowerCase().replace(/_/g, '-')
  if (!normalized) return null

  const parts = normalized.split('-')
  const base = parts[0]
  const region = parts.length > 1 ? parts[parts.length - 1] : ''
  const hasScript = parts.length > 2 || (parts.length === 2 && parts[1].length === 4)

  // Chinese: script subtag wins, otherwise region conventions.
  if (base === 'zh') {
    if (normalized.includes('hant')) return 'zh-Hant'
    if (normalized.includes('hans')) return 'zh-Hans'
    if (ZH_HANT_REGIONS.has(region)) return 'zh-Hant'
    if (ZH_HANS_REGIONS.has(region) || region === '') return 'zh-Hans'
    return 'zh-Hans'
  }

  // Common aliases.
  if (base === 'tl') return 'fil'
  if (base === 'no') return 'nb'

  // Exact match (case-insensitive).
  const exact = LOCALE_LOOKUP.get(normalized)
  if (exact) return exact.code

  // Base language match (e.g. fr-CA -> fr, pt-BR -> pt).
  const byBase = LOCALE_LOOKUP.get(base)
  if (byBase) return byBase.code

  // Strip script subtag and retry (e.g. sr-Cyrl-RS -> sr-RS -> sr).
  if (hasScript) {
    const withoutScript = [base, ...parts.slice(1).filter((p) => p.length !== 4)].join('-')
    if (withoutScript !== normalized) {
      const stripped = LOCALE_LOOKUP.get(withoutScript)
      if (stripped) return stripped.code
      const strippedBase = LOCALE_LOOKUP.get(withoutScript.split('-')[0])
      if (strippedBase) return strippedBase.code
    }
  }

  return null
}

/**
 * Detect the best supported interface language from the browser/device
 * preferences. Falls back to English when nothing matches.
 * Never throws - safe on any platform.
 */
export function detectDeviceLocale(): string {
  try {
    if (typeof navigator === 'undefined') return FALLBACK_LOCALE

    const candidates: string[] = []
    if (Array.isArray(navigator.languages)) {
      candidates.push(...navigator.languages.filter((l) => typeof l === 'string'))
    }
    if (typeof navigator.language === 'string' && navigator.language) {
      candidates.push(navigator.language)
    }

    for (const candidate of candidates) {
      const match = matchLocaleTag(candidate)
      if (match) return match
    }

    return FALLBACK_LOCALE
  } catch {
    return FALLBACK_LOCALE
  }
}
