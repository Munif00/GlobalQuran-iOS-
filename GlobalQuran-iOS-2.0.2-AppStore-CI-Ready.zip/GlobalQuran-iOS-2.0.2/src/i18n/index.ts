/**
 * Global Quran - i18n engine
 *
 * - Merges the active locale over the English fallback (missing strings
 *   are never exposed to users as raw keys).
 * - Tracks translation completeness per language.
 * - `useTranslation()` is the single entry point used by the whole UI.
 */

import { useMemo } from 'react'

import en, { type TranslationKey } from './locales/en'
import ar from './locales/ar'
import fr from './locales/fr'
import es from './locales/es'
import de from './locales/de'
import tr from './locales/tr'
import id from './locales/id'
import ur from './locales/ur'
import ru from './locales/ru'
import pt from './locales/pt'
import it from './locales/it'
import nl from './locales/nl'
import uk from './locales/uk'
import fa from './locales/fa'
import bn from './locales/bn'
import ms from './locales/ms'
import zhHans from './locales/zh-hans'
import zhHant from './locales/zh-hant'
import ja from './locales/ja'
import ko from './locales/ko'
import sw from './locales/sw'
import hi from './locales/hi'
import ps from './locales/ps'
import ku from './locales/ku'
import ha from './locales/ha'
import so from './locales/so'
import ta from './locales/ta'
import te from './locales/te'
import ml from './locales/ml'
import kn from './locales/kn'
import mr from './locales/mr'
import gu from './locales/gu'
import pa from './locales/pa'
import th from './locales/th'
import vi from './locales/vi'
import fil from './locales/fil'
import am from './locales/am'
import yo from './locales/yo'
import kk from './locales/kk'
import uz from './locales/uz'
import az from './locales/az'
import sq from './locales/sq'
import bs from './locales/bs'
import sr from './locales/sr'
import hr from './locales/hr'
import ro from './locales/ro'
import pl from './locales/pl'
import sv from './locales/sv'
import da from './locales/da'
import nb from './locales/nb'
import si from './locales/si'
import fi from './locales/fi'
import el from './locales/el'
import hu from './locales/hu'
import cs from './locales/cs'
import sk from './locales/sk'
import bg from './locales/bg'
import et from './locales/et'
import lv from './locales/lv'
import lt from './locales/lt'
import sl from './locales/sl'
import ca from './locales/ca'
import af from './locales/af'
import jv from './locales/jv'
import su from './locales/su'
import ceb from './locales/ceb'
import km from './locales/km'
import lo from './locales/lo'
import my from './locales/my'
import ne from './locales/ne'
import ky from './locales/ky'
import tg from './locales/tg'
import ug from './locales/ug'
import tk from './locales/tk'
import tt from './locales/tt'
import be from './locales/be'
import zu from './locales/zu'
import sn from './locales/sn'
import ny from './locales/ny'
import mg from './locales/mg'

import type { TranslationResource } from './locales/en'
import {
  FALLBACK_LOCALE,
  SUPPORTED_LOCALES,
  detectDeviceLocale,
  getDirection,
  getLocaleDefinition,
  isRTL,
  type LocaleDefinition,
} from './config'
import { usePreferencesStore } from '@/stores/preferences-store'
import { useMounted } from '@/hooks/use-mounted'

/** All locale resources. Languages without a resource fall back to English. */
const LOCALE_RESOURCES: Record<string, TranslationResource> = {
  ar,
  fr,
  es,
  de,
  tr,
  id,
  ur,
  ru,
  pt,
  it,
  nl,
  uk,
  fa,
  bn,
  ms,
  'zh-Hans': zhHans,
  'zh-Hant': zhHant,
  ja,
  ko,
  sw,
  hi,
  ps,
  ku,
  ha,
  so,
  ta,
  te,
  ml,
  kn,
  mr,
  gu,
  pa,
  th,
  vi,
  fil,
  am,
  yo,
  kk,
  uz,
  az,
  sq,
  bs,
  sr,
  hr,
  ro,
  pl,
  sv,
  da,
  nb,
  si,
  fi,
  el,
  hu,
  cs,
  sk,
  bg,
  et,
  lv,
  lt,
  sl,
  ca,
  af,
  jv,
  su,
  ceb,
  km,
  lo,
  my,
  ne,
  ky,
  tg,
  ug,
  tk,
  tt,
  be,
  zu,
  sn,
  ny,
  mg,
}

export type TranslationParams = Record<string, string | number>

export type TranslateFunction = (key: TranslationKey, params?: TranslationParams) => string

const TOTAL_KEY_COUNT = Object.keys(en).length

/** Memo cache of merged dictionaries: locale -> merged resource. */
const mergedCache = new Map<string, TranslationResource>()

/** Missing-key telemetry: each locale's keys that fell back to English.
 * Surfaced via `reportMissingKeys()` for developer tooling and (in
 * development) the browser console. Never shown to users. */
const missingKeysByLocale = new Map<string, Set<string>>()
const reportedLocales = new Set<string>()

function noteMissingKey(localeCode: string, key: string, fallbackValue: string): void {
  if (process.env.NODE_ENV !== 'development') return
  let set = missingKeysByLocale.get(localeCode)
  if (!set) {
    set = new Set()
    missingKeysByLocale.set(localeCode, set)
  }
  set.add(key)
  // One summary per locale per session keeps the console usable.
  if (!reportedLocales.has(localeCode) && set.size % 50 === 0) {
    reportedLocales.add(localeCode)
    console.debug(
      `[i18n] "${localeCode}" is missing ${set.size} keys (English fallback in use). ` +
        `Run reportMissingKeys('${localeCode}') for the full list.`,
    )
  }
  void fallbackValue
}

/** Developer helper: the list of keys a locale is still missing. */
export function reportMissingKeys(localeCode: string): string[] {
  const resource = LOCALE_RESOURCES[localeCode] ?? {}
  return Object.keys(en).filter((key) => !(key in resource))
}

export function getMissingKeysReport(): Record<string, number> {
  const report: Record<string, number> = {}
  for (const [localeCode, keys] of missingKeysByLocale) {
    report[localeCode] = keys.size
  }
  return report
}

function getMergedResource(localeCode: string): TranslationResource {
  const cached = mergedCache.get(localeCode)
  if (cached) return cached

  const localeResource = LOCALE_RESOURCES[localeCode] ?? {}
  // English fallback underneath the locale strings.
  const merged: TranslationResource = { ...en, ...localeResource }
  mergedCache.set(localeCode, merged)
  return merged
}

/**
 * Build a translate function for a locale. Missing keys fall back to English;
 * as a final safety net the key itself is returned (never shown in practice
 * because English is complete).
 */
export function createTranslator(localeCode: string): TranslateFunction {
  const dictionary = getMergedResource(localeCode)
  return (key, params) => {
    let value = dictionary[key] ?? en[key] ?? String(key)
    if (process.env.NODE_ENV === 'development' && localeCode !== FALLBACK_LOCALE && !(key in dictionary)) {
      noteMissingKey(localeCode, key, value)
    }
    if (params) {
      for (const [name, replacement] of Object.entries(params)) {
        value = value.split(`{${name}}`).join(String(replacement))
      }
    }
    return value
  }
}

/**
 * Translation completeness for a language, as a percentage of the English
 * key set (0-100). English itself is always 100.
 */
export function getLocaleCompleteness(localeCode: string): number {
  if (localeCode === FALLBACK_LOCALE) return 100
  const resource = LOCALE_RESOURCES[localeCode]
  if (!resource) return 0
  const translated = Object.keys(resource).filter((key) => key in en).length
  return Math.round((translated / TOTAL_KEY_COUNT) * 100)
}

/** Whether a locale has any translated strings at all. */
export function hasTranslations(localeCode: string): boolean {
  return localeCode === FALLBACK_LOCALE || Boolean(LOCALE_RESOURCES[localeCode])
}

export interface UseTranslationResult {
  /** Translate a key, with optional {param} interpolation. */
  t: TranslateFunction
  /** Active locale code (e.g. `ar`, `zh-Hans`). */
  locale: string
  /** Active locale definition from the registry. */
  localeDefinition: LocaleDefinition
  direction: 'ltr' | 'rtl'
  isRTL: boolean
  /** True once client-side language resolution has run (avoids SSR mismatch). */
  ready: boolean
}

/**
 * Resolve the interface language:
 * manual choice when the user picked one, otherwise the detected device
 * language (with English fallback). Exported (PROMPT 16) so non-hook
 * consumers (the native reminder bridge) resolve the SAME language as the
 * UI without duplicating the mode logic.
 */
export function resolveLanguage(languageMode: string, manualLanguage: string | null, detectedLanguage: string | null): string {
  if (languageMode === 'manual' && manualLanguage) {
    return manualLanguage
  }
  return detectedLanguage ?? FALLBACK_LOCALE
}

export function useTranslation(): UseTranslationResult {
  const languageMode = usePreferencesStore((s) => s.languageMode)
  const manualLanguage = usePreferencesStore((s) => s.manualLanguage)
  const detectedLanguage = usePreferencesStore((s) => s.detectedLanguage)
  const mounted = useMounted()

  const locale = useMemo(() => {
    if (!mounted) return FALLBACK_LOCALE
    return resolveLanguage(languageMode, manualLanguage, detectedLanguage)
  }, [mounted, languageMode, manualLanguage, detectedLanguage])

  const t = useMemo(() => createTranslator(locale), [locale])

  return {
    t,
    locale,
    localeDefinition: getLocaleDefinition(locale),
    direction: getDirection(locale),
    isRTL: isRTL(locale),
    ready: mounted,
  }
}

/** List of supported languages with their current completeness, for pickers. */
export function getSupportedLanguagesWithCompleteness(): Array<LocaleDefinition & { completeness: number }> {
  return SUPPORTED_LOCALES.map((definition) => ({
    ...definition,
    completeness: getLocaleCompleteness(definition.code),
  }))
}

export { detectDeviceLocale, SUPPORTED_LOCALES, FALLBACK_LOCALE }
export type { TranslationKey, LocaleDefinition }
