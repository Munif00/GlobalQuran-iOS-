/**
 * Download-manager UI store (reactive view over the download engine).
 *
 * The engine (download-manager.ts) owns the real state and persists job
 * records to IndexedDB; this store mirrors the live job map so React
 * components re-render on progress updates without polling.
 */

import { create } from 'zustand'

import type { DownloadJobRecord } from '@/types'

interface DownloadManagerState {
  /** Live job records keyed by id (active + recent). */
  jobs: Record<string, DownloadJobRecord>
  /** Ids of jobs with live progress (used for cheap re-render scoping). */
  activeIds: string[]
  /** True once the engine has restored persisted jobs after startup. */
  restored: boolean

  setJob: (job: DownloadJobRecord) => void
  setJobs: (jobs: DownloadJobRecord[]) => void
  removeJob: (id: string) => void
  setRestored: (restored: boolean) => void
}

export const useDownloadManagerStore = create<DownloadManagerState>()((set) => ({
  jobs: {},
  activeIds: [],
  restored: false,

  setJob: (job) =>
    set((state) => ({
      jobs: { ...state.jobs, [job.id]: job },
      activeIds:
        job.status === 'completed' || job.status === 'failed' || job.status === 'canceled' || job.status === 'corrupted'
          ? state.activeIds.filter((id) => id !== job.id)
          : state.activeIds.includes(job.id)
            ? state.activeIds
            : [...state.activeIds, job.id],
    })),

  setJobs: (jobs) =>
    set(() => {
      const map: Record<string, DownloadJobRecord> = {}
      for (const job of jobs) map[job.id] = job
      return { jobs: map }
    }),

  removeJob: (id) =>
    set((state) => {
      const jobs = { ...state.jobs }
      delete jobs[id]
      return { jobs, activeIds: state.activeIds.filter((active) => active !== id) }
    }),

  setRestored: (restored) => set({ restored }),
}))
