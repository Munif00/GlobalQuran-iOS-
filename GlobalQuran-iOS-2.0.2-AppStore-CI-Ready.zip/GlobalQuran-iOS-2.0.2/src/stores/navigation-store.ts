/**
 * Navigation store for the single-page app shell.
 *
 * The visible route is always `/` (the only user-facing page). Screens are
 * switched client-side and mirrored into the URL hash (`#/quran`, `#/prayer`)
 * so deep links and the browser Back button work naturally.
 */

import { create } from 'zustand'

import type { AppScreen } from '@/types'

export const APP_SCREENS: AppScreen[] = ['home', 'quran', 'downloads', 'prayer', 'qibla', 'settings', 'profile']

/** Map an arbitrary hash value to a valid screen. */
export function parseScreenFromHash(hash: string): AppScreen {
  const value = hash.replace(/^#\/?/, '').split('?')[0].trim().toLowerCase()
  return (APP_SCREENS as string[]).includes(value) ? (value as AppScreen) : 'home'
}

export function screenToHash(screen: AppScreen): string {
  return `#/${screen}`
}

interface NavigationState {
  activeScreen: AppScreen
  /** Optional anchor inside the settings screen to scroll to (cleared after use). */
  settingsSection: string | null
  /** Switch screens and sync the URL hash. */
  navigate: (screen: AppScreen) => void
  /** Open the settings screen focused on one section card. */
  navigateToSettingsSection: (section: string) => void
  /** Internal setter used by the hash-sync effect (no history entry). */
  setActiveScreen: (screen: AppScreen) => void
  /** Clear a consumed settings-section request. */
  clearSettingsSection: () => void
}

function currentHashScreen(): AppScreen {
  if (typeof window === 'undefined') return 'home'
  return parseScreenFromHash(window.location.hash)
}

export const useNavigationStore = create<NavigationState>()((set, get) => ({
  activeScreen: 'home',
  settingsSection: null,

  navigate: (screen) => {
    if (get().activeScreen !== screen) {
      set({ activeScreen: screen })
    }
    if (typeof window !== 'undefined') {
      const target = screenToHash(screen)
      if (window.location.hash !== target) {
        window.location.hash = target
      }
    }
  },

  navigateToSettingsSection: (section) => {
    set({ activeScreen: 'settings', settingsSection: section })
    if (typeof window !== 'undefined') {
      const target = screenToHash('settings')
      if (window.location.hash !== target) {
        window.location.hash = target
      }
    }
  },

  clearSettingsSection: () => set({ settingsSection: null }),

  setActiveScreen: (screen) => {
    if (get().activeScreen !== screen) {
      set({ activeScreen: screen })
    }
  },
}))

/** Initialize hash <-> store syncing. Returns a cleanup function. */
export function initNavigationSync(): () => void {
  if (typeof window === 'undefined') return () => undefined

  const applyHash = () => {
    useNavigationStore.getState().setActiveScreen(currentHashScreen())
  }

  // Adopt whatever the initial hash says (deep link support).
  applyHash()

  window.addEventListener('hashchange', applyHash)
  return () => {
    window.removeEventListener('hashchange', applyHash)
  }
}
