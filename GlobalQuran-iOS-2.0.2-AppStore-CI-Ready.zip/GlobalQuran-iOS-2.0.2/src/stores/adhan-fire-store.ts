/**
 * Global Quran - Adhan fire banner store (PROMPT 16).
 *
 * Drives the in-app foreground banner when a reminder fires while the app
 * is open in the NATIVE app (where the web Notification API cannot display
 * anything inside the Android WebView). The web/PWA platform keeps using
 * real web Notifications; the banner simply stays inactive there.
 */

import { create } from 'zustand'

export type AdhanFireState = 'played' | 'not-stored' | 'not-selected' | 'quiet' | 'silent'

export interface AdhanFireBannerData {
  /** Localized prayer name (e.g. 'Fajr'). */
  title: string
  /** Honest outcome body text. */
  body: string
  /** Which outcome produced this banner. */
  state: AdhanFireState
  /** When the event fired (epoch ms). */
  firedAt: number
}

interface AdhanFireStore {
  banner: AdhanFireBannerData | null
  show: (data: AdhanFireBannerData) => void
  /** Dismiss (user tapped dismiss / playback ended). */
  dismiss: () => void
}

export const useAdhanFireStore = create<AdhanFireStore>()((set) => ({
  banner: null,
  show: (data) => set({ banner: data }),
  dismiss: () => set({ banner: null }),
}))
