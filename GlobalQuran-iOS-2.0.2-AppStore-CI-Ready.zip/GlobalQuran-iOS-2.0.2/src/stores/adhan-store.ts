/**
 * Adhan library UI store (reactive view over the Adhan download engine).
 *
 * PROMPT 13. The engine (adhan-download-manager.ts) owns the real state and
 * persists the manifest to IndexedDB; this store mirrors per-recording
 * progress and the manifest so React components re-render on progress
 * updates without polling.
 */

import { create } from 'zustand'

import type { AdhanManifestEntry } from '@/types'

export type AdhanProgressPhase = 'idle' | 'downloading' | 'verifying' | 'ready' | 'failed'

export interface AdhanProgress {
  phase: AdhanProgressPhase
  /** Bytes received so far (downloading phase). */
  receivedBytes: number
  /** Exact total bytes (from the verified plan). */
  totalBytes: number
  /** Error key for friendly display (failed phase). */
  errorKey: string | null
}

interface AdhanLibraryState {
  /** Per-recording progress keyed by adhan id. */
  progress: Record<string, AdhanProgress>
  /** The restored local manifest (verified stored recordings only). */
  manifest: Record<string, AdhanManifestEntry>
  /** True once the persisted manifest has been restored after startup. */
  restored: boolean

  setProgress: (id: string, progress: AdhanProgress) => void
  markReady: (entry: AdhanManifestEntry) => void
  removeEntry: (id: string) => void
  setManifest: (entries: AdhanManifestEntry[]) => void
  setRestored: (restored: boolean) => void
}

export const useAdhanStore = create<AdhanLibraryState>()((set) => ({
  progress: {},
  manifest: {},
  restored: false,

  setProgress: (id, progress) =>
    set((state) => ({ progress: { ...state.progress, [id]: progress } })),

  markReady: (entry) =>
    set((state) => ({
      manifest: { ...state.manifest, [entry.id]: entry },
      progress: {
        ...state.progress,
        [entry.id]: {
          phase: 'ready',
          receivedBytes: entry.fileSize,
          totalBytes: entry.fileSize,
          errorKey: null,
        },
      },
    })),

  removeEntry: (id) =>
    set((state) => {
      const progress = { ...state.progress }
      const manifest = { ...state.manifest }
      delete progress[id]
      delete manifest[id]
      return { progress, manifest }
    }),

  setManifest: (entries) =>
    set(() => {
      const manifest: Record<string, AdhanManifestEntry> = {}
      const progress: Record<string, AdhanProgress> = {}
      for (const entry of entries) {
        manifest[entry.id] = entry
        progress[entry.id] = {
          phase: 'ready',
          receivedBytes: entry.fileSize,
          totalBytes: entry.fileSize,
          errorKey: null,
        }
      }
      return { manifest, progress }
    }),

  setRestored: (restored) => set({ restored }),
}))
