/**
 * User preferences store (persisted to localStorage).
 *
 * - Language: automatic (device detection) or manual (never overridden).
 * - Theme is delegated to next-themes; the conceptual preference lives here
 *   as part of the UserPreferences domain model.
 * - Prayer settings persist the location, the documented calculation
 *   settings, and the saved-locations list for the prayer dashboard.
 *
 * `skipHydration` is used so the first client render matches the server
 * output; providers rehydrate explicitly after mount. The store is
 * versioned with a deep-merging migrate so previously persisted prayer
 * settings gain the new fields with safe defaults.
 */

import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

import type {
  AdhanReminderSettings,
  LanguageMode,
  LocalProfile,
  PrayerNotificationPreferences,
  PrayerSettings,
  ReadingPosition,
  SavedPrayerLocation,
  TextSize,
  UserPreferences,
} from '@/types'

/** Built-in avatar artwork shipped with the app (public/avatars). */
export const BUILTIN_AVATARS = [
  { id: 'mushaf', src: '/avatars/mushaf.jpg' },
  { id: 'geometric', src: '/avatars/geometric.jpg' },
  { id: 'dome', src: '/avatars/dome.jpg' },
] as const

/** The default avatar: the elegant closed Quran Mushaf illustration. */
export const DEFAULT_AVATAR_ID = 'mushaf'

export const DEFAULT_PRAYER_SETTINGS: PrayerSettings = {
  countryCode: null,
  countryName: null,
  city: null,
  latitude: null,
  longitude: null,
  timeZone: null,
  timeZoneMode: 'auto',
  manualTimeZone: null,
  preferredAuthority: null,
  calculationMethod: 'MWL',
  madhhab: 'standard',
  adjustments: {
    fajr: 0,
    sunrise: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0,
  },
  methodMode: 'auto',
  highLatitudeRule: 'auto',
  jakimZone: null,
}

export const DEFAULT_ADHAN_SETTINGS: AdhanReminderSettings = {
  mode: 'silent',
  useSameForAll: true,
  sameForAllRecordingId: null,
  perPrayerRecordingIds: {
    fajr: null,
    dhuhr: null,
    asr: null,
    maghrib: null,
    isha: null,
  },
  volume: 1,
}

export const DEFAULT_NOTIFICATION_PREFERENCES: PrayerNotificationPreferences = {
  enabled: false,
  leadMinutes: 10,
  perPrayer: {
    fajr: true,
    sunrise: false,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  },
  // Legacy pre-PROMPT-13 flag; the live feature uses adhanSettings.
  adhan: false,
  adhanSettings: DEFAULT_ADHAN_SETTINGS,
  quietHours: {
    enabled: false,
    start: '22:00',
    end: '06:00',
  },
}

export const DEFAULT_PROFILE: LocalProfile = {
  displayName: null,
  avatarKind: 'builtin',
  builtinAvatarId: DEFAULT_AVATAR_ID,
  customAvatar: null,
}

interface PreferencesState {
  /* Language */
  languageMode: LanguageMode
  manualLanguage: string | null
  detectedLanguage: string | null

  /* Local profile (private, device-only) */
  profile: LocalProfile

  /* Appearance (theme itself is applied by next-themes) */
  themePreference: UserPreferences['theme']
  textSize: TextSize

  /* Reading */
  lastReadingPosition: ReadingPosition | null
  preferredQuranTranslationLanguage: string | null

  /* Prayer */
  prayerSettings: PrayerSettings
  savedLocations: SavedPrayerLocation[]
  activeLocationId: string | null
  prayerNotifications: PrayerNotificationPreferences

  /* Actions */
  setManualLanguage: (code: string) => void
  setLanguageModeAuto: () => void
  setDetectedLanguage: (code: string) => void
  updateProfile: (patch: Partial<LocalProfile>) => void
  setThemePreference: (theme: UserPreferences['theme']) => void
  setTextSize: (size: TextSize) => void
  setLastReadingPosition: (position: ReadingPosition | null) => void
  setPreferredQuranTranslationLanguage: (code: string | null) => void
  updatePrayerSettings: (patch: Partial<PrayerSettings>) => void
  addSavedLocation: (location: SavedPrayerLocation) => void
  removeSavedLocation: (id: string) => void
  setActiveLocationId: (id: string | null) => void
  updatePrayerNotifications: (patch: Partial<PrayerNotificationPreferences>) => void
  resetAll: () => void
}

const initialState = {
  languageMode: 'auto' as LanguageMode,
  manualLanguage: null as string | null,
  detectedLanguage: null as string | null,
  profile: DEFAULT_PROFILE,
  themePreference: 'system' as UserPreferences['theme'],
  textSize: 'md' as TextSize,
  lastReadingPosition: null as ReadingPosition | null,
  preferredQuranTranslationLanguage: null as string | null,
  prayerSettings: DEFAULT_PRAYER_SETTINGS,
  savedLocations: [] as SavedPrayerLocation[],
  activeLocationId: null as string | null,
  prayerNotifications: DEFAULT_NOTIFICATION_PREFERENCES,
}

/** localStorage key of the persisted preferences (also read by the opening
 * splash to resolve the interface language on the very first paint). */
export const PREFERENCES_STORAGE_KEY = 'global-quran-preferences'

function makeLocationId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `loc-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

export function createSavedLocation(input: Omit<SavedPrayerLocation, 'id' | 'createdAt'>): SavedPrayerLocation {
  return { ...input, id: makeLocationId(), createdAt: new Date().toISOString() }
}

export const usePreferencesStore = create<PreferencesState>()(
  persist(
    (set) => ({
      ...initialState,

      setManualLanguage: (code) =>
        set({ languageMode: 'manual', manualLanguage: code }),

      setLanguageModeAuto: () =>
        set({ languageMode: 'auto' }),

      setDetectedLanguage: (code) =>
        set({ detectedLanguage: code }),

      updateProfile: (patch) =>
        set((state) => ({
          profile: { ...state.profile, ...patch },
        })),

      setThemePreference: (theme) =>
        set({ themePreference: theme }),

      setTextSize: (size) =>
        set({ textSize: size }),

      setLastReadingPosition: (position) =>
        set({ lastReadingPosition: position }),

      setPreferredQuranTranslationLanguage: (code) =>
        set({ preferredQuranTranslationLanguage: code }),

      updatePrayerSettings: (patch) =>
        set((state) => ({
          prayerSettings: { ...state.prayerSettings, ...patch },
        })),

      addSavedLocation: (location) =>
        set((state) => ({
          savedLocations: [location, ...state.savedLocations.filter((entry) => entry.id !== location.id)].slice(0, 20),
          activeLocationId: location.id,
        })),

      removeSavedLocation: (id) =>
        set((state) => ({
          savedLocations: state.savedLocations.filter((entry) => entry.id !== id),
          activeLocationId: state.activeLocationId === id ? null : state.activeLocationId,
        })),

      setActiveLocationId: (id) => set({ activeLocationId: id }),

      updatePrayerNotifications: (patch) =>
        set((state) => ({
          prayerNotifications: { ...state.prayerNotifications, ...patch },
        })),

      resetAll: () => set({ ...initialState }),
    }),
    {
      name: PREFERENCES_STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      version: 4,
      /** Deep-merge persisted data so new fields always have defaults. */
      migrate: (persisted) => {
        const state = (persisted ?? {}) as Partial<PreferencesState> & {
          prayerSettings?: Partial<PrayerSettings>
          prayerNotifications?: Partial<PrayerNotificationPreferences> & {
            adhan?: boolean
            adhanSettings?: Partial<AdhanReminderSettings>
          }
          profile?: Partial<LocalProfile>
        }
        // PROMPT 13 migration: the legacy `adhan` flag becomes the audio
        // mode preference; the structured adhanSettings gains safe defaults.
        const legacyAdhan = state.prayerNotifications?.adhan === true
        const migratedAdhanSettings: AdhanReminderSettings = {
          ...DEFAULT_ADHAN_SETTINGS,
          ...(state.prayerNotifications?.adhanSettings ?? {}),
          perPrayerRecordingIds: {
            ...DEFAULT_ADHAN_SETTINGS.perPrayerRecordingIds,
            ...(state.prayerNotifications?.adhanSettings?.perPrayerRecordingIds ?? {}),
          },
          mode: state.prayerNotifications?.adhanSettings?.mode ?? (legacyAdhan ? 'audio' : 'silent'),
        }
        return {
          ...initialState,
          ...state,
          profile: { ...DEFAULT_PROFILE, ...(state.profile ?? {}) },
          prayerSettings: {
            ...DEFAULT_PRAYER_SETTINGS,
            ...(state.prayerSettings ?? {}),
            adjustments: {
              ...DEFAULT_PRAYER_SETTINGS.adjustments,
              ...(state.prayerSettings?.adjustments ?? {}),
            },
          },
          savedLocations: Array.isArray(state.savedLocations) ? state.savedLocations : [],
          activeLocationId: state.activeLocationId ?? null,
          prayerNotifications: {
            ...DEFAULT_NOTIFICATION_PREFERENCES,
            ...(state.prayerNotifications ?? {}),
            perPrayer: {
              ...DEFAULT_NOTIFICATION_PREFERENCES.perPrayer,
              ...(state.prayerNotifications?.perPrayer ?? {}),
            },
            adhanSettings: migratedAdhanSettings,
            quietHours: {
              ...DEFAULT_NOTIFICATION_PREFERENCES.quietHours,
              ...(state.prayerNotifications?.quietHours ?? {}),
            },
          },
        } as PreferencesState
      },
      partialize: (state) => ({
        languageMode: state.languageMode,
        manualLanguage: state.manualLanguage,
        profile: state.profile,
        themePreference: state.themePreference,
        textSize: state.textSize,
        lastReadingPosition: state.lastReadingPosition,
        preferredQuranTranslationLanguage: state.preferredQuranTranslationLanguage,
        prayerSettings: state.prayerSettings,
        savedLocations: state.savedLocations,
        activeLocationId: state.activeLocationId,
        prayerNotifications: state.prayerNotifications,
      }),
    },
  ),
)
