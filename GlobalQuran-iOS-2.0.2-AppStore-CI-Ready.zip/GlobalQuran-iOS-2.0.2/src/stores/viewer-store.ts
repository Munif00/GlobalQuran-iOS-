/**
 * Viewer store - opens the built-in file viewer for a stored offline file.
 *
 * The Downloads screen (and any future surface) opens a stored file by its
 * metadata id; the FileViewer overlay resolves the blob from IndexedDB and
 * dispatches to the right reader by format. Reading is fully offline - no
 * network request is involved at any point.
 */

import { create } from 'zustand'

interface ViewerState {
  /** Stored-file metadata id being viewed (null = viewer closed). */
  openFileId: string | null
  open: (fileId: string) => void
  close: () => void
}

export const useViewerStore = create<ViewerState>()((set) => ({
  openFileId: null,

  open: (fileId) => set({ openFileId: fileId }),

  close: () => set({ openFileId: null }),
}))
