/**
 * File viewer state store (persisted to localStorage).
 *
 * Per-file reading state for the offline viewers:
 * - PDF: last opened page.
 * - EPUB: CFI position + progress percentage.
 *
 * Survives application restarts; never requires network access. Kept small
 * on purpose (only positions, never file content).
 */

import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

import type { FileViewerState } from '@/types'

interface ViewerStateStore {
  /** Viewer state per stored-file id. */
  states: Record<string, FileViewerState>

  setPdfPage: (fileId: string, page: number) => void
  setEpubPosition: (fileId: string, cfi: string, progress: number) => void
  clearFileState: (fileId: string) => void
}

export const useViewerStateStore = create<ViewerStateStore>()(
  persist(
    (set) => ({
      states: {},

      setPdfPage: (fileId, page) =>
        set((state) => ({
          states: {
            ...state.states,
            [fileId]: { pdfPage: page, updatedAt: new Date().toISOString() },
          },
        })),

      setEpubPosition: (fileId, cfi, progress) =>
        set((state) => ({
          states: {
            ...state.states,
            [fileId]: { epubCfi: cfi, epubProgress: progress, updatedAt: new Date().toISOString() },
          },
        })),

      clearFileState: (fileId) =>
        set((state) => {
          const next = { ...state.states }
          delete next[fileId]
          return { states: next }
        }),
    }),
    {
      name: 'global-quran-viewer-state',
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({ states: state.states }),
    },
  ),
)

/** Non-hook accessor for imperative readers. */
export function getViewerState(fileId: string): FileViewerState | null {
  return useViewerStateStore.getState().states[fileId] ?? null
}
