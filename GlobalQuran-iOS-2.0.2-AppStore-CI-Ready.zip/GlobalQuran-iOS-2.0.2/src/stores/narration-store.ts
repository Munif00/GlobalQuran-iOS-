'use client'

/**
 * Translation narration store (persisted settings, ephemeral state).
 *
 * PROMPT 10 keeps translation narration a COMPLETELY separate concern from
 * Arabic recitation: separate store, separate engine, separate channel.
 *
 * Persisted between sessions (the user's narration configuration):
 * - narration speed,
 * - sequential narration (advance automatically through the sura) vs
 *   single-ayah narration (stop at the end of the ayah),
 * - repeat of the current ayah's narration (count 2..10 or endless),
 * - the follow-along highlight preference,
 * - the voice choice PER TRANSLATION LANGUAGE (device TTS voices are
 *   per-language; a choice made for English never affects French).
 *
 * Ephemeral (never persisted): the live narration state driven by the
 * narration engine - the narrating ayah, the MODE (human recording vs
 * device TTS voice - always visible to the user), buffering, position,
 * errors and the active voice name.
 */

import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

import type { NarrationMode } from '@/types'

export type NarrationSpeed = 0.75 | 1 | 1.25 | 1.5

export type NarrationErrorKind =
  | 'network'
  | 'file-missing'
  | 'voice-missing'
  | 'no-audio'
  | 'unsupported'
  | 'unknown'
  /** Native TTS bridge: no text-to-speech engine is active on the device. */
  | 'tts-engine-missing'
  /** Native TTS bridge: no installed voice speaks the translation's language. */
  | 'tts-voice-missing'
  /** Native TTS bridge: the language's speech data is not installed. */
  | 'tts-voice-data'
  /** Native TTS bridge: the engine failed to start speaking. */
  | 'tts-synthesis-failed'

/** How narration advances: one ayah only, or automatically through the sura. */
export type NarrationAdvanceMode = 'single' | 'sequential'

/** Repeat count: a finite number of repetitions, or endless looping. */
export type NarrationRepeatCount = number | 'infinite'

/** Serializable snapshot of the active narration session (for the UI). */
export interface NarrationSessionInfo {
  advance: NarrationAdvanceMode
  pressSura: number
  pressAyah: number
  /** Current repetition of the ayah (1-based). */
  ayahPlay: number
  /** Total repetitions per ayah; 'infinite' for endless repetition. */
  ayahPlayCount: NarrationRepeatCount
}

interface NarrationState {
  /* ---- persisted (settings) ---- */
  speed: NarrationSpeed
  advanceMode: NarrationAdvanceMode
  repeatEnabled: boolean
  repeatCount: NarrationRepeatCount
  followAyah: boolean
  /** Persisted voice choice per language ISO code (voiceURI). */
  voiceChoice: Record<string, string>
  /* ---- ephemeral (narration engine) ---- */
  /** The translation key the active narration belongs to. */
  narrationTranslationKey: string | null
  /** How the current narration is produced - ALWAYS visible in the UI. */
  mode: NarrationMode | null
  narratingSura: number | null
  narratingAyah: number | null
  isPlaying: boolean
  isBuffering: boolean
  isSpeaking: boolean
  error: NarrationErrorKind | null
  currentTime: number
  duration: number
  session: NarrationSessionInfo | null
  /** Where a recording load comes from: local file or network stream. */
  sourceMode: 'local' | 'network' | null
  /** Name of the active device voice (TTS mode, display only). */
  activeVoiceName: string | null
  /** Whether the platform exposes a speech synthesis engine at all. */
  ttsEngineAvailable: boolean | null
  /** Which speech backend produced the current TTS narration: the native
   *  TtsBridge inside the Android app, or the Web Speech API in browsers.
   *  Drives the player bar's honest labeling and failure actions. */
  ttsBackend: 'native' | 'web' | null
  /** Language ISO of the narration context (the SELECTED translation's
   *  language - voice matching follows it, never the interface language). */
  languageIso: string | null
  /** Human-readable name of that language (display in the voice picker). */
  languageName: string | null

  /* ---- actions ---- */
  setSpeed: (speed: NarrationSpeed) => void
  setAdvanceMode: (mode: NarrationAdvanceMode) => void
  setRepeatEnabled: (enabled: boolean) => void
  setRepeatCount: (count: NarrationRepeatCount) => void
  toggleFollowAyah: () => void
  setVoiceChoice: (languageIso: string, voiceUri: string | null) => void
  /** Engine-driven state sync (single batched update per event). */
  syncEngineState: (patch: Partial<Pick<NarrationState,
    | 'narrationTranslationKey'
    | 'mode'
    | 'narratingSura'
    | 'narratingAyah'
    | 'isPlaying'
    | 'isBuffering'
    | 'isSpeaking'
    | 'error'
    | 'currentTime'
    | 'duration'
    | 'session'
    | 'sourceMode'
    | 'activeVoiceName'
    | 'ttsEngineAvailable'
    | 'ttsBackend'
    | 'languageIso'
    | 'languageName'
  >>) => void
}

const initialState = {
  speed: 1 as NarrationSpeed,
  advanceMode: 'single' as NarrationAdvanceMode,
  repeatEnabled: false,
  repeatCount: 3 as NarrationRepeatCount,
  followAyah: true,
  voiceChoice: {} as Record<string, string>,
  narrationTranslationKey: null as string | null,
  mode: null as NarrationMode | null,
  narratingSura: null as number | null,
  narratingAyah: null as number | null,
  isPlaying: false,
  isBuffering: false,
  isSpeaking: false,
  error: null as NarrationErrorKind | null,
  currentTime: 0,
  duration: 0,
  session: null as NarrationSessionInfo | null,
  sourceMode: null as 'local' | 'network' | null,
  activeVoiceName: null as string | null,
  ttsEngineAvailable: null as boolean | null,
  ttsBackend: null as 'native' | 'web' | null,
  languageIso: null as string | null,
  languageName: null as string | null,
}

/** Valid finite repeat counts offered by the UI (endless is 'infinite'). */
export const FINITE_NARRATION_REPEAT_OPTIONS: number[] = [2, 3, 5, 10]

export const useNarrationStore = create<NarrationState>()(
  persist(
    (set) => ({
      ...initialState,

      setSpeed: (speed) => set({ speed }),

      setAdvanceMode: (advanceMode) => set({ advanceMode }),

      setRepeatEnabled: (repeatEnabled) => set({ repeatEnabled }),

      setRepeatCount: (count) =>
        set({
          repeatCount: count === 'infinite' ? 'infinite' : Math.max(2, Math.round(count)),
        }),

      toggleFollowAyah: () => set((state) => ({ followAyah: !state.followAyah })),

      setVoiceChoice: (languageIso, voiceUri) =>
        set((state) => {
          const voiceChoice = { ...state.voiceChoice }
          if (voiceUri === null) delete voiceChoice[languageIso]
          else voiceChoice[languageIso] = voiceUri
          return { voiceChoice }
        }),

      syncEngineState: (patch) => set(patch),
    }),
    {
      name: 'global-quran-narration',
      version: 1,
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        speed: state.speed,
        advanceMode: state.advanceMode,
        repeatEnabled: state.repeatEnabled,
        repeatCount: state.repeatCount,
        followAyah: state.followAyah,
        voiceChoice: state.voiceChoice,
      }),
    },
  ),
)
