'use client'

/**
 * Audio recitation store (persisted settings, ephemeral playback state).
 *
 * Persisted between sessions (the user's playback configuration):
 * - the selected recitation style (reciter + style),
 * - the playback MODE: single-ayah (play one ayah, stop at its end) or
 *   sequential (advance automatically through a range up to a configured
 *   end boundary),
 * - the REPEAT controls: off / current ayah / selected range / whole surah,
 *   each with a repeat count (2..10 or endless),
 * - the sequential END boundary: end of surah, or a configured ending ayah,
 * - playback speed and the follow-along highlight preference.
 *
 * Ephemeral (never persisted): the live playback state driven by the playback
 * engine - the playing ayah, buffering, position, duration, errors, and the
 * active session description (range, current pass, current repetition).
 *
 * Changing the selected style NEVER touches the reader store: the reading
 * position (sura + tracked ayah), translation and display preferences are a
 * separate concern and remain exactly as they are - the user can switch
 * reciters mid-surah without losing their place.
 */

import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

import { isKnownStyleId } from '@/data/audio-styles'

export type PlaybackSpeed = 0.75 | 1 | 1.25 | 1.5

export type AudioErrorKind =
  | 'network'
  | 'file-missing'
  | 'style-unavailable'
  | 'unknown'

/** How playback advances: one ayah only, or automatically through a range. */
export type PlaybackMode = 'single' | 'sequential'

/** What gets repeated. 'range'/'sura' force sequential playback. */
export type RepeatMode = 'off' | 'ayah' | 'range' | 'sura'

/** Repeat count: a finite number of repetitions, or endless looping. */
export type RepeatCount = number | 'infinite'

/** Serializable snapshot of the active playback session (for the UI). */
export interface PlaybackSessionInfo {
  mode: PlaybackMode
  /** Where the user pressed play (never changes during the session). */
  pressSurah: number
  pressAyah: number
  /** Range start: where later passes restart from. */
  startSurah: number
  startAyah: number
  /** Range end: the configured boundary the session stops at. */
  endSurah: number
  endAyah: number
  /** Current pass over the range (1-based). */
  pass: number
  /** Total passes over the range; 'infinite' for endless range repetition. */
  passCount: number | 'infinite'
  /** How many times the current ayah has played in this pass (1-based). */
  ayahPlay: number
  /** Total plays per ayah; 'infinite' for endless ayah repetition. */
  ayahPlayCount: number | 'infinite'
}

interface AudioState {
  /* ---- persisted (settings) ---- */
  selectedStyleId: string | null
  speed: PlaybackSpeed
  playbackMode: PlaybackMode
  repeatMode: RepeatMode
  repeatCount: RepeatCount
  /** Sequential end boundary: null = end of sura; a number = ending ayah. */
  sequenceEndAyah: number | null
  followAyah: boolean
  /* ---- ephemeral (playback engine) ---- */
  playingSura: number | null
  playingAyah: number | null
  isPlaying: boolean
  isBuffering: boolean
  error: AudioErrorKind | null
  currentTime: number
  duration: number
  session: PlaybackSessionInfo | null
  /** Where the CURRENT load comes from: a verified local file ('local',
   *  offline playback) or the network stream ('network'). Null when idle.
   *  Driven by the engine - never persisted. */
  sourceMode: 'local' | 'network' | null

  /* ---- actions ---- */
  selectStyle: (styleId: string | null) => void
  setSpeed: (speed: PlaybackSpeed) => void
  setPlaybackMode: (mode: PlaybackMode) => void
  setRepeatMode: (mode: RepeatMode) => void
  setRepeatCount: (count: RepeatCount) => void
  setSequenceEndAyah: (ayah: number | null) => void
  toggleFollowAyah: () => void
  /** Engine-driven state sync (single batched update per event). */
  syncEngineState: (patch: Partial<Pick<AudioState,
    'playingSura' | 'playingAyah' | 'isPlaying' | 'isBuffering' | 'error' | 'currentTime' | 'duration' | 'session' | 'sourceMode'
  >>) => void
}

const initialState = {
  selectedStyleId: null as string | null,
  speed: 1 as PlaybackSpeed,
  playbackMode: 'single' as PlaybackMode,
  repeatMode: 'off' as RepeatMode,
  repeatCount: 3 as RepeatCount,
  sequenceEndAyah: null as number | null,
  followAyah: true,
  playingSura: null as number | null,
  playingAyah: null as number | null,
  isPlaying: false,
  isBuffering: false,
  error: null as AudioErrorKind | null,
  currentTime: 0,
  duration: 0,
  session: null as PlaybackSessionInfo | null,
  sourceMode: null as 'local' | 'network' | null,
}

/** Valid finite repeat counts offered by the UI (endless is 'infinite'). */
export const FINITE_REPEAT_OPTIONS: number[] = [2, 3, 5, 10]

export const useAudioStore = create<AudioState>()(
  persist(
    (set) => ({
      ...initialState,

      selectStyle: (styleId) => {
        // Only known catalog ids can be selected; a persisted but unknown id
        // (catalog changed between releases) resolves to null, never a guess.
        set({ selectedStyleId: styleId !== null && isKnownStyleId(styleId) ? styleId : null })
      },

      setSpeed: (speed) => set({ speed }),

      setPlaybackMode: (mode) => set({ playbackMode: mode }),

      setRepeatMode: (mode) =>
        set((state) => ({
          repeatMode: mode,
          // Range and surah repetition are sequential concepts - selecting
          // either one switches the advance mode accordingly (never the
          // reverse: switching to single keeps the repeat choice visible).
          playbackMode:
            (mode === 'range' || mode === 'sura') && state.playbackMode !== 'sequential'
              ? 'sequential'
              : state.playbackMode,
        })),

      setRepeatCount: (count) =>
        set({ repeatCount: count === 'infinite' ? 'infinite' : Math.max(2, Math.round(count)) }),

      setSequenceEndAyah: (ayah) =>
        set({
          sequenceEndAyah:
            ayah === null ? null : Number.isInteger(ayah) && ayah >= 1 ? ayah : null,
        }),

      toggleFollowAyah: () => set((state) => ({ followAyah: !state.followAyah })),

      syncEngineState: (patch) => set(patch),
    }),
    {
      name: 'global-quran-audio',
      version: 2,
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        selectedStyleId: state.selectedStyleId,
        speed: state.speed,
        playbackMode: state.playbackMode,
        repeatMode: state.repeatMode,
        repeatCount: state.repeatCount,
        sequenceEndAyah: state.sequenceEndAyah,
        followAyah: state.followAyah,
      }),
      migrate: (persisted, version) => {
        const state = persisted as Record<string, unknown> | undefined
        if (version < 2 && state && typeof state === 'object') {
          // v1 had repeatAyah (an endless same-ayah loop) and autoAdvance
          // (continue to the next ayah). Map them faithfully:
          // - repeatAyah -> repeat the current ayah, endlessly.
          // - autoAdvance -> sequential advance; otherwise single-ayah.
          const repeatAyah = state.repeatAyah === true
          const autoAdvance = state.autoAdvance !== false
          const { repeatAyah: _oldRepeat, autoAdvance: _oldAdvance, ...rest } = state
          void _oldRepeat
          void _oldAdvance
          return {
            ...rest,
            playbackMode: autoAdvance ? 'sequential' : 'single',
            repeatMode: repeatAyah ? 'ayah' : 'off',
            repeatCount: repeatAyah ? 'infinite' : 3,
            sequenceEndAyah: null,
          } as unknown as AudioState
        }
        return state as unknown as AudioState
      },
    },
  ),
)
