/**
 * Reader store (persisted to localStorage).
 *
 * Holds everything about the Quran reading session:
 * - whether the reader view is open inside the Quran screen,
 * - the selected translation (QuranEnc key),
 * - the current sura,
 * - display preferences (text scales, reading theme, translation visibility),
 * - ayah bookmarks.
 *
 * `skipHydration` keeps the first client render identical to the server
 * output; the app shell rehydrates after mount.
 */

import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

export type ReadingTheme = 'match-app' | 'sepia' | 'night'

/** Font-size scale steps (1 = smallest, 5 = largest). */
export type TextScale = 1 | 2 | 3 | 4 | 5

export interface ReaderBookmark {
  id: string
  sura: number
  aya: number
  /** QuranEnc translation key active when the bookmark was created. */
  translationKey: string
  createdAt: string
  /** Optional personal note attached by the user (null when none). */
  note: string | null
  /** Short verbatim excerpt of the bookmarked ayah, captured at creation
   *  time from the text on screen (translation first, Arabic otherwise).
   *  Null for bookmarks created before this field existed - never fabricated. */
  preview: string | null
}

export const DEFAULT_TRANSLATION_KEY = 'english_rwwad'

interface ReaderState {
  readerOpen: boolean
  selectedTranslationKey: string | null
  sura: number
  showTranslation: boolean
  arabicScale: TextScale
  translationScale: TextScale
  readingTheme: ReadingTheme
  /** Distraction-free reading: Arabic text only, minimal chrome. */
  focusMode: boolean
  bookmarks: ReaderBookmark[]
  /** Translation keys most recently opened in the reader (newest first). */
  recentTranslations: string[]
  /** One-shot request to open the bookmarks panel when the reader mounts
   *  (used by the Home quick-access shortcut). Never persisted. */
  bookmarksPanelRequested: boolean
  /** One-shot exact-ayah navigation target ("Continue reading" / a bookmark
   *  tapped outside the reader). Consumed by the reader once the target
   *  sura content renders. Never persisted. */
  pendingAyahTarget: { sura: number; aya: number } | null

  /** Open the reader (optionally choosing a translation and/or sura). */
  openReader: (options?: { translationKey?: string | null; sura?: number }) => void
  /** Open the reader directly at one exact ayah ("Continue reading",
   *  bookmark taps outside the reader). */
  openReaderAt: (sura: number, aya: number) => void
  /** One-shot consumption of the pending exact-ayah target by the reader. */
  consumePendingAyahTarget: () => void
  closeReader: () => void
  setSelectedTranslationKey: (key: string) => void
  setSura: (sura: number) => void
  nextSura: () => void
  prevSura: () => void
  toggleTranslation: () => void
  setArabicScale: (scale: TextScale) => void
  setTranslationScale: (scale: TextScale) => void
  setReadingTheme: (theme: ReadingTheme) => void
  setFocusMode: (enabled: boolean) => void
  addBookmark: (sura: number, aya: number, preview?: string | null) => void
  removeBookmark: (id: string) => void
  /** PROMPT 14: re-insert a previously removed bookmark (Undo), keeping its
   *  note, preview and creation time. No-op if the ayah is bookmarked again. */
  restoreBookmark: (bookmark: ReaderBookmark) => void
  /** Set, change or clear (empty string) the personal note of a bookmark. */
  updateBookmarkNote: (id: string, note: string) => void
  /** True when the given ayah is bookmarked. */
  isAyahBookmarked: (sura: number, aya: number) => boolean
  /** Ask the reader to open the bookmarks panel on next mount. */
  requestBookmarksPanel: () => void
  /** Consumed by the reader view when the panel has been opened. */
  clearBookmarksPanelRequest: () => void
}

function clampSura(value: number): number {
  if (!Number.isFinite(value)) return 1
  return Math.min(114, Math.max(1, Math.round(value)))
}

function clampScale(value: number): TextScale {
  if (!Number.isFinite(value)) return 3
  return Math.min(5, Math.max(1, Math.round(value))) as TextScale
}

function makeBookmarkId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `bm-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

/** Keep the most recent translation keys (newest first, max 8, no dupes). */
function recordRecent(recent: string[], key: string | null | undefined): string[] {
  if (!key) return recent
  return [key, ...recent.filter((entry) => entry !== key)].slice(0, 8)
}

const initialState = {
  readerOpen: false,
  selectedTranslationKey: null as string | null,
  sura: 1,
  showTranslation: true,
  arabicScale: 3 as TextScale,
  translationScale: 3 as TextScale,
  readingTheme: 'match-app' as ReadingTheme,
  focusMode: false,
  bookmarks: [] as ReaderBookmark[],
  recentTranslations: [] as string[],
  bookmarksPanelRequested: false,
  pendingAyahTarget: null as { sura: number; aya: number } | null,
}

export const useReaderStore = create<ReaderState>()(
  persist(
    (set, get) => ({
      ...initialState,

      openReader: (options) =>
        set((state) => ({
          readerOpen: true,
          selectedTranslationKey: options?.translationKey ?? state.selectedTranslationKey,
          sura: clampSura(options?.sura ?? state.sura),
          recentTranslations: recordRecent(
            state.recentTranslations,
            options?.translationKey ?? state.selectedTranslationKey,
          ),
        })),

      openReaderAt: (sura, aya) =>
        set((state) => ({
          readerOpen: true,
          sura: clampSura(sura),
          pendingAyahTarget: { sura: clampSura(sura), aya: Math.max(1, Math.round(aya)) },
          recentTranslations: state.recentTranslations,
        })),

      consumePendingAyahTarget: () => set({ pendingAyahTarget: null }),

      closeReader: () => set({ readerOpen: false, pendingAyahTarget: null }),

      setSelectedTranslationKey: (key) =>
        set((state) => ({
          selectedTranslationKey: key,
          recentTranslations: recordRecent(state.recentTranslations, key),
        })),

      setSura: (sura) => set({ sura: clampSura(sura) }),

      nextSura: () => set((state) => ({ sura: clampSura(state.sura + 1) })),
      prevSura: () => set((state) => ({ sura: clampSura(state.sura - 1) })),

      toggleTranslation: () => set((state) => ({ showTranslation: !state.showTranslation })),

      setArabicScale: (scale) => set({ arabicScale: clampScale(scale) }),
      setTranslationScale: (scale) => set({ translationScale: clampScale(scale) }),

      setReadingTheme: (theme) => set({ readingTheme: theme }),

      setFocusMode: (enabled) => set({ focusMode: enabled }),

      addBookmark: (sura, aya, preview = null) =>
        set((state) => {
          if (state.bookmarks.some((b) => b.sura === sura && b.aya === aya)) return state
          const trimmedPreview =
            typeof preview === 'string' && preview.trim().length > 0 ? preview.trim() : null
          const bookmark: ReaderBookmark = {
            id: makeBookmarkId(),
            sura,
            aya,
            translationKey: state.selectedTranslationKey ?? DEFAULT_TRANSLATION_KEY,
            createdAt: new Date().toISOString(),
            note: null,
            preview: trimmedPreview,
          }
          return { bookmarks: [bookmark, ...state.bookmarks].slice(0, 200) }
        }),

      removeBookmark: (id) =>
        set((state) => ({ bookmarks: state.bookmarks.filter((b) => b.id !== id) })),

      restoreBookmark: (bookmark) =>
        set((state) => {
          if (state.bookmarks.some((b) => b.sura === bookmark.sura && b.aya === bookmark.aya)) return state
          return { bookmarks: [bookmark, ...state.bookmarks].slice(0, 200) }
        }),

      updateBookmarkNote: (id, note) =>
        set((state) => ({
          bookmarks: state.bookmarks.map((b) =>
            b.id === id ? { ...b, note: note.trim().length > 0 ? note.trim() : null } : b,
          ),
        })),

      isAyahBookmarked: (sura, aya) =>
        get().bookmarks.some((b) => b.sura === sura && b.aya === aya),

      requestBookmarksPanel: () => set({ bookmarksPanelRequested: true }),

      clearBookmarksPanelRequest: () => set({ bookmarksPanelRequested: false }),
    }),
    {
      name: 'global-quran-reader',
      version: 3,
      migrate: (persisted, version) => {
        const state = persisted as Partial<ReaderState> & {
          bookmarks?: Array<ReaderBookmark & { note?: string | null; preview?: string | null }>
        }
        // v1 bookmarks lack `note`; v2 bookmarks lack `preview` - backfill
        // honestly as null (never fabricated).
        if (version < 3 && Array.isArray(state.bookmarks)) {
          state.bookmarks = state.bookmarks.map((b) => ({
            ...b,
            note: b.note ?? null,
            preview: b.preview ?? null,
          }))
        }
        return state as ReaderState
      },
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        selectedTranslationKey: state.selectedTranslationKey,
        sura: state.sura,
        showTranslation: state.showTranslation,
        arabicScale: state.arabicScale,
        translationScale: state.translationScale,
        readingTheme: state.readingTheme,
        focusMode: state.focusMode,
        bookmarks: state.bookmarks,
        recentTranslations: state.recentTranslations,
      }),
    },
  ),
)
