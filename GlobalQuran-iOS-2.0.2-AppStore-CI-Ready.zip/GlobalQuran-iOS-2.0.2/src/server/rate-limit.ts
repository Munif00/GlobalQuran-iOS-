/**
 * Global Quran - In-memory rate limiter.
 *
 * Simple fixed-window limiter keyed by client IP + bucket name. This is a
 * single-instance guard suitable for the self-hosted deployment this app
 * documents - it is NOT a distributed limiter, and it makes no claim to be
 * one. Bucket state lives in process memory and resets on restart.
 *
 * Requests that exceed the limit receive HTTP 429 with Retry-After.
 */

interface BucketState {
  windowStart: number
  count: number
}

const buckets = new Map<string, BucketState>()

/** Prune expired buckets occasionally so the map cannot grow unbounded. */
let lastPrune = 0
function prune(now: number) {
  if (now - lastPrune < 60_000) return
  lastPrune = now
  for (const [key, state] of buckets) {
    if (now - state.windowStart > 3_600_000) buckets.delete(key)
  }
}

export interface RateLimitOptions {
  /** Bucket name (usually the route identifier). */
  name: string
  /** Maximum requests per window per IP. */
  limit: number
  /** Window length in milliseconds. */
  windowMs: number
}

export interface RateLimitResult {
  ok: boolean
  /** Seconds until the client may retry. */
  retryAfterSeconds: number
}

export function checkRateLimit(request: Request, options: RateLimitOptions): RateLimitResult {
  const now = Date.now()
  prune(now)

  // Best-effort client IP. Behind the documented reverse proxy this is the
  // forwarded-for address; direct requests fall back to the connection peer.
  const forwarded = request.headers.get('x-forwarded-for')
  const ip =
    (forwarded ? forwarded.split(',')[0]?.trim() : null) ||
    request.headers.get('x-real-ip') ||
    'unknown'

  const key = `${options.name}:${ip}`
  const state = buckets.get(key)

  if (!state || now - state.windowStart >= options.windowMs) {
    buckets.set(key, { windowStart: now, count: 1 })
    return { ok: true, retryAfterSeconds: 0 }
  }

  state.count += 1
  if (state.count > options.limit) {
    const retryAfterSeconds = Math.max(1, Math.ceil((state.windowStart + options.windowMs - now) / 1000))
    return { ok: false, retryAfterSeconds }
  }
  return { ok: true, retryAfterSeconds: 0 }
}

/** Standard 429 response for a rejected request. */
export function rateLimitResponse(result: RateLimitResult): Response {
  return new Response(
    JSON.stringify({ message: 'Too many requests. Please slow down and try again shortly.' }),
    {
      status: 429,
      headers: {
        'content-type': 'application/json',
        'retry-after': String(result.retryAfterSeconds),
      },
    },
  )
}
