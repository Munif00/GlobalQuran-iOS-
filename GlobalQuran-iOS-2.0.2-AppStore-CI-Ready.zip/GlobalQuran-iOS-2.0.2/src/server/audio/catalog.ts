/**
 * Recitation catalog service (server side).
 *
 * Combines the verified seed catalog (exact per-ayah availability + byte
 * sizes from the official EveryAyah folder listings) with the style
 * definitions, and exposes aggregate + per-sura views.
 *
 * Honesty rules:
 * - Availability and sizes come ONLY from the seed - never computed by
 *   assumption ("every reciter has every ayah" is never assumed).
 * - The seed's completeness is re-validated at load time against the
 *   authentic structural index; any inconsistency makes the app fail closed
 *   (the style is reported not verified) rather than overpromise.
 */

import seedJson from '@/data/audio-catalog-seed.json'
import { RECITATION_STYLES, getStyleDefinition } from '@/data/audio-styles'
import { getSuraAyahCount } from '@/lib/audio/urls'
import type { LiveCheckResult } from './everyayah'

interface SeedStyleEntry {
  folder: string
  totalAyat: number
  totalSuras: number
  totalBytes: number
  /** sura number (string keys) -> per-ayah byte sizes (index 0 = ayah 1; 0 = absent). */
  suraSizes: Record<string, number[]>
}

interface SeedShape {
  version: number
  verifiedAt: string
  source: {
    name: string
    site: string
    listingBaseUrl: string
    urlPattern: string
    verificationMethod: string
  }
  styles: Record<string, SeedStyleEntry>
}

const seed = seedJson as unknown as SeedShape

/** Per-style seed data, re-validated against the structure of the Quran. */
function loadSeedStyle(styleId: string): SeedStyleEntry | null {
  const entry = seed.styles[styleId]
  if (!entry) return null
  if (!Array.isArray(Object.values(entry.suraSizes)) || Object.keys(entry.suraSizes).length !== 114) {
    return null
  }
  for (let sura = 1; sura <= 114; sura += 1) {
    const sizes = entry.suraSizes[String(sura)]
    const expected = getSuraAyahCount(sura)
    if (!Array.isArray(sizes) || sizes.length !== expected) return null
  }
  return entry
}

export interface SuraAudioFile {
  ayah: number
  /** Exact file size in bytes (verified from the source listing). */
  sizeBytes: number
  /** Full EveryAyah URL of the verified file. */
  url: string
}

export interface SuraAudioSummary {
  styleId: string
  sura: number
  ayahCount: number
  /** Ayat with a verified file (from the seed - never assumed). */
  availableAyat: number
  /** Ayat without a verified file - reported honestly, never playable. */
  missingAyat: number[]
  totalBytes: number
  files: SuraAudioFile[]
}

export interface ReciterStyleSummary {
  id: string
  reciterName: string
  reciterNameArabic: string
  style: string
  styleLabel: string
  bitrate: string
  format: string
  folder: string
  sourceName: string
  sourceSite: string
  bioNote: string | null
  bioNoteSource: string | null
  forLearning: boolean
  /** Verification status of the file inventory (from the seed). */
  seedVerified: boolean
  verifiedAt: string
  verificationMethod: string
  /** Total files verified present for this style. */
  totalAyat: number
  /** Suras with the complete ayah set verified. */
  completeSuras: number
  totalBytes: number
  /** Live reachability of the style's files (null when the style is invalid). */
  live: LiveCheckResult | null
  /** Final availability verdict: seed verified AND live reachable. */
  available: boolean
}

/** Aggregate summary of one style (live check result merged in by the caller). */
export function getStyleSummary(
  styleId: string,
  live: LiveCheckResult | null,
): ReciterStyleSummary | null {
  const style = getStyleDefinition(styleId)
  if (!style) return null
  const entry = loadSeedStyle(styleId)
  if (!entry) return null

  let completeSuras = 0
  for (let sura = 1; sura <= 114; sura += 1) {
    const sizes = entry.suraSizes[String(sura)]
    if (sizes && sizes.every((size) => size > 0)) completeSuras += 1
  }

  return {
    id: style.id,
    reciterName: style.reciterName,
    reciterNameArabic: style.reciterNameArabic,
    style: style.style,
    styleLabel: style.styleLabel,
    bitrate: style.bitrate,
    format: style.format,
    folder: style.folder,
    sourceName: style.sourceName,
    sourceSite: style.sourceSite,
    bioNote: style.bioNote,
    bioNoteSource: style.bioNoteSource,
    forLearning: style.forLearning,
    seedVerified: entry.totalAyat > 0,
    verifiedAt: seed.verifiedAt,
    verificationMethod: seed.source.verificationMethod,
    totalAyat: entry.totalAyat,
    completeSuras,
    totalBytes: entry.totalBytes,
    live,
    available: live?.status === 'available',
  }
}

/** All style summaries (live checks supplied per style). */
export function getAllStyleSummaries(liveResults: Map<string, LiveCheckResult | null>): ReciterStyleSummary[] {
  const summaries: ReciterStyleSummary[] = []
  for (const style of RECITATION_STYLES) {
    const summary = getStyleSummary(style.id, liveResults.get(style.id) ?? null)
    if (summary) summaries.push(summary)
  }
  return summaries
}

/** Per-sura verified file list for one style. */
export function getSuraAudioFiles(styleId: string, sura: number): SuraAudioSummary | null {
  const style = getStyleDefinition(styleId)
  if (!style) return null
  const ayahCount = getSuraAyahCount(sura)
  if (ayahCount === 0) return null
  const entry = loadSeedStyle(styleId)
  if (!entry) return null

  const sizes = entry.suraSizes[String(sura)]
  if (!sizes) return null

  const files: SuraAudioFile[] = []
  const missingAyat: number[] = []
  let totalBytes = 0
  for (let ayah = 1; ayah <= ayahCount; ayah += 1) {
    const sizeBytes = sizes[ayah - 1]
    if (!sizeBytes || sizeBytes <= 0) {
      missingAyat.push(ayah)
      continue
    }
    // URL building is structural; invalid references are impossible here but
    // are still guarded in everyAyahFileUrl.
    const url = `https://everyayah.com/data/${style.folder}/${String(sura).padStart(3, '0')}${String(ayah).padStart(3, '0')}.mp3`
    files.push({ ayah, sizeBytes, url })
    totalBytes += sizeBytes
  }

  return {
    styleId,
    sura,
    ayahCount,
    availableAyat: files.length,
    missingAyat,
    totalBytes,
    files,
  }
}
