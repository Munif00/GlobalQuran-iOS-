/**
 * Live EveryAyah verification (server side).
 *
 * The seed catalog proves which files existed at verification time, but a
 * recitation may only be PRESENTED as available when the files are also
 * confirmed reachable NOW. These helpers perform cheap live checks:
 *
 * - `verifyStyleLive`   - one sample file per style folder (Al-Fatiha 1:1),
 *                         TTL-cached and single-flight, for catalog status.
 * - `verifySuraLive`    - the first ayah of a requested sura (per style),
 *                         TTL-cached, for sura-level availability.
 *
 * A check passes only when EveryAyah answers 200/206 with content-type
 * audio/mpeg. Failures and network errors are cached briefly too, so a
 * flaky upstream is not hammered; and the result carries an honest
 * `status: 'unverified'` rather than a guess.
 */

import { everyAyahFileUrl, getSuraAyahCount } from '@/lib/audio/urls'
import { getStyleDefinition } from '@/data/audio-styles'

export type LiveStatus = 'available' | 'unavailable' | 'unknown'

export interface LiveCheckResult {
  status: LiveStatus
  /** When the check was last performed (ISO string). */
  checkedAt: string
  /** HTTP status observed (when a response arrived). */
  httpStatus: number | null
}

interface CacheEntry {
  result: LiveCheckResult
  expiresAt: number
}

/** Result cache: key -> entry. Positive results live 10 min, failures 90 s. */
const cache = new Map<string, CacheEntry>()
/** In-flight checks: key -> promise (single-flight per key). */
const inflight = new Map<string, Promise<LiveCheckResult>>()

const OK_TTL_MS = 10 * 60 * 1000
const FAIL_TTL_MS = 90 * 1000
const FETCH_TIMEOUT_MS = 12_000

const cacheKey = (styleId: string, sura: number) => `${styleId}:${sura}`

async function performCheck(url: string): Promise<LiveCheckResult> {
  const checkedAt = new Date().toISOString()
  try {
    const response = await fetch(url, {
      method: 'HEAD',
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
      headers: { Accept: 'audio/mpeg, */*' },
      cache: 'no-store',
    })
    // BunnyCDN answers 200 (sometimes 206) for existing files; 404/410 otherwise.
    const ok = (response.status === 200 || response.status === 206) &&
      (response.headers.get('content-type') ?? '').toLowerCase().includes('audio/mpeg')
    return {
      status: ok ? 'available' : 'unavailable',
      checkedAt,
      httpStatus: response.status,
    }
  } catch {
    // Network failure / timeout - honest "unknown", never reported available.
    return { status: 'unknown', checkedAt, httpStatus: null }
  }
}

async function checkWithCache(key: string, url: string): Promise<LiveCheckResult> {
  const cached = cache.get(key)
  if (cached && cached.expiresAt > Date.now()) return cached.result

  const existing = inflight.get(key)
  if (existing) return existing

  const promise = performCheck(url)
    .then((result) => {
      cache.set(key, {
        result,
        expiresAt: Date.now() + (result.status === 'available' ? OK_TTL_MS : FAIL_TTL_MS),
      })
      return result
    })
    .finally(() => {
      inflight.delete(key)
    })
  inflight.set(key, promise)
  return promise
}

/**
 * Live availability of a recitation style (sample: Al-Fatiha 1:1).
 * Returns null when the style id or URL is invalid (never a fabricated guess).
 */
export async function verifyStyleLive(styleId: string): Promise<LiveCheckResult | null> {
  const style = getStyleDefinition(styleId)
  if (!style) return null
  const url = everyAyahFileUrl(style.folder, 1, 1)
  if (!url) return null
  return checkWithCache(`${styleId}:s1`, url)
}

/**
 * Live availability of a sura's audio for a style (sample: the sura's first
 * ayah). Returns null for invalid style/sura references.
 */
export async function verifySuraLive(styleId: string, sura: number): Promise<LiveCheckResult | null> {
  const style = getStyleDefinition(styleId)
  if (!style) return null
  const ayahCount = getSuraAyahCount(sura)
  if (ayahCount === 0) return null
  const url = everyAyahFileUrl(style.folder, sura, 1)
  if (!url) return null
  return checkWithCache(cacheKey(styleId, sura), url)
}
