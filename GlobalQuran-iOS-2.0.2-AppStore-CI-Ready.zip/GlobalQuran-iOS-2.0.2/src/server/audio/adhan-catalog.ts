/**
 * Global Quran - VERIFIED Adhan (call to prayer) recording catalog.
 *
 * PROMPT 13. Every entry in this catalog was verified by hand before being
 * listed (the same honesty rule as the Quran recitation library):
 *
 * - Source: the official AlAdhan download page
 *   https://aladhan.com/download-adhans, which publishes these recordings
 *   as MP3 downloads for personal use. The project owner has approved this
 *   audio source and its licensing for use in the application.
 * - Identity: each label below is the EXACT title published on that page.
 *   Country/mosque info is included ONLY where the official page states it.
 *   Unlabeled files that exist on the same CDN (a5, a6, a8, a10) are NOT
 *   listed - no identity may be guessed. A non-muezzin choral work published
 *   on the same page (Karl Jenkins' "Mass for Peace") is excluded on
 *   purpose: this library contains only authentic Adhan recordings by real
 *   muezzins.
 * - Byte sizes: verified with HTTP HEAD against the CDN
 *   (https://cdn.aladhan.com/audio/adhans/<file>.mp3) at implementation
 *   time; the live catalog route re-probes and overrides when possible.
 * - Durations: verified by decoding the actual files (44.1 kHz stereo MP3).
 * - No recording is ever generated, synthesized, or imitated; playback always
 *   uses the real published files.
 */

import type { AdhanCatalogEntry } from '@/types'

export const ADHAN_SOURCE_PAGE = 'https://aladhan.com/download-adhans'
export const ADHAN_CDN_BASE = 'https://cdn.aladhan.com/audio/adhans'
export const ADHAN_LICENSE_NOTE =
  'Adhan recordings published by AlAdhan for download and personal use. Usage approved for this application by the project owner. Attribution preserved: AlAdhan (aladhan.com).'

/** The verified library: six authentic recordings by four muezzins. */
export const ADHAN_CATALOG: AdhanCatalogEntry[] = [
  {
    id: 'alafasy-1',
    fileName: 'a9.mp3',
    title: "Yet Another Adhan by Mishary Rashid Alafasy",
    titleAr: 'أذان آخر بالمؤذن مشاري راشد العفاسي',
    muezzinEn: 'Mishary Rashid Alafasy',
    muezzinAr: 'مشاري راشد العفاسي',
    country: null,
    url: `${ADHAN_CDN_BASE}/a9.mp3`,
    sizeBytes: 4114842,
    durationSeconds: 257.1,
    format: 'mp3',
    attribution: 'AlAdhan (aladhan.com/download-adhans)',
  },
  {
    id: 'alafasy-dubai',
    fileName: 'a4.mp3',
    title: "Adhan from Dubai's One TV by Mishary Rashid Alafasy",
    titleAr: 'أذان من تلفزيون دبي مع مشاري راشد العفاسي',
    muezzinEn: 'Mishary Rashid Alafasy',
    muezzinAr: 'مشاري راشد العفاسي',
    country: 'Dubai, UAE (One TV)',
    url: `${ADHAN_CDN_BASE}/a4.mp3`,
    sizeBytes: 5375044,
    durationSeconds: 215.2,
    format: 'mp3',
    attribution: 'AlAdhan (aladhan.com/download-adhans)',
  },
  {
    id: 'alafasy-2',
    fileName: 'a7.mp3',
    title: 'Another Adhan by Mishary Rashid Alafasy',
    titleAr: 'أذان آخر للمؤذن مشاري راشد العفاسي',
    muezzinEn: 'Mishary Rashid Alafasy',
    muezzinAr: 'مشاري راشد العفاسي',
    country: null,
    url: `${ADHAN_CDN_BASE}/a7.mp3`,
    sizeBytes: 3881483,
    durationSeconds: 242.6,
    format: 'mp3',
    attribution: 'AlAdhan (aladhan.com/download-adhans)',
  },
  {
    id: 'ahmad-al-nafees',
    fileName: 'a1.mp3',
    title: 'Adhan by Ahmad al-Nafees',
    titleAr: 'أذان المؤذن أحمد النفيس',
    muezzinEn: 'Ahmad al-Nafees',
    muezzinAr: 'أحمد النفيس',
    country: null,
    url: `${ADHAN_CDN_BASE}/a1.mp3`,
    sizeBytes: 3418938,
    durationSeconds: 213.7,
    format: 'mp3',
    attribution: 'AlAdhan (aladhan.com/download-adhans)',
  },
  {
    id: 'mustafa-ozcan',
    fileName: 'a2.mp3',
    title: 'Adhan by Hafiz Mustafa Özcan from Turkey',
    titleAr: 'أذان الحافظ مصطفى أوزجان من تركيا',
    muezzinEn: 'Hafiz Mustafa Özcan',
    muezzinAr: 'حافظ مصطفى أوزجان',
    country: 'Turkey',
    url: `${ADHAN_CDN_BASE}/a2.mp3`,
    sizeBytes: 3805132,
    durationSeconds: 237.8,
    format: 'mp3',
    attribution: 'AlAdhan (aladhan.com/download-adhans)',
  },
  {
    id: 'mansour-al-zahrani',
    fileName: 'a11-mansour-al-zahrani.mp3',
    title: 'Adhan by Mansour Al-Zahrani',
    titleAr: 'أذان المؤذن منصور الزهراني',
    muezzinEn: 'Mansour Al-Zahrani',
    muezzinAr: 'منصور الزهراني',
    country: null,
    url: `${ADHAN_CDN_BASE}/a11-mansour-al-zahrani.mp3`,
    sizeBytes: 3358625,
    durationSeconds: 131.6,
    format: 'mp3',
    attribution: 'AlAdhan (aladhan.com/download-adhans)',
  },
]

const byId = new Map(ADHAN_CATALOG.map((entry) => [entry.id, entry]))

/** One verified catalog entry by id (null for unknown ids - never guessed). */
export function getAdhanById(id: string): AdhanCatalogEntry | null {
  return byId.get(id) ?? null
}

/** Only URLs from the verified catalog are ever fetched (no user-built URLs). */
export function isVerifiedAdhanUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl)
    if (url.protocol !== 'https:') return false
    if (url.hostname !== 'cdn.aladhan.com') return false
    if (!url.pathname.startsWith('/audio/adhans/')) return false
    return ADHAN_CATALOG.some((entry) => entry.url === rawUrl)
  } catch {
    return false
  }
}

/**
 * Live size probe of the source CDN (HEAD, Range 0-0), cached in memory for
 * 10 minutes. Returns the exact total size when reachable, null otherwise.
 * Failure is honest and non-fatal: the catalog keeps its seed-verified
 * sizes, and the actual file download remains the real verification.
 */
const probeCache = new Map<string, { at: number; size: number | null }>()
const PROBE_TTL_MS = 10 * 60 * 1000

export async function probeAdhanSize(url: string): Promise<number | null> {
  const cached = probeCache.get(url)
  if (cached && Date.now() - cached.at < PROBE_TTL_MS) return cached.size
  let size: number | null = null
  try {
    const response = await fetch(url, {
      method: 'HEAD',
      credentials: 'omit',
      signal: AbortSignal.timeout(8000),
      cache: 'no-store',
      headers: { Accept: 'audio/mpeg, */*' },
    })
    if (response.ok) {
      const length = Number(response.headers.get('content-length'))
      if (Number.isSafeInteger(length) && length > 0) size = length
    }
  } catch {
    size = null
  }
  probeCache.set(url, { at: Date.now(), size })
  return size
}
