/**
 * QuranEnc recorded translation narration audio (PROMPT 10) - isomorphic
 * module (used by the API routes AND the native adapter).
 *
 * Source of truth: QuranEnc's official audio developers dashboard
 * (https://d.quranenc.com/data/audio/) and the per-translation JSON
 * manifests it publishes (files.json). The documented file URL contract is:
 *
 *   https://d.quranenc.com/data/audio/{translation_key}/{sura_3digits}{aya_3digits}.mp3
 *
 * Honesty rules (verbatim from the PROMPT 10 requirements):
 * - The audio catalog is DISCOVERED dynamically from the dashboard - never
 *   a hardcoded list of languages or translations.
 * - A translation is only reported as having recorded audio AFTER its
 *   files.json manifest was actually fetched and parsed.
 * - Not every Quran translation has recorded audio; most do not.
 * - File existence for a given (translation, sura, ayah) is answered from
 *   the real manifest - a file the source does not list is never offered,
 *   never played and never downloaded.
 * - Exact byte sizes are probed live (HEAD, cached); a complete-package
 *   size is a clearly-flagged SAMPLED ESTIMATE, never presented as exact.
 */

import { z } from 'zod'

import { getSuraAyahCount } from '@/lib/audio/urls'
import type { TranslationAudioCatalogEntry } from '@/types'

export const QURANENC_AUDIO_DASHBOARD_URL = 'https://d.quranenc.com/data/audio/'
export const QURANENC_AUDIO_BASE_URL = 'https://d.quranenc.com/data/audio/'
export const QURANENC_AUDIO_SOURCE_NAME = 'QuranEnc'

/** Dashboard + manifest cache lifetime. */
const CATALOG_TTL_MS = 24 * 60 * 60 * 1000
/** Stale-serving window after expiry (a failed refresh serves stale data). */
const CATALOG_STALE_MS = 7 * 24 * 60 * 60 * 1000
const FETCH_TIMEOUT_MS = 20_000
/** Size probe caches: successes live long, failures briefly. */
const SIZE_TTL_MS = 6 * 60 * 60 * 1000
const SIZE_FAIL_TTL_MS = 5 * 60 * 1000
/** Parallel HEAD probes for batch plans (bounded; the CDN handles it). */
const PROBE_CONCURRENCY = 14
/** Sample size for complete-package estimates. */
const ESTIMATE_SAMPLE_SIZE = 40

const TOTAL_QURAN_AYAT = 6236

/* ------------------------------------------------------------------ */
/* URL construction                                                    */
/* ------------------------------------------------------------------ */

function pad3(value: number): string {
  return String(value).padStart(3, '0')
}

/**
 * The documented QuranEnc translation audio URL. Returns null for
 * structurally invalid references - never a guessed URL.
 */
export function quranEncTranslationAudioUrl(
  translationKey: string,
  sura: number,
  ayah: number,
): string | null {
  if (!/^[a-z0-9_]+$/.test(translationKey)) return null
  if (getSuraAyahCount(sura) === 0) return null
  if (!Number.isInteger(ayah) || ayah < 1 || ayah > getSuraAyahCount(sura)) return null
  return `${QURANENC_AUDIO_BASE_URL}${translationKey}/${pad3(sura)}${pad3(ayah)}.mp3`
}

/* ------------------------------------------------------------------ */
/* Manifest schema                                                     */
/* ------------------------------------------------------------------ */

const FilesManifestSchema = z.object({
  translation: z.string().min(1),
  generated: z.string().optional().nullable(),
  available: z.number().int().nonnegative(),
  total: z.number().int().nonnegative(),
  base_url: z.string().optional().nullable(),
  files: z.array(z.string().regex(/^\d{6}\.mp3$/)),
})
export type TranslationFilesManifest = z.infer<typeof FilesManifestSchema>

/** One dashboard card entry (parsed from the dashboard HTML). */
interface DashboardEntry {
  key: string
  name: string
}

interface CatalogCacheEntry {
  entries: Array<{ dashboard: DashboardEntry; manifest: TranslationFilesManifest }>
  fetchedAt: number
  expiresAt: number
}

let catalogCache: CatalogCacheEntry | null = null
let catalogInflight: Promise<CatalogCacheEntry> | null = null

/* ------------------------------------------------------------------ */
/* Dashboard + manifest discovery                                      */
/* ------------------------------------------------------------------ */

/** Fetch and parse the audio dashboard (the dynamic folder list). */
async function fetchDashboardEntries(): Promise<DashboardEntry[]> {
  const response = await fetch(QURANENC_AUDIO_DASHBOARD_URL, {
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    headers: { Accept: 'text/html, */*' },
    cache: 'no-store',
  })
  if (!response.ok) {
    throw new Error(`QuranEnc audio dashboard responded ${response.status}`)
  }
  const html = await response.text()

  // The dashboard renders one <a class="card" href="./{key}/index.html">
  // per translation audio folder, followed by the display name and the
  // verified file counts. Parse defensively: anything unmatched is skipped.
  const entries: DashboardEntry[] = []
  const seen = new Set<string>()
  const parts = html.split(/href="\.\/([a-z0-9_]+)\/index\.html"/)
  for (let i = 1; i < parts.length; i += 2) {
    const key = parts[i]
    if (seen.has(key)) continue
    seen.add(key)
    // The card body follows the href; the display name is the
    // `card-name` span inside the card header.
    const body = parts[i + 1] ?? ''
    const nameMatch = body.match(/<span[^>]*class="[^"]*card-name[^"]*"[^>]*>([\s\S]*?)<\/span>/)
    let name = ''
    if (nameMatch) {
      name = nameMatch[1]
        .replace(/&amp;/g, '&')
        .replace(/&#39;|&rsquo;/g, '\u2019')
        .replace(/&[a-z#0-9]+;/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
    }
    entries.push({ key, name })
  }
  return entries
}

/** Fetch and validate one translation's files.json manifest. */
async function fetchFilesManifest(translationKey: string): Promise<TranslationFilesManifest | null> {
  try {
    const response = await fetch(`${QURANENC_AUDIO_BASE_URL}${translationKey}/files.json`, {
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
      headers: { Accept: 'application/json, */*' },
      cache: 'no-store',
    })
    if (!response.ok) return null
    const parsed = FilesManifestSchema.safeParse(await response.json())
    return parsed.success ? parsed.data : null
  } catch {
    return null
  }
}

/**
 * The discovered + verified translation audio catalog: every dashboard
 * folder whose files.json manifest was actually fetched and validated.
 * TTL-cached with stale-while-error semantics.
 */
async function loadCatalogRecords(): Promise<CatalogCacheEntry> {
  const now = Date.now()
  if (catalogCache && catalogCache.expiresAt > now) return catalogCache
  if (catalogInflight) return catalogInflight

  catalogInflight = (async () => {
    const dashboard = await fetchDashboardEntries()
    const settled = await Promise.all(
      dashboard.map(async (entry) => ({
        dashboard: entry,
        manifest: await fetchFilesManifest(entry.key),
      })),
    )
    const records = settled.filter(
      (item): item is { dashboard: DashboardEntry; manifest: TranslationFilesManifest } =>
        item.manifest !== null,
    )
    const fresh: CatalogCacheEntry = {
      entries: records,
      fetchedAt: now,
      expiresAt: now + CATALOG_TTL_MS,
    }
    catalogCache = fresh
    return fresh
  })()

  try {
    return await catalogInflight
  } catch (error) {
    // Stale data beats no data (within the stale window).
    if (catalogCache && now - catalogCache.fetchedAt < CATALOG_STALE_MS) {
      return catalogCache
    }
    throw error
  } finally {
    catalogInflight = null
  }
}

/** Parse `001001.mp3` into (sura, ayah); null when malformed. */
function parseFileName(fileName: string): { sura: number; ayah: number } | null {
  const sura = Number(fileName.slice(0, 3))
  const ayah = Number(fileName.slice(3, 6))
  if (!Number.isInteger(sura) || !Number.isInteger(ayah)) return null
  if (getSuraAyahCount(sura) === 0) return null
  if (ayah < 1 || ayah > getSuraAyahCount(sura)) return null
  return { sura, ayah }
}

/** The verified manifest of one translation (null when it has no audio). */
export async function getTranslationFilesManifest(
  translationKey: string,
): Promise<TranslationFilesManifest | null> {
  if (!/^[a-z0-9_]+$/.test(translationKey)) return null
  const cache = await loadCatalogRecords()
  const record = cache.entries.find((entry) => entry.dashboard.key === translationKey)
  return record?.manifest ?? null
}

/** Every (sura, ayah) the source manifest actually lists for a translation. */
export async function getTranslationAudioInventory(
  translationKey: string,
): Promise<Map<number, Set<number>> | null> {
  const manifest = await getTranslationFilesManifest(translationKey)
  if (!manifest) return null
  const bySura = new Map<number, Set<number>>()
  for (const fileName of manifest.files) {
    const position = parseFileName(fileName)
    if (!position) continue
    const set = bySura.get(position.sura)
    if (set) set.add(position.ayah)
    else bySura.set(position.sura, new Set([position.ayah]))
  }
  return bySura
}

/**
 * The verified catalog entries, cross-referenced with the text translation
 * catalog (for language metadata). `textLookup` maps a translation key to
 * its language metadata; when unavailable the fields stay null - the entry
 * is still listed (its manifest IS verified) with honest nulls.
 */
export async function getTranslationAudioCatalog(textLookup?: (
  translationKey: string,
) => {
  title: string | null
  languageIso: string | null
  languageName: string | null
  direction: 'ltr' | 'rtl' | null
} | null): Promise<TranslationAudioCatalogEntry[]> {
  const cache = await loadCatalogRecords()
  return cache.entries.map(({ dashboard, manifest }) => {
    const text = textLookup?.(dashboard.key) ?? null
    return {
      translationKey: dashboard.key,
      audioName: dashboard.name || manifest.translation,
      textTitle: text?.title ?? null,
      languageIso: text?.languageIso ?? null,
      languageName: text?.languageName ?? null,
      direction: text?.direction ?? null,
      availableFiles: manifest.files.length,
      totalFiles: TOTAL_QURAN_AYAT,
      complete: manifest.files.length >= TOTAL_QURAN_AYAT,
      generatedAt: manifest.generated ?? null,
      sourceName: QURANENC_AUDIO_SOURCE_NAME,
    }
  })
}

/* ------------------------------------------------------------------ */
/* Live checks and size probes                                         */
/* ------------------------------------------------------------------ */

export interface TranslationAudioLiveCheck {
  status: 'available' | 'unavailable' | 'unknown'
  checkedAt: string
  httpStatus: number | null
}

const liveCache = new Map<string, { result: TranslationAudioLiveCheck; expiresAt: number }>()
const liveInflight = new Map<string, Promise<TranslationAudioLiveCheck>>()

/** Live reachability of one translation audio file at the CDN. */
export async function verifyTranslationAudioLive(
  translationKey: string,
  sura: number,
  ayah: number,
): Promise<TranslationAudioLiveCheck> {
  const key = `${translationKey}:${sura}:${ayah}`
  const cached = liveCache.get(key)
  if (cached && cached.expiresAt > Date.now()) return cached.result

  const existing = liveInflight.get(key)
  if (existing) return existing

  const url = quranEncTranslationAudioUrl(translationKey, sura, ayah)
  const checkedAt = new Date().toISOString()
  const promise = (async (): Promise<TranslationAudioLiveCheck> => {
    if (!url) return { status: 'unavailable', checkedAt, httpStatus: null }
    try {
      const response = await fetch(url, {
        method: 'HEAD',
        signal: AbortSignal.timeout(12_000),
        headers: { Accept: 'audio/mpeg, */*' },
        cache: 'no-store',
      })
      const ok =
        (response.status === 200 || response.status === 206) &&
        (response.headers.get('content-type') ?? '').toLowerCase().includes('audio')
      return {
        status: ok ? 'available' : 'unavailable',
        checkedAt,
        httpStatus: response.status,
      }
    } catch {
      return { status: 'unknown', checkedAt, httpStatus: null }
    }
  })()

  liveInflight.set(key, promise)
  try {
    const result = await promise
    liveCache.set(key, {
      result,
      expiresAt: Date.now() + (result.status === 'available' ? 10 * 60 * 1000 : 90 * 1000),
    })
    return result
  } finally {
    liveInflight.delete(key)
  }
}

const sizeCache = new Map<string, { size: number | null; expiresAt: number }>()
const sizeInflight = new Map<string, Promise<number | null>>()

/** Exact byte size of one translation audio file (HEAD probe, cached). */
export async function probeTranslationAudioSize(
  translationKey: string,
  sura: number,
  ayah: number,
): Promise<number | null> {
  const key = `${translationKey}:${sura}:${ayah}`
  const cached = sizeCache.get(key)
  if (cached && cached.expiresAt > Date.now()) return cached.size

  const existing = sizeInflight.get(key)
  if (existing) return existing

  const url = quranEncTranslationAudioUrl(translationKey, sura, ayah)
  const promise = (async (): Promise<number | null> => {
    if (!url) return null
    try {
      const response = await fetch(url, {
        method: 'HEAD',
        signal: AbortSignal.timeout(12_000),
        headers: { Accept: 'audio/mpeg, */*' },
        cache: 'no-store',
      })
      if (!response.ok) return null
      const length = Number(response.headers.get('content-length'))
      return Number.isFinite(length) && length > 0 ? length : null
    } catch {
      return null
    }
  })()

  sizeInflight.set(key, promise)
  try {
    const size = await promise
    sizeCache.set(key, {
      size,
      expiresAt: Date.now() + (size !== null ? SIZE_TTL_MS : SIZE_FAIL_TTL_MS),
    })
    return size
  } finally {
    sizeInflight.delete(key)
  }
}

/**
 * Probe the sizes of a list of files with bounded concurrency. Files whose
 * probe fails get size 0 (the plan reports the count of unprobed files so
 * the UI can stay honest about the exactness of the total).
 */
export async function probeTranslationAudioSizes(
  translationKey: string,
  positions: Array<{ sura: number; ayah: number }>,
): Promise<{ files: Array<{ sura: number; ayah: number; sizeBytes: number }>; unprobed: number }> {
  const results: Array<{ sura: number; ayah: number; sizeBytes: number }> = []
  let unprobed = 0
  let cursor = 0

  async function worker(): Promise<void> {
    while (cursor < positions.length) {
      const position = positions[cursor]
      cursor += 1
      const size = await probeTranslationAudioSize(translationKey, position.sura, position.ayah)
      if (size === null) {
        unprobed += 1
        results.push({ ...position, sizeBytes: 0 })
      } else {
        results.push({ ...position, sizeBytes: size })
      }
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(PROBE_CONCURRENCY, Math.max(positions.length, 1)) }, worker),
  )
  return { files: results, unprobed }
}

/**
 * SAMPLED size estimate for a large batch (the complete package): probes a
 * deterministic spread of the verified files and scales the mean. Always
 * flagged as an estimate by the caller - never presented as exact.
 */
export async function estimateTranslationAudioSize(
  translationKey: string,
  positions: Array<{ sura: number; ayah: number }>,
): Promise<{ estimatedBytes: number; sampleCount: number }> {
  if (positions.length === 0) return { estimatedBytes: 0, sampleCount: 0 }
  const sampleCount = Math.min(ESTIMATE_SAMPLE_SIZE, positions.length)
  const step = Math.max(1, Math.floor(positions.length / sampleCount))
  const sample: Array<{ sura: number; ayah: number }> = []
  for (let i = 0; i < positions.length && sample.length < sampleCount; i += step) {
    sample.push(positions[i])
  }
  const probed: number[] = []
  for (const position of sample) {
    const size = await probeTranslationAudioSize(translationKey, position.sura, position.ayah)
    if (size !== null) probed.push(size)
  }
  if (probed.length === 0) return { estimatedBytes: 0, sampleCount: 0 }
  const mean = probed.reduce((sum, value) => sum + value, 0) / probed.length
  return { estimatedBytes: Math.round(mean * positions.length), sampleCount: probed.length }
}
