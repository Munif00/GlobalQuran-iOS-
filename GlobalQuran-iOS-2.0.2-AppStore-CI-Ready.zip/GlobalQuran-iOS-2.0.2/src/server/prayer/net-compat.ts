/**
 * Global Quran - Server-side network compatibility.
 *
 * Some hosting environments (including this app's sandbox) have no IPv6
 * egress while DNS still returns AAAA records. Node's default Happy-Eyeballs
 * behavior (`autoSelectFamily: true`) can then hang and fail with an
 * AggregateError even though the IPv4 route works perfectly - curl and Bun
 * fall back cleanly, Node's global fetch does not.
 *
 * Fix (documented Node APIs, applied once at module load):
 * - Disable auto-select-family (no IPv6 attempt racing the IPv4 one).
 * - Prefer IPv4 in DNS result order.
 *
 * Both calls are safe no-ops on runtimes that do not implement them.
 */

import dns from 'node:dns'
import net from 'node:net'

let applied = false

export function ensureEgressCompatibility(): void {
  if (applied) return
  applied = true
  try {
    net.setDefaultAutoSelectFamily(false)
  } catch {
    // Not implemented (e.g. some runtimes) - ignore.
  }
  try {
    dns.setDefaultResultOrder('ipv4first')
  } catch {
    // Not implemented - ignore.
  }
}
