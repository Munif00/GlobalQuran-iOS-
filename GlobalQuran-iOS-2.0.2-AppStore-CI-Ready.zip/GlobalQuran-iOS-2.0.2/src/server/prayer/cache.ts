/**
 * Global Quran - Prayer-time cache (Prisma/SQLite backed).
 *
 * Policy (per the offline honesty requirements):
 * - Successful upstream fetches are cached keyed by source + date-range +
 *   location + calculation parameters (NOT adjustments - those are applied
 *   app-side at serve time).
 * - Fresh (< 24h) cached payloads are served directly as a read-through
 *   cache; older payloads are only served when the upstream tier fails.
 * - EVERY payload served from this cache is labeled `isCached: true` with
 *   its original `fetchedAt` - cached data is never presented as a fresh
 *   upstream verification.
 *
 * This module implements the platform-agnostic PrayerCachePort
 * (src/lib/prayer-engine/cache-port.ts) for the web server and registers
 * itself when the server barrel (src/server/prayer/index.ts) is imported.
 */

import { db } from '@/lib/db'
import {
  setPrayerCache,
  type CacheReadResult,
  type CachedPrayerPayload,
  type PrayerCachePort,
} from '@/lib/prayer-engine/cache-port'

export type { CachedPrayerPayload }
export { coordKeyPart } from '@/lib/prayer-engine/cache-port'

/**
 * Rows older than this are pruned opportunistically: they can only ever be
 * served as stale fallbacks, and prayer data for a past date range has no
 * fallback value once the range has fully passed.
 */
const PRUNE_AFTER_MS = 60 * 24 * 3600_000 // 60 days

/** Prune at most once per hour (module-level timestamp; single-instance app). */
const PRUNE_INTERVAL_MS = 3600_000
let lastPrunedAt = 0

/** Best-effort pruning of old cache rows; never blocks or breaks requests. */
async function pruneOldRows(): Promise<void> {
  const now = Date.now()
  if (now - lastPrunedAt < PRUNE_INTERVAL_MS) return
  lastPrunedAt = now
  try {
    const cutoff = new Date(now - PRUNE_AFTER_MS)
    await db.prayerTimeCache.deleteMany({ where: { fetchedAt: { lt: cutoff } } })
  } catch {
    // Pruning is hygiene, not correctness - ignore failures.
  }
}

/** The web-server cache backend (Prisma/SQLite). */
const prismaPrayerCache: PrayerCachePort = {
  async read(key: string): Promise<CacheReadResult | null> {
    try {
      const row = await db.prayerTimeCache.findUnique({ where: { cacheKey: key } })
      if (!row) return null
      const payload = JSON.parse(row.payload) as CachedPrayerPayload
      if (!Array.isArray(payload?.days) || payload.days.length === 0) return null
      return { ...payload, fetchedAt: row.fetchedAt.toISOString(), isCached: true }
    } catch {
      // Cache failures must never break the request path.
      return null
    }
  },

  async write(entry: {
    cacheKey: string
    kind: 'day' | 'month' | 'year'
    dateLabel: string
    sourceType: string
    sourceName: string
    payload: CachedPrayerPayload
  }): Promise<void> {
    try {
      await db.prayerTimeCache.upsert({
        where: { cacheKey: entry.cacheKey },
        create: {
          cacheKey: entry.cacheKey,
          kind: entry.kind,
          dateLabel: entry.dateLabel,
          sourceType: entry.sourceType,
          sourceName: entry.sourceName,
          payload: JSON.stringify(entry.payload),
          fetchedAt: new Date(),
        },
        update: {
          kind: entry.kind,
          dateLabel: entry.dateLabel,
          sourceType: entry.sourceType,
          sourceName: entry.sourceName,
          payload: JSON.stringify(entry.payload),
          fetchedAt: new Date(),
        },
      })
      // Opportunistic hygiene: keep the table bounded over long uptimes.
      void pruneOldRows()
    } catch (error) {
      // Best-effort only - cache failures must never break the request path.
      console.warn('[prayer-cache-write]', String(error).slice(0, 200))
    }
  },
}

setPrayerCache(prismaPrayerCache)
