/**
 * Global Quran - Web-server prayer engine wiring.
 *
 * Importing this barrel:
 * 1. applies the Node egress compatibility fix (see net-compat.ts),
 * 2. registers the Prisma/SQLite prayer cache backend,
 * 3. forwards the Nominatim usage-policy contact from the environment,
 * 4. re-exports the shared (isomorphic) prayer engine API.
 *
 * The engine itself lives in src/lib/prayer-engine/ and contains no
 * platform-specific code; this module is the server-side composition root.
 * The native app composes the same engine with an IndexedDB cache instead
 * (src/services/native/).
 */

import { ensureEgressCompatibility } from './net-compat'

// Apply the sandbox/Node egress fix before any upstream request can run.
ensureEgressCompatibility()

// Register the Prisma cache backend (side effect of the import).
import './cache'

import { setGeocodingContact } from '@/lib/prayer-engine/geocoding'

// Nominatim usage policy: forward the operator-configured contact, if any.
setGeocodingContact(process.env.NOMINATIM_CONTACT?.trim() || null)

export { coordKeyPart } from './cache'
export {
  resolvePrayerDay,
  resolvePrayerMonth,
  type PrayerRequestContext,
} from '@/lib/prayer-engine/resolver'
export { parsePrayerQuery, type ParsedPrayerQuery, type ParseResult } from '@/lib/prayer-engine/request'
export {
  searchCities,
  reverseGeocode,
  type CitySearchOutcome,
  type GeocodingTransport,
} from '@/lib/prayer-engine/geocoding'
