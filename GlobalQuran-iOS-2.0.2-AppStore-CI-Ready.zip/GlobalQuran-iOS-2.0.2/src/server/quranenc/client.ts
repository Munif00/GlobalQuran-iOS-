/**
 * QuranEnc API v1 server client.
 *
 * Every endpoint, path segment, parameter and response field below is taken
 * from the official API documentation (https://quranenc.com/en/home/api/ and
 * its machine-readable OpenAPI spec at https://quranenc.com/openapi.json).
 * Nothing is guessed:
 * - GET /translations/languages            -> { languages: string[] }
 * - GET /translations/isocodes             -> { languages_isocodes, isocodes_languages }
 * - GET /translations/locales              -> { locales: string[] }
 * - GET /translations/list?localization=   -> { translations: [...] }
 * - GET /translations/sowar_locales        -> { locales: string[] }
 * - GET /translations/sowar_names?iso_code -> { "1".."114": string }
 * - GET /translation/sura/{key}/{sura}     -> { result: Aya[] }
 * - GET /translations/updates?key=         -> version info (used by tests/sync)
 *
 * The client is server-side only. It adds:
 * - zod validation of every upstream response (malformed data is rejected),
 * - request timeouts,
 * - in-memory TTL caching with stale-while-error revalidation so the source
 *   is never hammered with repeated requests,
 * - control-character sanitizing of all text that reaches the client.
 */

import { z } from 'zod'

import { SUPPLEMENTAL_TRANSLATIONS, type SupplementalTranslation } from './supplemental-registry'
import { stripControlCharacters } from '@/utils/text-normalize'

export const QURANENC_API_BASE = 'https://quranenc.com/api/v1'
export const QURANENC_SITE_URL = 'https://quranenc.com'
export const QURANENC_API_DOCS_URL = 'https://quranenc.com/en/home/api/'

/** Upstream request timeout. */
const REQUEST_TIMEOUT_MS = 20_000
/** Catalog / language metadata cache lifetime. */
const CATALOG_TTL_MS = 6 * 60 * 60 * 1000 // 6 hours
/** Sura content cache lifetime (text editions change rarely). */
const SURA_TTL_MS = 24 * 60 * 60 * 1000 // 24 hours
/** Sura names cache lifetime. */
const SURA_NAMES_TTL_MS = 7 * 24 * 60 * 60 * 1000 // 7 days

/* ------------------------------------------------------------------ */
/* Response schemas (documented shapes, nulls allowed where documented) */
/* ------------------------------------------------------------------ */

const nullableString = z.union([z.string(), z.null()]).optional()
const nullableNumber = z.union([z.number(), z.null()]).optional()

/** Documented `Translation` object of GET /translations/list. */
export const QuranEncTranslationSchema = z.object({
  key: z.string().min(1),
  direction: z.enum(['ltr', 'rtl']),
  language_iso_code: z.string().min(1),
  version: nullableString,
  last_update: nullableNumber,
  title: nullableString,
  description: nullableString,
  file: nullableString,
  database_url: nullableString,
  database_uncompressed_url: nullableString,
  pdf_url: nullableString,
  pdf_size: nullableNumber,
  pdf_cover: nullableString,
  pdf_pure_url: nullableString,
  pdf_pure_size: nullableNumber,
  pdf_pure_cover: nullableString,
  pdf_mobile_url: nullableString,
  pdf_mobile_size: nullableNumber,
  pdf_mobile_cover: nullableString,
  epub_url: nullableString,
  epub_size: nullableNumber,
})
export type QuranEncTranslation = z.infer<typeof QuranEncTranslationSchema>

const TranslationListSchema = z.object({
  translations: z.array(QuranEncTranslationSchema),
})

const LanguagesSchema = z.object({
  languages: z.array(z.string()),
})

const IsoCodesSchema = z.object({
  languages_isocodes: z.record(z.string(), z.string()),
  isocodes_languages: z.record(z.string(), z.string()),
})

const LocalesSchema = z.object({
  locales: z.array(z.string()),
})

/** Documented `Aya` object (numbers are returned as strings by the source). */
const AyaSchema = z.object({
  id: z.union([z.string(), z.number()]).optional(),
  sura: z.union([z.string(), z.number()]),
  aya: z.union([z.string(), z.number()]),
  arabic_text: z.string(),
  translation: z.string(),
  footnotes: nullableString,
})
export type QuranEncAya = z.infer<typeof AyaSchema>

const SuraResponseSchema = z.object({
  result: z.union([z.array(AyaSchema), z.null()]).optional(),
})

const SuraNamesSchema = z.record(z.string(), z.string())

/* ------------------------------------------------------------------ */
/* Cache                                                              */
/* ------------------------------------------------------------------ */

interface CacheEntry<T> {
  value: T
  expiresAt: number
  /** Kept after expiry so a failed refresh can still serve stale data. */
  fetchedAt: number
}

const cache = new Map<string, CacheEntry<unknown>>()

/**
 * Upper bound on cached entries. The working set is inherently bounded
 * (114 suras x the few translations actually requested, plus metadata), so
 * this cap is defense-in-depth against pathological usage - when reached,
 * the oldest entries are dropped first (Map preserves insertion order) and
 * fresh entries are never evicted in favor of stale ones when avoidable.
 */
const MAX_CACHE_ENTRIES = 600

function cacheGet<T>(key: string): { value: T; fresh: boolean } | null {
  const entry = cache.get(key) as CacheEntry<T> | undefined
  if (!entry) return null
  return { value: entry.value, fresh: Date.now() < entry.expiresAt }
}

function cacheSet<T>(key: string, value: T, ttlMs: number): void {
  if (cache.size >= MAX_CACHE_ENTRIES && !cache.has(key)) {
    // Prefer dropping long-stale entries; otherwise drop the oldest.
    const now = Date.now()
    let staleKey: string | null = null
    let oldestKey: string | null = null
    let oldestFetchedAt = Infinity
    for (const [entryKey, entry] of cache) {
      if (entry.expiresAt < now) {
        staleKey = entryKey
        break
      }
      if (entry.fetchedAt < oldestFetchedAt) {
        oldestFetchedAt = entry.fetchedAt
        oldestKey = entryKey
      }
    }
    cache.delete(staleKey ?? oldestKey ?? (cache.keys().next().value as string))
  }
  cache.set(key, { value, expiresAt: Date.now() + ttlMs, fetchedAt: Date.now() })
}

/* ------------------------------------------------------------------ */
/* Errors                                                             */
/* ------------------------------------------------------------------ */

export class QuranEncUpstreamError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'QuranEncUpstreamError'
  }
}

/* ------------------------------------------------------------------ */
/* Fetch core                                                         */
/* ------------------------------------------------------------------ */

function sanitizeText(value: string | null | undefined): string | null {
  if (typeof value !== 'string') return null
  const cleaned = stripControlCharacters(value)
  return cleaned.length > 0 ? cleaned : null
}

async function fetchJson<T>(path: string, schema: z.ZodType<T>): Promise<T> {
  const url = `${QURANENC_API_BASE}${path}`
  let response: Response
  try {
    response = await fetch(url, {
      headers: { Accept: 'application/json' },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      // Never send or store cookies - this is a public read-only API.
      credentials: 'omit',
      cache: 'no-store',
    })
  } catch (error) {
    console.error(`[quranenc] request failed: ${path}`, error instanceof Error ? error.message : error)
    throw new QuranEncUpstreamError('Upstream request failed')
  }

  if (response.status === 404) {
    throw new QuranEncUpstreamError('Not found at source')
  }
  if (!response.ok) {
    console.error(`[quranenc] upstream HTTP ${response.status}: ${path}`)
    throw new QuranEncUpstreamError(`Upstream returned HTTP ${response.status}`)
  }

  let raw: unknown
  try {
    raw = await response.json()
  } catch (error) {
    console.error(`[quranenc] invalid JSON: ${path}`, error instanceof Error ? error.message : error)
    throw new QuranEncUpstreamError('Upstream returned malformed JSON')
  }

  const parsed = schema.safeParse(raw)
  if (!parsed.success) {
    console.error(`[quranenc] schema validation failed: ${path}`, parsed.error.issues.slice(0, 5))
    throw new QuranEncUpstreamError('Upstream response failed validation')
  }
  return parsed.data
}

/**
 * Cached fetch: fresh cache is served directly; expired cache triggers a
 * refresh but the stale value is served if the refresh fails.
 */
async function fetchCached<T>(
  cacheKey: string,
  ttlMs: number,
  loader: () => Promise<T>,
): Promise<{ value: T; servedFromCache: boolean }> {
  const cached = cacheGet<T>(cacheKey)
  if (cached?.fresh) return { value: cached.value, servedFromCache: true }

  try {
    const value = await loader()
    cacheSet(cacheKey, value, ttlMs)
    return { value, servedFromCache: false }
  } catch (error) {
    if (cached) {
      // Serve stale data rather than failing the whole screen.
      return { value: cached.value, servedFromCache: true }
    }
    throw error
  }
}

/* ------------------------------------------------------------------ */
/* Endpoints                                                          */
/* ------------------------------------------------------------------ */

/** Map our locale codes to ISO codes the source accepts (e.g. zh-Hans -> zh).
 * Inputs longer than any legitimate BCP 47 tag fall back to English - this
 * also bounds the in-memory cache keys derived from the result. */
export function toSourceIsoCode(locale: string): string {
  if (locale.length > 35) return 'en'
  const lower = locale.toLowerCase()
  if (lower.startsWith('zh')) return 'zh'
  if (lower === 'fil') return 'tl'
  if (lower === 'nb' || lower === 'nb-no') return 'no'
  const base = lower.split('-')[0]
  return base
}

/** GET /translations/languages - ISO codes that have translations. */
export async function getLanguages(): Promise<string[]> {
  const { value } = await fetchCached('languages', CATALOG_TTL_MS, async () => {
    const data = await fetchJson('/translations/languages', LanguagesSchema)
    return data.languages
  })
  return value
}

/** GET /translations/isocodes - language name <-> ISO code maps. */
export async function getIsoCodes(): Promise<{ nameToCode: Record<string, string>; codeToName: Record<string, string> }> {
  const { value } = await fetchCached('isocodes', CATALOG_TTL_MS, async () => {
    const data = await fetchJson('/translations/isocodes', IsoCodesSchema)
    return { nameToCode: data.languages_isocodes, codeToName: data.isocodes_languages }
  })
  return value
}

/** GET /translations/locales - locales accepted by the `localization` param. */
export async function getLocales(): Promise<string[]> {
  const { value } = await fetchCached('locales', CATALOG_TTL_MS, async () => {
    const data = await fetchJson('/translations/locales', LocalesSchema)
    return data.locales
  })
  return value
}

export interface TranslationListResult {
  translations: QuranEncTranslation[]
  servedFromCache: boolean
}

/**
 * GET /translations/list - all available translations with full metadata.
 * `localization` localizes `title` and `description` (documented param).
 */
export async function getTranslationsList(localization: string): Promise<TranslationListResult> {
  const iso = toSourceIsoCode(localization)
  const { value, servedFromCache } = await fetchCached(
    `list:${iso}`,
    CATALOG_TTL_MS,
    async () => {
      const data = await fetchJson(
        `/translations/list?localization=${encodeURIComponent(iso)}`,
        TranslationListSchema,
      )
      // Sanitize text fields once, right at the boundary.
      return data.translations.map((item) => ({
        ...item,
        title: sanitizeText(item.title),
        description: sanitizeText(item.description),
      }))
    },
  )
  return { translations: value, servedFromCache }
}

/** Convert a verified supplemental registry record into the source record shape. */
function supplementalToTranslation(record: SupplementalTranslation): QuranEncTranslation {
  return {
    key: record.key,
    direction: record.direction,
    language_iso_code: record.languageIsoCode,
    version: record.version,
    last_update: record.lastUpdate,
    title: record.title,
    description: record.description,
    file: record.key,
    database_url: record.databaseUrl,
    database_uncompressed_url: record.databaseUncompressedUrl,
    pdf_url: null,
    pdf_size: null,
    pdf_cover: null,
    pdf_pure_url: null,
    pdf_pure_size: null,
    pdf_pure_cover: null,
    pdf_mobile_url: null,
    pdf_mobile_size: null,
    pdf_mobile_cover: null,
    epub_url: null,
    epub_size: null,
  }
}

/**
 * The live /translations/list response merged with the verified supplemental
 * registry (see supplemental-registry.ts for provenance).
 *
 * Merge rules:
 * - Supplemental records whose key is already in the live list are skipped -
 *   the live (localized) record always wins.
 * - Supplemental records are appended only when the live list actually loaded
 *   (a failed fetch must not turn the static registry into a "catalog").
 *
 * Every catalog consumer (library, reader metadata, downloads, offline packs,
 * export, verification) uses this so the app offers exactly what the source
 * publishes and serves - no more, no less.
 */
export async function getMergedTranslationsList(localization: string): Promise<TranslationListResult> {
  const { translations, servedFromCache } = await getTranslationsList(localization)
  if (translations.length === 0) {
    return { translations, servedFromCache }
  }
  const liveKeys = new Set(translations.map((item) => item.key))
  const merged = [...translations]
  for (const record of SUPPLEMENTAL_TRANSLATIONS) {
    if (liveKeys.has(record.key)) continue
    merged.push(supplementalToTranslation(record))
  }
  return { translations: merged, servedFromCache }
}

/** GET /translations/sowar_locales - locales with localized sura names. */
export async function getSuraNameLocales(): Promise<string[]> {
  const { value } = await fetchCached('sowar-locales', SURA_NAMES_TTL_MS, async () => {
    const data = await fetchJson('/translations/sowar_locales', LocalesSchema)
    return data.locales
  })
  return value
}

/**
 * GET /translations/sowar_names - names of all 114 suras in a language.
 * Returns the requested locale when supported, falling back to English.
 */
export async function getSuraNames(
  locale: string,
): Promise<{ names: Record<string, string>; effectiveLocale: string }> {
  const requested = toSourceIsoCode(locale)
  const { value } = await fetchCached(`sowar-names:${requested}`, SURA_NAMES_TTL_MS, async () => {
    const supported = await getSuraNameLocales()
    const effective = supported.includes(requested) ? requested : 'en'
    const data = await fetchJson(
      `/translations/sowar_names?iso_code=${encodeURIComponent(effective)}`,
      SuraNamesSchema,
    )
    return { names: data, effectiveLocale: effective }
  })
  return value
}

export interface SuraContentResult {
  ayat: Array<{
    sura: number
    aya: number
    arabicText: string
    translation: string
    footnotes: string | null
  }>
  servedFromCache: boolean
}

/** Safe pattern for translation keys (used by path parameters). */
export const TRANSLATION_KEY_PATTERN = /^[a-z0-9_]{2,64}$/

/**
 * GET /translation/sura/{translation_key}/{sura_number} - every aya of a
 * sura with the original Arabic text and the translation.
 */
export async function getSuraTranslation(
  translationKey: string,
  suraNumber: number,
): Promise<SuraContentResult> {
  if (!TRANSLATION_KEY_PATTERN.test(translationKey)) {
    throw new QuranEncUpstreamError('Invalid translation key')
  }
  if (!Number.isInteger(suraNumber) || suraNumber < 1 || suraNumber > 114) {
    throw new QuranEncUpstreamError('Invalid sura number')
  }

  const { value, servedFromCache } = await fetchCached(
    `sura:${translationKey}:${suraNumber}`,
    SURA_TTL_MS,
    async () => {
      const data = await fetchJson(
        `/translation/sura/${encodeURIComponent(translationKey)}/${suraNumber}`,
        SuraResponseSchema,
      )
      const rows = Array.isArray(data.result) ? data.result : []
      return rows
        .map((aya) => ({
          sura: Number(aya.sura),
          aya: Number(aya.aya),
          arabicText: stripControlCharacters(aya.arabic_text),
          translation: stripControlCharacters(aya.translation) ?? '',
          footnotes: sanitizeText(aya.footnotes),
        }))
        .filter((aya) => Number.isFinite(aya.sura) && Number.isFinite(aya.aya))
    },
  )
  return { ayat: value, servedFromCache }
}
