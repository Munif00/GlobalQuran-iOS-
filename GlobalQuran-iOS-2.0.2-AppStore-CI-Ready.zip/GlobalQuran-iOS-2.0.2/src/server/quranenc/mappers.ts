/**
 * Mapper: QuranEnc `Translation` records -> app `Translation` model.
 *
 * Honesty rules implemented here:
 * - Fields the source does not provide as distinct data (translator,
 *   publisher, edition, publication year, reviewing authority, rights
 *   statements) are mapped to `null`. They are NEVER inferred from titles
 *   or descriptions.
 * - Download files are built only from documented URL fields; sizes are kept
 *   only when the source publishes them.
 * - Verification status defaults to `not_verified`; the administrator
 *   verification registry can override it with documented evidence.
 */

import { SUPPORTED_LOCALES } from '@/i18n/config'
import type { CatalogLanguage, Translation, TranslationFile, VerificationStatus } from '@/types'
import type { QuranEncTranslation } from './client'

/** Native names for language codes we know from the interface registry. */
const NATIVE_NAMES: ReadonlyMap<string, string> = new Map(
  SUPPORTED_LOCALES.map((locale) => [locale.code.toLowerCase(), locale.nativeName]),
)

/**
 * Extra native names for language codes the source uses but the interface
 * registry spells differently, plus codes that only appear in the
 * supplemental registry. Display-only - never a data claim.
 */
const NATIVE_NAME_ALIASES: ReadonlyMap<string, string> = new Map([
  ['zh', '中文'],
  ['tl', 'Filipino'],
  ['no', 'Norsk'],
  ['be', 'Беларуская'],
  ['bg', 'Български'],
  ['ca', 'Català'],
  ['dag', 'Dagbani'],
  ['el', 'Ελληνικά'],
  ['he', 'עברית'],
  ['ilp', 'Iranun'],
  ['ka', 'ქართული'],
  ['kbd', 'Адыгэбзэ'],
  ['kmr', 'Kurmancî'],
  ['lg', 'Luganda'],
  ['luy', 'Luhya'],
  ['mg', 'Malagasy'],
  ['ne', 'नेपाली'],
  ['ny', 'Chicheŵa'],
  ['prs', 'دری'],
  ['sn', 'Shona'],
  ['yao', 'ChiYao'],
  ['zu', 'isiZulu'],
])

function nativeNameFor(code: string): string | null {
  const lower = code.toLowerCase()
  return NATIVE_NAMES.get(lower) ?? NATIVE_NAME_ALIASES.get(lower) ?? null
}

/** Registry for administrator-attached verification evidence. */
export interface VerificationOverrides {
  byKey: Record<
    string,
    {
      status: VerificationStatus
      reviewingAuthority: string | null
    }
  >
}

export const EMPTY_VERIFICATION_OVERRIDES: VerificationOverrides = { byKey: {} }

/** Source page for a translation on quranenc.com. */
function translationPageUrl(key: string): string {
  return `https://quranenc.com/en/home/translation/${key}`
}

function buildDownloadFiles(item: QuranEncTranslation): TranslationFile[] {
  const files: TranslationFile[] = []

  if (typeof item.database_url === 'string' && item.database_url.startsWith('https://')) {
    files.push({
      id: 'sql-database',
      format: 'sql',
      variant: 'database',
      url: item.database_url,
      size: null,
      coverUrl: null,
    })
  }
  if (
    typeof item.database_uncompressed_url === 'string' &&
    item.database_uncompressed_url.startsWith('https://')
  ) {
    files.push({
      id: 'sql-database-uncompressed',
      format: 'sql',
      variant: 'database-uncompressed',
      url: item.database_uncompressed_url,
      size: null,
      coverUrl: null,
    })
  }
  if (typeof item.pdf_url === 'string' && item.pdf_url.startsWith('https://')) {
    files.push({
      id: 'pdf-standard',
      format: 'pdf',
      variant: 'standard',
      url: item.pdf_url,
      size: typeof item.pdf_size === 'number' ? item.pdf_size : null,
      coverUrl: typeof item.pdf_cover === 'string' ? item.pdf_cover : null,
    })
  }
  if (typeof item.pdf_pure_url === 'string' && item.pdf_pure_url.startsWith('https://')) {
    files.push({
      id: 'pdf-pure',
      format: 'pdf',
      variant: 'pure',
      url: item.pdf_pure_url,
      size: typeof item.pdf_pure_size === 'number' ? item.pdf_pure_size : null,
      coverUrl: typeof item.pdf_pure_cover === 'string' ? item.pdf_pure_cover : null,
    })
  }
  if (typeof item.pdf_mobile_url === 'string' && item.pdf_mobile_url.startsWith('https://')) {
    files.push({
      id: 'pdf-mobile',
      format: 'pdf',
      variant: 'mobile',
      url: item.pdf_mobile_url,
      size: typeof item.pdf_mobile_size === 'number' ? item.pdf_mobile_size : null,
      coverUrl: typeof item.pdf_mobile_cover === 'string' ? item.pdf_mobile_cover : null,
    })
  }
  if (typeof item.epub_url === 'string' && item.epub_url.startsWith('https://')) {
    files.push({
      id: 'epub',
      format: 'epub',
      variant: null,
      url: item.epub_url,
      size: typeof item.epub_size === 'number' ? item.epub_size : null,
      coverUrl: null,
    })
  }

  return files
}

function unixToIso(timestamp: number | null | undefined): string | null {
  if (typeof timestamp !== 'number' || !Number.isFinite(timestamp) || timestamp <= 0) return null
  return new Date(timestamp * 1000).toISOString()
}

/** Capitalize the first letter of a source-supplied language name (display only). */
export function prettifyLanguageName(name: string): string {
  if (!name) return name
  return name.charAt(0).toUpperCase() + name.slice(1)
}

/** Map one source record into the app model. */
export function mapTranslation(
  item: QuranEncTranslation,
  codeToName: Record<string, string>,
  overrides: VerificationOverrides,
  lastCheckedAt: string,
): Translation {
  const verification = overrides.byKey[item.key]
  const files = buildDownloadFiles(item)
  const formats = Array.from(new Set(files.map((file) => file.format)))
  const languageName = prettifyLanguageName(
    codeToName[item.language_iso_code] ?? item.language_iso_code,
  )

  return {
    id: item.key,
    key: item.key,
    languageCode: item.language_iso_code,
    languageName,
    languageNativeName: nativeNameFor(item.language_iso_code),
    direction: item.direction === 'rtl' ? 'rtl' : 'ltr',
    title: item.title ?? item.key,
    description: item.description ?? null,
    // Not provided as distinct fields by the source - kept null, never inferred.
    translator: null,
    publisher: null,
    reviewingAuthority: verification?.reviewingAuthority ?? null,
    edition: null,
    publicationYear: null,
    version: typeof item.version === 'string' && item.version.length > 0 ? item.version : null,
    lastUpdated: unixToIso(item.last_update),
    sourceUrl: translationPageUrl(item.key),
    availableFormats: formats,
    downloadFiles: files,
    approvalStatus: verification?.status ?? 'not_verified',
    rightsStatus: null,
    lastChecked: lastCheckedAt,
  }
}

/** Build the language summary (real counts) from mapped translations. */
export function buildLanguageSummary(translations: Translation[], codeToName: Record<string, string>): CatalogLanguage[] {
  const counts = new Map<string, number>()
  for (const translation of translations) {
    counts.set(translation.languageCode, (counts.get(translation.languageCode) ?? 0) + 1)
  }
  const languages: CatalogLanguage[] = []
  for (const [code, count] of counts) {
    languages.push({
      code,
      name: prettifyLanguageName(codeToName[code] ?? code),
      nativeName: nativeNameFor(code),
      count,
    })
  }
  languages.sort((a, b) => a.name.localeCompare(b.name))
  return languages
}
