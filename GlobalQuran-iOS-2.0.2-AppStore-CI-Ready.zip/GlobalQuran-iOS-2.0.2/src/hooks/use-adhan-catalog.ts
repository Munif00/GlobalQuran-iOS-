'use client'

/**
 * Catalog query for the verified Adhan library (PROMPT 13).
 *
 * Fetches /api/prayer/adhans/catalog through the platform-aware fetch (web
 * server route or native adapter). The catalog only ever contains the
 * hand-verified recordings from the server module - the client never
 * invents entries.
 */

import { useQuery } from '@tanstack/react-query'

import { platformFetch } from '@/services/platform/fetch'
import type { AdhanCatalogResponse } from '@/types'

export async function fetchAdhanCatalog(): Promise<AdhanCatalogResponse> {
  const response = await platformFetch('/api/prayer/adhans/catalog', { credentials: 'same-origin' })
  if (!response.ok) {
    throw new Error(`Adhan catalog request failed (${response.status})`)
  }
  return (await response.json()) as AdhanCatalogResponse
}

export function useAdhanCatalog() {
  return useQuery({
    queryKey: ['adhan-catalog'],
    queryFn: fetchAdhanCatalog,
    staleTime: 10 * 60 * 1000,
    retry: 1,
  })
}
