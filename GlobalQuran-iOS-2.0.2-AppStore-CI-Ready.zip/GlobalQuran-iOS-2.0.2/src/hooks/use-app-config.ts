'use client'

/**
 * App configuration query (integration status, supported languages).
 */

import { useQuery } from '@tanstack/react-query'

import { getAppConfig } from '@/services/api/config-api'
import type { AppConfigDto } from '@/types'

export function useAppConfig() {
  return useQuery<AppConfigDto>({
    queryKey: ['app-config'],
    queryFn: getAppConfig,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  })
}
