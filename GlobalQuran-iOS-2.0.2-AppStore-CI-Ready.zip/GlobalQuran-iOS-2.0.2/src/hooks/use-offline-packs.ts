'use client'

/**
 * Offline-pack status hook - joins the quran-cache pack indexes with the
 * live download-manager jobs.
 *
 * - `statuses` maps every locally cached translation to its real offline
 *   status (computed from IndexedDB, never guessed).
 * - The query key includes the live job count, so statuses refresh the
 *   moment a download finishes (active jobs shrink) or starts.
 * - `refresh` re-reads the indexes on demand (e.g. after removing a pack).
 * - `jobsByTranslation` exposes the active pack job per translation for
 *   inline progress on the library cards.
 */

import { useMemo } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'

import { listPackIndexes } from '@/services/storage/quran-cache'
import { useDownloadManagerStore } from '@/stores/download-manager-store'
import type { DownloadJobRecord, OfflinePackStatus } from '@/types'

/** Total suras of the Quran (offline completeness threshold). */
const TOTAL_SURAS = 114

/** Shared query-key prefix of all offline-pack status queries. */
export const OFFLINE_PACK_STATUSES_KEY = 'offline-pack-statuses'

function statusFromIndex(index: {
  translationKey: string
  updatedAt: string
  entries: Array<{ sura: number; version: string | null; bytes: number }>
}): OfflinePackStatus {
  const versions = new Set(index.entries.map((entry) => entry.version))
  return {
    translationKey: index.translationKey,
    cachedSuras: index.entries.length,
    totalSuras: TOTAL_SURAS,
    complete: index.entries.length >= TOTAL_SURAS,
    approxBytes: index.entries.reduce((sum, entry) => sum + entry.bytes, 0),
    version: versions.size === 1 ? [...versions][0] : null,
    updatedAt: index.updatedAt,
  }
}

/** Read the pack indexes and map them to offline statuses. */
export async function loadOfflinePackStatuses(): Promise<Record<string, OfflinePackStatus>> {
  const indexes = await listPackIndexes()
  const map: Record<string, OfflinePackStatus> = {}
  for (const index of indexes) map[index.translationKey] = statusFromIndex(index)
  return map
}

export function useOfflinePacks() {
  const queryClient = useQueryClient()
  const jobs = useDownloadManagerStore((s) => s.jobs)
  const activeIds = useDownloadManagerStore((s) => s.activeIds)

  const statusQuery = useQuery({
    queryKey: [OFFLINE_PACK_STATUSES_KEY, activeIds.length],
    queryFn: loadOfflinePackStatuses,
    staleTime: 30_000,
  })

  /** Force a re-read of the pack indexes (after removals, updates, ...). */
  const refresh = useMemo(
    () => async () => {
      await queryClient.invalidateQueries({ queryKey: [OFFLINE_PACK_STATUSES_KEY] })
    },
    [queryClient],
  )

  /** Active pack jobs keyed by translation key. */
  const jobsByTranslation = useMemo(() => {
    const map = new Map<string, DownloadJobRecord>()
    for (const job of Object.values(jobs)) {
      if (job.kind !== 'offline-pack') continue
      if (job.translationKey === null) continue
      if (['completed', 'failed', 'canceled', 'corrupted'].includes(job.status)) continue
      map.set(job.translationKey, job)
    }
    return map
  }, [jobs])

  return { statuses: statusQuery.data ?? null, refresh, jobsByTranslation }
}
