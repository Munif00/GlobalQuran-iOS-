'use client'

/**
 * Install (Add-to-Home-Screen) engine for the Android + iOS application.
 *
 * Surfaces everything the UI needs to install Global Quran as a standalone
 * app on every platform:
 *
 * - Android (Chrome, Samsung Internet, Edge): the browser fires
 *   `beforeinstallprompt` once the installability criteria are met. The
 *   event is captured and `install()` replays the native install dialog.
 * - iOS / iPadOS (Safari): there is no programmatic install - the user
 *   taps Share -> "Add to Home Screen". The UI shows guided steps instead.
 * - Desktop (Chrome, Edge): same `beforeinstallprompt` flow as Android.
 *
 * Also tracks whether the app is already running in standalone mode
 * (launched from the home screen) via the `display-mode` media query and
 * iOS's legacy `navigator.standalone`.
 */

import { useCallback, useEffect, useState } from 'react'

import { isRealNativePlatform } from '@/services/platform/native-mode'

/** Platform family used to pick the right install instructions. */
export type InstallPlatform = 'android' | 'ios' | 'desktop'

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
}

/** localStorage key: when the user last dismissed the install banner. */
export const INSTALL_BANNER_DISMISSED_KEY = 'gq-install-banner-dismissed-at'

/** Re-offer the banner after this long (14 days, in milliseconds). */
export const INSTALL_BANNER_REOFFER_MS = 14 * 24 * 60 * 60 * 1000

/** Best-effort platform detection (client only). */
export function detectInstallPlatform(): InstallPlatform {
  if (typeof navigator === 'undefined') return 'desktop'
  const ua = navigator.userAgent
  // iPadOS 13+ masquerades as desktop macOS, but is the only Mac with
  // multi-touch - and it needs the Safari Share instructions.
  const isIpad = /ipad/i.test(ua) || (/macintosh/i.test(ua) && navigator.maxTouchPoints > 1)
  if (/iphone|ipod/i.test(ua) || isIpad) return 'ios'
  if (/android/i.test(ua)) return 'android'
  return 'desktop'
}

export interface InstallPromptState {
  /** True after the first client render (hydration-safe gate). */
  mounted: boolean
  platform: InstallPlatform
  /** Running as an installed app (standalone display mode). */
  isStandalone: boolean
  /** The app can be installed from here (native prompt captured or iOS). */
  canInstall: boolean
  /**
   * Opens the native install dialog (Android/desktop). Resolves with the
   * user's choice, or 'unavailable' when no prompt was captured.
   */
  install: () => Promise<'accepted' | 'dismissed' | 'unavailable'>
  /** True between calling install() and the user answering the prompt. */
  isPrompting: boolean
  /** The app finished installing while this hook was mounted. */
  wasInstalled: boolean
}

export function useInstallPrompt(): InstallPromptState {
  const [mounted, setMounted] = useState(false)
  const [platform, setPlatform] = useState<InstallPlatform>('desktop')
  const [isStandalone, setIsStandalone] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [isPrompting, setIsPrompting] = useState(false)
  const [wasInstalled, setWasInstalled] = useState(false)

  useEffect(() => {
    setMounted(true)
    setPlatform(detectInstallPlatform())

    const standaloneQuery = window.matchMedia('(display-mode: standalone)')
    const isNavigatorStandalone = () =>
      (window.navigator as Navigator & { standalone?: boolean }).standalone === true
    const sync = () => {
      // Inside the Capacitor native app the app is by definition already
      // installed - no install UI may ever appear there.
      setIsStandalone(
        standaloneQuery.matches || isNavigatorStandalone() || isRealNativePlatform(),
      )
    }
    sync()
    standaloneQuery.addEventListener('change', sync)

    const onBeforeInstallPrompt = (event: Event) => {
      // Prevent Chrome's mini-infobar - the app shows its own UI.
      event.preventDefault()
      setDeferredPrompt(event as BeforeInstallPromptEvent)
    }
    const onAppInstalled = () => {
      setDeferredPrompt(null)
      setWasInstalled(true)
    }

    window.addEventListener('beforeinstallprompt', onBeforeInstallPrompt)
    window.addEventListener('appinstalled', onAppInstalled)
    return () => {
      standaloneQuery.removeEventListener('change', sync)
      window.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt)
      window.removeEventListener('appinstalled', onAppInstalled)
    }
  }, [])

  const install = useCallback(async () => {
    if (!deferredPrompt) return 'unavailable' as const
    try {
      setIsPrompting(true)
      await deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      if (outcome === 'accepted') setDeferredPrompt(null)
      return outcome
    } catch {
      return 'unavailable' as const
    } finally {
      setIsPrompting(false)
    }
  }, [deferredPrompt])

  const canInstall =
    mounted && !isStandalone && (deferredPrompt !== null || platform === 'ios')

  return { mounted, platform, isStandalone, canInstall, install, isPrompting, wasInstalled }
}
