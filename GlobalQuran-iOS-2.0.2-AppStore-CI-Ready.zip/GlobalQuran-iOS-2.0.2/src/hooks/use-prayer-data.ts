'use client'

/**
 * Global Quran - Prayer data hooks (TanStack Query).
 *
 * - Day/month queries are keyed by the full parameter set (location +
 *   settings), so switching dates or settings never shows stale data.
 * - The hooks return the honest `status` from the API; "unavailable"
 *   responses are rendered as explanations, never as invented times.
 * - TanStack Query's own cache doubles as an in-memory offline copy:
 *   when the network fails, the last successful data is shown with a
 *   cached indicator.
 * - On top of that, successful day responses are persisted to a
 *   localStorage snapshot (services/storage/prayer-snapshot.ts). When the
 *   app server itself is unreachable, the last verified record for the
 *   exact same parameters + date is served instead - flagged
 *   `clientCache` so the UI can label it as stored data with its original
 *   retrieval date. No invented times in any path.
 */

import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'

import type { PrayerTimeRecord } from '@/types'
import {
  fetchPrayerDay,
  fetchPrayerMeta,
  fetchPrayerMonth,
  prayerParamsKeyPart,
  searchCitiesOnline,
  type PrayerQueryParams,
} from '@/services/api/prayer-api'
import { loadPrayerSnapshot, savePrayerSnapshot } from '@/services/storage/prayer-snapshot'

/** Static-ish method registry (verified data; refetch rarely). */
export function usePrayerMeta() {
  return useQuery({
    queryKey: ['prayer-meta'],
    queryFn: fetchPrayerMeta,
    staleTime: 24 * 60 * 60 * 1000,
    retry: 1,
  })
}

export function usePrayerDay(date: string | null, params: PrayerQueryParams | null) {
  const enabled = date != null && params != null
  return useQuery({
    queryKey: ['prayer-day', date, params ? prayerParamsKeyPart(params) : '-'],
    queryFn: async () => {
      const response = await fetchPrayerDay(date as string, params as PrayerQueryParams)
      if (response.status === 'live' && response.record) {
        // Persist the verified response for the offline case.
        savePrayerSnapshot(prayerParamsKeyPart(params as PrayerQueryParams), response.record, response.source ?? null)
        return response
      }
      // The server is unreachable or every source failed: fall back to the
      // last verified snapshot for the exact same parameters + date, if one
      // exists. Served with `clientCache: true` and the original fetchedAt.
      const snapshot = loadPrayerSnapshot(prayerParamsKeyPart(params as PrayerQueryParams), date as string)
      if (snapshot) {
        return {
          status: 'live' as const,
          message: null,
          messageKey: null,
          record: { ...snapshot.record, isCached: true },
          source: snapshot.source ? { ...snapshot.source, isCached: true } : null,
          clientCache: true,
        }
      }
      return response
    },
    enabled,
    staleTime: 5 * 60 * 1000,
    retry: 0,
    refetchOnWindowFocus: false,
  })
}

export function usePrayerMonth(month: string | null, params: PrayerQueryParams | null, enabled = true) {
  const isActive = enabled && month != null && params != null
  return useQuery({
    queryKey: ['prayer-month', month, params ? prayerParamsKeyPart(params) : '-'],
    queryFn: () => fetchPrayerMonth(month as string, params as PrayerQueryParams),
    enabled: isActive,
    staleTime: 10 * 60 * 1000,
    retry: 0,
    refetchOnWindowFocus: false,
  })
}

/** Debounced online city search (bundled results are merged server-side). */
export function useCitySearch(query: string) {
  const [debounced, setDebounced] = useState('')
  const trimmedQuery = query.trim()
  useEffect(() => {
    if (trimmedQuery.length < 2) return
    const timer = window.setTimeout(() => setDebounced(trimmedQuery), 400)
    return () => window.clearTimeout(timer)
  }, [trimmedQuery])

  // While the input is too short the effective query is empty (search off);
  // otherwise it is the latest debounced value.
  const effectiveQuery = trimmedQuery.length >= 2 ? debounced : ''

  return useQuery({
    queryKey: ['prayer-city-search', effectiveQuery],
    queryFn: () => searchCitiesOnline(effectiveQuery),
    enabled: effectiveQuery.length >= 2,
    staleTime: 60 * 1000,
    retry: 0,
  })
}

/* ------------------------------------------------------------------ */
/* "Now" & next-prayer computation                                     */
/* ------------------------------------------------------------------ */

/** Ticking clock - 1s while the tab is visible (paused when hidden). */
export function useNow(): Date {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    let timer = 0
    const tick = () => setNow(new Date())
    const start = () => {
      // Guard against a duplicate 'visible' event (seen in some WebViews)
      // overwriting - and thereby leaking - a still-running interval.
      if (timer !== 0) return
      timer = window.setInterval(tick, 1000)
    }
    const stop = () => {
      window.clearInterval(timer)
      timer = 0
    }
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        tick()
        start()
      } else {
        stop()
      }
    }
    if (document.visibilityState === 'visible') {
      start()
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      stop()
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [])
  return now
}

export type PrayerSlotKey = 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'

export interface PrayerSlot {
  key: PrayerSlotKey
  iso: string
  instant: Date
}

export const PRAYER_SLOT_ORDER: PrayerSlotKey[] = [
  'fajr',
  'sunrise',
  'dhuhr',
  'asr',
  'maghrib',
  'isha',
]

/** The six slots of a record as comparable instants. */
export function prayerSlots(record: PrayerTimeRecord): PrayerSlot[] {
  return PRAYER_SLOT_ORDER.map((key) => ({
    key,
    iso: record[key],
    instant: new Date(record[key]),
  })).filter((slot) => !Number.isNaN(slot.instant.getTime()))
}

export interface NextPrayerView {
  /** The next upcoming slot (may belong to the following day). */
  slot: PrayerSlot
  /** Previous slot (for the progress bar); null before Fajr. */
  previous: PrayerSlot | null
  /** The record the next slot belongs to. */
  recordDate: string
  progress: number
}

/**
 * Next prayer across today's (and optionally tomorrow's) records.
 * Pure instants - exact across time zones and DST transitions.
 */
export function computeNextPrayer(
  now: Date,
  today: PrayerTimeRecord,
  tomorrow: PrayerTimeRecord | null,
): NextPrayerView | null {
  const todaySlots = prayerSlots(today)
  const upcoming = todaySlots.find((slot) => slot.instant.getTime() > now.getTime())

  if (upcoming) {
    const index = todaySlots.indexOf(upcoming)
    const previous = index > 0 ? todaySlots[index - 1] : null
    const start = previous?.instant.getTime() ?? upcoming.instant.getTime() - 60 * 60 * 1000
    const end = upcoming.instant.getTime()
    const progress = Math.min(
      1,
      Math.max(0, (now.getTime() - start) / Math.max(1, end - start)),
    )
    return { slot: upcoming, previous, recordDate: today.date, progress }
  }

  if (tomorrow) {
    const tomorrowSlots = prayerSlots(tomorrow)
    const first = tomorrowSlots[0]
    if (first) {
      const last = todaySlots[todaySlots.length - 1]
      const start = last?.instant.getTime() ?? first.instant.getTime() - 8 * 60 * 60 * 1000
      const end = first.instant.getTime()
      const progress = Math.min(
        1,
        Math.max(0, (now.getTime() - start) / Math.max(1, end - start)),
      )
      return { slot: first, previous: last ?? null, recordDate: tomorrow.date, progress }
    }
  }
  return null
}

/** Format a countdown as `H:MM:SS` (or `M:SS` under an hour). */
export function formatCountdown(msRemaining: number): string {
  const total = Math.max(0, Math.floor(msRemaining / 1000))
  const hours = Math.floor(total / 3600)
  const minutes = Math.floor((total % 3600) / 60)
  const seconds = total % 60
  const mm = String(minutes).padStart(2, '0')
  const ss = String(seconds).padStart(2, '0')
  return hours > 0 ? `${hours}:${mm}:${ss}` : `${minutes}:${ss}`
}

/** Which of today's slots have passed (for dimming the timeline). */
export function passedSlotKeys(record: PrayerTimeRecord, now: Date): Set<PrayerSlotKey> {
  const passed = new Set<PrayerSlotKey>()
  for (const slot of prayerSlots(record)) {
    if (slot.instant.getTime() <= now.getTime()) passed.add(slot.key)
  }
  return passed
}

/** Hijri month names for display (standard names, shown with source label). */
export const HIJRI_MONTHS_EN = [
  'Muharram',
  'Safar',
  'Rabi al-Awwal',
  'Rabi al-Thani',
  'Jumada al-Ula',
  'Jumada al-Akhirah',
  'Rajab',
  'Shaban',
  'Ramadan',
  'Shawwal',
  'Dhul-Qadah',
  'Dhul-Hijjah',
]

/** Arabic Hijri month names + era suffix for RTL locales. */
export const HIJRI_MONTHS_AR = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الثاني',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة',
] as const

/** Month list + era suffix matching the UI language (English default). */
export function hijriDisplayForLocale(locale: string): {
  months: ReadonlyArray<string>
  eraSuffix: string
} {
  if (locale === 'ar' || locale === 'ar-SA' || locale === 'ar-EG') {
    return { months: HIJRI_MONTHS_AR, eraSuffix: 'هـ' }
  }
  return { months: HIJRI_MONTHS_EN, eraSuffix: 'AH' }
}

/** Format a stored `DD-MM-YYYY` Hijri date for display; null when malformed. */
export function formatHijriDate(
  value: string | null,
  months: ReadonlyArray<string> = HIJRI_MONTHS_EN,
  eraSuffix: string = 'AH',
): string | null {
  if (!value) return null
  const match = /^(\d{1,2})-(\d{1,2})-(\d{4})$/.exec(value)
  if (!match) return null
  const day = match[1]
  const monthIndex = Number(match[2]) - 1
  const year = match[3]
  const monthName = months[monthIndex]
  if (!monthName) return `${day}/${match[2]}/${year} ${eraSuffix}`
  return `${day} ${monthName} ${year} ${eraSuffix}`
}

