'use client'

/**
 * Compass hook: explicit start (user gesture), iOS permission handling,
 * declination-corrected heading state fed only by real sensor readings,
 * stability monitoring, and page-lifecycle-aware listener management.
 *
 * - `heading` stays null until the first trustworthy (compass-grade) reading.
 * - `headingReference` tells whether the heading is true-north (W3C absolute
 *   orientation, or iOS magnetic + WMM2025 correction) or an honestly
 *   labeled uncorrected magnetic reading (no location available).
 * - Heading state updates are throttled to ~10 per second; stability is
 *   assessed once per second from the same sample stream.
 * - Listeners are released on unmount, on `pagehide`, and while the page is
 *   hidden; they resume automatically when the page becomes visible again
 *   (only if the compass was active before hiding) so no battery is drained
 *   in the background.
 * - `noSensorData` turns true after NO_SENSOR_DATA_TIMEOUT_MS of listening
 *   without a single orientation event - typical on desktops where the API
 *   exists but no sensors ever fire. The UI then stops promising a live
 *   needle and offers the calculated-direction fallback instead.
 */

import { useCallback, useEffect, useRef, useState } from 'react'

import {
  HeadingStabilityMonitor,
  compassRequiresExplicitPermission,
  isCompassApiAvailable,
  requestCompassPermission,
  startCompassListening,
  type CompassReading,
} from '@/services/sensors/compass-service'

export type CompassStatus = 'idle' | 'starting' | 'active' | 'unavailable' | 'denied'
export type CompassStability = 'no-data' | 'stale' | 'unstable' | 'steady'
export type CompassSourceKind = 'webkit-compass' | 'absolute-orientation' | 'relative-orientation' | null

/** Emit at most ~10 heading updates per second to avoid excessive renders. */
const HEADING_UPDATE_INTERVAL_MS = 100
/** How often the stability assessment runs. */
const STABILITY_CHECK_INTERVAL_MS = 1000
/** Listening this long without a single orientation event => no sensors. */
const NO_SENSOR_DATA_TIMEOUT_MS = 8000

export interface UseCompassResult {
  /** Sensor lifecycle state. */
  status: CompassStatus
  /**
   * Last trustworthy heading of the top of the screen (degrees clockwise
   * from north, 0-360), or null. True-north referenced whenever possible -
   * see `headingReference` for what the number actually means.
   */
  heading: number | null
  /**
   * Continuous (unwrapped) heading: always congruent to `heading` modulo 360,
   * but accumulated across turns so that consecutive values take the short
   * path. Ideal for driving a smooth CSS dial rotation across the 359/0
   * boundary. Null until the first trustworthy reading.
   */
  unwrappedHeading: number | null
  /** What `heading` is referenced to (null before the first reading). */
  headingReference: 'true_north' | 'magnetic' | null
  /** Whether the WMM declination correction was applied to the current heading. */
  declinationApplied: boolean
  /** Which sensor pipeline produced the current heading. */
  sourceKind: CompassSourceKind
  /** Event-reported accuracy in degrees (iOS), null when not provided. */
  sensorAccuracy: number | null
  /** Device tilt from flat in degrees (null when unknown / iOS path). */
  tilt: number | null
  /** Rolling-window sensor stability assessment. */
  stability: CompassStability
  /**
   * True while listening when the device has not produced a single
   * orientation event within the timeout - the API exists but no sensors
   * are firing (typical on desktops). Never true after any real reading.
   */
  noSensorData: boolean
  /** True while listening for sensor readings. */
  isActive: boolean
  /** Begin the permission flow and start listening. Call from a user gesture. */
  start: () => Promise<void>
  /** Stop listening and reset heading/state to idle. */
  stop: () => void
}

/**
 * @param location current user location (live GPS or saved), or null.
 * Used only to correct iOS magnetic headings to true north; never tracked
 * or transmitted.
 */
export function useCompass(location: { latitude: number; longitude: number } | null): UseCompassResult {
  const [status, setStatus] = useState<CompassStatus>('idle')
  const [heading, setHeading] = useState<number | null>(null)
  const [unwrappedHeading, setUnwrappedHeading] = useState<number | null>(null)
  const [headingReference, setHeadingReference] = useState<'true_north' | 'magnetic' | null>(null)
  const [declinationApplied, setDeclinationApplied] = useState(false)
  const [sourceKind, setSourceKind] = useState<CompassSourceKind>(null)
  const [sensorAccuracy, setSensorAccuracy] = useState<number | null>(null)
  const [tilt, setTilt] = useState<number | null>(null)
  const [stability, setStability] = useState<CompassStability>('no-data')
  const [noSensorData, setNoSensorData] = useState(false)

  const stopListeningRef = useRef<(() => void) | null>(null)
  const lastHeadingUpdateRef = useRef(0)
  const unwrapStateRef = useRef<{ lastRaw: number; unwrapped: number } | null>(null)
  const disposedRef = useRef(false)
  const monitorRef = useRef<HeadingStabilityMonitor | null>(null)
  const stabilityTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const locationRef = useRef<{ latitude: number; longitude: number } | null>(location)
  /** Whether the user wants the compass running (survives visibility pauses). */
  const wantedRef = useRef(false)
  /** When the current listening session started (for the no-data timeout). */
  const startedAtRef = useRef(0)
  /** Whether any orientation event at all arrived in this session. */
  const anyEventRef = useRef(false)
  /** Whether a compass-grade heading ever arrived in this session. */
  const headingEverRef = useRef(false)

  // Keep the latest location available to the sensor listener without
  // re-registering it (assignment happens in an effect, never during render).
  useEffect(() => {
    locationRef.current = location
  }, [location])

  const clearStabilityTimer = () => {
    if (stabilityTimerRef.current !== null) {
      clearInterval(stabilityTimerRef.current)
      stabilityTimerRef.current = null
    }
  }

  const stop = useCallback(() => {
    wantedRef.current = false
    stopListeningRef.current?.()
    stopListeningRef.current = null
    lastHeadingUpdateRef.current = 0
    unwrapStateRef.current = null
    monitorRef.current?.reset()
    clearStabilityTimer()
    setStatus('idle')
    setHeading(null)
    setUnwrappedHeading(null)
    setHeadingReference(null)
    setDeclinationApplied(false)
    setSourceKind(null)
    setSensorAccuracy(null)
    setTilt(null)
    setStability('no-data')
    setNoSensorData(false)
  }, [])

  const beginListening = useCallback(() => {
    if (stopListeningRef.current || disposedRef.current) return
    if (!isCompassApiAvailable()) {
      setStatus('unavailable')
      return
    }

    const monitor = new HeadingStabilityMonitor()
    monitorRef.current = monitor
    startedAtRef.current = Date.now()
    anyEventRef.current = false
    headingEverRef.current = false
    setNoSensorData(false)

    const handleReading = (reading: CompassReading) => {
      anyEventRef.current = true
      monitor.push(reading.heading, reading.timestamp)

      // Source metadata updates are cheap; heading updates are throttled.
      if (reading.heading != null) {
        headingEverRef.current = true
        setNoSensorData(false)
        setHeadingReference(reading.reference)
        setDeclinationApplied(reading.declinationApplied)
        setSourceKind(reading.source)
        setSensorAccuracy(reading.accuracy)
        setTilt(reading.tilt)

        if (reading.timestamp - lastHeadingUpdateRef.current >= HEADING_UPDATE_INTERVAL_MS) {
          lastHeadingUpdateRef.current = reading.timestamp

          // Accumulate the shortest-path delta so CSS rotations stay smooth
          // across the 359/0 boundary (the result stays congruent mod 360).
          const previous = unwrapStateRef.current
          const unwrapped =
            previous == null
              ? reading.heading
              : previous.unwrapped + ((((reading.heading - previous.lastRaw) % 360) + 540) % 360 - 180)
          unwrapStateRef.current = { lastRaw: reading.heading, unwrapped }

          setHeading(reading.heading)
          setUnwrappedHeading(unwrapped)
        }
      } else {
        // A relative-only event: mark the source so the UI can explain the
        // missing needle, but never fabricate a heading.
        setSourceKind(reading.source)
      }
    }

    const stopListening = startCompassListening(handleReading, {
      getLocation: () => locationRef.current,
    })

    // The component went away while permission was requested: register
    // nothing and release the listeners immediately.
    if (disposedRef.current) {
      stopListening()
      return
    }

    stopListeningRef.current = stopListening
    setStatus('active')

    // Periodic stability assessment (also catches silent sensor loss).
    clearStabilityTimer()
    stabilityTimerRef.current = setInterval(() => {
      setStability(monitor.assess(Date.now()))
      // No-data timeout: listening, but not a single event has arrived.
      // (Devices that do fire events - e.g. relative-only - are excluded;
      // they are explained by `sourceKind` instead.)
      if (
        !headingEverRef.current &&
        !anyEventRef.current &&
        Date.now() - startedAtRef.current > NO_SENSOR_DATA_TIMEOUT_MS
      ) {
        setNoSensorData(true)
      }
    }, STABILITY_CHECK_INTERVAL_MS)
  }, [])

  const start = useCallback(async () => {
    // Already listening: nothing to do.
    if (stopListeningRef.current) return
    wantedRef.current = true

    if (!isCompassApiAvailable()) {
      setStatus('unavailable')
      return
    }

    setStatus('starting')

    if (compassRequiresExplicitPermission()) {
      const permission = await requestCompassPermission()
      if (disposedRef.current) return
      if (permission !== 'granted') {
        wantedRef.current = false
        setStatus(permission === 'denied' ? 'denied' : 'unavailable')
        return
      }
    }

    beginListening()
  }, [beginListening])

  // Mount/unmount lifecycle: release everything on unmount.
  useEffect(() => {
    disposedRef.current = false
    return () => {
      disposedRef.current = true
      stopListeningRef.current?.()
      stopListeningRef.current = null
      clearStabilityTimer()
    }
  }, [])

  // Page lifecycle: release listeners when hidden/gone, resume when visible.
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') {
        // Free the sensors while backgrounded.
        stopListeningRef.current?.()
        stopListeningRef.current = null
        clearStabilityTimer()
        if (wantedRef.current) setStatus('starting')
      } else if (wantedRef.current && !stopListeningRef.current && !disposedRef.current) {
        beginListening()
      }
    }
    const handlePageHide = () => {
      stopListeningRef.current?.()
      stopListeningRef.current = null
    }
    document.addEventListener('visibilitychange', handleVisibility)
    window.addEventListener('pagehide', handlePageHide)
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility)
      window.removeEventListener('pagehide', handlePageHide)
    }
  }, [beginListening])

  return {
    status,
    heading,
    unwrappedHeading,
    headingReference,
    declinationApplied,
    sourceKind,
    sensorAccuracy,
    tilt,
    stability,
    noSensorData,
    isActive: status === 'active',
    start,
    stop,
  }
}
