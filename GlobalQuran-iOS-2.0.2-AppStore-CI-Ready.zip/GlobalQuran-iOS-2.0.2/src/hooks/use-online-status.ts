'use client'

/**
 * Tracks the internet connection status through the browser's
 * online/offline events.
 */

import { useSyncExternalStore } from 'react'

import { useMounted } from './use-mounted'

function subscribeToConnection(callback: () => void): () => void {
  window.addEventListener('online', callback)
  window.addEventListener('offline', callback)
  return () => {
    window.removeEventListener('online', callback)
    window.removeEventListener('offline', callback)
  }
}

export function useOnlineStatus(): { isOnline: boolean; mounted: boolean } {
  const isOnline = useSyncExternalStore(
    subscribeToConnection,
    () => navigator.onLine,
    () => true,
  )
  const mounted = useMounted()
  return { isOnline: mounted ? isOnline : true, mounted }
}
