'use client'

/**
 * Geolocation hook: permission status, last known coordinates, and an
 * explicit request() that only runs in response to a user action.
 *
 * Native additions (the incident fix):
 * - `serviceEnabled`: the Android system location service state (null when
 *   not determinable, e.g. the web browser);
 * - `openSettings()`: deep-links to the Android location settings so the
 *   user can enable the service, then returns to the app;
 * - automatic re-check when the app becomes visible again after the user
 *   returns from the system settings (permission + service state).
 *
 * Automatic settings trip (the double-press fix): when a request fails with
 * the typed code 'service-disabled', the SAME press opens the device
 * settings (no extra tap) and arms a one-shot trip. When the user returns
 * with the service ON and the permission granted, the position is obtained
 * automatically through the identical request path - prayer times and every
 * dependent screen update without a second "Get my location" press. The
 * trip runs at most once, never re-opens the settings, never loops, and
 * fails honestly (still-disabled / auto-failure) when the preconditions are
 * not met. On the web none of this can trigger: 'service-disabled' is a
 * native-only code, so the web behavior is unchanged.
 */

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { App } from '@capacitor/app'
import type { PluginListenerHandle } from '@capacitor/core'

import {
  GeoErrorCode,
  GeoPermissionState,
  GeoCoordinates,
  GeolocationError,
  isGeolocationSupported,
  isLocationServiceEnabled,
  openLocationSettings,
  queryLocationPermission,
  requestCurrentLocation,
} from '@/services/location/geolocation-service'
import { isRealNativePlatform } from '@/services/platform/native-mode'

const emptySubscribe = () => () => {}

/** States of the automatic settings trip (native only; 'idle' on the web). */
export type GeoAutoFlowState = 'idle' | 'awaiting-settings' | 'auto-locating' | 'succeeded' | 'failed'

export interface UseGeolocationOptions {
  /**
   * Called with the REAL coordinates once the automatic post-settings
   * acquisition succeeds. Apply them exactly like a successful manual
   * request (the same screen-side code path) - nothing is reported before
   * a position actually resolves.
   */
  onAutoLocated?: (position: GeoCoordinates) => void | Promise<void>
}

export interface UseGeolocationResult {
  supported: boolean
  permission: GeoPermissionState
  coordinates: GeoCoordinates | null
  /** Typed failure code for the last request (translated by the UI). */
  errorCode: GeoErrorCode | null
  isRequesting: boolean
  /** Android system location service state (null = not determinable). */
  serviceEnabled: boolean | null
  /** Ask for the current position (triggers the browser prompt). */
  request: () => Promise<GeoCoordinates | null>
  /** Re-read the permission state (e.g. after returning from system
   *  settings); resolves with the fresh value. */
  refreshPermission: () => Promise<GeoPermissionState>
  /** Re-read the system location service state; resolves with the fresh
   *  value. */
  refreshServiceState: () => Promise<boolean | null>
  /** Open the Android location settings (no-op returning false on web).
   *  In the native shell a successful open also arms the automatic trip,
   *  so returning with the service on acquires the position without a
   *  second press. */
  openSettings: () => Promise<boolean>
  /** The typed code of the last failed request (null after success) -
   *  readable immediately after `request()` resolves (no stale closure). */
  getLastErrorCode: () => GeoErrorCode | null
  /** Live state of the automatic settings trip ('idle' outside a trip). */
  autoFlow: GeoAutoFlowState
  /** Typed failure code of the automatic attempt. Non-null only when the
   *  trip ended in 'failed' because the automatic REQUEST failed (or the
   *  permission was not granted on return); the service-still-disabled
   *  ending keeps it null - the UI shows the stillDisabled notice. */
  autoFlowErrorCode: GeoErrorCode | null
}

export function useGeolocation(options?: UseGeolocationOptions): UseGeolocationResult {
  const [permission, setPermission] = useState<GeoPermissionState>('prompt')
  const [coordinates, setCoordinates] = useState<GeoCoordinates | null>(null)
  const [errorCode, setErrorCode] = useState<GeoErrorCode | null>(null)
  const [isRequesting, setIsRequesting] = useState(false)
  const [serviceEnabled, setServiceEnabled] = useState<boolean | null>(null)
  const [autoFlow, setAutoFlow] = useState<GeoAutoFlowState>('idle')
  const [autoFlowErrorCode, setAutoFlowErrorCode] = useState<GeoErrorCode | null>(null)
  /* Mirrors errorCode without re-render timing gaps, so callers can read
   * the failure reason immediately after `await request()`. */
  const errorCodeRef = useRef<GeoErrorCode | null>(null)
  /* Mirrors autoFlow: the event listeners below must read the LIVE trip
   * state, never a stale render closure. */
  const autoFlowRef = useRef<GeoAutoFlowState>('idle')
  /* One-shot guard: the return handler runs at most ONCE per settings
   * trip, no matter how many triggers fire (visibilitychange AND the
   * native appStateChange can both fire on the same resume). */
  const tripHandledRef = useRef(false)
  /* Latest automatic-acquisition callback - kept fresh via an effect so the
   * listeners never need re-subscribing on re-renders. */
  const onAutoLocatedRef = useRef<UseGeolocationOptions['onAutoLocated']>(undefined)

  // Environment capability is stable; read it without effects.
  const supported = useSyncExternalStore(
    emptySubscribe,
    () => isGeolocationSupported(),
    () => false,
  )

  /** Set the trip state in both the ref (for listeners) and the state
   *  (for the UI) - they must never diverge. */
  const applyAutoFlow = useCallback((next: GeoAutoFlowState) => {
    autoFlowRef.current = next
    setAutoFlow(next)
  }, [])

  const refreshPermission = useCallback(async (): Promise<GeoPermissionState> => {
    const state = await queryLocationPermission()
    setPermission(state)
    return state
  }, [])

  const refreshServiceState = useCallback(async (): Promise<boolean | null> => {
    const enabled = await isLocationServiceEnabled()
    setServiceEnabled(enabled)
    return enabled
  }, [])

  const getLastErrorCode = useCallback(() => errorCodeRef.current, [])

  /** Shared acquisition core: the IDENTICAL request path (20s timeout,
   *  typed error codes, honest state refresh on failure) for BOTH the
   *  manual press and the automatic post-settings attempt - one path,
   *  never two that can drift. */
  const performRequest = useCallback(async (): Promise<GeoCoordinates | null> => {
    setIsRequesting(true)
    setErrorCode(null)
    errorCodeRef.current = null
    try {
      const position = await requestCurrentLocation()
      setCoordinates(position)
      setPermission('granted')
      setServiceEnabled(true)
      return position
    } catch (requestError) {
      const code = requestError instanceof GeolocationError ? requestError.code : 'unknown'
      setErrorCode(code)
      errorCodeRef.current = code
      const state = await queryLocationPermission()
      setPermission(state)
      const enabled = await isLocationServiceEnabled()
      setServiceEnabled(enabled)
      return null
    } finally {
      setIsRequesting(false)
    }
  }, [])

  /** Arm a fresh one-shot settings trip. Called ONLY after the settings
   *  screen actually opened (a failed open arms nothing). */
  const armSettingsTrip = useCallback(() => {
    tripHandledRef.current = false
    setAutoFlowErrorCode(null)
    applyAutoFlow('awaiting-settings')
  }, [applyAutoFlow])

  const request = useCallback(async (): Promise<GeoCoordinates | null> => {
    if (!isGeolocationSupported()) {
      setErrorCode('unsupported')
      errorCodeRef.current = 'unsupported'
      setPermission('unsupported')
      return null
    }
    // A new manual press always starts from a clean trip state: every
    // automatic flag resets here (guard: one auto attempt per trip, and a
    // new press is a new trip).
    tripHandledRef.current = false
    setAutoFlowErrorCode(null)
    applyAutoFlow('idle')
    const position = await performRequest()
    if (!position && errorCodeRef.current === 'service-disabled') {
      /* Typed failure: the system location service is off - on this SAME
       * press (no extra tap) send the user to the device settings and arm
       * the automatic acquisition for the moment they return. */
      const opened = await openLocationSettings()
      if (opened) armSettingsTrip()
    }
    return position
  }, [performRequest, applyAutoFlow, armSettingsTrip])

  const openSettings = useCallback(async () => {
    const opened = await openLocationSettings()
    if (opened) {
      /* The manual settings button starts the same automatic trip, so this
       * path also ends with the position acquired on return - never a
       * forced second "Get my location" press. The same guards apply: the
       * trip is one-shot and never re-opens the settings by itself. */
      armSettingsTrip()
    }
    return opened
  }, [armSettingsTrip])

  /* One-shot return handler shared by BOTH triggers (the web
   * visibilitychange and, in the native shell, appStateChange). It always
   * refreshes the observed states (existing behavior on every return to
   * the app), then - exactly once per armed trip - either starts the
   * automatic acquisition or fails honestly. It NEVER opens the settings
   * and NEVER retries on its own, so no loop is possible. */
  const handleReturnFromSettings = useCallback(async () => {
    const [state, enabled] = await Promise.all([refreshPermission(), refreshServiceState()])
    if (autoFlowRef.current !== 'awaiting-settings' || tripHandledRef.current) return
    tripHandledRef.current = true
    if (enabled !== true) {
      /* The user returned with the service still off (or its state is not
       * determinable): stop this trip for good. Only a new button press
       * may start a new one. */
      applyAutoFlow('failed')
      setAutoFlowErrorCode(null)
      return
    }
    if (state !== 'granted') {
      /* The service is on but the permission is not granted: no silent
       * permission request on return - fail with the honest reason; the
       * next manual press runs the regular prompt flow. */
      applyAutoFlow('failed')
      setAutoFlowErrorCode('denied')
      return
    }
    /* Service on + permission granted: obtain the position automatically
     * through the same request path a manual press uses. */
    applyAutoFlow('auto-locating')
    const position = await performRequest()
    if (position) {
      /* Real coordinates resolved - only now may anything claim success. */
      applyAutoFlow('succeeded')
      setAutoFlowErrorCode(null)
      // Hand the coordinates to the screen so they flow through the exact
      // same apply path as a successful manual press.
      await onAutoLocatedRef.current?.(position)
    } else {
      applyAutoFlow('failed')
      setAutoFlowErrorCode(errorCodeRef.current)
    }
  }, [refreshPermission, refreshServiceState, performRequest, applyAutoFlow])

  // Keep the automatic-acquisition callback fresh without touching the
  // event subscriptions.
  useEffect(() => {
    onAutoLocatedRef.current = options?.onAutoLocated
  }, [options?.onAutoLocated])

  useEffect(() => {
    void refreshPermission()
    void refreshServiceState()
  }, [refreshPermission, refreshServiceState])

  // Web trigger (also fires in the native WebView): re-check after the
  // user returns from the system settings (or any other app switch) - both
  // the permission and the service state may have changed. The trip logic
  // inside is one-shot, so extra fires are harmless.
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') void handleReturnFromSettings()
    }
    document.addEventListener('visibilitychange', handleVisibility)
    return () => document.removeEventListener('visibilitychange', handleVisibility)
  }, [handleReturnFromSettings])

  // Native second trigger: appStateChange(isActive) is the reliable resume
  // signal inside the Android WebView when returning from a system
  // settings screen (visibilitychange alone can lag or miss there). Both
  // triggers share the one-shot trip guard, so a double fire runs the
  // return handling only once. Guarded to the real native platform and
  // wrapped in try/catch - the web is completely unaffected.
  useEffect(() => {
    if (!isRealNativePlatform()) return
    let handle: PluginListenerHandle | null = null
    let disposed = false
    void App.addListener('appStateChange', (status) => {
      if (status.isActive) void handleReturnFromSettings()
    })
      .then((listener) => {
        if (disposed) void listener.remove().catch(() => {})
        else handle = listener
      })
      .catch(() => {
        // Plugin unavailable (unexpected in the native shell): the
        // visibilitychange trigger above remains the fallback.
      })
    return () => {
      disposed = true
      if (handle) void handle.remove().catch(() => {})
    }
  }, [handleReturnFromSettings])

  return {
    supported,
    permission,
    coordinates,
    errorCode,
    isRequesting,
    serviceEnabled,
    request,
    refreshPermission,
    refreshServiceState,
    openSettings,
    getLastErrorCode,
    autoFlow,
    autoFlowErrorCode,
  }
}
