'use client'

/**
 * Mounted flag for client-only rendering without hydration mismatches.
 * Uses useSyncExternalStore so no state is set inside effects.
 */

import { useSyncExternalStore } from 'react'

const emptySubscribe = () => () => {}

export function useMounted(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  )
}
