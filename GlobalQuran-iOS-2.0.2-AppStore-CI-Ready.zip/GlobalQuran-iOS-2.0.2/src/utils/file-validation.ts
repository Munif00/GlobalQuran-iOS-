/**
 * Import file validation - every imported file is treated as untrusted input.
 *
 * Layers:
 * 1. Extension allow-list (PDF, EPUB, SQLite, JSON, TXT, ZIP).
 * 2. Magic-byte sniffing of the first bytes (a renamed `.pdf` that is really
 *    an executable is rejected).
 * 3. Size limits.
 * 4. SQLite/EPUB structural checks are done by their readers, which treat
 *    parse errors as corruption (never execute file content).
 *
 * The browser-reported MIME type is recorded as metadata but deliberately
 * not enforced (it is trivially spoofable); the magic bytes are the real
 * content check. Nothing is ever executed. Archive (zip) contents are never
 * extracted automatically; the zip is only stored as-is.
 */

import type { DownloadFormat } from '@/types'
import type { ImportValidationResult } from '@/types'

/** Hard upper bound for imports - protects against absurd memory use. */
export const MAX_IMPORT_BYTES = 512 * 1024 * 1024 // 512 MB

/** Upper bound for files that the built-in viewers can open. */
export const MAX_VIEWER_BYTES = 256 * 1024 * 1024 // 256 MB

const EXTENSION_FORMATS: Record<string, DownloadFormat | 'zip'> = {
  pdf: 'pdf',
  epub: 'epub',
  sql: 'sql',
  sqlite: 'sql',
  db: 'sql',
  json: 'json',
  txt: 'txt',
  zip: 'zip',
}

/** Read the first bytes of a Blob for magic-number sniffing. */
async function readHead(blob: Blob, bytes: number): Promise<Uint8Array> {
  const slice = blob.slice(0, bytes)
  const buffer = await slice.arrayBuffer()
  return new Uint8Array(buffer)
}

function startsWith(head: Uint8Array, signature: number[], offset = 0): boolean {
  if (head.length < offset + signature.length) return false
  return signature.every((byte, index) => head[offset + index] === byte)
}

/** UTF-8 decode of a byte range (for header text checks). */
function decodeAscii(head: Uint8Array, length: number): string {
  let out = ''
  const max = Math.min(length, head.length)
  for (let i = 0; i < max; i += 1) out += String.fromCharCode(head[i])
  return out
}

/** Real format detection from magic bytes. */
async function sniffFormat(head: Uint8Array): Promise<DownloadFormat | 'zip' | null> {
  // PDF: "%PDF-"
  if (decodeAscii(head, 5) === '%PDF-') return 'pdf'
  // ZIP family: "PK\x03\x04" (epub and zip archives)
  if (startsWith(head, [0x50, 0x4b, 0x03, 0x04])) return 'zip'
  // Empty zip (PK\x05\x06) or spanned zip (PK\x07\x08) also count as zip.
  if (startsWith(head, [0x50, 0x4b, 0x05, 0x06])) return 'zip'
  if (startsWith(head, [0x50, 0x4b, 0x07, 0x08])) return 'zip'
  // SQLite: "SQLite format 3\0"
  if (decodeAscii(head, 15) === 'SQLite format 3' && head[15] === 0x00) return 'sql'
  // JSON: leading BOM, brace or bracket (best effort; text formats are weakly
  // typed so extension + content preview decide).
  const preview = decodeAscii(head, 32).trimStart()
  if (preview.startsWith('{') || preview.startsWith('[')) return 'json'
  return null
}

/** Whether a detected zip payload looks like an EPUB (mimetype entry first). */
export function looksLikeEpub(head: Uint8Array): boolean {
  // A valid EPUB has "mimetype" as the first local file header entry with
  // content "application/epub+zip" stored uncompressed, so the magic string
  // appears near the start of the file.
  const text = decodeAscii(head, 64)
  return text.includes('application/epub+zip')
}

function extensionOf(fileName: string): string {
  const match = /\.([a-z0-9]+)$/i.exec(fileName.trim())
  return match ? match[1].toLowerCase() : ''
}

/**
 * Validate a user-picked file for import.
 * Never throws - always returns a structured result.
 */
export async function validateImportFile(file: {
  name: string
  size: number
  type?: string | null
  blob: Blob
}): Promise<ImportValidationResult> {
  const mimeType = typeof file.type === 'string' && file.type.length > 0 ? file.type : null

  if (file.size <= 0) {
    return { ok: false, format: null, errorCode: 'empty-file', mimeType, fileSize: file.size }
  }
  if (file.size > MAX_IMPORT_BYTES) {
    return { ok: false, format: null, errorCode: 'too-large', mimeType, fileSize: file.size }
  }

  const extension = extensionOf(file.name)
  const extensionFormat = EXTENSION_FORMATS[extension] ?? null
  if (!extensionFormat) {
    return { ok: false, format: null, errorCode: 'unsupported-extension', mimeType, fileSize: file.size }
  }

  // Sniff the real content (first 256 bytes cover all signatures used).
  let head: Uint8Array
  try {
    head = await readHead(file.blob, 256)
  } catch {
    return { ok: false, format: null, errorCode: 'unreadable', mimeType, fileSize: file.size }
  }

  let detected = await sniffFormat(head)

  // Resolve the zip family: epub when the mimetype entry says so.
  if (detected === 'zip' && looksLikeEpub(head)) detected = 'epub'

  // Plain text formats have no magic bytes; accept when the content is
  // mostly printable and the extension matches json/txt/sql-ish use.
  if (detected === null && (extensionFormat === 'json' || extensionFormat === 'txt')) {
    const printable = Array.from(head).filter((b) => b === 9 || b === 10 || b === 13 || (b >= 32 && b < 127) || b >= 128).length
    if (printable / head.length > 0.95) detected = extensionFormat
  }

  // SQLite extension but a zip payload = the zipped database the source
  // distributes - accept as zip (stored as-is, never auto-extracted).
  if (detected === 'zip' && (extensionFormat === 'sql' || extensionFormat === 'zip')) {
    return { ok: true, format: 'zip', errorCode: null, mimeType, fileSize: file.size }
  }

  if (detected === null) {
    return { ok: false, format: null, errorCode: 'unknown-content', mimeType, fileSize: file.size }
  }

  // The detected real content must be compatible with the claimed extension
  // (pdf<->pdf, epub<->epub/zip, sql<->sql, json<->json, txt<->txt).
  const compatible =
    (detected === extensionFormat) ||
    (detected === 'epub' && extensionFormat === 'epub') ||
    (detected === 'json' && extensionFormat === 'txt') ||
    (detected === 'txt' && extensionFormat === 'json')
  if (!compatible) {
    return { ok: false, format: detected, errorCode: 'content-extension-mismatch', mimeType, fileSize: file.size }
  }

  return { ok: true, format: detected, errorCode: null, mimeType, fileSize: file.size }
}

/** Whether a stored format can be opened by the built-in viewers. */
export function isViewableFormat(format: DownloadFormat | 'zip'): boolean {
  return format === 'pdf' || format === 'epub' || format === 'sql' || format === 'txt' || format === 'json'
}

/**
 * Sanitize a file name for storage: strips path traversal segments and
 * control characters, keeps a readable basename.
 */
export function sanitizeFileName(name: string): string {
  const base = name.split(/[\\/]/).pop() ?? 'file'
  const cleaned = base.replace(/[\u0000-\u001F\u007F]/g, '').trim()
  return cleaned.length > 0 ? cleaned.slice(0, 180) : 'file'
}
