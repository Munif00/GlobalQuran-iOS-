/**
 * Locale-aware formatting utilities.
 *
 * Intl formatter construction is comparatively expensive; the home and
 * prayer screens re-format every second (live countdowns), so constructed
 * formatters are cached per locale+options key. The cache is a plain Map
 * (bounded - the app uses a fixed set of locales and a handful of option
 * presets, so growth is naturally limited to a few dozen entries).
 */

const dateTimeCache = new Map<string, Intl.DateTimeFormat>()
const numberCache = new Map<string, Intl.NumberFormat>()

/** Hard cap as defense-in-depth (never reached in practice). */
const MAX_CACHE_ENTRIES = 200

function cachePut<T>(cache: Map<string, T>, key: string, value: T): void {
  if (cache.size >= MAX_CACHE_ENTRIES) {
    // Drop the oldest inserted entries (Map preserves insertion order).
    const drop = cache.size - MAX_CACHE_ENTRIES + 1
    let dropped = 0
    for (const entryKey of cache.keys()) {
      if (dropped >= drop) break
      cache.delete(entryKey)
      dropped++
    }
  }
  cache.set(key, value)
}

function getDateTimeFormat(locale: string, options?: Intl.DateTimeFormatOptions): Intl.DateTimeFormat {
  const key = `${locale}|${options ? JSON.stringify(stabilizeOptions(options)) : ''}`
  let formatter = dateTimeCache.get(key)
  if (!formatter) {
    formatter = safeDateTime(locale, options)
    cachePut(dateTimeCache, key, formatter)
  }
  return formatter
}

function getNumberFormat(locale: string, options?: Intl.NumberFormatOptions): Intl.NumberFormat {
  const key = `${locale}|${options ? JSON.stringify(options) : ''}`
  let formatter = numberCache.get(key)
  if (!formatter) {
    formatter = safeNumber(locale, options)
    cachePut(numberCache, key, formatter)
  }
  return formatter
}

function safeDateTime(locale: string, options?: Intl.DateTimeFormatOptions): Intl.DateTimeFormat {
  try {
    return new Intl.DateTimeFormat(locale, options)
  } catch {
    return new Intl.DateTimeFormat('en', options)
  }
}

function safeNumber(locale: string, options?: Intl.NumberFormatOptions): Intl.NumberFormat {
  try {
    return new Intl.NumberFormat(locale, options)
  } catch {
    return new Intl.NumberFormat('en', options)
  }
}

/** Key-order-independent JSON for DateTimeFormat options. */
function stabilizeOptions(options: Intl.DateTimeFormatOptions): Record<string, unknown> {
  const sorted: Record<string, unknown> = {}
  for (const key of Object.keys(options).sort()) sorted[key] = options[key as keyof Intl.DateTimeFormatOptions]
  return sorted
}

export function formatNumber(locale: string, value: number, options?: Intl.NumberFormatOptions): string {
  return getNumberFormat(locale, options).format(value)
}

export function formatBytes(locale: string, bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return formatNumber(locale, 0, { style: 'unit', unit: 'byte' })
  const units = ['byte', 'kilobyte', 'megabyte', 'gigabyte']
  const exponent = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1)
  return formatNumber(locale, bytes / 1024 ** exponent, {
    style: 'unit',
    unit: units[exponent],
    maximumFractionDigits: 1,
  })
}

export function formatDate(locale: string, date: Date, options?: Intl.DateTimeFormatOptions): string {
  return getDateTimeFormat(locale, options).format(date)
}

export function formatTime(locale: string, date: Date): string {
  return formatDate(locale, date, { hour: '2-digit', minute: '2-digit' })
}

/** Format an ISO 8601 date+time string in the given locale. */
export function formatDateTimeString(locale: string, iso: string): string {
  try {
    return formatDate(locale, new Date(iso), {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return iso
  }
}
