/**
 * Date utilities, including Hijri date formatting through the platform's
 * Umm al-Qura calendar (ICU). Returns null when no reliable Hijri source
 * is available so callers can hide the element entirely.
 */

export function formatGregorianDate(locale: string, date: Date): string {
  try {
    return new Intl.DateTimeFormat(locale, {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date)
  } catch {
    return new Intl.DateTimeFormat('en', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date)
  }
}

/**
 * Hijri date via the Umm al-Qura calendar. Only returned when the runtime
 * actually supports it; otherwise null (the UI hides the Hijri date).
 */
export function formatHijriDate(locale: string, date: Date): string | null {
  try {
    return new Intl.DateTimeFormat(locale, {
      calendar: 'islamic-umalqura',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date)
  } catch {
    try {
      return new Intl.DateTimeFormat('en', {
        calendar: 'islamic-umalqura',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }).format(date)
    } catch {
      return null
    }
  }
}

/** Part of day used for time-based greetings. */
export type DayPart = 'morning' | 'afternoon' | 'evening' | 'night'

export function getDayPart(date: Date): DayPart {
  const hour = date.getHours()
  if (hour >= 5 && hour < 12) return 'morning'
  if (hour >= 12 && hour < 17) return 'afternoon'
  if (hour >= 17 && hour < 21) return 'evening'
  return 'night'
}
