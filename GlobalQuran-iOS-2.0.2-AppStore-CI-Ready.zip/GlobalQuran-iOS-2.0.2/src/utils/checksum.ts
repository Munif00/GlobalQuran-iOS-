/**
 * Integrity utilities - SHA-256 checksums computed locally via Web Crypto.
 */

export async function sha256Hex(data: ArrayBuffer | Blob): Promise<string> {
  const buffer = data instanceof Blob ? await data.arrayBuffer() : data
  const digest = await crypto.subtle.digest('SHA-256', buffer)
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('')
}

/** Short human-friendly form of a hex checksum (first 12 characters). */
export function shortChecksum(checksum: string): string {
  return checksum.slice(0, 12)
}
