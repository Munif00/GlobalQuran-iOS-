/**
 * Text normalization for search matching.
 *
 * Goals (per the library search requirements):
 * - Case-insensitive matching for all scripts.
 * - Unicode normalization (NFKC) so composed/decomposed forms match.
 * - Arabic diacritic tolerance: harakat, tanwin, shadda, sukun, small marks
 *   and tatweel are stripped so a search without diacritics matches
 *   fully-vocalized Arabic text (and vice versa).
 * - Arabic letter-form folding: alef/hamza variants, yeh forms, teh marbuta
 *   and heh goal are folded so common spelling variants still match.
 *
 * The original text is never modified for display - this normalization is
 * used only to build comparable search keys.
 */

/** Combining Arabic diacritics (harakat, tanwin, shadda, sukun, etc.). */
const ARABIC_DIACRITICS = /[\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08E1\u08E3-\u08FF]/g
/** Tatweel (kashida) - decorative stretch, ignored for matching. */
const TATWEEL = /\u0640/g
/** Zero-width joiners/non-joiners and BOM - shaping artifacts. */
const INVISIBLE = /[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g

/** Arabic letter-form folding map (applied after diacritics are removed). */
const ARABIC_FOLD: Record<string, string> = {
  '\u0622': '\u0627', // Alef madda -> alef
  '\u0623': '\u0627', // Alef hamza above -> alef
  '\u0625': '\u0627', // Alef hamza below -> alef
  '\u0671': '\u0627', // Alef wasla -> alef
  '\u0624': '\u0648', // Waw hamza -> waw
  '\u0626': '\u064A', // Yeh hamza -> yeh
  '\u0649': '\u064A', // Alef maksura -> yeh
  '\u06CC': '\u064A', // Farsi yeh -> yeh
  '\u0629': '\u0647', // Teh marbuta -> heh
  '\u06C3': '\u0647', // Heh goal -> heh
}

function foldArabic(text: string): string {
  return text.replace(/[\u0621-\u06FF]/g, (char) => ARABIC_FOLD[char] ?? char)
}

/**
 * Build a normalized search key for a piece of text.
 * Safe for any input - never throws.
 */
export function normalizeForSearch(input: string | null | undefined): string {
  if (!input) return ''
  try {
    // Decompose first so Latin diacritics become base + combining marks,
    // then strip the combining marks (Français -> francais, Åmélien -> amelien).
    let text = input.normalize('NFD').replace(/[\u0300-\u036F]/g, '')
    text = text.normalize('NFKC').toLowerCase()
    text = text.replace(ARABIC_DIACRITICS, '')
    text = text.replace(TATWEEL, '')
    text = text.replace(INVISIBLE, '')
    text = foldArabic(text)
    // Collapse whitespace so multi-word queries still match across spacing.
    return text.replace(/\s+/g, ' ').trim()
  } catch {
    return input.toLowerCase().trim()
  }
}

/** True when `query` (already normalized) appears anywhere in `candidate`. */
export function normalizedIncludes(candidate: string, normalizedQuery: string): boolean {
  if (!normalizedQuery) return true
  return normalizeForSearch(candidate).includes(normalizedQuery)
}

/** Strip ASCII/Unicode control characters from source text before rendering. */
export function stripControlCharacters(input: string): string {
  // Keep \n and \t (legitimate formatting); remove C0/C1 controls except those.
  return input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, '')
}
