/**
 * Global Quran - Domain models
 *
 * These are the core typed entities of the application. They are intentionally
 * decoupled from any UI or persistence concern. Future stages (QuranEnc sync,
 * prayer-time integration, offline downloads) consume these models.
 */

/* ------------------------------------------------------------------ */
/* App structure                                                       */
/* ------------------------------------------------------------------ */

/** The main sections of the application. */
export type AppScreen =
  | 'home'
  | 'quran'
  | 'downloads'
  | 'prayer'
  | 'qibla'
  | 'settings'
  | 'profile'

/* ------------------------------------------------------------------ */
/* Translations library                                                */
/* ------------------------------------------------------------------ */

/**
 * Verification states for translation records.
 * `official_verified` may only ever be assigned with documented evidence
 * from the relevant reviewing authority.
 */
export type VerificationStatus =
  | 'official_verified'
  | 'awaiting_verification'
  | 'not_verified'
  | 'rejected'

/** File formats a translation may be distributed in. */
export type DownloadFormat = 'json' | 'sql' | 'txt' | 'pdf' | 'epub' | 'mp3'

/**
 * A downloadable file offered by the source for a translation.
 * Derived strictly from documented QuranEnc fields - every entry is a real URL
 * the source publishes; `size` is null when the source does not publish it.
 */
export interface TranslationFile {
  /** Stable id for list keys (format + variant). */
  id: string
  format: DownloadFormat
  /** Neutral variant label derived from the source field name. */
  variant: 'database' | 'database-uncompressed' | 'standard' | 'pure' | 'mobile' | null
  url: string
  /** Size in bytes as published by the source; null when not published. */
  size: number | null
  /** Cover image URL published by the source, when present (PDF variants). */
  coverUrl: string | null
}

/**
 * A Quran translation with its source metadata.
 *
 * Mapping policy (QuranEnc API v1 does not provide separate fields for these):
 * - `translator`, `publisher`, `reviewingAuthority`, `edition`,
 *   `publicationYear` are `null` unless documented by the source or attached
 *   through the verification registry. They are never inferred from titles or
 *   descriptions.
 * - Records are only ever created from the real QuranEnc catalog.
 */
export interface Translation {
  id: string
  /** Stable source key, e.g. `english_rwwad`. */
  key: string
  /** ISO language code of the translation (e.g. `en`, `zh`, `ceb`). */
  languageCode: string
  /** English name of the language as returned by the source ISO-code map. */
  languageName: string
  /** Native name of the language when known from the app locale registry. */
  languageNativeName: string | null
  /** Text direction of the translation (`ltr` or `rtl`). */
  direction: 'ltr' | 'rtl'
  /** Title of the translation work (localized by the source when available). */
  title: string
  /** Description supplied by the source, when provided. */
  description: string | null
  /** Translator as a distinct documented field - not provided by QuranEnc. */
  translator: string | null
  publisher: string | null
  /** Institution that reviewed/approved the translation, if documented. */
  reviewingAuthority: string | null
  edition: string | null
  publicationYear: number | null
  version: string | null
  /** ISO 8601 timestamp of the last content update at the source. */
  lastUpdated: string | null
  /** Source page URL. */
  sourceUrl: string | null
  availableFormats: DownloadFormat[]
  /** Real downloadable files published by the source. */
  downloadFiles: TranslationFile[]
  /** Institutional approval - kept separate from licensing. */
  approvalStatus: VerificationStatus
  /** Content licensing / rights status as documented by the source. */
  rightsStatus: string | null
  /** When this record was last checked against the source. */
  lastChecked: string | null
}

/** A language entry in the live catalog (real counts from the source). */
export interface CatalogLanguage {
  code: string
  /** English name from the source ISO-code map. */
  name: string
  /** Native name when known from the app locale registry. */
  nativeName: string | null
  /** Number of translations in this language. */
  count: number
}

/* ------------------------------------------------------------------ */
/* Downloads / offline storage                                         */
/* ------------------------------------------------------------------ */

export type DownloadStatus =
  | 'queued'
  | 'downloading'
  | 'paused'
  | 'verifying'
  | 'completed'
  | 'failed'
  | 'interrupted'
  | 'corrupted'
  | 'canceled'

export type IntegrityStatus = 'unverified' | 'checking' | 'verified' | 'mismatch'

/** A downloaded (or imported) file tracked by the offline library. */
export interface Download {
  id: string
  translationId: string
  fileName: string
  format: DownloadFormat
  /** Size in bytes. */
  fileSize: number
  version: string | null
  /** ISO 8601 timestamp. */
  downloadedAt: string
  /** Storage-adapter URI (IndexedDB key on web, file URI on mobile). */
  localUri: string
  /** SHA-256 checksum, when published by the source or computed locally. */
  checksum: string | null
  downloadStatus: DownloadStatus
  integrityStatus: IntegrityStatus
}

/* ------------------------------------------------------------------ */
/* Download manager (Prompt 3)                                         */
/* ------------------------------------------------------------------ */

/**
 * A managed download job (persisted across restarts in IndexedDB).
 *
 * Completed jobs reference the stored file in the offline library; the job
 * record keeps the full state machine history: queued -> downloading
 * -> verifying -> completed, with paused / interrupted / failed / corrupted
 * / canceled branches.
 */
export interface DownloadJobRecord {
  /** Stable job id. */
  id: string
  /** `file` (document download - default for pre-existing records),
   *  `offline-pack` (complete translation for in-app offline reading),
   *  `audio-batch` (verified recitation audio) or `translation-audio-batch`
   *  (verified human-recorded translation narration audio downloaded for
   *  offline playback - one record per batch, per-file progress inside). */
  kind?: 'file' | 'offline-pack' | 'audio-batch' | 'translation-audio-batch'
  /** Catalog translation key (null for direct imports). */
  translationKey: string | null
  /** Snapshot of the translation title at enqueue time. */
  translationTitle: string
  /** Snapshot of the language display name at enqueue time. */
  languageName: string | null
  /** Catalog file id (e.g. `pdf-standard`, `sql-database-uncompressed`). */
  fileId: string
  fileName: string
  format: DownloadFormat
  /** Source URL from the catalog (never user-supplied). */
  sourceUrl: string
  /** Total size in bytes when the source published it. */
  expectedSize: number | null
  /** Source version at enqueue time. */
  sourceVersion: string | null
  /** Current state. */
  status: DownloadStatus
  /** Bytes received so far (0 until the stream starts). */
  bytesReceived: number
  /** Total bytes when known from the stream (content-length). */
  totalBytes: number | null
  /** Human-safe error code, never a raw upstream error string. */
  errorCode: string | null
  /** SHA-256 of the completed file, computed locally. */
  checksum: string | null
  /** Id of the finalized stored file (once completed). */
  storedFileId: string | null
  /** True when the request server supported byte ranges (resume possible). */
  rangeSupported: boolean | null
  createdAt: string
  updatedAt: string
  completedAt: string | null
  /** Batch descriptor (only for kind: 'audio-batch'). */
  audioBatch?: AudioBatchDescriptor
  /** Translation audio batch descriptor (only for kind: 'translation-audio-batch'). */
  translationAudioBatch?: TranslationAudioBatchDescriptor
}

/** What a recitation audio batch covers. */
export type AudioBatchKind = 'ayah' | 'sura' | 'range' | 'juz' | 'complete'

/** The audio-batch part of a download job record (kind: 'audio-batch'). */
export interface AudioBatchDescriptor {
  styleId: string
  reciterName: string
  styleLabel: string
  batchKind: AudioBatchKind
  /** Sura of an ayah/sura/range batch; null for juz/complete. */
  sura: number | null
  /** Single ayah (ayah batch) or range start (range batch). */
  ayahFrom: number | null
  /** Range end (range batch). */
  ayahTo: number | null
  /** Juz number (juz batch). */
  juz: number | null
  /** Verified files the batch covers (from the server plan). */
  filesTotal: number
  /** Files already stored + verified when the record was last written. */
  filesCompleted: number
  /** Files that failed verification during this run. */
  filesFailed: number
  /** Exact expected total bytes (from the verified plan). */
  bytesTotal: number
}

/** Storage quota snapshot from the platform (when available). */
export interface StorageEstimateInfo {
  usage: number | null
  quota: number | null
  persisted: boolean
}

/** Offline status of one translation, computed from the real pack index. */
export interface OfflinePackStatus {
  translationKey: string
  /** Sura records currently cached on this device. */
  cachedSuras: number
  /** Always 114 - the complete Quran. */
  totalSuras: number
  /** True only when every sura is cached (full offline availability). */
  complete: boolean
  /** Approximate stored size in bytes, computed locally. */
  approxBytes: number
  /** Source version shared by every cached sura (null when mixed/unknown). */
  version: string | null
  /** When the pack index was last updated. */
  updatedAt: string | null
}

/** Validation outcome for an imported file. */
export interface ImportValidationResult {
  ok: boolean
  /** Detected real format (from magic bytes + extension). */
  format: DownloadFormat | 'zip' | null
  /** Stable error code when rejected. */
  errorCode: string | null
  /** Detected MIME type from the browser, when provided. */
  mimeType: string | null
  fileSize: number
}

/** Per-file viewer state (reading positions survive restarts). */
export interface FileViewerState {
  /** Last PDF page opened. */
  pdfPage?: number
  /** EPUB CFI position. */
  epubCfi?: string
  /** EPUB progress percentage 0-100, when known. */
  epubProgress?: number
  updatedAt: string
}

/* ------------------------------------------------------------------ */
/* Prayer times                                                        */
/* ------------------------------------------------------------------ */

/**
 * Calculation method identifiers as defined by the AlAdhan API
 * (https://aladhan.com/calculation-methods).
 *
 * The full documented method set was verified live against
 * `GET https://api.aladhan.com/v1/methods` on 2026-11-15. Numeric API ids
 * live in `src/lib/prayer/methods.ts` (single source of truth).
 */
export type CalculationMethodId =
  | 'MWL'
  | 'ISNA'
  | 'EGYPT'
  | 'MAKKAH'
  | 'KARACHI'
  | 'TEHRAN'
  | 'JAFARI'
  | 'DUBAI'
  | 'KUWAIT'
  | 'QATAR'
  | 'SINGAPORE'
  | 'TURKEY'
  | 'MOONSIGHTING'
  | 'GULF'
  | 'FRANCE'
  | 'RUSSIA'
  | 'JAKIM'
  | 'TUNISIA'
  | 'ALGERIA'
  | 'KEMENAG'
  | 'MOROCCO'
  | 'PORTUGAL'
  | 'JORDAN'

/** Asr juristic method. */
export type Madhhab = 'standard' | 'hanafi'

/**
 * What an Asr time in a record actually follows.
 * `authority_published` = the Asr time was published by an official
 * authority (e.g. the JAKIM timetable); the madhhab setting is not applied
 * to official authority data.
 */
export type AsrBasis = Madhhab | 'authority_published'

/** Per-prayer minute adjustments. */
export interface PrayerAdjustments {
  fajr: number
  sunrise: number
  dhuhr: number
  asr: number
  maghrib: number
  isha: number
}

/** High-latitude (twilight) handling rule. `auto` defers to the engine. */
export type HighLatitudeRuleMode = 'auto' | 'middle_of_night' | 'one_seventh' | 'angle_based'

/** The concrete rule an engine applied (null for official authority data). */
export type AppliedHighLatitudeRule = 'middle_of_night' | 'one_seventh' | 'angle_based'

/** How the calculation method was chosen. */
export type MethodSelectionMode = 'auto' | 'manual'

export interface PrayerSettings {
  countryCode: string | null
  /** Country display name (from geocoding or city selection). */
  countryName: string | null
  city: string | null
  latitude: number | null
  longitude: number | null
  timeZone: string | null
  /**
   * `auto` uses the zone detected from the location; `manual` keeps the
   * user's correction in `manualTimeZone` (used when detection is wrong).
   */
  timeZoneMode: 'auto' | 'manual'
  /** User-selected IANA zone correction; only used in manual mode. */
  manualTimeZone: string | null
  /** Local authority the user prefers to follow, when known. */
  preferredAuthority: string | null
  calculationMethod: CalculationMethodId
  madhhab: Madhhab
  adjustments: PrayerAdjustments
  /** `auto` resolves the documented default for the detected country. */
  methodMode: MethodSelectionMode
  highLatitudeRule: HighLatitudeRuleMode
  /** JAKIM e-Solat zone code (Malaysia only), when the user selected one. */
  jakimZone: string | null
}

/** A user-saved prayer location (persisted client-side). */
export interface SavedPrayerLocation {
  id: string
  /** Display label, e.g. `Makkah, Saudi Arabia`. */
  label: string
  city: string | null
  country: string | null
  countryCode: string | null
  latitude: number
  longitude: number
  timeZone: string | null
  /** JAKIM zone when the location is in Malaysia. */
  jakimZone: string | null
  createdAt: string
}

/* ------------------------------------------------------------------ */
/* Prayer times - data records & API contracts                         */
/* ------------------------------------------------------------------ */

/** Which tier of the hybrid source strategy produced a record. */
export type PrayerSourceType = 'official_authority' | 'aladhan_api' | 'local_engine'

/**
 * A single day of prayer times with full source transparency.
 * Every time value is an ISO 8601 instant (with UTC offset) so countdowns
 * and sorting are exact across time zones and DST transitions.
 */
export interface PrayerTimeRecord {
  /** Gregorian date the times are for (YYYY-MM-DD, location-local). */
  date: string
  /** Hijri date when a reliable source provided it (format `DD-MM-YYYY`). */
  hijriDate: string | null
  /** Where the Hijri date came from - never claimed from nothing. */
  hijriSource: 'jakim_official' | 'aladhan_hjcosa' | 'local_calendar' | null
  latitude: number
  longitude: number
  /** IANA time-zone identifier the times are expressed in. */
  timeZone: string
  fajr: string
  sunrise: string
  dhuhr: string
  asr: string
  maghrib: string
  isha: string
  sourceType: PrayerSourceType
  sourceName: string
  authorityName: string | null
  /** Human-readable method label (e.g. `Umm Al-Qura University, Makkah`). */
  calculationMethod: string
  /** Method code when the times come from a calculation method. */
  calculationMethodCode: CalculationMethodId | null
  /** What the Asr time actually follows. */
  madhhab: AsrBasis
  /** Minute adjustments applied app-side to these times. */
  adjustments: PrayerAdjustments
  /** ISO 8601 - when the underlying data was fetched from its source. */
  fetchedAt: string
  /** True when served from cache after an upstream failure. */
  isCached: boolean
  validationStatus: 'ok' | 'cached' | 'degraded'
}

/** How the method was resolved for a request (auto vs manual). */
export interface MethodResolution {
  mode: MethodSelectionMode
  methodId: CalculationMethodId
  /** ISO country code the default was derived from (null for manual). */
  countryCode: string | null
  /**
   * `official_national` - the method represents that country's national
   * authority standard. `regional_common` - a widely used regional default,
   * not an official government setting. `global_default` - Muslim World
   * League fallback where no country-specific method is documented.
   * null - the user chose the method manually.
   */
  kind: 'official_national' | 'regional_common' | 'global_default' | null
}

/** Full transparency block describing how a result was produced. */
export interface PrayerSourceInfo {
  sourceType: PrayerSourceType
  sourceName: string
  authorityName: string | null
  /** Registry id of the official authority, when one was used. */
  officialRegistryId: string | null
  calculationMethodCode: CalculationMethodId | null
  calculationMethodName: string | null
  /** Documented parameters, e.g. `Fajr 18.5° · Isha 90 min`. */
  calculationMethodParams: string | null
  methodResolution: MethodResolution | null
  madhhab: Madhhab
  /** Concrete high-latitude rule applied (null for official authority data). */
  appliedHighLatitudeRule: AppliedHighLatitudeRule | null
  /** True when the rule was applied due to the location's latitude. */
  highLatitudeAdjusted: boolean
  timeZone: string
  /** How the time zone was resolved for this request. */
  timeZoneSource: 'provided' | 'aladhan_detected' | 'zone_derived' | null
  adjustments: PrayerAdjustments
  /** ISO 8601 - when the data was fetched (or originally cached). */
  fetchedAt: string
  isCached: boolean
  /** Why each source tier was used or skipped - the honest fallback trace. */
  attempts: Array<PrayerSourceAttempt>
  /** Honest caveats that the UI must surface. */
  notes: string[]
}

export interface PrayerSourceAttempt {
  source: 'jakim_esolat' | 'aladhan_api' | 'local_engine' | 'cache'
  outcome: 'used' | 'failed' | 'skipped'
  /** Stable, non-technical reason code (translated in the UI). */
  reasonCode:
    | 'ok'
    | 'not_applicable'
    | 'out_of_published_range'
    | 'network_error'
    | 'invalid_response'
    | 'timeout'
    | 'no_zone_selected'
    | 'no_cached_data'
    | null
}

/** Response of GET /api/prayer/times. */
export interface PrayerTimesResponse {
  status: 'live' | 'unavailable'
  /** Human-readable, pre-localized fallback message (client prefers messageKey). */
  message: string | null
  /** i18n key for the honest explanation when status is unavailable. */
  messageKey: string | null
  record: PrayerTimeRecord | null
  source: PrayerSourceInfo | null
  /**
   * True when this response was served from the client-side offline snapshot
   * (the server itself could not be reached). The record is a previously
   * verified one - never a fabrication - and the UI labels it as stored data.
   */
  clientCache?: boolean
  /** Source-chain trace - present when status is not live. */
  trace?: PrayerSourceAttempt[]
  traceNotes?: string[]
}

/** Response of GET /api/prayer/calendar. */
export interface PrayerCalendarResponse {
  status: 'live' | 'unavailable' | 'partial'
  message: string | null
  messageKey: string | null
  month: string
  days: PrayerTimeRecord[]
  source: PrayerSourceInfo | null
  /** Source-chain trace - present when status is not live. */
  trace?: PrayerSourceAttempt[]
  traceNotes?: string[]
}

/** One entry of the verified AlAdhan method registry. */
export interface CalculationMethodInfo {
  id: CalculationMethodId
  /** AlAdhan numeric API id (verified via GET /v1/methods). */
  numericId: number
  /** Official method name exactly as documented by AlAdhan. */
  name: string
  /** Documented parameters summary, e.g. `Fajr 18° · Isha 17°`. */
  paramsSummary: string
  /** True when AlAdhan itself labels the method experimental. */
  experimental: boolean
  /** True when the offline engine can reproduce this method locally. */
  localEngineSupported: boolean
}

/** Documented default method for a country. */
export interface CountryMethodDefaultDto {
  countryCode: string
  countryName: string
  methodId: CalculationMethodId
  kind: 'official_national' | 'regional_common' | 'global_default'
}

/** Response of GET /api/prayer/meta. */
export interface PrayerMetaResponse {
  status: 'live'
  methods: CalculationMethodInfo[]
  countryDefaults: CountryMethodDefaultDto[]
  /** When the method registry was verified against the live API. */
  verifiedAt: string
  verifiedFrom: string
}

/** A JAKIM e-Solat prayer zone (verified live, see authorities registry). */
export interface JakimZoneInfo {
  code: string
  /** Malaysian state the zone belongs to. */
  state: string
  /** IANA time zone covering the zone. */
  timeZone: string
}

/** One record of the official prayer-time authority registry. */
export interface AuthorityRegistryEntryDto {
  /** Stable registry id, e.g. `MY-JAKIM`. */
  id: string
  countryCode: string
  countryName: string
  region: string
  authorityName: string
  authorityType: string
  website: string | null
  /** Machine-readable endpoint, when a public one exists and was verified. */
  endpoint: string | null
  endpointFormat: string | null
  coverage: string
  updateFrequency: string
  lastVerified: string
  verificationEvidence: string
  reliability: 'verified_live' | 'official_source_no_public_api' | 'requires_api_key' | 'unverified'
  implementation: 'integrated' | 'fallback_to_aladhan' | 'not_integrated'
  /** AlAdhan method implementing the authority's standard, when one exists. */
  aladhanMethod: CalculationMethodId | null
  aladhanMethodNote: string | null
}

/** Response of GET /api/prayer/registry. */
export interface PrayerRegistryResponse {
  status: 'live'
  registry: AuthorityRegistryEntryDto[]
  jakimZones: JakimZoneInfo[]
  /** Honest summary - no worldwide official coverage is claimed. */
  summary: string
}

/** A city-search result (bundled dataset and/or Nominatim). */
export interface CitySearchResult {
  id: string
  name: string
  region: string | null
  country: string
  countryCode: string
  latitude: number
  longitude: number
  timeZone: string | null
  /** Whether the coordinates are an approximate city center. */
  approximate: boolean
  /** `bundled` (curated list) or `nominatim` (live geocoding). */
  origin: 'bundled' | 'nominatim'
}

/** Response of GET /api/prayer/geocode?q=. */
export interface CitySearchResponse {
  status: 'live' | 'degraded'
  /** Degraded = live geocoding unavailable; bundled results only. */
  messageKey: string | null
  results: CitySearchResult[]
}

/** Response of GET /api/prayer/reverse-geocode. */
export interface ReverseGeocodeResponse {
  status: 'live' | 'unavailable'
  city: string | null
  region: string | null
  countryName: string | null
  countryCode: string | null
}

/**
 * Adhan reminder settings (PROMPT 13). Fully functional offline: the
 * assigned VERIFIED local recording plays at the exact prayer time; it is
 * never streamed from a website and never silently substituted.
 */
export interface AdhanReminderSettings {
  /** 'audio' - full Adhan from the local library at the exact prayer time
   *  (falls back honestly to a silent notification when the assigned
   *  recording is not stored/verified). 'silent' - plain notification,
   *  optionally `leadMinutes` early. */
  mode: 'audio' | 'silent'
  /** One recording for all five prayers, or independent per-prayer choice. */
  useSameForAll: boolean
  /** Recording id applied to all prayers when `useSameForAll` (null = none chosen yet). */
  sameForAllRecordingId: string | null
  /** Per-prayer recording ids (used when `!useSameForAll`). Sunrise never plays Adhan. */
  perPrayerRecordingIds: {
    fajr: string | null
    dhuhr: string | null
    asr: string | null
    maghrib: string | null
    isha: string | null
  }
  /** Playback volume 0..1, applied where the platform allows it. */
  volume: number
}

/** Notification preferences (architecture - no permission is ever requested
 *  without an explicit user action). */
export interface PrayerNotificationPreferences {
  enabled: boolean
  /** Minutes before the prayer time to fire the reminder (silent mode). */
  leadMinutes: number
  perPrayer: {
    fajr: boolean
    sunrise: boolean
    dhuhr: boolean
    asr: boolean
    maghrib: boolean
    isha: boolean
  }
  /** @deprecated Legacy pre-PROMPT-13 flag; migrated into `adhanSettings.mode`. */
  adhan: boolean
  /** Adhan audio settings (PROMPT 13). */
  adhanSettings: AdhanReminderSettings
  quietHours: {
    enabled: boolean
    /** Local wall-clock times (`HH:mm`). */
    start: string
    end: string
  }
}

/* ------------------------------------------------------------------ */
/* Adhan muezzin library                                               */
/* ------------------------------------------------------------------ */

/** One recording in the VERIFIED Adhan catalog (server-side source of truth).
 *  Only real recordings from the approved source are ever listed - never
 *  generated audio, never unverified identity metadata. */
export interface AdhanCatalogEntry {
  id: string
  /** Official file name at the source. */
  fileName: string
  /** Official label exactly as published by the source page. */
  title: string
  /** Arabic rendering of the same official label. */
  titleAr: string
  muezzinEn: string
  muezzinAr: string
  /** Country / mosque info - only what the official source page states. */
  country: string | null
  url: string
  /** Exact byte size verified at the source. */
  sizeBytes: number
  /** Duration verified while verifying the source file. */
  durationSeconds: number
  format: 'mp3'
  attribution: string
}

/** Response of GET /api/prayer/adhans/catalog. */
export interface AdhanCatalogResponse {
  status: 'live'
  source: string
  sourceUrl: string
  licenseNote: string
  /** Whether a live size probe of the source succeeded just now. */
  sourceReachable: boolean
  recordings: AdhanCatalogEntry[]
}

/** One entry of the persistent local Adhan manifest (IndexedDB). */
export interface AdhanManifestEntry {
  /** Recording id (matches the catalog). */
  id: string
  muezzinEn: string
  muezzinAr: string
  title: string
  sourceRef: string
  fileSize: number
  fileFormat: 'mp3'
  /** 'ready' only after full verification (size + MP3 signature + decode). */
  status: 'ready'
  verification: 'verified'
  downloadedAt: string
}

/* ------------------------------------------------------------------ */
/* Reading & user preferences                                          */
/* ------------------------------------------------------------------ */

export interface ReadingPosition {
  surah: number
  ayah: number
  /** ISO 8601 timestamp. */
  savedAt: string
}

export type TextSize = 'sm' | 'md' | 'lg' | 'xl'

export type LanguageMode = 'auto' | 'manual'

export type ThemePreference = 'light' | 'dark' | 'system'

/** Built-in avatar artwork shipped with the application. */
export interface BuiltinAvatar {
  id: string
  /** Public asset path (e.g. `/avatars/mushaf.jpg`). */
  src: string
}

/** Which avatar image the profile shows. */
export type AvatarKind = 'builtin' | 'custom'

/** Local, private profile data (never leaves the device). */
export interface LocalProfile {
  /** Optional display name typed by the user (null when unset). */
  displayName: string | null
  avatarKind: AvatarKind
  /** Built-in avatar id when `avatarKind` is `builtin`. */
  builtinAvatarId: string
  /** Data-URL of the uploaded image when `avatarKind` is `custom`. */
  customAvatar: string | null
}

export interface UserPreferences {
  interfaceLanguage: string
  languageMode: LanguageMode
  theme: ThemePreference
  textSize: TextSize
  lastReadingPosition: ReadingPosition | null
  /** Preferred translation language - independent of the interface language. */
  preferredQuranTranslationLanguage: string | null
  prayerSettings: PrayerSettings
}

/* ------------------------------------------------------------------ */
/* API contracts                                                       */
/* ------------------------------------------------------------------ */

export type IntegrationState = 'planned' | 'in_progress' | 'partial' | 'live'

export interface IntegrationInfo {
  status: IntegrationState
  source: string
  note?: string
}

/** Response of GET /api/config */
export interface AppConfigDto {
  appVersion: string
  fallbackLocale: string
  supportedLanguages: Array<{
    code: string
    englishName: string
    nativeName: string
    direction: 'ltr' | 'rtl'
  }>
  integrations: {
    quranText: IntegrationInfo
    translationsCatalog: IntegrationInfo
    prayerTimes: IntegrationInfo
    qibla: IntegrationInfo
    offlineDownloads: IntegrationInfo
  }
}

/** Response of GET /api/translations/catalog (live from QuranEnc). */
export interface TranslationsCatalogResponse {
  status: 'live' | 'not_integrated'
  source: string
  sourceUrl: string
  message: string
  items: Translation[]
  /** Languages that actually have translations at the source. */
  languages: CatalogLanguage[]
  total: number
  /** ISO 8601 - when the catalog was last successfully synchronized. */
  lastSyncedAt: string | null
  /** ISO 8601 - when the catalog was last checked against the source. */
  lastCheckedAt: string | null
  /** True when the served data came from cache after an upstream failure. */
  servedFromCache: boolean
}

/** One ayah of the Quran with its translation (source-verbatim). */
export interface QuranAya {
  sura: number
  aya: number
  /** Uthmanic Hafs Arabic text, exactly as supplied by the source. */
  arabicText: string
  /** Translation text, exactly as supplied by the source. */
  translation: string
  /** Footnotes supplied by the source; empty string when none. */
  footnotes: string | null
}

/** Response of GET /api/quran/sura/[translationKey]/[suraNumber]. */
export interface SuraContentResponse {
  status: 'live'
  source: string
  translationKey: string
  translationTitle: string | null
  languageCode: string | null
  direction: 'ltr' | 'rtl'
  sura: number
  ayahCount: number
  version: string | null
  ayat: QuranAya[]
}

/** Response of GET /api/quran/sowar-names. */
export interface SuraNamesResponse {
  status: 'live'
  locale: string
  /** Locale actually used when the requested one is not available at the source. */
  effectiveLocale: string
  names: Record<string, string>
}

/** Administrator-attached verification record (persisted server-side). */
export interface VerificationRecordDto {
  translationKey: string
  status: VerificationStatus
  reviewingAuthority: string | null
  officialSource: string | null
  documentReference: string | null
  verifiedAt: string | null
  reviewerNotes: string | null
  updatedAt: string
}

/** Response of GET /api/translations/verification. */
export interface VerificationListResponse {
  records: VerificationRecordDto[]
}

/** Payload of POST /api/translations/verification. */
export interface VerificationUpsertPayload {
  translationKey: string
  status: VerificationStatus
  reviewingAuthority?: string | null
  officialSource?: string | null
  documentReference?: string | null
  verifiedAt?: string | null
  reviewerNotes?: string | null
}

/* ------------------------------------------------------------------ */
/* Audio recitation (verified EveryAyah catalog)                       */
/* ------------------------------------------------------------------ */

/** Live reachability of a recitation's files at the source. */
export interface AudioLiveCheck {
  status: 'available' | 'unavailable' | 'unknown'
  checkedAt: string
  httpStatus: number | null
}

/** One recitation style of the verified catalog (GET /api/quran/audio/reciters). */
export interface ReciterStyleDto {
  id: string
  reciterName: string
  reciterNameArabic: string
  style: 'muallim' | 'murattal' | 'mujawwad' | string
  styleLabel: string
  bitrate: string
  format: string
  folder: string
  sourceName: string
  sourceSite: string
  bioNote: string | null
  bioNoteSource: string | null
  forLearning: boolean
  seedVerified: boolean
  verifiedAt: string
  verificationMethod: string
  totalAyat: number
  completeSuras: number
  totalBytes: number
  live: AudioLiveCheck | null
  /** Final verdict: seed-verified inventory AND live-confirmed availability. */
  available: boolean
}

/** Response of GET /api/quran/audio/reciters. */
export interface ReciterCatalogResponse {
  styles: ReciterStyleDto[]
}

/** One verified audio file of a sura (exact size from the source listing). */
export interface SuraAudioFileDto {
  ayah: number
  sizeBytes: number
  url: string
}

/** Response of GET /api/quran/audio/sura/[styleId]/[sura]. */
export interface SuraAudioResponse {
  styleId: string
  styleLabel: string | null
  reciterName: string | null
  bitrate: string | null
  folder: string | null
  sourceName: string | null
  sura: number
  ayahCount: number
  availableAyat: number
  missingAyat: number[]
  totalBytes: number
  live: AudioLiveCheck
  files: SuraAudioFileDto[]
}

/* ------------------------------------------------------------------ */
/* Recitation audio downloads & offline playback (PROMPT 9)            */
/* ------------------------------------------------------------------ */

/**
 * One entry of the persistent local audio download manifest - the record of
 * one VERIFIED ayah audio file stored on this device.
 */
export interface AudioManifestEntry {
  /** `${styleId}:${sura}:${ayah}` - stable manifest key. */
  id: string
  /** Reciter identifier (recitation style id). */
  styleId: string
  /** Surah number (1-114). */
  sura: number
  /** Ayah number within the surah. */
  ayah: number
  /** Platform storage identifier (IndexedDB key of the blob store). */
  storageKey: string
  /** Source file name (e.g. `002286.mp3`). */
  fileName: string
  /** Exact file size in bytes (verified against the source listing). */
  fileSize: number
  /** SHA-256 checksum computed locally at download time. */
  checksum: string | null
  /** Verification status of the stored copy. */
  verification: 'verified' | 'corrupted'
  /** Canonical source URL of the recording (EveryAyah). */
  sourceUrl: string
  /** Source attribution name. */
  sourceName: string
  /** ISO 8601 timestamp of when the file was stored. */
  downloadedAt: string
}

/** Offline status of one sura's audio for one recitation style. */
export interface AudioSuraOfflineStatus {
  styleId: string
  sura: number
  ayahCount: number
  /** Ayat with a verified local file. */
  storedAyat: number
  /** Ayat whose local copy is marked corrupted. */
  corruptedAyat: number
  /** True only when EVERY ayah of the sura has a verified local file. */
  complete: boolean
  totalBytes: number
}

/** Offline status of one recitation style (aggregate over its manifest). */
export interface AudioStyleOfflineStatus {
  styleId: string
  storedFiles: number
  corruptedFiles: number
  totalBytes: number
  /** Suras with every ayah stored + verified. */
  completeSuras: number
  /** Per-sura statuses for suras with at least one stored file. */
  suras: AudioSuraOfflineStatus[]
}

/** One planned file of a recitation audio batch (verified inventory). */
export interface AudioBatchPlanFile {
  sura: number
  ayah: number
  /** Exact byte size from the verified source listing. */
  sizeBytes: number
}

/**
 * Response of GET /api/quran/audio/batch - the verified download plan for
 * one batch (ayah / sura / range / juz / complete).
 */
export interface AudioBatchPlanResponse {
  styleId: string
  reciterName: string
  styleLabel: string
  folder: string
  sourceName: string
  batchKind: AudioBatchKind
  /** Human-readable batch description parts (already server-validated). */
  sura: number | null
  ayahFrom: number | null
  ayahTo: number | null
  juz: number | null
  files: AudioBatchPlanFile[]
  totalFiles: number
  totalBytes: number
  /** Ayat of the requested range the source does NOT have a verified file
   *  for (reported honestly; they are never offered as downloadable). */
  missing: Array<{ sura: number; ayah: number }>
  /** True when the source inventory covers every ayah of the batch range. */
  sourceComplete: boolean
  /** True only for a complete package whose source covers all 6236 ayat. */
  completePackageOfferable: boolean
}

/* ------------------------------------------------------------------ */
/* Translation narration audio (QuranEnc recordings + TTS, PROMPT 10)  */
/* ------------------------------------------------------------------ */

/**
 * One VERIFIED translation-audio edition of the QuranEnc audio catalog.
 *
 * Every field comes from QuranEnc's own audio developers dashboard and the
 * per-translation `files.json` manifest - nothing is assumed. A translation
 * audio edition is listed ONLY after its file manifest was actually fetched
 * and its file set verified.
 */
export interface TranslationAudioCatalogEntry {
  /** The QuranEnc translation key (identical to the text translation key). */
  translationKey: string
  /** Audio edition display name from the source dashboard (e.g. "English – Rwwad Center"). */
  audioName: string
  /** Title of the matching text translation (null when the text catalog is unreachable). */
  textTitle: string | null
  /** ISO code of the translation language (null when unresolved). */
  languageIso: string | null
  /** Language display name (null when unresolved). */
  languageName: string | null
  /** Text direction of the translation (null when unresolved). */
  direction: 'ltr' | 'rtl' | null
  /** Files the source manifest actually lists as present. */
  availableFiles: number
  /** Total numbered ayat (6236). */
  totalFiles: number
  /** True only when the manifest lists every ayah. */
  complete: boolean
  /** When the source manifest was generated (ISO-like source timestamp). */
  generatedAt: string | null
  /** Source attribution. */
  sourceName: string
}

/** Response of GET /api/quran/translation-audio/catalog. */
export interface TranslationAudioCatalogResponse {
  translations: TranslationAudioCatalogEntry[]
}

/** One verified translation narration file of a sura. */
export interface TranslationSuraAudioFileDto {
  ayah: number
  /** Canonical source URL (d.quranenc.com). */
  url: string
}

/** Response of GET /api/quran/translation-audio/sura/[translationKey]/[sura]. */
export interface TranslationSuraAudioResponse {
  translationKey: string
  translationTitle: string | null
  audioName: string | null
  languageIso: string | null
  sura: number
  ayahCount: number
  availableAyat: number
  missingAyat: number[]
  live: AudioLiveCheck
  files: TranslationSuraAudioFileDto[]
}

/** One planned file of a translation audio batch (verified inventory). */
export interface TranslationAudioBatchPlanFile {
  sura: number
  ayah: number
  /** Exact byte size probed from the source (0 when the probe failed). */
  sizeBytes: number
}

/**
 * Response of GET /api/quran/translation-audio/batch - the verified download
 * plan for one translation audio batch.
 */
export interface TranslationAudioBatchPlanResponse {
  translationKey: string
  audioName: string
  translationTitle: string | null
  languageName: string | null
  batchKind: AudioBatchKind
  sura: number | null
  ayahFrom: number | null
  ayahTo: number | null
  juz: number | null
  files: TranslationAudioBatchPlanFile[]
  totalFiles: number
  totalBytes: number
  /** True when totalBytes is a sampled ESTIMATE, not an exact sum. */
  sizeEstimated: boolean
  missing: Array<{ sura: number; ayah: number }>
  sourceComplete: boolean
  completePackageOfferable: boolean
  sourceName: string
}

/**
 * One entry of the persistent TRANSLATION audio download manifest - the
 * record of one verified translation narration file stored on this device.
 * Lives in a dedicated store, fully separate from recitation audio.
 */
export interface TranslationAudioManifestEntry {
  /** `${translationKey}:${sura}:${ayah}` - stable manifest key. */
  id: string
  translationKey: string
  sura: number
  ayah: number
  storageKey: string
  fileName: string
  fileSize: number
  checksum: string | null
  verification: 'verified' | 'corrupted'
  sourceUrl: string
  sourceName: string
  downloadedAt: string
}

/** Offline status of one sura's translation audio for one translation. */
export interface TranslationAudioSuraOfflineStatus {
  translationKey: string
  sura: number
  ayahCount: number
  storedAyat: number
  corruptedAyat: number
  complete: boolean
  totalBytes: number
}

/** Offline status of one translation's audio (aggregate over its manifest). */
export interface TranslationAudioOfflineStatus {
  translationKey: string
  storedFiles: number
  corruptedFiles: number
  totalBytes: number
  completeSuras: number
  suras: TranslationAudioSuraOfflineStatus[]
}

/** The translation-audio part of a download job record. */
export interface TranslationAudioBatchDescriptor {
  translationKey: string
  audioName: string
  translationTitle: string | null
  batchKind: AudioBatchKind
  sura: number | null
  ayahFrom: number | null
  ayahTo: number | null
  juz: number | null
  filesTotal: number
  filesCompleted: number
  filesFailed: number
  bytesTotal: number
  /** True when bytesTotal is a sampled estimate. */
  sizeEstimated: boolean
}

/** How the current narration is being produced (always visible in the UI). */
export type NarrationMode = 'recording' | 'tts'
