import type { NextConfig } from "next";

/**
 * Security headers applied to every response (web deployment).
 *
 * Deliberately pragmatic: only headers that cannot break application
 * functionality are set. A full Content-Security-Policy is intentionally
 * NOT set yet - the app relies on same-origin blob isrames (EPUB viewer),
 * blob workers (PDF.js) and WASM (sql.js), which requires a carefully
 * nonce-based policy that must be validated against a production build
 * before it can ship safely.
 *
 * X-Frame-Options / frame-ancestors are intentionally not set so the app
 * remains embeddable in the sandbox preview panel and comparable hosts;
 * production deployments behind their own gateway should add a
 * frame-ancestors policy appropriate to their hosting setup.
 *
 * Native builds (NATIVE_BUILD=1) export a fully static bundle for the
 * Capacitor app (no server, no headers) into out/ with an isolated distDir
 * so a concurrently running dev server is never disturbed.
 */
const SECURITY_HEADERS = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  /* Disable capabilities the app never uses. Geolocation (Prayer/Qibla) and
     notifications (prayer reminders) stay available in any embedding
     context, so they are not restricted here. */
  {
    key: "Permissions-Policy",
    value: "camera=(), microphone=(), payment=(), usb=(), xr-spatial-tracking=()",
  },
  { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
];

const isNativeBuild = process.env.NATIVE_BUILD === "1";

const nextConfig: NextConfig = isNativeBuild
  ? {
      /* Static export for the Capacitor Android/iOS app.
       * - output 'export': everything is prerendered to out/.
       * - distDir: isolated from .next so a running dev server is untouched.
       * - images unoptimized: no server-side image pipeline exists in the
       *   app shell (all icons/assets are static files). */
      output: "export",
      distDir: ".next-native",
      images: { unoptimized: true },
      reactStrictMode: false,
    }
  : {
      output: "standalone",
      async headers() {
        return [
          {
            source: "/:path*",
            headers: SECURITY_HEADERS,
          },
          {
            /* The Android App Bundle (.aab) has no universal MIME mapping
             * (some servers fall back to application/x-authorware-bin).
             * Serve it as a clean binary download; browsers then use the
             * filename from the URL. Developer artifact for Play upload -
             * never rendered inline. */
            source: "/downloads/:file(.*\\.aab)",
            headers: [{ key: "Content-Type", value: "application/octet-stream" }],
          },
        ];
      },
      reactStrictMode: false,
    };

export default nextConfig;
