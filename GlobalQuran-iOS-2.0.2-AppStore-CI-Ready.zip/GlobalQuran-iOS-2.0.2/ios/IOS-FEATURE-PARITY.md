# Global Quran — iOS Feature-Parity Matrix (vs Android 2.0.2)

Android 2.0.2 is the authoritative reference. Status vocabulary
(mandated):

- **Implemented and verified** — implemented AND verified with real
  evidence in this environment (executed test suites / browser
  verification of the shared web core; structural verification of the
  iOS project).
- **Implemented, not device-verified** — implementation complete and
  structurally verified, but final execution requires macOS + Xcode +
  an iOS device which this authoring environment does not have.
- **Partially implemented** — a known functional gap remains.
- **Blocked by an iOS limitation** — iOS cannot provide the Android
  behavior; the closest reliable native equivalent is implemented and
  the difference is documented in `IOS-PLATFORM-DIFFERENCES.md`.
- **Not tested** — no verification evidence of any kind.

> Environment honesty: this iOS port was authored on Linux. The web
> core (100% of the UI, business logic, and data flows) is the SAME
> code Android 2.0.2 ships and was re-verified here (TypeScript, lint,
> i18n 80/80, native-adapter contract suite, Quran-integrity suite,
> browser run). The four Swift plugins were written against the actual
> Capacitor 8.6.2 Swift API sources and are structurally verified
> (65/65 checks in `bun run verify:ios`), but Swift compilation,
> XCTest execution, and on-device behavior **require a Mac and were
> NOT executed here**. Every status below reflects exactly that.

## A. Screens and general UX

| Area | iOS status | Notes |
|---|---|---|
| Home screen | **Implemented and verified** (web core, browser-verified) | Identical component; hash navigation, safe areas, Dynamic-Island-ready insets all shared |
| Quran index & search | **Implemented and verified** | Shared |
| Surah/Ayah reader (Basmala/Isti'adha presentation) | **Implemented and verified** | The 2.0.2 opening rules (Fatihah none, At-Tawbah Isti'adha, others Basmala, An-Naml 27:30 untouched) are the shared display component; verified across 114 surahs by `verify-sura-opening.ts` |
| Translations (80 catalog) | **Implemented and verified** | QuranEnc integration through the native adapter (isomorphic code path identical to Android) |
| Bookmarks | **Implemented and verified** | IndexedDB, shared |
| Reading history / Library | **Implemented and verified** | Shared |
| Downloads screen (fullscreen, stable) | **Implemented and verified** | Shared 2.0.2 fix |
| Prayer times | **Implemented and verified** | Same hybrid engine, same source fallback order (JAKIM → Aladhan → local), same method/madhhab settings |
| Qibla | **Implemented, not device-verified** | The compass logic is the shared web core (already iOS-aware: `webkitCompassHeading` + WMM2025 declination + the iOS 13+ motion-permission flow); real compass accuracy needs a physical device |
| Settings / Profile | **Implemented and verified** | Shared; capability matrix identical |
| Navigation (hash router) | **Implemented and verified** | iOS back = edge-swipe / on-screen back; the Android hardware-Back controller correctly stays Android-only |
| 80 interface languages | **Implemented and verified** | `verify-i18n.ts` gate: 80/80 locales, full key parity including the new iOS delivery note |
| RTL / LTR | **Implemented and verified** | Shared layout system |
| Dark / light theme | **Implemented and verified** | Shared |
| App icon | **Implemented and verified** | Original 2.0.x brand icon regenerated from the same `native-assets` source as Android (1024×1024 single-size AppIcon) |
| Splash screen | **Implemented, not device-verified** | Brand splash in the asset catalog (light+dark); render verified structurally |
| iPad layout | **Implemented, not device-verified** | All four orientations enabled; the responsive web layout adapts; needs simulator/device confirmation |

## B. Audio

| Area | iOS status | Notes |
|---|---|---|
| Recitation of the 5 approved reciters | **Implemented and verified** (web core) | Same verified EveryAyah inventory, same URLs, local-first playback |
| Ayah play button (single ayah) | **Implemented and verified** | Shared |
| Continuous playback, no infinite repeat | **Implemented and verified** | Shared advance logic |
| Pause / resume / stop / seek | **Implemented and verified** | Shared |
| Lock Screen / Control Center controls | **Implemented, not device-verified** | Media Session API (iOS 15+ WKWebView); needs device confirmation |
| Background playback / locked screen | **Implemented, not device-verified** | `UIBackgroundModes: audio` + AVAudioSession `.playback` activated by the AudioSessionBridge plugin on every play; the standard iOS approach — MUST be verified on a physical device |
| Bluetooth / AirPods | **Implemented, not device-verified** | Standard AVAudioSession routing; needs device test |
| Phone-call interruptions | **Implemented, not device-verified** | WebKit pauses WebView audio; native Adhan stops on interruption (mirrors Android focus-loss) |
| Recitation vs narration vs Adhan exclusivity | **Implemented and verified** | Shared session coordinator (unchanged) |
| Translation narration (recorded) | **Implemented and verified** | Shared |
| Translation narration (device TTS) | **Implemented, not device-verified** | TtsBridge ported to AVSpeechSynthesizer: same contract, voices, alias table, rate/pitch mapping, chunking; never used for Arabic Quranic text; needs device run |
| Downloads (ayah / surah / range / juz / whole Quran) | **Implemented and verified** | Shared IndexedDB pipeline with checksum verification |
| Offline playback | **Implemented and verified** | Verified local files only; verified by the adapter suite |

## C. Prayer times, Qibla, Adhan

| Area | iOS status | Notes |
|---|---|---|
| Location acquisition | **Implemented, not device-verified** | `@capacitor/geolocation` + `NSLocationWhenInUseUsageDescription`; DeviceBridge ported (service state, permission state, settings deep-link to the app's settings page) |
| Manual city selection | **Implemented and verified** | Shared |
| Notification permission flow | **Implemented, not device-verified** | UNUserNotificationCenter authorization via the plugin |
| Reminder scheduling | **Implemented, not device-verified** | AdhanScheduler ported: same store/payloads, 60-notification window, quiet hours fail-open, 24h trim, 10-min stale skip |
| Adhan — app open (foreground) | **Implemented, not device-verified** | Same foregroundFire flow as Android; full Adhan plays through the native player with REAL volume (WKWebView volume is a no-op) |
| Adhan — app closed (background) | **Blocked by an iOS limitation** | iOS plays notification sounds only (≤30 s custom sound, else default); full-length background Adhan is impossible without Apple's Critical-Alert entitlement (not claimed). Honest iOS note shown in the reminder sheet (80/80 languages) |
| Adhan after force-quit | **Blocked by an iOS limitation** | iOS stops delivering notifications to a force-quit app until it is reopened; documented in-app and in `IOS-PLATFORM-DIFFERENCES.md` |
| Quiet hours | **Implemented and verified** | Decision table ported 1:1 and covered by unit tests (test execution pending Xcode) |
| Adhan recording mirror + verification | **Implemented, not device-verified** | Same chunked begin/chunk/finalize contract with exact-size verification, stored in `Library/Sounds` (the iOS notification-sound location) |
| Adhan volume | **Partially implemented, not device-verified** | Foreground: native AVAudioPlayer honors the selected volume; background notification sounds use the iOS system sound level because UNNotificationSound exposes no per-notification volume API. Custom sound is attached only when the recording is within the iOS 30-second limit; otherwise the default notification sound is used |

## D. Data, privacy, security

| Area | iOS status | Notes |
|---|---|---|
| Local data persistence (bookmarks, history, downloads, settings) | **Implemented and verified** | Same IndexedDB storage layer; WKWebView supports it |
| Persistent storage request | **Implemented, not device-verified** | `navigator.storage.persist()` — behavior on device to be confirmed |
| Privacy manifest | **Implemented and verified** | `PrivacyInfo.xcprivacy`: no tracking, precise location = app functionality only, UserDefaults/FileTimestamp required-reason APIs declared |
| Secrets in source | **Implemented and verified** | None exist (no API keys in the codebase; verified by audit) |
| TLS / network audit | **Implemented and verified** | All external hosts are HTTPS; ITSAppUsesNonExemptEncryption=false (standard TLS only) |
| App Tracking Transparency | **Not applicable** | The app performs no tracking (manifest declares none) |

## E. Native plugins

| Plugin | Android (Java, unchanged) | iOS (Swift, new) | Status |
|---|---|---|---|
| AdhanScheduler | registerPlugin from MainActivity | packageClassList + @objc registration | **Implemented, not device-verified** |
| DeviceBridge | same | same | **Implemented, not device-verified** |
| TtsBridge | same | same | **Implemented, not device-verified** |
| AudioSessionBridge | not needed (WebView manages focus) | new, iOS-only | **Implemented, not device-verified** |
| @capacitor/app (appStateChange, lifecycle) | shipped | SPM package included | **Implemented, not device-verified** |
| @capacitor/geolocation | shipped | SPM package included | **Implemented, not device-verified** |

## F. What is deliberately NOT on iOS (with reasons)

1. **No new Android signing keys, no Android changes** — the Android
   project, its 2.0.2 artifacts, and its signing state are untouched
   (verified: build.gradle still 2.0.2/9; APK/AAB hashes still match
   the delivered sums).
2. **No Critical Alerts entitlement** — overriding Silent Mode/Focus
   requires Apple's special approval; the app instead states the
   honest behavior. (Applying for the entitlement is a future option
   that would not change the app's data or UI.)
3. **No Widget / Watch / App Clip** — none exist in Android 2.0.2
   either; parity means none are added.
