# Global Quran iOS — إعداد البناء والتوقيع لـ App Store عبر GitHub Actions

هذه الإعدادات مخصصة لإصدار iOS الحالي:

- التطبيق: Global Quran
- Bundle ID: `com.globalquran.app`
- Version: `2.0.2`
- Build الافتراضي: `9` (غيّره إلى رقم جديد إذا كان هذا الرقم قد رُفع سابقًا إلى App Store Connect)

## ما الذي ينفذه الـWorkflow؟

1. ينتظر تشغيلًا يدويًا من تبويب Actions (حتى لا يبدأ قبل إعداد مفاتيح Apple).
2. يستخرج ملف ZIP من مستودع GitHub دون مطالبتك بفك ضغطه يدويًا.
3. يثبت تبعيات Bun من ملف القفل، ويزامن Capacitor مع iOS مع الحفاظ على تسجيل إضافات Swift الأربع.
4. يشغل الفحوصات الهيكلية واختبارات XCTest على iPhone Simulator.
5. يتحقق من شهادة Apple Distribution وملف App Store Connect provisioning profile.
6. يبني Xcode Archive لوضع Release، ثم يصدّر IPA باستخدام طريقة `app-store-connect` والتوقيع اليدوي.
7. يتحقق من Bundle ID والإصدار ورقم البناء وهوية Apple Distribution وTeam ID والـEntitlements.
8. يحفظ IPA النهائي كـGitHub Actions Artifact.
9. يمكنه — عند تفعيل الخيار وإضافة مفاتيح API — التحقق من IPA ثم رفعه إلى App Store Connect.

لا تُنشأ شهادة أو مفاتيح مزيفة. إذا غابت بيانات التوقيع أو لم تطابق الملف، يتوقف مسار إصدار IPA برسالة خطأ بدل تسليم ملف غير موقّع على أنه جاهز للمتجر.

## أولًا: ارفع ملف المصدر إلى GitHub كما هو

1. أنشئ مستودع GitHub خاصًا (Private).
2. ارفع الملف التالي إلى جذر المستودع دون فك ضغطه:
   `GlobalQuran-iOS-2.0.2-AppStore-CI-Ready.zip`
3. أضف ملف Workflow مستقلًا داخل GitHub بالمسار التالي:
   `.github/workflows/ios-app-store.yml`
4. انسخ محتوى ملف `ios-app-store.yml` المرفق مع حزمة التعديلات إلى ذلك الملف ثم احفظه.

> ملاحظة: GitHub لا يشغّل Workflow موجودًا داخل ZIP مرفوع كملف عادي؛ لذلك يجب إضافة ملف YAML إلى المسار أعلاه مرة واحدة.

## ثانيًا: جهّز بيانات توقيع Apple

يلزم حساب Apple Developer مؤهل للتوزيع، وشهادة Apple Distribution مع مفتاحها الخاص، وملف Provisioning Profile من نوع App Store Connect للمعرّف الصريح `com.globalquran.app`.

أنشئ ملف P12 من شهادة التوزيع ومفتاحها الخاص. ثم أنشئ App Store Connect provisioning profile في بوابة Apple Developer، واختر App ID المطابق تمامًا `com.globalquran.app` وشهادة التوزيع نفسها.

لا تستخدم ملف Development أو Ad Hoc profile. الـWorkflow يرفض هذه الأنواع.

## ثالثًا: أضف GitHub Secrets المطلوبة للتوقيع

في مستودع GitHub افتح:

`Settings` → `Secrets and variables` → `Actions` → `New repository secret`

أضف الأسماء التالية كما هي:

| اسم Secret | المحتوى |
|---|---|
| `IOS_CERTIFICATE_P12_BASE64` | ملف P12 كاملًا بعد تحويله إلى Base64 |
| `IOS_CERTIFICATE_PASSWORD` | كلمة مرور ملف P12 |
| `IOS_PROVISIONING_PROFILE_BASE64` | ملف App Store provisioning profile بعد تحويله إلى Base64 |
| `APPLE_TEAM_ID` | Team ID الخاص بحساب Apple Developer (10 أحرف/أرقام) |

لتحويل الملفات إلى Base64 على macOS:

```bash
base64 -i AppleDistribution.p12 | tr -d '\n'
base64 -i GlobalQuran-AppStore.mobileprovision | tr -d '\n'
```

على Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("AppleDistribution.p12"))
[Convert]::ToBase64String([IO.File]::ReadAllBytes("GlobalQuran-AppStore.mobileprovision"))
```

انسخ الناتج إلى قيمة Secret المناسبة. لا تضع ملفات P12 أو كلمات المرور أو ملفات Provisioning Profile أو المفاتيح الخاصة في ملفات المشروع، ولا ترسلها في المحادثات.

## رابعًا: إعداد الرفع التلقائي (اختياري)

لرفع IPA إلى App Store Connect تلقائيًا، أنشئ App Store Connect API Key واحفظ ملف `.p8` الخاص به. ثم أضف هذه الأسرار الثلاثة:

| اسم Secret | المحتوى |
|---|---|
| `APP_STORE_CONNECT_API_KEY_ID` | Key ID |
| `APP_STORE_CONNECT_ISSUER_ID` | Issuer ID |
| `APP_STORE_CONNECT_API_KEY_P8_BASE64` | ملف `.p8` بعد تحويله إلى Base64 |

على macOS لتحويل ملف المفتاح:

```bash
base64 -i AuthKey_XXXXXXXXXX.p8 | tr -d '\n'
```

لا يلزم إعداد مفاتيح API إذا كنت تريد تنزيل IPA أولًا ورفعه يدويًا من Transporter أو Xcode.

## خامسًا: شغّل البناء

1. افتح تبويب `Actions` في مستودع GitHub.
2. اختر `Global Quran - iOS App Store Release`.
3. اضغط `Run workflow`.
4. اترك Build number على `9` إذا لم يسبق رفع هذا الرقم. عند إنشاء رفع جديد استخدم رقمًا جديدًا مثل `10` ثم `11`.
5. اختر `Upload to App Store Connect` فقط بعد إضافة أسرار API الثلاثة أعلاه.
6. اضغط `Run workflow`.

لا يبدأ البناء تلقائيًا عند رفع ZIP أو إنشاء Workflow؛ شغّله يدويًا بعد استكمال Secrets والتأكد منها.

## أين أجد IPA؟

بعد نجاح جميع المراحل، افتح صفحة تشغيل Workflow ثم قسم `Artifacts` ونزّل:

`GlobalQuran-iOS-AppStore-IPA-...`

ستجد داخله:

- `GlobalQuran-2.0.2-[BUILD]-AppStore.ipa`
- `Build-Verification.txt` وفيه نتيجة فحوصات التوقيع وبصمة SHA-256.

كما يوجد Artifact منفصل لسجلات Xcode والاختبارات عند الحاجة إلى التشخيص.

## ما المقصود بـ«جاهز للمتجر»؟

IPA المصدّر بهذه الطريقة موقّع لتوزيع App Store Connect ويمكن رفعه إلى حسابك. لكن الرفع لا يعني أن التطبيق أصبح منشورًا للجمهور مباشرة: على Apple معالجة النسخة، ثم تختارها داخل App Store Connect وتكمل بيانات صفحة المتجر وتقدمها إلى App Review. قرار القبول والنشر يعود إلى Apple.

## حدود التحقق

تم إعداد إصلاحات المصدر وملفات CI في هذه الحزمة، لكن بيئة العمل التي أُجريت فيها التعديلات ليست macOS ولا تحتوي Xcode. لذلك لا يمكن الادعاء بأن Swift/XCTest أو التوقيع قد نُفذت بنجاح هنا. إثبات النجاح النهائي هو تشغيل الـWorkflow على GitHub macOS runner وظهور IPA موقّع واجتيازه فحوصات التوقيع المضمنة.
