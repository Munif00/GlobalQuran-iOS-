# Global Quran — iOS Test Plan

This plan covers every mandated area. It separates, honestly, what has
ALREADY been executed (and where), what is prepared and must run on a
Mac, and what requires physical devices. Nothing is marked passed
without an executed test behind it.

## 0. Test status legend

- **EXECUTATED (this environment)** — ran during the iOS port work on
  Linux; results recorded in §1.
- **READY (requires macOS + Xcode)** — prepared in the repository,
  executes with the documented command; not yet run.
- **READY (requires physical device)** — requires a real iPhone/iPad;
  listed with acceptance criteria.

## 1. Executed in this environment (results)

| Suite | Command | Result |
|---|---|---|
| TypeScript strict check | `bunx tsc --noEmit` | **PASS — 0 errors** |
| ESLint | `bun run lint` | **PASS — 0 problems** (after ignoring the generated `ios/**` build outputs, matching the existing `android/**` pattern) |
| iOS project structural verification (65 checks: pbxproj integrity/UUID resolution, plists, plugin contracts vs TS interfaces, asset catalogs, versions 2.0.2/9, scheme, Android-untouched gates) | `bun run verify:ios` | **PASS — 65/65** |
| Localization parity (80 locales × full key set incl. the new iOS delivery note) | `bun run scripts/verify-i18n.ts` | **PASS — 80/80** (re-run after the 78-locale translation pipeline finished; see §6) |
| Quran data integrity (all 114 surahs: ayah counts, contiguous numbering, Basmala/Isti'adha rules, live API fetch) | `bun run scripts/verify-sura-opening.ts` | **PASS** (re-executed for the iOS port sign-off) |
| Native adapter contract (every API route the app replaces server-side: config, prayer, adhan catalog, Quran, audio, offline packs, exports) | `bun run scripts/verify-native-adapter.ts` | **PASS** (re-executed) |
| Static export build (the bundle iOS ships) | `bun run scripts/build-native.mjs` | **PASS** — `native/www` produced and synced into `ios/App/App/public` |
| Web app runtime verification (dev server, browser) | browser run of `/` | **PASS** — app renders and operates; the iOS branches are inert in the browser (platform-gated), Android path byte-identical |

The web core that iOS ships is the SAME verified 2.0.2 bundle as
Android; all previously-passing suites (prayer, Qibla, adhan
reminders, export) remain green.

## 2. XCTest unit tests (READY — run on a Mac)

```bash
cd ios/App
xcodebuild test -project App.xcodeproj -scheme App \
  -destination 'platform=iOS Simulator,name=iPhone 15'
```

Coverage (all target the pure logic layers, no UI):

- **AdhanModelsTests** — event parsing defaults (the exact Android
  contract), required-field drops, quiet-flag semantics,
  foregroundFire payload shape (incl. NSNull round-trip), 24 h trim,
  scheduling-window selection.
- **AdhanQuietHoursTests** — the full fail-open decision table:
  disabled/malformed/degenerate/zoneless windows never mute; normal
  [start, end) and overnight wrapping; event-zone (not device-zone)
  evaluation; HH:mm parsing validation.
- **AdhanSanitizerAndStoreTests** — id sanitization (path-traversal),
  Android-literal file names, store codec round-trip, malformed-store
  honest-empty, non-serializable payload rejection, notification body
  selection, 30-second mirror-sound gate.
- **TtsBridgeMappingTests** — rate mapping (Web Speech → AVSpeech
  scale, clamps), pitch mapping, the shared alias table, candidate
  ordering, primary-subtag matching, 3500-char whitespace chunking.
- **DeviceBridgeMappingTests** — CLAuthorizationStatus → granted /
  denied / not-requested.

## 3. Simulator test pass (READY — requires macOS)

Functional, per the mandate "verify actual user-visible behavior":

1. Cold launch → splash → home renders; language auto-detection.
2. Every screen: Home, Quran index, Reader, Prayer, Qibla, Downloads,
   Library, Profile/Settings — open, exercise, close, reopen.
3. Reader: all four opening cases (1, 2, 9, 27), jump-to-ayah,
   prev/next surah, bookmark add/open, recently-read restore.
4. Recitation: ayah play, continuous play, pause/resume/stop, next/prev
   ayah buttons; verify NO infinite repeat.
5. Downloads: download one surah (progress, completion), verify
   offline playback in airplane mode (simulator: Network Link
   Conditioner / Wi-Fi off), delete download, storage numbers change.
6. Prayer: manual city selection, method/madhhab changes, month view.
7. Qibla: simulator heading is synthetic — verify the UI/permission
   flow and the honest low-accuracy handling only (real accuracy needs
   a device).
8. Adhan: enable reminders, grant notification permission, use
   `debugFireNext` (via the debug bridge) → verify foreground banner +
   native playback at the chosen volume, and the Stop control.
9. TTS narration: pick translations with installed voices (e.g. en,
   fr, de) → narrate; verify lock-screen metadata appears; verify the
   honest "voice unavailable" state for a language without voices.
10. Localization: switch UI language across LTR (en, fr), RTL (ar,
    ur, fa), and CJK (ja, zh-Hans); verify layout direction, fonts,
    and the full-translation rule.
11. Orientation: rotate iPhone and iPad simulators; portrait/landscape
    and upside-down (iPad).
12. Dynamic Type: largest accessibility sizes; VoiceOver pass over
    Home + Reader + Prayer.
13. iOS 15 and newest iOS simulators (minimum-supported check).

## 4. Physical-device test pass (READY — required for sign-off)

Items that cannot be honestly verified in a simulator:

- **Qibla compass accuracy** — real magnetometer, calibration prompt,
  interference warning behavior, multiple real locations.
- **Background recitation** — lock the screen during playback; expect
  continued playback (audio background mode + .playback session);
  measure battery use over 30 min of playback.
- **Bluetooth/AirPods** — connect, play, pause from headphone controls,
  disconnect mid-play (expect honest pause state).
- **Phone call interruption** — call the device during recitation
  (expect pause) and during foreground Adhan (expect stop).
- **Notifications in background** — schedule a reminder 2 minutes
  ahead, background the app, lock the screen: notification arrives
  with sound; tap opens the app.
- **Silent switch / Focus** — repeat with the switch silent and a
  Focus mode on: notification arrives, sound follows system rules
  (documented behavior).
- **Force-quit** — force-quit then wait for the scheduled time: no
  delivery (documented); open the app → window re-arms.
- **Real GPS** — location permission prompt, position fix, prayer
  times for the real location, denied-permission guidance, app
  settings round-trip.
- **TTS voices** — device-installed voices (may differ from the
  simulator), AirPods routing, interruption handling.
- **Upgrade persistence** — install over a previous build (same
  signing identity) → bookmarks/downloads/history preserved.

## 5. Performance acceptance thresholds (measure on device; Xcode Instruments + `xcrun xctrace`)

| Metric | Threshold | How to measure |
|---|---|---|
| Cold start (launch → home interactive) | ≤ 3.0 s on iPhone 12+ | Instruments App Launch template |
| Warm start | ≤ 1.5 s | same |
| Quran sura load (cached) | ≤ 400 ms | in-app timing (existing performance surfaces) |
| Search response | ≤ 300 ms | in-app |
| Navigation transition | ≤ 200 ms | Instruments |
| Audio start latency (tap → sound) | ≤ 600 ms local, ≤ 1.5 s stream | in-app + stopwatch |
| RAM at rest / during reader | ≤ 250 MB / ≤ 400 MB | Instruments Allocations |
| Scrolling (reader, 100 ayat) | no dropped-frame streak > 5; ≥ 55 fps average | Instruments Core Animation |
| CPU idle (no playback) | ≤ 2% sustained | Instruments |
| Battery | ≤ 4%/hour continuous recitation, screen on | device measurement |
| App size (Release IPA) | ≤ 30 MB | App Store Connect / archive |
| Memory leaks | none after 15 min reader + audio cycling | Instruments Leaks |

## 6. Automated localization check (EXECUTATED)

`bun run scripts/verify-i18n.ts` verifies that all 80 locale
dictionaries contain the complete English contract — including the new
`adhan.reminder.iosDeliveryNote` key added for the honest iOS delivery
note — with placeholder validation. The 78 non-hand-authored locales
were produced by the established translation pipeline
(`scripts/i18n/translate.ts`) and reviewed per the established corpus
process.

## 7. Android-parity comparison pass (READY — on a Mac with an Android device)

Run Android 2.0.2 and iOS 2.0.2 side by side:

- Visual: home, reader (same surah × same translation × same theme),
  prayer, Qibla, downloads, settings — same content, same layout
  intent (platform chrome differs by design).
- Workflow: bookmark → reopen; download surah → offline play; enable
  reminder → fire; quiet hours; volume slider behavior.
- Data integrity: same surah renders identical Arabic text and
  translation on both platforms (the data source is shared and the
  Quran-integrity suite passes).
- Response times: comparable within 1.5× where the platforms differ
  (document any larger gap).

## 8. Build / distribution tests (READY — on a Mac)

1. `xcodebuild build` (Debug) — zero errors.
2. `xcodebuild build` (Release) — zero errors, no warnings introduced
   by the custom plugins.
3. `xcodebuild test` — all XCTest suites pass (report counts: passed /
   failed / skipped).
4. `xcodebuild archive` — archive succeeds; `validate` in
   Organizer/App Store Connect passes (bundle id, privacy manifest,
   Info.plist keys, icon).
5. Install the Development IPA on a registered device — launches, no
   crash on startup, notification permission prompt appears.
