/**
 * Global Quran — DeviceBridge native plugin (iOS).
 *
 * The iOS counterpart of the audited Android DeviceBridgePlugin.java.
 * Same JS contract (src/services/native/device-bridge.ts), same honest
 * semantics, with the platform-appropriate native APIs:
 *
 *  - isLocationServiceEnabled(): CoreLocation's system-wide switch state
 *    (CLLocationManager.locationServicesEnabled) — the exact equivalent
 *    of Android's LocationManager.isProviderEnabled probe: granting the
 *    app permission does NOT enable the system service, and without the
 *    service every position request fails, so the app must detect the
 *    state and guide the user (same reasoning as Android).
 *
 *  - getPermissionState(): the real CoreLocation authorization status
 *    mapped onto the shared three-state contract. iOS exposes a single
 *    location permission, so `fine` and `coarse` report the same state
 *    (honest — there is no fine/coarse split on this platform).
 *
 *  - openLocationSettings(): opens this app's Settings page via
 *    UIApplication.openSettingsURLString — the ONLY public deep-link iOS
 *    offers. iOS provides no public URL for the system-wide
 *    Settings > Privacy > Location Services screen (an Android-specific
 *    concept); the app's own permission toggle lives on the page we
 *    open. This difference is documented in PLATFORM-DIFFERENCES.md.
 *
 *  - isAvailable(): always true here — the web fallback in the shared
 *    service resolves every method to an honest 'unavailable' state.
 */

import Foundation
import Capacitor
import CoreLocation
import UIKit

@objc(DeviceBridgePlugin)
public class DeviceBridgePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "DeviceBridgePlugin"
    public let jsName = "DeviceBridge"

    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "isLocationServiceEnabled", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "isAvailable", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "openLocationSettings", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getPermissionState", returnType: CAPPluginReturnPromise),
    ]

    @objc public func isLocationServiceEnabled(_ call: CAPPluginCall) {
        call.resolve(["enabled": CLLocationManager.locationServicesEnabled()])
    }

    @objc public func isAvailable(_ call: CAPPluginCall) {
        call.resolve(["available": true])
    }

    @objc public func openLocationSettings(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let url = URL(string: UIApplication.openSettingsURLString) else {
                call.resolve(["opened": false])
                return
            }
            UIApplication.shared.open(url, options: [:]) { opened in
                call.resolve(["opened": opened])
            }
        }
    }

    @objc public func getPermissionState(_ call: CAPPluginCall) {
        let state = DeviceBridgePermissionMapper.contractState(
            from: CLLocationManager.authorizationStatus()
        )
        call.resolve([
            "fine": state,
            "coarse": state,
        ])
    }
}

/// Pure mapping (unit-tested): CLAuthorizationStatus → the shared
/// 'granted' | 'denied' | 'not-requested' contract.
enum DeviceBridgePermissionMapper {

    static func contractState(from status: CLAuthorizationStatus) -> String {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            return "granted"
        case .notDetermined:
            return "not-requested"
        case .denied, .restricted:
            // restricted (parental controls etc.) can never be granted by
            // the user — reported as denied (the UI explains the state).
            return "denied"
        @unknown default:
            return "denied"
        }
    }
}
