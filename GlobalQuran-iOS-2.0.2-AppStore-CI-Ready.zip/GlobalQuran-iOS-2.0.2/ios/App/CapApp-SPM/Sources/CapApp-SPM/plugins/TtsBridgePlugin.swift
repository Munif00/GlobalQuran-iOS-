/**
 * Global Quran — TtsBridge native plugin (iOS).
 *
 * The iOS counterpart of the audited Android TtsBridgePlugin.java,
 * implemented on AVSpeechSynthesizer (Apple's native speech engine —
 * the mandated technology for translation narration on iOS).
 *
 * The JS contract (src/services/native/tts-bridge.ts) is identical on
 * both platforms: real device voices, honest statuses, typed failure
 * codes. TTS is EXCLUSIVELY for reading translation meanings — the
 * shared narration engine never sends Arabic Quranic text to the bridge
 * (Arabic recitation is served from the verified EveryAyah recordings),
 * a rule enforced in the shared web layer on both platforms.
 *
 * Faithful behaviors ported from the Android implementation:
 *  - speak() resolves { started, utteranceId } only when the engine
 *    actually STARTS the first chunk; completion arrives via the
 *    "ttsUtterance" listener event ("done" | "error").
 *  - A new speak() flushes whatever is still speaking (QUEUE_FLUSH).
 *  - Long text is chunked at whitespace boundaries (max 3500 chars,
 *    the same limit and algorithm as the Java implementation).
 *  - Voice lookup uses the same language alias table the web engine
 *    uses (tl<->fil, nb/nn<->no, in<->id, iw<->he).
 *  - stop() rejects unstarted pending speaks with the same message.
 *
 * Platform-honest differences (documented, never faked):
 *  - iOS has exactly one speech engine (built-in); getStatus reports it.
 *  - "missing-data" never occurs on iOS (voices are preinstalled via
 *    Settings; per-language downloadable data is an Android concept).
 *  - pauseSupported() reports false: the BRIDGE does not expose
 *    pause/resume methods (the shared contract has none), so claiming
 *    support would be dishonest even though AVSpeechSynthesizer can
 *    pause internally.
 *  - openTtsSettings() reports { opened: false }: iOS offers no public
 *    deep-link to a speech settings screen, and none exists for
 *    third-party apps. The web layer shows its honest explanation.
 *  - Speech rate mapping: the Web Speech scale (1 = normal) maps onto
 *    AVSpeechUtterance's scale (0.5 = normal) as rate/2, clamped to the
 *    system limits; pitch maps 1:1 (clamped to the 0.5–2.0 range).
 */

import Foundation
import Capacitor
import AVFoundation

@objc(TtsBridgePlugin)
public class TtsBridgePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "TtsBridgePlugin"
    public let jsName = "TtsBridge"

    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "getStatus", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getVoices", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "isLanguageAvailable", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "speak", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stop", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "pauseSupported", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "openTtsSettings", returnType: CAPPluginReturnPromise),
    ]

    private static let engineId = "com.apple.avspeechsynthesizer"
    private static let maxChunkChars = 3500
    private static let eventUtterance = "ttsUtterance"

    private let synthesizer = AVSpeechSynthesizer()
    /// Serial queue guarding session state (Capacitor calls arrive on
    /// bridge threads; delegate callbacks on arbitrary threads).
    private let stateQueue = DispatchQueue(label: "com.globalquran.app.tts")

    private var utteranceCounter = 0
    /// Active speak sessions by session id.
    private var sessions: [String: TtsSpeakSession] = [:]
    /// utterance object identity -> session id (the delegate receives
    /// the utterance, AVSpeechUtterance carries no user payload).
    private var utteranceToSession: [ObjectIdentifier: String] = [:]

    private var didAttachDelegate = false

    // MARK: - Lifecycle

    override public func load() {
        super.load()
        if !didAttachDelegate {
            synthesizer.delegate = self
            didAttachDelegate = true
        }
    }

    // MARK: - Plugin methods

    @objc public func getStatus(_ call: CAPPluginCall) {
        call.resolve([
            "available": true,
            "ready": true,
            "engine": TtsBridgePlugin.engineId,
            "engines": [TtsBridgePlugin.engineId],
        ])
    }

    @objc public func getVoices(_ call: CAPPluginCall) {
        let lang = call.getString("lang")
        // AVSpeechSynthesisVoice is a typed Foundation object, not a
        // dictionary. Sort by its actual language/name properties before
        // mapping it to the JavaScript dictionary contract.
        let matched: [[String: String]] = TtsVoiceCatalog.voices(forLanguage: lang)
            .sorted { lhs, rhs in
                let languageOrder = lhs.language.localizedCaseInsensitiveCompare(rhs.language)
                if languageOrder != .orderedSame {
                    return languageOrder == .orderedAscending
                }

                let nameOrder = lhs.name.localizedCaseInsensitiveCompare(rhs.name)
                if nameOrder != .orderedSame {
                    return nameOrder == .orderedAscending
                }

                return lhs.identifier < rhs.identifier
            }
            .map { voice in
                [
                    // Apple voices expose both an identifier and a real
                    // display name (Android exposes only the name).
                    "id": voice.identifier,
                    "name": voice.name,
                    "locale": voice.language,
                ]
            }
        call.resolve(["voices": matched])
    }

    @objc public func isLanguageAvailable(_ call: CAPPluginCall) {
        guard let lang = call.getString("lang"), !lang.trimmingCharacters(in: .whitespaces).isEmpty else {
            call.reject("missing lang", "failed")
            return
        }
        let available = !TtsVoiceCatalog.voices(forLanguage: lang).isEmpty
        // "missing-data" is an Android-only state (downloadable language
        // data); on iOS a language either has an installed voice or it
        // does not — reported honestly as not-supported.
        call.resolve(["status": available ? "ok" : "not-supported"])
    }

    @objc public func speak(_ call: CAPPluginCall) {
        guard let text = call.getString("text"),
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            call.reject("missing text", "failed")
            return
        }
        guard let lang = call.getString("lang"),
              !lang.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            call.reject("missing lang", "failed")
            return
        }
        let voiceId = call.getString("voiceId")
        let rate = call.getDouble("rate")
        let pitch = call.getDouble("pitch")

        // 1. Voice: explicit pick first (the user's choice from getVoices).
        var voice: AVSpeechSynthesisVoice?
        if let voiceId = voiceId, !voiceId.isEmpty {
            voice = TtsVoiceCatalog.voice(byIdentifier: voiceId)
            if voice == nil {
                call.reject("voice not found", "voice-missing")
                return
            }
        }
        // 2. Otherwise the language (direct tag first, then the same
        //    alias table the web engine uses).
        if voice == nil {
            voice = TtsVoiceCatalog.voice(forLanguage: lang)
            if voice == nil {
                call.reject("no voice for this language", "voice-missing")
                return
            }
        }

        stateQueue.async { [weak self] in
            guard let self = self else { return }
            self.utteranceCounter += 1
            let sessionId = "gq-tts-\(self.utteranceCounter)"
            let chunks = TtsTextChunker.splitForTts(
                text.trimmingCharacters(in: .whitespacesAndNewlines),
                maxChars: TtsBridgePlugin.maxChunkChars
            )
            guard !chunks.isEmpty else {
                call.reject("missing text", "failed")
                return
            }

            // 3. New narration flushes whatever is still speaking
            //    (QUEUE_FLUSH). The old session's unstarted call is
            //    rejected by the didCancel path below.
            self.synthesizer.stopSpeaking(at: .immediate)

            let session = TtsSpeakSession(
                id: sessionId,
                call: call,
                totalChunks: chunks.count
            )
            self.sessions[sessionId] = session
            for (index, chunk) in chunks.enumerated() {
                let utterance = AVSpeechUtterance(string: chunk)
                utterance.voice = voice
                utterance.rate = TtsVoiceCatalog.mappedRate(rate)
                utterance.pitchMultiplier = TtsVoiceCatalog.mappedPitch(pitch)
                utterance.postUtteranceDelay = 0
                utterance.preUtteranceDelay = 0
                self.utteranceToSession[ObjectIdentifier(utterance)] = sessionId
                session.utterances.append(utterance)
                _ = index
                self.synthesizer.speak(utterance)
            }
            // The call is resolved by didStart of the first chunk — or
            // rejected by the failure paths (exactly like Android).
        }
    }

    @objc public func stop(_ call: CAPPluginCall) {
        stateQueue.async { [weak self] in
            guard let self = self else { return }
            // Reject every pending (unstarted) speak with the same
            // message the Android bridge uses.
            for session in self.sessions.values where !session.started {
                session.call.reject("speech stopped before it started", "failed")
            }
            self.sessions.removeAll()
            self.utteranceToSession.removeAll()
            self.synthesizer.stopSpeaking(at: .immediate)
        }
        call.resolve(["stopped": true])
    }

    @objc public func pauseSupported(_ call: CAPPluginCall) {
        // Honest: this bridge exposes no pause/resume methods (the shared
        // contract has none), so pause support through the bridge is
        // false even though AVSpeechSynthesizer itself can pause.
        call.resolve(["supported": false])
    }

    @objc public func openTtsSettings(_ call: CAPPluginCall) {
        // Honest: iOS has no system text-to-speech settings screen for
        // third-party apps and no public deep-link for voice management.
        call.resolve(["opened": false])
    }
}

// MARK: - Session model

private final class TtsSpeakSession {
    let id: String
    let call: CAPPluginCall
    let totalChunks: Int
    var started = false
    var finishedChunks = 0
    var utterances: [AVSpeechUtterance] = []

    init(id: String, call: CAPPluginCall, totalChunks: Int) {
        self.id = id
        self.call = call
        self.totalChunks = totalChunks
    }

    var isComplete: Bool { finishedChunks >= totalChunks }
}

// MARK: - AVSpeechSynthesizerDelegate

extension TtsBridgePlugin: AVSpeechSynthesizerDelegate {

    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        let session = session(for: utterance)
        guard let session = session else { return }
        stateQueue.async { [weak self] in
            guard let self = self else { return }
            defer { self.ensurePlaybackSessionActive() }
            if !session.started {
                session.started = true
                session.call.resolve(["started": true, "utteranceId": session.id])
            }
        }
    }

    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        let session = session(for: utterance)
        guard let session = session else { return }
        stateQueue.async { [weak self] in
            guard let self = self else { return }
            session.finishedChunks += 1
            if session.isComplete {
                self.sessions.removeValue(forKey: session.id)
                self.notifyUtteranceEvent(type: "done", sessionId: session.id)
                self.deactivateSessionIfIdle()
            }
        }
    }

    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        let session = session(for: utterance)
        guard let session = session else { return }
        stateQueue.async { [weak self] in
            guard let self = self else { return }
            if !session.started {
                // Flushed before it ever started (a new speak() took over
                // or stop() was called) — same message as Android.
                session.call.reject("speech stopped before it started", "failed")
            }
            self.sessions.removeValue(forKey: session.id)
            self.cleanupMapping(for: session)
            self.deactivateSessionIfIdle()
        }
    }

    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFail utterance: AVSpeechUtterance, error: Error?) {
        let session = session(for: utterance)
        guard let session = session else { return }
        stateQueue.async { [weak self] in
            guard let self = self else { return }
            if !session.started {
                session.call.reject("the engine failed before speech started", "failed")
            }
            self.sessions.removeValue(forKey: session.id)
            self.cleanupMapping(for: session)
            self.notifyUtteranceEvent(type: "error", sessionId: session.id)
            self.deactivateSessionIfIdle()
        }
    }

    // MARK: Session helpers

    private func session(for utterance: AVSpeechUtterance) -> TtsSpeakSession? {
        stateQueue.sync {
            guard let sessionId = utteranceToSession[ObjectIdentifier(utterance)] else { return nil }
            return sessions[sessionId]
        }
    }

    private func cleanupMapping(for session: TtsSpeakSession) {
        for utterance in session.utterances {
            utteranceToSession.removeValue(forKey: ObjectIdentifier(utterance))
        }
    }

    private func notifyUtteranceEvent(type: String, sessionId: String) {
        DispatchQueue.main.async { [weak self] in
            self?.notifyListeners(TtsBridgePlugin.eventUtterance, data: [
                "type": type,
                "utteranceId": sessionId,
            ])
        }
    }

    /// Narration must be audible with the Ring/Silent switch silent (the
    /// same intent as Android's music-stream TTS): .playback with the
    /// spoken-audio mode, activated lazily with the first utterance.
    private func ensurePlaybackSessionActive() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            // The synthesizer still speaks; the session state is reported
            // honestly through the utterance events when it fails.
        }
    }

    private func deactivateSessionIfIdle() {
        guard sessions.isEmpty else { return }
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            // Best-effort: another component may own the session now.
        }
    }
}

// MARK: - Voice catalog (pure, unit-tested)

/// Voice lookup and parameter mapping, isolated for the XCTest target.
enum TtsVoiceCatalog {

    /// The same language alias table the web engine and the Android
    /// bridge use (some platforms label these languages differently).
    static let languageAliases: [String: [String]] = [
        "tl": ["tl", "fil"],
        "fil": ["fil", "tl"],
        "nb": ["nb", "no"],
        "nn": ["nn", "no"],
        "in": ["in", "id"],
        "iw": ["iw", "he"],
    ]

    /// Primary subtag of a BCP-47 tag ("pt-BR" -> "pt").
    static func primarySubtag(of language: String) -> String {
        return String(language.split(separator: "-").first ?? Substring(language))
    }

    /// All installed voices matching the requested language (primary
    /// subtag match including the alias table) — nil lang returns ALL
    /// voices (same contract as the Java implementation).
    static func voices(forLanguage language: String?) -> [AVSpeechSynthesisVoice] {
        let all = AVSpeechSynthesisVoice.speechVoices()
        guard let language = language, !language.isEmpty else { return all }
        let candidates = candidateLanguages(for: language)
        return all.filter { voice in
            candidates.contains(where: { candidate in
                languageMatches(voiceLanguage: voice.language, requested: candidate)
            })
        }
    }

    /// The first installed voice for the language (direct tag, then
    /// aliases — the same precedence as the Java implementation).
    static func voice(forLanguage language: String) -> AVSpeechSynthesisVoice? {
        for candidate in candidateLanguages(for: language) {
            if let exact = AVSpeechSynthesisVoice(language: candidate) {
                return exact
            }
            let matches = voices(forLanguage: candidate)
            if let first = matches.first {
                return first
            }
        }
        return nil
    }

    /// Exact voice by identifier (the user's explicit pick).
    static func voice(byIdentifier identifier: String) -> AVSpeechSynthesisVoice? {
        if let direct = AVSpeechSynthesisVoice(identifier: identifier) {
            return direct
        }
        return AVSpeechSynthesisVoice.speechVoices().first { $0.identifier == identifier }
    }

    static func candidateLanguages(for language: String) -> [String] {
        var candidates: [String] = []
        let primary = primarySubtag(of: language)
        if !language.isEmpty { candidates.append(language) }
        if let aliases = languageAliases[primary] {
            for alias in aliases where !candidates.contains(alias) {
                candidates.append(alias)
            }
        }
        return candidates
    }

    /// Primary-subtag comparison ("ar-SA" voice matches requested "ar").
    static func languageMatches(voiceLanguage: String, requested: String) -> Bool {
        return primarySubtag(of: voiceLanguage) == primarySubtag(of: requested)
    }

    /// Web Speech rate (1 = normal) -> AVSpeechUtterance rate
    /// (0.5 = normal), clamped to the system limits.
    static func mappedRate(_ rate: Double?) -> Float {
        let webRate = rate ?? 1.0
        let avRate = webRate / 2.0
        let clamped = max(
            Double(AVSpeechUtteranceMinimumSpeechRate),
            min(Double(AVSpeechUtteranceMaximumSpeechRate), avRate)
        )
        return Float(clamped)
    }

    /// Web Speech pitch (1 = normal) -> pitchMultiplier (0.5–2.0).
    static func mappedPitch(_ pitch: Double?) -> Float {
        let webPitch = pitch ?? 1.0
        let clamped = max(0.5, min(2.0, webPitch))
        return Float(clamped)
    }
}

// MARK: - Text chunking (pure, unit-tested — same algorithm as Android)

enum TtsTextChunker {

    static let maxChunkChars = 3500

    static func splitForTts(_ text: String, maxChars: Int) -> [String] {
        var chunks: [String] = []
        let characters = Array(text)
        var start = 0
        while start < characters.count {
            var end = min(start + maxChars, characters.count)
            if end < characters.count {
                let boundary = lastWhitespaceBoundary(characters, from: start, to: end)
                if boundary > start { end = boundary }
            }
            let chunk = String(characters[start..<end]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !chunk.isEmpty { chunks.append(chunk) }
            start = end
        }
        return chunks
    }

    private static func lastWhitespaceBoundary(_ characters: [Character], from: Int, to: Int) -> Int {
        var index = to - 1
        while index > from {
            if characters[index].isWhitespace { return index }
            index -= 1
        }
        return -1
    }
}
