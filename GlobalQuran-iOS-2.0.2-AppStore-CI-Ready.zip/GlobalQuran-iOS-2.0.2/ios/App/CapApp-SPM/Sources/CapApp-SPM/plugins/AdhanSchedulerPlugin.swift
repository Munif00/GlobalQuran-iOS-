/**
 * Global Quran — AdhanScheduler native plugin (iOS).
 *
 * The iOS counterpart of the audited Android implementation
 * (AdhanSchedulerPlugin.java + AdhanScheduling.java + AdhanAlarmReceiver
 * + AdhanPlaybackService). The JS interface and the stored payloads are
 * IDENTICAL on both platforms (see src/services/native/adhan-scheduler-
 * plugin.ts — the typed contract). Platform-honest differences, all of
 * them imposed by iOS and never hidden from the user:
 *
 *  1. Delivery engine: Android uses AlarmManager.setAlarmClock (exact,
 *     Doze-proof) + a foreground MediaPlayer service. iOS offers
 *     UNUserNotificationCenter local notifications: they fire while the
 *     app is suspended/backgrounded, but are NOT alarm-clock-grade
 *     (`status.exact == false`) and are NOT delivered after the user
 *     force-quits the app (iOS keeps scheduled notifications, but the
 *     system stops delivering to a force-quit app until it is reopened).
 *  2. Background sound: a full Adhan (~2 min) cannot play as a
 *     notification sound — iOS caps custom notification sounds at 30
 *     seconds (longer files fall back to the default sound). The
 *     mirrored recording is attached only when its MEASURED duration is
 *     <= 30 s; otherwise the honest default sound is used.
 *  3. Silent Mode / Focus: notification sounds respect the system sound
 *     settings. Only Apple-approved Critical Alerts (a special
 *     entitlement) could override them — this app does not claim that
 *     capability.
 *  4. Foreground behavior is identical to Android: while the app is open
 *     the plugin emits the `foregroundFire` bridge event and the web
 *     layer plays the full Adhan (through this plugin's native player,
 *     which honors the user's volume slider — WKWebView cannot control
 *     HTMLAudioElement volume) and shows the in-app banner.
 *  5. Scheduling window: the store keeps the whole 60-day horizon, the
 *     system holds the next 60 notifications (~12 days of five daily
 *     slots); every fire, tap, app activation and sync re-arms it.
 *
 * Store, trimming, quiet hours (fail-open), stale-skip and the chunked
 * file mirror all replicate the Android semantics one-to-one (see
 * AdhanModels.swift for the shared, unit-tested data layer).
 */

import Foundation
import Capacitor
import UserNotifications
import AVFoundation
import UIKit

@objc(AdhanSchedulerPlugin)
public class AdhanSchedulerPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "AdhanSchedulerPlugin"
    public let jsName = "AdhanScheduler"

    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "sync", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "status", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "requestNotificationPermission", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "beginFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "writeFileChunk", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "finalizeFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "deleteFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "listFiles", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "debugFireNext", returnType: CAPPluginReturnPromise),
        // iOS-only foreground playback bridge (honest volume control):
        CAPPluginMethod(name: "playMirrored", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopMirroredPlayback", returnType: CAPPluginReturnPromise),
    ]

    /// Maximum scheduled local notifications (iOS caps at 64 pending).
    private static let schedulingWindow = 60
    /// Skip fires more than 10 minutes late (Android STALE_AFTER_MS).
    private static let staleAfterSeconds: TimeInterval = 10 * 60

    /// Bridge event names.
    private static let eventForegroundFire = "foregroundFire"
    private static let eventPlaybackEnded = "playbackEnded"

    private var defaults: UserDefaults

    /// Serial queue guarding all mutable state (the Android code uses
    /// synchronized(lock); the plugin calls arrive on Capacitor threads
    /// and UNUserNotificationCenter callbacks on arbitrary queues).
    private let stateQueue = DispatchQueue(label: "com.globalquran.app.adhan")

    /// Foreground Adhan playback (AVAudioPlayer honors per-stream volume
    /// on iOS — the reason the foreground fire routes through native).
    private var adhanPlayer: AVAudioPlayer?
    private weak var adhanPlayerDelegateProxy: AdhanPlayerDelegateProxy?

    private var appObservers: [NSObjectProtocol] = []

    // MARK: - Init / lifecycle

    public override init() {
        self.defaults = UserDefaults(suiteName: AdhanStoreCodec.defaultsSuiteName)
            ?? UserDefaults.standard
        super.init()
    }

    override public func load() {
        super.load()

        // Route local notifications through this plugin while the app is
        // alive. Capacitor's NotificationRouter owns the
        // UNUserNotificationCenter delegate; registering as its
        // localNotificationHandler is the supported integration point
        // (the same mechanism @capacitor/local-notifications uses).
        if let router = bridge?.notificationRouter {
            router.localNotificationHandler = self
        }

        // Mirror Android's foreground flag persistence (used by status()
        // and the foreground/background delivery decision).
        let center = NotificationCenter.default
        appObservers.append(center.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            self.defaults.set(true, forKey: AdhanStoreCodec.keyForeground)
            self.registerWindow()
        })
        appObservers.append(center.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            self.defaults.set(false, forKey: AdhanStoreCodec.keyForeground)
        })

        // Audio interruptions (phone call, Siri): stop foreground Adhan
        // playback — the same policy as Android's audio-focus loss.
        appObservers.append(center.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            guard let self = self else { return }
            // Notification.userInfo is optional. Normalize it to a concrete
            // dictionary before subscripting. This avoids optional-dictionary
            // subscript diagnostics across Swift/Xcode compiler versions.
            let userInfo: [AnyHashable: Any] = note.userInfo ?? [:]
            guard let rawType = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt else {
                return
            }
            guard let type = AVAudioSession.InterruptionType(rawValue: rawType) else {
                return
            }
            if type == .began {
                self.stopForegroundPlayback(notify: false)
            }
        })

        registerWindow()
    }

    deinit {
        for observer in appObservers {
            NotificationCenter.default.removeObserver(observer)
        }
        stopForegroundPlayback(notify: false)
    }

    // MARK: - Store access

    private func storedEvents(now: Date = Date()) -> [AdhanEvent] {
        let raw = defaults.string(forKey: AdhanStoreCodec.keySchedule)
        return AdhanStoreTrimmer.trim(AdhanStoreCodec.decodeEvents(from: raw), now: now)
    }

    // MARK: - Plugin methods

    /// sync(payload): replace the whole schedule atomically (single-key
    /// UserDefaults write — the iOS equivalent of the Android
    /// SharedPreferences swap), then re-arm the notification window.
    @objc public func sync(_ call: CAPPluginCall) {
        let payload = call.options
        guard (payload["events"] as? [[String: Any]]) != nil else {
            call.reject("missing payload", "failed")
            return
        }
        guard let encoded = AdhanStoreCodec.encodePayload(payload) else {
            call.reject("malformed payload", "failed")
            return
        }
        let count = AdhanEventParser.parseEvents(from: payload).count
        defaults.set(encoded, forKey: AdhanStoreCodec.keySchedule)
        registerWindow()
        call.resolve(["stored": count])
    }

    /// status(): read-only state for the UI. Every field is honest:
    /// `exact` and `alarmPlayback` are false on iOS (see class docs).
    @objc public func status(_ call: CAPPluginCall) {
        let now = Date()
        let events = storedEvents(now: now)
        let future = AdhanStoreTrimmer.futureEvents(events, now: now)

        var next: AdhanEvent?
        for event in future {
            if next == nil || event.at < next!.at { next = event }
        }

        let horizonDays: Int
        if let maxAt = future.map({ $0.at }).max() {
            horizonDays = max(0, Int(((maxAt / 1000.0) - now.timeIntervalSince1970) / 86400.0 + 0.5))
        } else {
            horizonDays = 0
        }

        let foreground = defaults.object(forKey: AdhanStoreCodec.keyForeground) as? Bool ?? true

        let result: [String: Any] = [
            "available": true,
            "eventCount": events.count,
            "nextAt": next.map { Int($0.at) } ?? NSNull(),
            "nextSlot": next?.slot ?? NSNull(),
            "nextTimeZone": next?.timeZone ?? NSNull(),
            // Honest: UNUserNotificationCenter is not alarm-clock-grade
            // (no setAlarmClock equivalent; delivery may defer in Low
            // Power Mode). The UI shows the "exact" label only when true.
            "exact": false,
            // Honest: iOS cannot start full-length Adhan playback from a
            // background notification (Android's foreground service has
            // no iOS equivalent).
            "alarmPlayback": false,
            "horizonDays": horizonDays,
            "notificationPermission": "denied", // replaced asynchronously below
            "foreground": foreground,
        ]

        UNUserNotificationCenter.current().getNotificationSettings { settings in
            let permission: String
            switch settings.authorizationStatus {
            case .authorized, .provisional, .ephemeral:
                permission = "granted"
            default:
                // notDetermined / denied / restricted: nothing will be
                // presented right now — reported as denied (the UI then
                // offers the enable path, exactly like Android).
                permission = "denied"
            }
            var final = result
            final["notificationPermission"] = permission
            call.resolve(final)
        }
    }

    /// requestNotificationPermission(): the iOS authorization prompt
    /// (the counterpart of the Android 13 POST_NOTIFICATIONS dialog).
    @objc public func requestNotificationPermission(_ call: CAPPluginCall) {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { settings in
            if settings.authorizationStatus == .authorized
                || settings.authorizationStatus == .provisional
                || settings.authorizationStatus == .ephemeral {
                call.resolve(["granted": true])
                return
            }
            center.requestAuthorization(options: [.alert, .sound]) { granted, _ in
                if granted {
                    self.registerWindow()
                }
                call.resolve(["granted": granted])
            }
        }
    }

    // MARK: - File mirroring (chunked, verified — Android contract)

    /// Mirror directory. Library/Sounds is one of the two locations iOS
    /// searches for custom notification sounds (the other is the app
    /// bundle), and AVAudioPlayer reads from it for foreground playback.
    private var soundsDirectory: URL? {
        guard let library = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask).first else {
            return nil
        }
        let dir = library.appendingPathComponent("Sounds", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            return dir
        } catch {
            return nil
        }
    }

    private func mirrorURL(adhanId: String) -> URL? {
        soundsDirectory?.appendingPathComponent(AdhanIdSanitizer.finalFileName(adhanId: adhanId), isDirectory: false)
    }

    private func tempURL(adhanId: String) -> URL? {
        soundsDirectory?.appendingPathComponent(AdhanIdSanitizer.tempFileName(adhanId: adhanId), isDirectory: false)
    }

    private func fileSize(at url: URL) -> Int? {
        guard let attrs = try? FileManager.default.attributesOfItem(atPath: url.path),
              let size = attrs[.size] as? NSNumber else { return nil }
        return size.intValue
    }

    private func mirrorExists(adhanId: String) -> Bool {
        guard let url = mirrorURL(adhanId: adhanId) else { return false }
        return (fileSize(at: url) ?? 0) > 0
    }

    private func soundDurations() -> [String: Double] {
        defaults.dictionary(forKey: AdhanStoreCodec.keySoundDurations) as? [String: Double] ?? [:]
    }

    @objc public func beginFile(_ call: CAPPluginCall) {
        guard let adhanId = call.getString("adhanId"), !adhanId.isEmpty else {
            call.reject("missing adhanId", "failed")
            return
        }
        guard let temp = tempURL(adhanId: adhanId) else {
            call.reject("cannot create temp file", "failed")
            return
        }
        // Delete any interrupted previous temp, then create fresh —
        // exactly the Android sequence.
        try? FileManager.default.removeItem(at: temp)
        if FileManager.default.createFile(atPath: temp.path, contents: nil) {
            call.resolve()
        } else {
            call.reject("cannot create temp file", "failed")
        }
    }

    @objc public func writeFileChunk(_ call: CAPPluginCall) {
        guard let adhanId = call.getString("adhanId"), !adhanId.isEmpty,
              let base64 = call.getString("base64"),
              call.getAny("offset") != nil else {
            call.reject("missing chunk fields", "failed")
            return
        }
        // offset is validated but unused: chunks are appended strictly
        // in order (identical to the Android implementation).
        guard let temp = tempURL(adhanId: adhanId),
              let data = Data(base64Encoded: base64) else {
            call.reject("chunk write failed", "failed")
            return
        }
        do {
            let handle = try FileHandle(forWritingTo: temp)
            defer { try? handle.close() }
            try handle.seekToEnd()
            try handle.write(contentsOf: data)
            call.resolve()
        } catch {
            call.reject("chunk write failed", "failed")
        }
    }

    @objc public func finalizeFile(_ call: CAPPluginCall) {
        guard let adhanId = call.getString("adhanId"), !adhanId.isEmpty else {
            call.reject("missing adhanId", "failed")
            return
        }
        let sizeNumber: NSNumber?
        if let n = call.getAny("sizeBytes") as? NSNumber {
            sizeNumber = n
        } else if let d = call.getDouble("sizeBytes") {
            sizeNumber = NSNumber(value: d)
        } else {
            sizeNumber = nil
        }
        guard let resolvedSize = sizeNumber else {
            call.reject("missing adhanId", "failed")
            return
        }
        let sizeBytes = resolvedSize.intValue
        guard let temp = tempURL(adhanId: adhanId), let target = mirrorURL(adhanId: adhanId) else {
            call.resolve(["ok": false])
            return
        }

        let verify: () -> Bool = {
            guard sizeBytes > 0,
                  let attrs = try? FileManager.default.attributesOfItem(atPath: temp.path),
                  let actual = attrs[.size] as? Int,
                  actual == sizeBytes else {
                return false
            }
            return true
        }
        guard verify() else {
            // An incomplete mirror is NEVER exposed to the notification
            // system (Android behavior).
            try? FileManager.default.removeItem(at: temp)
            call.resolve(["ok": false])
            return
        }
        try? FileManager.default.removeItem(at: target)
        do {
            try FileManager.default.moveItem(at: temp, to: target)
        } catch {
            try? FileManager.default.removeItem(at: temp)
            call.resolve(["ok": false])
            return
        }

        // Measure the duration once (AVAudioFile): the notification-sound
        // decision (<= 30 s) must never be a guess.
        var durations = soundDurations()
        if let audioFile = try? AVAudioFile(forReading: target) {
            let seconds = Double(audioFile.length) / audioFile.processingFormat.sampleRate
            if seconds > 0 && seconds.isFinite {
                durations[AdhanIdSanitizer.sanitize(adhanId)] = seconds
            }
        } else {
            durations.removeValue(forKey: AdhanIdSanitizer.sanitize(adhanId))
        }
        defaults.set(durations, forKey: AdhanStoreCodec.keySoundDurations)

        registerWindow()
        call.resolve(["ok": true])
    }

    @objc public func deleteFile(_ call: CAPPluginCall) {
        guard let adhanId = call.getString("adhanId"), !adhanId.isEmpty else {
            call.reject("missing adhanId", "failed")
            return
        }
        if let url = mirrorURL(adhanId: adhanId) {
            try? FileManager.default.removeItem(at: url)
        }
        var durations = soundDurations()
        durations.removeValue(forKey: AdhanIdSanitizer.sanitize(adhanId))
        defaults.set(durations, forKey: AdhanStoreCodec.keySoundDurations)
        registerWindow()
        call.resolve()
    }

    @objc public func listFiles(_ call: CAPPluginCall) {
        var files: [[String: Any]] = []
        if let dir = soundsDirectory,
           let names = try? FileManager.default.contentsOfDirectory(atPath: dir.path) {
            for name in names.sorted() {
                guard name.hasSuffix(".mp3"), !name.hasPrefix(".tmp-") else { continue }
                let adhanId = String(name.dropLast(4))
                let size = fileSize(at: dir.appendingPathComponent(name)) ?? 0
                files.append(["adhanId": adhanId, "sizeBytes": size])
            }
        }
        call.resolve(["files": files])
    }

    /// Test hook: fire the next event now (never used in production
    /// paths). Posts the notification immediately and, when the app is
    /// foreground with listeners, also emits foregroundFire.
    @objc public func debugFireNext(_ call: CAPPluginCall) {
        let now = Date()
        guard let next = AdhanStoreTrimmer.futureEvents(storedEvents(now: now), now: now).first else {
            call.resolve()
            return
        }
        let isForeground = defaults.object(forKey: AdhanStoreCodec.keyForeground) as? Bool ?? true
        if isForeground && hasListeners(AdhanSchedulerPlugin.eventForegroundFire) {
            emitForegroundFire(next)
        } else {
            postNotification(for: next)
        }
        registerWindow()
        call.resolve()
    }

    // MARK: - Foreground native playback (iOS volume bridge)

    /// playMirrored({ adhanId, volume }): play the verified local mirror
    /// with real per-stream volume — the honest iOS replacement for the
    /// volume-less WKWebView HTMLAudioElement used by the web fallback.
    /// Completion is reported through the `playbackEnded` bridge event.
    @objc public func playMirrored(_ call: CAPPluginCall) {
        guard let adhanId = call.getString("adhanId"), !adhanId.isEmpty else {
            call.reject("missing adhanId", "failed")
            return
        }
        let volume = max(0.0, min(1.0, call.getDouble("volume") ?? 1.0))
        guard let url = mirrorURL(adhanId: adhanId),
              FileManager.default.fileExists(atPath: url.path) else {
            call.resolve(["playing": false])
            return
        }
        do {
            stopForegroundPlayback(notify: false)

            // The Adhan must be audible with the Ring/Silent switch in
            // silent (same intent as Android's ALARM stream); spoken-
            // content mode keeps the audio session well-behaved.
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .spokenAudio, options: [])
            try session.setActive(true)

            let player = try AVAudioPlayer(contentsOf: url)
            player.volume = Float(volume)
            player.prepareToPlay()
            let proxy = AdhanPlayerDelegateProxy { [weak self] in
                self?.handlePlaybackEnded()
            }
            player.delegate = proxy
            adhanPlayerDelegateProxy = proxy
            adhanPlayer = player
            guard player.play() else {
                stopForegroundPlayback(notify: false)
                call.resolve(["playing": false])
                return
            }
            call.resolve(["playing": true])
        } catch {
            stopForegroundPlayback(notify: false)
            call.resolve(["playing": false])
        }
    }

    @objc public func stopMirroredPlayback(_ call: CAPPluginCall) {
        let stopped = adhanPlayer?.isPlaying ?? false
        stopForegroundPlayback(notify: false)
        call.resolve(["stopped": stopped])
    }

    private func stopForegroundPlayback(notify: Bool) {
        let wasPlaying = adhanPlayer?.isPlaying ?? false
        adhanPlayer?.stop()
        adhanPlayer = nil
        adhanPlayerDelegateProxy = nil
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            // Deactivation is best-effort (another session may own audio).
        }
        if notify || wasPlaying {
            handlePlaybackEnded()
        }
    }

    private func handlePlaybackEnded() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.notifyListeners(AdhanSchedulerPlugin.eventPlaybackEnded, data: [:])
        }
    }

    // MARK: - Scheduling window

    /// Re-arm the notification window: cancel exactly the previously
    /// registered requests (tracked like Android's pending_alarms_v1),
    /// then schedule the next `schedulingWindow` future events. Quiet-
    /// hour events are never scheduled (fail-open evaluation at fire
    /// time is impossible on iOS — the system delivers notifications
    /// without waking the app — so the deterministic fire instant is
    /// evaluated while scheduling).
    private func registerWindow() {
        stateQueue.async { [weak self] in
            guard let self = self else { return }
            let center = UNUserNotificationCenter.current()

            let previouslyScheduled = (self.defaults.stringArray(forKey: AdhanStoreCodec.keyPendingScheduled) ?? [])
            let previousSet = Set(previouslyScheduled)

            let now = Date()
            let events = AdhanStoreTrimmer.window(
                self.storedEvents(now: now),
                limit: AdhanSchedulerPlugin.schedulingWindow,
                now: now
            )

            center.getPendingNotificationRequests { pending in
                let toRemove = pending
                    .map { $0.identifier }
                    .filter { previousSet.contains($0) }
                center.removePendingNotificationRequests(withIdentifiers: toRemove)

                var scheduledIds: [String] = []
                for event in events {
                    // Quiet hours: skip the event entirely (Android also
                    // skips muted fires with no notification).
                    let zone = event.timeZone.flatMap { TimeZone(identifier: $0) }
                    if AdhanQuietHours.isQuiet(at: event.fireDate, in: zone, window: event.quiet) {
                        continue
                    }
                    if let request = self.makeRequest(for: event, now: now) {
                        center.add(request) { error in
                            if error != nil {
                                // Per-event failures are skipped honestly
                                // (the Android code swallows per-alarm
                                // exceptions the same way).
                            }
                        }
                        scheduledIds.append(event.id)
                    }
                }
                self.defaults.set(scheduledIds, forKey: AdhanStoreCodec.keyPendingScheduled)
            }
        }
    }

    private func makeRequest(for event: AdhanEvent, now: Date) -> UNNotificationRequest? {
        let interval = event.fireDate.timeIntervalSince(now)
        guard interval > 0 else { return nil }
        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: max(1, interval),
            repeats: false
        )

        let content = UNMutableNotificationContent()
        content.title = event.title

        let sanitizedId = event.adhanId.map { AdhanIdSanitizer.sanitize($0) }
        let hasMirror: Bool
        if let id = sanitizedId, let url = mirrorURL(adhanId: id) {
            hasMirror = FileManager.default.fileExists(atPath: url.path)
        } else {
            hasMirror = false
        }
        content.body = AdhanNotificationTexts.body(for: event, hasMirror: hasMirror)

        // Sound decision (honest): attach the mirrored recording only
        // when its measured duration fits iOS's 30-second notification
        // sound limit; otherwise the default sound.
        if event.isAudioMode, let id = sanitizedId, hasMirror,
           AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: soundDurations()[id]) {
            // iOS notification sounds do not expose per-notification
            // volume control. The system applies the user's device sound
            // level; the app's selected volume is honored for foreground
            // playback through AVAudioPlayer.playMirrored instead.
            content.sound = UNNotificationSound(named: UNNotificationSoundName("\(id).mp3"))
        } else {
            content.sound = .default
        }

        return UNNotificationRequest(
            identifier: event.id,
            content: content,
            trigger: trigger
        )
    }

    private func postNotification(for event: AdhanEvent) {
        let content = UNMutableNotificationContent()
        content.title = event.title
        let sanitizedId = event.adhanId.map { AdhanIdSanitizer.sanitize($0) }
        var hasMirror = false
        if let id = sanitizedId, let url = mirrorURL(adhanId: id) {
            hasMirror = FileManager.default.fileExists(atPath: url.path)
        }
        content.body = AdhanNotificationTexts.body(for: event, hasMirror: hasMirror)
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: "debug-\(event.id)", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    // MARK: - Foreground fire emission

    private func emitForegroundFire(_ event: AdhanEvent) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.notifyListeners(
                AdhanSchedulerPlugin.eventForegroundFire,
                data: AdhanEventParser.foregroundFirePayload(event)
            )
        }
    }

    // MARK: - UNUserNotificationCenter routing (via Capacitor)

    private func event(byNotificationId id: String, now: Date = Date()) -> AdhanEvent? {
        storedEvents(now: now).first { $0.id == id }
    }

    private var isForegroundNow: Bool {
        defaults.object(forKey: AdhanStoreCodec.keyForeground) as? Bool ?? true
    }
}

// MARK: - NotificationHandlerProtocol (forwarded by Capacitor's router)

extension AdhanSchedulerPlugin: NotificationHandlerProtocol {

    /// Called when a notification arrives while the app is foreground.
    /// Mirrors the Android decision: foreground + web layer ready → emit
    /// `foregroundFire` and suppress the system notification (the app
    /// plays the full Adhan itself and shows the banner); otherwise →
    /// present banner + sound (the honest fallback when the WebView has
    /// no listeners yet, e.g. during cold start).
    public func willPresent(notification: UNNotification) -> UNNotificationPresentationOptions {
        let now = Date()
        let id = notification.request.identifier
        // Only OUR scheduled events (identified by stored event id); any
        // other local notification is ignored.
        guard let event = event(byNotificationId: id, now: now) else {
            return [.banner, .list, .sound]
        }

        // A fire consumed a window slot — re-arm.
        registerWindow()

        // Stale skip (Android STALE_AFTER_MS): too-late fires are not
        // delivered in the foreground either.
        if now.timeIntervalSince(event.fireDate) > AdhanSchedulerPlugin.staleAfterSeconds {
            return []
        }
        // Quiet hours are also enforced here (fail-open), belt-and-braces
        // with the schedule-time evaluation.
        let zone = event.timeZone.flatMap { TimeZone(identifier: $0) }
        if AdhanQuietHours.isQuiet(at: event.fireDate, in: zone, window: event.quiet) {
            return []
        }

        if isForegroundNow && hasListeners(AdhanSchedulerPlugin.eventForegroundFire) {
            emitForegroundFire(event)
            return []
        }
        return [.banner, .list, .sound]
    }

    /// Called when the user taps the notification: the app opens (the
    /// same behavior as Android's tap → MainActivity). Re-arm the window.
    public func didReceive(response: UNNotificationResponse) {
        registerWindow()
    }
}

// MARK: - AVAudioPlayer delegate proxy

/// AVAudioPlayer's delegate is weak; this proxy keeps the plugin
/// lifetime decoupled and forwards completion once.
private final class AdhanPlayerDelegateProxy: NSObject, AVAudioPlayerDelegate {
    private let onEnd: () -> Void
    private var fired = false

    init(onEnd: @escaping () -> Void) {
        self.onEnd = onEnd
        super.init()
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        guard !fired else { return }
        fired = true
        onEnd()
    }

    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        guard !fired else { return }
        fired = true
        onEnd()
    }
}
