/**
 * Global Quran — AudioSessionBridge native plugin (iOS).
 *
 * A small, focused bridge that lets the shared web audio engines manage
 * the app's AVAudioSession so Quran recitation (an HTMLAudioElement
 * inside WKWebView) can continue in the background and with the screen
 * locked, where iOS permits it:
 *
 *  - setPlaybackActive({ active: true })  -> category .playback + active
 *      (.playback keeps WebKit media audible with the Ring/Silent
 *      switch in silent — the same user expectation as Android's media
 *      stream — and, combined with the `audio` UIBackgroundModes entry
 *      in Info.plist, allows background playback).
 *  - setPlaybackActive({ active: false }) -> deactivation with
 *      .notifyOthersOnDeactivation (paused/finished playback releases
 *      the audio focus politely, like a native music app).
 *
 * The shared web layer calls this ONLY on the iOS native platform (see
 * src/services/native/audio-session-bridge.ts); Android needs no
 * equivalent (its WebView media stack manages audio focus itself).
 *
 * Honest limitation, documented in PLATFORM-DIFFERENCES.md: background
 * continuation of WKWebView audio with the `audio` background mode is
 * the standard approach but MUST be verified on physical devices during
 * the on-Mac test pass — no claim of verified background behavior is
 * made from this environment.
 */

import Foundation
import Capacitor
import AVFoundation

@objc(AudioSessionBridgePlugin)
public class AudioSessionBridgePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "AudioSessionBridgePlugin"
    public let jsName = "AudioSessionBridge"

    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "setPlaybackActive", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "isPlaybackActive", returnType: CAPPluginReturnPromise),
    ]

    /// Tracked honestly: the AVAudioSession API exposes no "is active"
    /// query, so this reflects the last successful transition we made.
    /// (Note: other components — TTS, the Adhan player — also manage the
    /// shared session; the category report is always the live truth.)
    private var lastActivationSucceeded = false

    @objc public func setPlaybackActive(_ call: CAPPluginCall) {
        let active = call.getBool("active") ?? true
        do {
            let session = AVAudioSession.sharedInstance()
            if active {
                try session.setCategory(.playback, mode: .default, options: [])
                try session.setActive(true)
            } else {
                try session.setActive(false, options: .notifyOthersOnDeactivation)
            }
            lastActivationSucceeded = active
            call.resolve(["active": active])
        } catch {
            // The audio itself is not blocked by a failed session
            // transition; report the failure honestly so the caller can
            // log it — never fake success.
            call.reject("audio session transition failed: \(error.localizedDescription)", "failed")
        }
    }

    @objc public func isPlaybackActive(_ call: CAPPluginCall) {
        let session = AVAudioSession.sharedInstance()
        call.resolve([
            "active": lastActivationSucceeded,
            "category": session.category.rawValue,
        ])
    }
}
