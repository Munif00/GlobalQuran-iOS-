/**
 * Global Quran — Adhan scheduler shared models (iOS).
 *
 * Pure-Foundation data types for the AdhanScheduler native plugin. This
 * file intentionally contains NO UIKit / notification / audio APIs so the
 * XCTest target can verify the full data layer (event parsing, quiet
 * hours, sanitization, store codec) without a host application.
 *
 * The semantics are a faithful port of the audited Android implementation
 * (android/app/src/main/java/com/globalquran/app/plugins/AdhanEventStore.java
 * and the quiet-hours / window logic in AdhanScheduling.java) so both
 * platforms store, trim, and evaluate exactly the same payloads:
 *
 *  - Event schema and defaults mirror NativeReminderEvent (JS contract)
 *    and AdhanEventStore.parseEvent (Android) one-to-one.
 *  - Trimming drops events older than 24 h on every load.
 *  - Quiet hours are evaluated FAIL-OPEN: an unparseable window, an
 *    unknown time zone, or a degenerate range (start == end) never mutes.
 *  - Ids are sanitized to [A-Za-z0-9_-] (path-traversal guard) before
 *    they are ever used as file names.
 */

import Foundation

// MARK: - Event model

/// One scheduled reminder fire, mirroring the JS `NativeReminderEvent`.
struct AdhanEvent {
    var id: String
    /// Epoch milliseconds (UTC) when the reminder must fire.
    var at: Double
    var slot: String
    var slotIso: String
    var timeZone: String?
    /// "audio" = full Adhan from the local library; "silent" = notification only.
    var mode: String
    var adhanId: String?
    /// Playback volume 0...1 (default 1.0, same default as Android).
    var volume: Double
    var title: String
    var bodyPlaying: String
    var bodyUnavailable: String
    var bodyFallback: String
    var bodySilent: String
    var quiet: AdhanQuietWindow

    var isAudioMode: Bool { mode == "audio" }
    var fireDate: Date { Date(timeIntervalSince1970: at / 1000.0) }
}

/// Quiet-hours window snapshot (all defaults identical to Android).
struct AdhanQuietWindow {
    var enabled: Bool
    /// "HH:mm" strings; defaults match the Android parser (22:00–06:00).
    var start: String
    var end: String

    static let `default` = AdhanQuietWindow(enabled: false, start: "22:00", end: "06:00")
}

// MARK: - Event parsing

/// Parses and validates the stored schedule exactly like the Android
/// `AdhanEventStore`: the whole sync payload is kept verbatim, and events
/// are re-parsed defensively with per-field defaults.
enum AdhanEventParser {

    /// Parses the full sync payload `{ version, generatedAt, events: [...] }`.
    /// Returns [] when the payload is not a JSON object or `events` is
    /// missing/not an array (the caller then treats the store as empty —
    /// same honest behavior as a malformed Android store).
    static func parseEvents(from payload: Any) -> [AdhanEvent] {
        guard let object = payload as? [String: Any],
              let rawEvents = object["events"] as? [[String: Any]] else {
            return []
        }
        return rawEvents.compactMap(parseEvent)
    }

    /// Parses one event with the exact Android defaults:
    /// id/at required (silently dropped when missing), slot/slotIso "",
    /// mode "silent", volume 1.0, bodies "", quiet disabled.
    static func parseEvent(_ raw: [String: Any]) -> AdhanEvent? {
        guard let id = raw["id"] as? String, !id.isEmpty,
              let at = raw["at"] as? Double else {
            return nil
        }
        var quiet = AdhanQuietWindow.default
        if let quietRaw = raw["quiet"] as? [String: Any] {
            // quietEnabled is set true ONLY when quiet.enabled is true —
            // the absence of the key never enables quiet hours.
            if let enabled = quietRaw["enabled"] as? Bool {
                quiet.enabled = enabled
            }
            if let start = quietRaw["start"] as? String, !start.isEmpty { quiet.start = start }
            if let end = quietRaw["end"] as? String, !end.isEmpty { quiet.end = end }
        }
        return AdhanEvent(
            id: id,
            at: at,
            slot: raw["slot"] as? String ?? "",
            slotIso: raw["slotIso"] as? String ?? "",
            timeZone: raw["timeZone"] as? String,
            mode: raw["mode"] as? String ?? "silent",
            adhanId: raw["adhanId"] as? String,
            volume: raw["volume"] as? Double ?? 1.0,
            title: raw["title"] as? String ?? "",
            bodyPlaying: raw["bodyPlaying"] as? String ?? "",
            bodyUnavailable: raw["bodyUnavailable"] as? String ?? "",
            bodyFallback: raw["bodyFallback"] as? String ?? "",
            bodySilent: raw["bodySilent"] as? String ?? "",
            quiet: quiet
        )
    }

    /// Serializes one event back into the exact JS payload shape used for
    /// the `foregroundFire` bridge event (field-for-field identical to the
    /// Android notifyForegroundFire payload).
    static func eventPayload(_ event: AdhanEvent) -> [String: Any] {
        let quiet: [String: Any] = [
            "enabled": event.quiet.enabled,
            "start": event.quiet.start,
            "end": event.quiet.end,
        ]
        return [
            "id": event.id,
            "at": event.at,
            "slot": event.slot,
            "slotIso": event.slotIso,
            "timeZone": event.timeZone ?? NSNull(),
            "mode": event.mode,
            "adhanId": event.adhanId ?? NSNull(),
            "volume": event.volume,
            "title": event.title,
            "bodyPlaying": event.bodyPlaying,
            "bodyUnavailable": event.bodyUnavailable,
            "bodyFallback": event.bodyFallback,
            "bodySilent": event.bodySilent,
            "quiet": quiet,
        ]
    }

    /// foregroundFire bridge event envelope (matches Android exactly).
    static func foregroundFirePayload(_ event: AdhanEvent) -> [String: Any] {
        ["event": eventPayload(event)]
    }
}

// MARK: - Store trimming

enum AdhanStoreTrimmer {

    static let trimHorizonSeconds: TimeInterval = 24 * 60 * 60

    /// Drops events whose fire instant is older than 24 h — identical to
    /// the Android load()-time trim (recently-fired events survive).
    static func trim(_ events: [AdhanEvent], now: Date) -> [AdhanEvent] {
        let cutoff = (now.timeIntervalSince1970 - trimHorizonSeconds) * 1000.0
        return events.filter { $0.at >= cutoff }
    }

    /// Future events (at > now) in stored order.
    static func futureEvents(_ events: [AdhanEvent], now: Date) -> [AdhanEvent] {
        let nowMs = now.timeIntervalSince1970 * 1000.0
        return events.filter { $0.at > nowMs }
    }

    /// The rolling scheduling window. Android registers 3 exact alarms
    /// and re-arms on every fire; iOS holds at most 64 pending local
    /// notifications, so the window is 60 — safely under the system cap
    /// while covering ~12 days of five daily prayer slots without the
    /// app being opened (every fire, tap, and app activation re-arms).
    static func window(_ events: [AdhanEvent], limit: Int, now: Date) -> [AdhanEvent] {
        Array(futureEvents(events, now: now).prefix(limit))
    }
}

// MARK: - Quiet hours (fail-open, identical decision table to Android)

enum AdhanQuietHours {

    /// Minutes-of-day for "HH:mm"; nil when malformed (same regex
    /// contract as Android: ^(\d{1,2}):(\d{2})$ with range validation).
    static func parseMinutes(_ value: String) -> Int? {
        let parts = value.split(separator: ":", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        guard let hours = Int(parts[0]), let minutes = Int(parts[1]) else { return nil }
        guard parts[0].count <= 2, parts[1].count == 2 else { return nil }
        guard hours >= 0, hours < 24, minutes >= 0, minutes < 60 else { return nil }
        return hours * 60 + minutes
    }

    /// Whether `date` falls inside the quiet window, evaluated in `zone`.
    /// FAIL-OPEN: every uncertainty (disabled window, bad zone, malformed
    /// or degenerate range) answers false — a reminder is never muted on
    /// a guess. Decision table mirrors AdhanScheduling.isQuietNow.
    static func isQuiet(at date: Date, in zone: TimeZone?, window: AdhanQuietWindow) -> Bool {
        guard window.enabled else { return false }
        guard let startMinutes = parseMinutes(window.start),
              let endMinutes = parseMinutes(window.end),
              startMinutes != endMinutes else { return false }
        guard let zone = zone else { return false }

        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = zone
        let components = calendar.dateComponents([.hour, .minute], from: date)
        guard let hour = components.hour, let minute = components.minute else { return false }
        let nowMinutes = hour * 60 + minute

        if startMinutes < endMinutes {
            // Normal window: [start, end)
            return nowMinutes >= startMinutes && nowMinutes < endMinutes
        }
        // Overnight window: >= start || < end
        return nowMinutes >= startMinutes || nowMinutes < endMinutes
    }
}

// MARK: - Id sanitization

enum AdhanIdSanitizer {

    /// Keeps only [A-Za-z0-9_-] — the exact Android rule (anti
    /// path-traversal); used for every mirrored file name.
    static func sanitize(_ adhanId: String) -> String {
        return String(adhanId.filter { char in
            guard let scalar = char.unicodeScalars.first else { return false }
            let value = scalar.value
            let isAsciiUpper = value >= 65 && value <= 90
            let isAsciiLower = value >= 97 && value <= 122
            let isDigit = value >= 48 && value <= 57
            return isAsciiUpper || isAsciiLower || isDigit || char == "_" || char == "-"
        })
    }

    /// Temporary mirror file name: ".tmp-<sanitized>" (Android literal).
    static func tempFileName(adhanId: String) -> String {
        ".tmp-" + sanitize(adhanId)
    }

    /// Final mirror file name: "<sanitized>.mp3" (Android literal).
    static func finalFileName(adhanId: String) -> String {
        sanitize(adhanId) + ".mp3"
    }
}

// MARK: - Store codec

/// Encodes/decodes the persisted schedule. The whole sync payload is
/// stored verbatim as a JSON string under "schedule_v1" in the
/// "adhan_scheduler" defaults suite — byte-identical semantics to the
/// Android SharedPreferences store (single-key atomic replacement).
enum AdhanStoreCodec {

    static let defaultsSuiteName = "adhan_scheduler"
    static let keySchedule = "schedule_v1"
    static let keyPendingScheduled = "pending_scheduled_v1"
    static let keyForeground = "foreground"
    static let keySoundDurations = "sound_durations_v1"

    /// Re-serializes the received payload verbatim. Returns nil when the
    /// payload cannot be represented as JSON ("malformed payload" path).
    static func encodePayload(_ payload: Any) -> String? {
        guard JSONSerialization.isValidJSONObject(payload),
              let data = try? JSONSerialization.data(withJSONObject: payload) else {
            return nil
        }
        return String(data: data, encoding: .utf8)
    }

    /// Parses a stored schedule string back into events (empty on any
    /// malformation — the honest no-schedule state, same as Android).
    static func decodeEvents(from stored: String?) -> [AdhanEvent] {
        guard let stored = stored,
              let data = stored.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) else {
            return []
        }
        return AdhanEventParser.parseEvents(from: object)
    }
}

// MARK: - Notification body selection

/// Mirrors AdhanScheduling.postNotificationTexts: which body text and
/// whether a per-recording sound can be attached, given mirror presence.
enum AdhanNotificationTexts {

    static func body(for event: AdhanEvent, hasMirror: Bool) -> String {
        if event.isAudioMode {
            if event.adhanId == nil { return event.bodyUnavailable }
            return hasMirror ? event.bodyPlaying : event.bodyFallback
        }
        return event.bodySilent
    }

    /// Whether the mirrored recording may legally be attached as the
    /// notification sound: iOS only plays custom notification sounds of
    /// 30 seconds or shorter (longer files fall back to the default
    /// sound), so the decision is made from the MEASURED duration and
    /// never guessed. `durationSeconds` is nil when unknown.
    static func canAttachMirrorSound(durationSeconds: Double?) -> Bool {
        guard let duration = durationSeconds else { return false }
        return duration > 0 && duration <= 30.0
    }
}
