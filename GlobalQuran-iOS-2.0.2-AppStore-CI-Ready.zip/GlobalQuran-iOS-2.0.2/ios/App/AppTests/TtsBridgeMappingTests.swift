/**
 * Global Quran — TTS mapping tests (iOS unit tests).
 *
 * Verifies the rate/pitch mapping onto AVSpeechUtterance's scales, the
 * language alias table shared with the web engine and the Android
 * bridge, primary-subtag matching, and the chunker algorithm.
 *
 * EXECUTION STATUS: created for the CapAppTests target — requires
 * Xcode (macOS) to run; NOT executed in the authoring environment.
 * (Voice-catalog lookups depend on the simulator/installed voices and
 * are exercised in the on-Mac test pass; these tests cover the pure
 * mapping logic that does not depend on installed voices.)
 */

import XCTest
import AVFoundation
@testable import CapApp_SPM

final class TtsBridgeMappingTests: XCTestCase {

    // MARK: Rate mapping (Web Speech 1 = normal -> AVSpeech 0.5)

    func testRateDefaultsAndNormals() {
        // nil (unset) and 1 = normal speech -> AV default 0.5
        XCTAssertEqual(TtsVoiceCatalog.mappedRate(nil), AVSpeechUtteranceDefaultSpeechRate)
        XCTAssertEqual(TtsVoiceCatalog.mappedRate(1.0), AVSpeechUtteranceDefaultSpeechRate, accuracy: 0.0001)
        // 2 = fast -> 1.0 on the AV scale
        XCTAssertEqual(TtsVoiceCatalog.mappedRate(2.0), 1.0, accuracy: 0.0001)
        // 0.5 = slow -> 0.25 on the AV scale
        XCTAssertEqual(TtsVoiceCatalog.mappedRate(0.5), 0.25, accuracy: 0.0001)
    }

    func testRateClampsToSystemLimits() {
        // Extreme Web Speech rates (10x) clamp to the AV maximum.
        XCTAssertEqual(TtsVoiceCatalog.mappedRate(10.0), AVSpeechUtteranceMaximumSpeechRate, accuracy: 0.0001)
        XCTAssertEqual(TtsVoiceCatalog.mappedRate(0.0), AVSpeechUtteranceMinimumSpeechRate, accuracy: 0.0001)
    }

    // MARK: Pitch mapping (1:1, clamped to 0.5...2.0)

    func testPitchMapping() {
        XCTAssertEqual(TtsVoiceCatalog.mappedPitch(nil), 1.0, accuracy: 0.0001)
        XCTAssertEqual(TtsVoiceCatalog.mappedPitch(1.5), 1.5, accuracy: 0.0001)
        XCTAssertEqual(TtsVoiceCatalog.mappedPitch(0.1), 0.5, accuracy: 0.0001)
        XCTAssertEqual(TtsVoiceCatalog.mappedPitch(3.0), 2.0, accuracy: 0.0001)
    }

    // MARK: Language aliases (identical table to Android/web)

    func testAliasTableMatchesTheSharedEngine() {
        XCTAssertEqual(TtsVoiceCatalog.languageAliases["tl"], ["tl", "fil"])
        XCTAssertEqual(TtsVoiceCatalog.languageAliases["fil"], ["fil", "tl"])
        XCTAssertEqual(TtsVoiceCatalog.languageAliases["nb"], ["nb", "no"])
        XCTAssertEqual(TtsVoiceCatalog.languageAliases["nn"], ["nn", "no"])
        XCTAssertEqual(TtsVoiceCatalog.languageAliases["in"], ["in", "id"])
        XCTAssertEqual(TtsVoiceCatalog.languageAliases["iw"], ["iw", "he"])
    }

    func testCandidateLanguagesDirectThenAliases() {
        XCTAssertEqual(TtsVoiceCatalog.candidateLanguages(for: "fil"), ["fil", "tl"])
        XCTAssertEqual(TtsVoiceCatalog.candidateLanguages(for: "nb"), ["nb", "no"])
        XCTAssertEqual(TtsVoiceCatalog.candidateLanguages(for: "en"), ["en"])
        XCTAssertEqual(TtsVoiceCatalog.candidateLanguages(for: "pt-BR"), ["pt-BR"])
    }

    func testPrimarySubtag() {
        XCTAssertEqual(TtsVoiceCatalog.primarySubtag(of: "pt-BR"), "pt")
        XCTAssertEqual(TtsVoiceCatalog.primarySubtag(of: "ar"), "ar")
        XCTAssertEqual(TtsVoiceCatalog.primarySubtag(of: "zh-Hant-TW"), "zh")
    }

    func testLanguageMatchesPrimarySubtag() {
        XCTAssertTrue(TtsVoiceCatalog.languageMatches(voiceLanguage: "ar-SA", requested: "ar"))
        XCTAssertTrue(TtsVoiceCatalog.languageMatches(voiceLanguage: "en-GB", requested: "en-US"))
        XCTAssertFalse(TtsVoiceCatalog.languageMatches(voiceLanguage: "ur", requested: "fa"))
    }

    // MARK: Chunker (same algorithm/limit as the Android bridge)

    func testShortTextIsOneChunk() {
        XCTAssertEqual(TtsTextChunker.splitForTts("Hello world", maxChars: 3500), ["Hello world"])
    }

    func testChunkingSplitsAtWhitespaceBoundaries() {
        let text = String(repeating: "word ", count: 100) // 500 chars
        let chunks = TtsTextChunker.splitForTts(text, maxChars: 120)
        XCTAssertGreaterThan(chunks.count, 1)
        for chunk in chunks {
            XCTAssertLessThanOrEqual(chunk.count, 120)
            XCTAssertFalse(chunk.hasPrefix(" "), "chunks are trimmed")
        }
        // No text is lost:
        XCTAssertEqual(chunks.joined(separator: " ").split(separator: " ").count,
                       text.split(separator: " ").count)
    }

    func testTextWithoutWhitespaceSplitsHard() {
        let text = String(repeating: "a", count: 300)
        let chunks = TtsTextChunker.splitForTts(text, maxChars: 100)
        XCTAssertEqual(chunks.count, 3)
        XCTAssertEqual(chunks.joined(), text)
    }
}
