/**
 * Global Quran — DeviceBridge permission mapping tests (iOS unit tests).
 *
 * Verifies the CLAuthorizationStatus -> shared contract mapping used by
 * getPermissionState (fine and coarse report the same honest state —
 * iOS exposes a single location permission).
 *
 * EXECUTION STATUS: created for the CapAppTests target — requires
 * Xcode (macOS) to run; NOT executed in the authoring environment.
 */

import XCTest
import CoreLocation
@testable import CapApp_SPM

final class DeviceBridgeMappingTests: XCTestCase {

    func testAuthorizedStatesMapToGranted() {
        XCTAssertEqual(DeviceBridgePermissionMapper.contractState(from: .authorizedWhenInUse), "granted")
        XCTAssertEqual(DeviceBridgePermissionMapper.contractState(from: .authorizedAlways), "granted")
    }

    func testNotDeterminedMapsToNotRequested() {
        XCTAssertEqual(DeviceBridgePermissionMapper.contractState(from: .notDetermined), "not-requested")
    }

    func testDeniedAndRestrictedMapToDenied() {
        XCTAssertEqual(DeviceBridgePermissionMapper.contractState(from: .denied), "denied")
        XCTAssertEqual(DeviceBridgePermissionMapper.contractState(from: .restricted), "denied")
    }
}
