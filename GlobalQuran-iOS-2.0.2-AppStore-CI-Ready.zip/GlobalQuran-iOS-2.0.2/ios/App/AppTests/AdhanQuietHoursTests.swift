/**
 * Global Quran — quiet hours tests (iOS unit tests).
 *
 * Verifies the fail-open decision table ported from Android's
 * AdhanScheduling.isQuietNow: disabled windows, malformed values,
 * degenerate ranges and unknown zones never mute; normal and overnight
 * windows follow [start, end) semantics in the event's own zone.
 *
 * EXECUTION STATUS: created for the CapAppTests target — requires
 * Xcode (macOS) to run; NOT executed in the authoring environment.
 */

import XCTest
@testable import CapApp_SPM

final class AdhanQuietHoursTests: XCTestCase {

    private var aden: TimeZone { TimeZone(identifier: "Asia/Aden")! }

    private func date(hour: Int, minute: Int, zone: TimeZone) -> Date {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = zone
        var components = DateComponents()
        components.year = 2026
        components.month = 1
        components.day = 15
        components.hour = hour
        components.minute = minute
        return calendar.date(from: components)!
    }

    func testDisabledWindowNeverMutes() {
        let window = AdhanQuietWindow(enabled: false, start: "00:00", end: "23:59")
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 3, minute: 0, zone: aden), in: aden, window: window))
    }

    func testMalformedWindowNeverMutes() {
        let bad = AdhanQuietWindow(enabled: true, start: "nope", end: "06:00")
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 3, minute: 0, zone: aden), in: aden, window: bad))
        let bad2 = AdhanQuietWindow(enabled: true, start: "22:00", end: "99:00")
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 3, minute: 0, zone: aden), in: aden, window: bad2))
    }

    func testDegenerateRangeNeverMutes() {
        let window = AdhanQuietWindow(enabled: true, start: "22:00", end: "22:00")
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 22, minute: 30, zone: aden), in: aden, window: window))
    }

    func testMissingZoneNeverMutes() {
        let window = AdhanQuietWindow(enabled: true, start: "22:00", end: "06:00")
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 3, minute: 0, zone: aden), in: nil, window: window))
    }

    func testNormalWindowIsStartInclusiveEndExclusive() {
        let window = AdhanQuietWindow(enabled: true, start: "13:00", end: "15:00")
        XCTAssertTrue(AdhanQuietHours.isQuiet(at: date(hour: 13, minute: 0, zone: aden), in: aden, window: window))
        XCTAssertTrue(AdhanQuietHours.isQuiet(at: date(hour: 14, minute: 59, zone: aden), in: aden, window: window))
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 15, minute: 0, zone: aden), in: aden, window: window))
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 12, minute: 59, zone: aden), in: aden, window: window))
    }

    func testOvernightWindowWrapsMidnight() {
        let window = AdhanQuietWindow(enabled: true, start: "22:00", end: "06:00")
        XCTAssertTrue(AdhanQuietHours.isQuiet(at: date(hour: 23, minute: 30, zone: aden), in: aden, window: window))
        XCTAssertTrue(AdhanQuietHours.isQuiet(at: date(hour: 3, minute: 0, zone: aden), in: aden, window: window))
        XCTAssertTrue(AdhanQuietHours.isQuiet(at: date(hour: 5, minute: 59, zone: aden), in: aden, window: window))
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 6, minute: 0, zone: aden), in: aden, window: window))
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: date(hour: 12, minute: 0, zone: aden), in: aden, window: window))
    }

    func testEvaluationUsesTheEventZoneNotTheDeviceZone() {
        // 01:00 in Aden is 22:00 the previous day in New York — an
        // overnight quiet window evaluated in the EVENT zone (New York)
        // must be quiet, while the same instant is not quiet when
        // (incorrectly) evaluated in Aden.
        let newYork = TimeZone(identifier: "America/New_York")!
        let instant = date(hour: 1, minute: 0, zone: aden)
        let window = AdhanQuietWindow(enabled: true, start: "22:00", end: "06:00")
        XCTAssertTrue(AdhanQuietHours.isQuiet(at: instant, in: newYork, window: window))
        XCTAssertFalse(AdhanQuietHours.isQuiet(at: instant, in: aden, window: window))
    }

    func testParseMinutesValidation() {
        XCTAssertEqual(AdhanQuietHours.parseMinutes("00:00"), 0)
        XCTAssertEqual(AdhanQuietHours.parseMinutes("23:59"), 23 * 60 + 59)
        XCTAssertEqual(AdhanQuietHours.parseMinutes("9:05"), 9 * 60 + 5)
        XCTAssertNil(AdhanQuietHours.parseMinutes("24:00"))
        XCTAssertNil(AdhanQuietHours.parseMinutes("12:60"))
        XCTAssertNil(AdhanQuietHours.parseMinutes("12:5"))
        XCTAssertNil(AdhanQuietHours.parseMinutes("1200"))
        XCTAssertNil(AdhanQuietHours.parseMinutes(""))
        XCTAssertNil(AdhanQuietHours.parseMinutes("aa:bb"))
    }
}
