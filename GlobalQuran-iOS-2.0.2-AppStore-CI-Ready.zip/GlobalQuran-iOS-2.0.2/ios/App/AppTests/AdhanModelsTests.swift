/**
 * Global Quran — Adhan event model tests (iOS unit tests).
 *
 * Verifies the data layer shared with Android: event parsing defaults,
 * required-field handling, foregroundFire payload shape, trimming and
 * the scheduling window.
 *
 * EXECUTION STATUS: created for the CapAppTests target — these tests
 * require Xcode (macOS) to run and have NOT been executed in the
 * authoring environment (Linux). Run with: xcodebuild test
 * -workspace App.xcproj -scheme App -destination 'platform=iOS Simulator,name=iPhone 15'
 */

import XCTest
@testable import CapApp_SPM

final class AdhanModelsTests: XCTestCase {

    private func makeRawEvent(overrides: [String: Any] = [:]) -> [String: Any] {
        var raw: [String: Any] = [
            "id": "1700000000000-fajr",
            "at": 1_700_000_000_000.0,
        ]
        for (key, value) in overrides { raw[key] = value }
        return raw
    }

    // MARK: Parsing defaults (mirroring AdhanEventStore.parseEvent)

    func testMinimalEventUsesAndroidDefaults() {
        let event = AdhanEventParser.parseEvent(makeRawEvent())
        XCTAssertNotNil(event)
        // Defaults identical to the Android parser:
        XCTAssertEqual(event?.slot, "")
        XCTAssertEqual(event?.slotIso, "")
        XCTAssertEqual(event?.mode, "silent")
        XCTAssertEqual(event?.volume, 1.0)
        XCTAssertEqual(event?.title, "")
        XCTAssertEqual(event?.bodyPlaying, "")
        XCTAssertEqual(event?.bodyUnavailable, "")
        XCTAssertEqual(event?.bodyFallback, "")
        XCTAssertEqual(event?.bodySilent, "")
        XCTAssertEqual(event?.quiet.enabled, false)
        XCTAssertEqual(event?.quiet.start, "22:00")
        XCTAssertEqual(event?.quiet.end, "06:00")
        XCTAssertNil(event?.timeZone)
        XCTAssertNil(event?.adhanId)
    }

    func testMissingIdOrAtDropsEvent() {
        XCTAssertNil(AdhanEventParser.parseEvent(["at": 123.0]))
        XCTAssertNil(AdhanEventParser.parseEvent(["id": "x"]))
        XCTAssertNil(AdhanEventParser.parseEvent(["id": "", "at": 123.0]))
    }

    func testQuietEnabledOnlyWhenExplicitlyTrue() {
        let event = AdhanEventParser.parseEvent(makeRawEvent(overrides: [
            "quiet": ["start": "23:00", "end": "05:00"],
        ]))
        XCTAssertEqual(event?.quiet.enabled, false)
        XCTAssertEqual(event?.quiet.start, "23:00")

        let enabled = AdhanEventParser.parseEvent(makeRawEvent(overrides: [
            "quiet": ["enabled": true, "start": "23:00", "end": "05:00"],
        ]))
        XCTAssertEqual(enabled?.quiet.enabled, true)
    }

    // MARK: Payload shape (the foregroundFire contract)

    func testForegroundFirePayloadMatchesContract() {
        let event = AdhanEventParser.parseEvent(makeRawEvent(overrides: [
            "slot": "fajr",
            "mode": "audio",
            "adhanId": "makkar-royal",
            "volume": 0.6,
            "title": "Fajr",
            "timeZone": "Asia/Aden",
        ]))!
        let payload = AdhanEventParser.eventPayload(event)
        XCTAssertEqual(payload["id"] as? String, "1700000000000-fajr")
        XCTAssertEqual(payload["at"] as? Double, 1_700_000_000_000.0)
        XCTAssertEqual(payload["slot"] as? String, "fajr")
        XCTAssertEqual(payload["mode"] as? String, "audio")
        XCTAssertEqual(payload["adhanId"] as? String, "makkar-royal")
        XCTAssertEqual(payload["volume"] as? Double, 0.6)
        XCTAssertEqual(payload["timeZone"] as? String, "Asia/Aden")
        let quiet = payload["quiet"] as? [String: Any]
        XCTAssertNotNil(quiet)
        XCTAssertEqual(quiet?["enabled"] as? Bool, false)
        XCTAssertEqual(quiet?["start"] as? String, "22:00")

        // Null round-trip: absent optional fields become NSNull in the
        // payload (the Android JSON behavior the web layer expects).
        let minimal = AdhanEventParser.eventPayload(
            AdhanEventParser.parseEvent(makeRawEvent())!
        )
        XCTAssertTrue(minimal["timeZone"] is NSNull)
        XCTAssertTrue(minimal["adhanId"] is NSNull)
    }

    // MARK: Trimming and window

    func testTrimDropsEventsOlderThan24Hours() {
        let now = Date()
        let nowMs = now.timeIntervalSince1970 * 1000.0
        let events = [
            AdhanEventParser.parseEvent(makeRawEvent(overrides: ["id": "a", "at": nowMs - 23 * 3_600_000.0]))!,
            AdhanEventParser.parseEvent(makeRawEvent(overrides: ["id": "b", "at": nowMs - 25 * 3_600_000.0]))!,
            AdhanEventParser.parseEvent(makeRawEvent(overrides: ["id": "c", "at": nowMs + 3_600_000.0]))!,
        ]
        let trimmed = AdhanStoreTrimmer.trim(events, now: now)
        XCTAssertEqual(trimmed.map { $0.id }, ["a", "c"])
    }

    func testWindowTakesFutureEventsInStoredOrder() {
        let now = Date()
        let nowMs = now.timeIntervalSince1970 * 1000.0
        var events: [AdhanEvent] = []
        for index in 0..<10 {
            events.append(AdhanEventParser.parseEvent(makeRawEvent(overrides: [
                "id": "e\(index)",
                "at": nowMs - 3_600_000.0 + Double(index) * 1_800_000.0,
            ]))!)
        }
        let window = AdhanStoreTrimmer.window(events, limit: 5, now: now)
        XCTAssertEqual(window.map { $0.id }, ["e1", "e2", "e3", "e4", "e5"])
    }
}
