/**
 * Global Quran — sanitizer, store codec and notification-text tests
 * (iOS unit tests).
 *
 * EXECUTION STATUS: created for the CapAppTests target — requires
 * Xcode (macOS) to run; NOT executed in the authoring environment.
 */

import XCTest
@testable import CapApp_SPM

final class AdhanSanitizerAndStoreTests: XCTestCase {

    // MARK: Id sanitization (Android rule: keep [A-Za-z0-9_-])

    func testSanitizerKeepsOnlyAllowedCharacters() {
        XCTAssertEqual(AdhanIdSanitizer.sanitize("makkar-royal"), "makkar-royal")
        XCTAssertEqual(AdhanIdSanitizer.sanitize("Ab_99"), "Ab_99")
        // Path traversal is neutralized:
        XCTAssertEqual(AdhanIdSanitizer.sanitize("../../etc/passwd"), "etcpasswd")
        XCTAssertEqual(AdhanIdSanitizer.sanitize("a b/c:d"), "abcd")
        XCTAssertEqual(AdhanIdSanitizer.sanitize("سلام"), "")
        XCTAssertEqual(AdhanIdSanitizer.sanitize("id.with.dots"), "idwithdots")
    }

    func testFileNamesMatchAndroidLiterals() {
        XCTAssertEqual(AdhanIdSanitizer.finalFileName(adhanId: "makkar-royal"), "makkar-royal.mp3")
        XCTAssertEqual(AdhanIdSanitizer.tempFileName(adhanId: "makkar-royal"), ".tmp-makkar-royal")
        XCTAssertEqual(AdhanIdSanitizer.finalFileName(adhanId: "../x"), "x.mp3")
    }

    // MARK: Store codec (verbatim single-key replacement semantics)

    func testEncodeDecodeRoundTrip() {
        let payload: [String: Any] = [
            "version": 1,
            "generatedAt": 1_700_000_000_000.0,
            "events": [
                ["id": "a", "at": 1.0, "slot": "fajr", "mode": "audio", "adhanId": "m1", "volume": 0.5],
                ["id": "b", "at": 2.0],
            ],
        ]
        let encoded = AdhanStoreCodec.encodePayload(payload)
        XCTAssertNotNil(encoded)
        let decoded = AdhanStoreCodec.decodeEvents(from: encoded)
        XCTAssertEqual(decoded.count, 2)
        XCTAssertEqual(decoded[0].slot, "fajr")
        XCTAssertEqual(decoded[0].mode, "audio")
        XCTAssertEqual(decoded[0].adhanId, "m1")
        XCTAssertEqual(decoded[0].volume, 0.5)
        XCTAssertEqual(decoded[1].mode, "silent")
    }

    func testMalformedStoreDecodesEmpty() {
        XCTAssertEqual(AdhanStoreCodec.decodeEvents(from: nil), [])
        XCTAssertEqual(AdhanStoreCodec.decodeEvents(from: ""), [])
        XCTAssertEqual(AdhanStoreCodec.decodeEvents(from: "not json"), [])
        XCTAssertEqual(AdhanStoreCodec.decodeEvents(from: "{\"events\": \"nope\"}"), [])
        // Missing events key -> honest empty state:
        XCTAssertEqual(AdhanStoreCodec.decodeEvents(from: "{\"version\": 1}"), [])
    }

    func testNonSerializablePayloadIsRejected() {
        // A payload that cannot be represented as JSON must reject the
        // sync ("malformed payload"), never corrupt the store.
        let bad: [String: Any] = ["events": [["id": "a", "at": Double.infinity]]]
        XCTAssertNil(AdhanStoreCodec.encodePayload(bad))
    }

    // MARK: Notification body selection (Android decision table)

    private func audioEvent(adhanId: String?) -> AdhanEvent {
        AdhanEventParser.parseEvent([
            "id": "x", "at": 1.0, "mode": "audio",
            "adhanId": adhanId as Any,
            "bodyPlaying": "playing",
            "bodyUnavailable": "unavailable",
            "bodyFallback": "fallback",
            "bodySilent": "silent",
        ])!
    }

    func testBodySelectionMirrorsAndroid() {
        XCTAssertEqual(AdhanNotificationTexts.body(for: audioEvent(adhanId: "m1"), hasMirror: true), "playing")
        XCTAssertEqual(AdhanNotificationTexts.body(for: audioEvent(adhanId: "m1"), hasMirror: false), "fallback")
        XCTAssertEqual(AdhanNotificationTexts.body(for: audioEvent(adhanId: nil), hasMirror: false), "unavailable")
        let silent = AdhanEventParser.parseEvent(["id": "x", "at": 1.0, "bodySilent": "silent"])!
        XCTAssertEqual(AdhanNotificationTexts.body(for: silent, hasMirror: true), "silent")
    }

    // MARK: Notification sound gate (iOS 30-second honesty rule)

    func testMirrorSoundOnlyForShortMeasuredDurations() {
        XCTAssertFalse(AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: nil))
        XCTAssertFalse(AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: 0))
        XCTAssertFalse(AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: 31))
        XCTAssertFalse(AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: 120))
        XCTAssertTrue(AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: 30))
        XCTAssertTrue(AdhanNotificationTexts.canAttachMirrorSound(durationSeconds: 12.5))
    }
}
