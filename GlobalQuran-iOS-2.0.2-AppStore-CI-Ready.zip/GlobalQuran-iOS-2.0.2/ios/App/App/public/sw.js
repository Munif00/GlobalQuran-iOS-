/*
 * Global Quran - service worker.
 *
 * Goals (and only these - nothing is over-claimed):
 * 1. Make the installed PWA able to start offline: the app shell (the `/`
 *    document) is cached after the first successful visit and served as the
 *    navigation fallback when the network is unreachable.
 * 2. Cache-first for stable static assets (fonts, icons, wasm, the PDF
 *    worker). These change only on app updates, which bump the cache name.
 * 3. API calls are NEVER cached here. Downloaded translations live in
 *    IndexedDB (the app's own storage), and prayer/Quran API data has its
 *    own clearly-labeled server-side cache. When offline, API calls fail
 *    and the app shows its honest offline states.
 *
 * Strategy for navigations: network-first. In development this keeps live
 * reload working; when offline the cached shell is served instead.
 */

const CACHE_VERSION = 'global-quran-v4'
const SHELL_URL = '/'

/** Truly stable static assets (never content-addressed): cache-first. */
const STATIC_ASSETS = [
  '/manifest.webmanifest',
  '/icon.svg',
  '/icon-192.png',
  '/icon-512.png',
  '/icon-maskable-192.png',
  '/icon-maskable-512.png',
  '/icon-monochrome-512.png',
  '/apple-touch-icon.png',
  '/fonts/Hafs_20.woff2',
  // Opening Dua splash artwork - the splash must render offline too.
  '/splash/mushaf.jpg',
  // Built-in profile avatar artwork.
  '/avatars/mushaf.jpg',
  '/avatars/geometric.jpg',
  '/avatars/dome.jpg',
]

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_VERSION)
      // Best-effort precache: individual failures must not block install.
      await Promise.allSettled([
        cache.add(SHELL_URL),
        ...STATIC_ASSETS.map((asset) => cache.add(asset)),
      ])
      await self.skipWaiting()
    })(),
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      // Drop caches from previous versions.
      const keys = await caches.keys()
      await Promise.all(
        keys.filter((key) => key !== CACHE_VERSION).map((key) => caches.delete(key)),
      )
      await self.clients.claim()
    })(),
  )
})

/* The page asks the waiting worker to take over ("Refresh" in the update
 * toast). The following controllerchange triggers the page reload. */
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting()
})

self.addEventListener('fetch', (event) => {
  const request = event.request
  const url = new URL(request.url)

  // Only same-origin requests.
  if (url.origin !== self.location.origin) return
  // API traffic is never intercepted (see header note).
  if (url.pathname.startsWith('/api/')) return
  // Only GET.
  if (request.method !== 'GET') return

  // Stable, never-changing assets: cache-first (safe in dev AND production).
  // /launch/ (iOS launch screens) and /shortcuts/ (launcher quick-action
  // icons) are immutable artwork, exactly like /fonts/ and /avatars/.
  if (
    url.pathname.startsWith('/fonts/') ||
    url.pathname.startsWith('/launch/') ||
    url.pathname.startsWith('/shortcuts/') ||
    url.pathname === '/sql-wasm.wasm' ||
    url.pathname === '/pdf.worker.min.mjs' ||
    STATIC_ASSETS.includes(url.pathname)
  ) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_VERSION)
        const cached = await cache.match(request)
        if (cached) return cached
        try {
          const response = await fetch(request)
          if (response.ok) cache.put(request, response.clone())
          return response
        } catch {
          return new Response('', { status: 504 })
        }
      })(),
    )
    return
  }

  // Navigations (HTML documents): network-first with offline shell fallback.
  // In development this keeps live reload working; when offline the cached
  // shell is served instead.
  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const response = await fetch(request)
          if (response.ok) {
            const cache = await caches.open(CACHE_VERSION)
            cache.put(SHELL_URL, response.clone())
          }
          return response
        } catch {
          const cache = await caches.open(CACHE_VERSION)
          const shell = await cache.match(SHELL_URL)
          if (shell) return shell
          return new Response(
            '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Offline</title></head><body style="font-family: system-ui; padding: 2rem; text-align: center;"><h1>Offline</h1><p>The app shell has not been cached yet. Connect once, then reopen offline.</p></body></html>',
            { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } },
          )
        }
      })(),
    )
    return
  }

  // Build chunks and other static files (/_next/...): network-first so a
  // development recompile is always served fresh; the cache is updated on
  // every successful fetch and serves as the offline copy. In production
  // these URLs are content-hashed, so the cached copy is always consistent.
  if (url.pathname.startsWith('/_next/') || url.pathname.startsWith('/static/')) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_VERSION)
        try {
          const response = await fetch(request)
          if (response.ok) {
            cache.put(request, response.clone())
            return response
          }
          const cached = await cache.match(request)
          return cached ?? response
        } catch {
          const cached = await cache.match(request)
          if (cached) return cached
          return new Response('', { status: 504 })
        }
      })(),
    )
  }
})
