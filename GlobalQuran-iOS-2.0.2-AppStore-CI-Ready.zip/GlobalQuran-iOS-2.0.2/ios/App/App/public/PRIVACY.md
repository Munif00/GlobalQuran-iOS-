# Global Quran - Privacy Policy

_Last updated with application version 1.6.0._

## Summary

Global Quran works without an account, without tracking, and without
analytics. Downloaded content and all preferences stay on your device. When
you use the app online, it requests data from the application server (or,
in the installed app, from the documented public services it proxies to) -
and nothing else. The app contains no cookies, no advertising, and no
analytics of any kind.

## What stays on your device only

The following are stored in your browser's local storage (IndexedDB and
localStorage) - or, in the installed Android app, in the app's private
storage - and are **never transmitted to the application server or any
third party** as stored data:

- Downloaded Quran translation files (SQLite/PDF/EPUB) and files you import.
- Downloaded Quran recitation audio, translation narration audio, and Adhan
  recordings (verified locally before use).
- Reading position, bookmarks (with notes), and reader preferences.
- Interface language choice and detected device language.
- Prayer settings: chosen location (city or coordinates), calculation
  method, madhhab, high-latitude rule, and per-prayer minute adjustments.
- Saved locations and the active location.
- Adhan reminder preferences (selected muezzin, volume, quiet hours) and the
  reminder schedule itself.
- Download queue state.
- The administrator token (sessionStorage, this tab only) if you use the
  verification management tool.

In the installed Android app, the reminder schedule (prayer times, the
selected Adhan assignment, and localized reminder texts) is also kept in
the app's private storage so reminders fire through Android's alarm system
even when the app is closed. Clearing the app's storage or uninstalling the
app deletes all of the above. There is no server-side copy, because there
is no account system.

## Notifications

If you explicitly enable prayer/Adhan reminders, the app (on Android) shows
local notifications at prayer time. Notification permission is requested
only in response to that action. Reminders use Android's alarm-clock
scheduling and need no special access; the schedule survives reboots and
clock changes. No push service is used - nothing is sent anywhere to
deliver a reminder.

## What your app sends to the application server (online use)

When the app is used online, it requests data from the application server
(same origin) - in the installed app these requests are made directly to
the documented public services listed below, with the same data:

- **Quran text and translation catalog**: requests name the translation and
  surah; no user identifier is attached.
- **Quran and translation downloads**: requests name the translation
  (QuranEnc download host) or the audio style/reciter (EveryAyah) or the
  narration set (QuranEnc audio dashboard).
- **Adhan recordings**: downloaded from AlAdhan's public audio CDN
  (cdn.aladhan.com) with no user data attached.
- **Prayer times**: requests carry the location you chose (coordinates for
  the location you selected, or your device location if you granted
  permission), the calculation settings, and the date. Coordinates are used
  to compute or fetch prayer times and are not stored in a profile.
- **Qibla**: the bearing is computed **on your device** from your
  coordinates. Nothing is uploaded for the Qibla feature.
- **Exports**: requesting a full-translation export tells the server which
  translation to generate; no user data is included.

## Location and sensor permissions

- Location is requested **only** when you explicitly use a feature that
  needs it (Prayer Times "use my location", Qibla "request location").
  Permission can be denied; every feature offers manual city selection as
  an alternative.
- Precise location is **never** sent to unrelated services. It is used only
  for the prayer-times request you made; on the web it is cached only as
  part of the anonymous prayer-times cache entry (keyed by rounded
  coordinates and settings), never linked to an identity.
- The Qibla compass uses device orientation sensors. Sensor data is
  processed on-device only.

## External services the application calls

The application server (or, in the installed app, the app itself) contacts
these public, key-less services on your behalf, and only with the data
needed for the request:

| Service | Purpose | Data sent |
|---|---|---|
| QuranEnc API (quranenc.com) | Quran text, translations, catalog, translation narration audio | Translation key, surah number, language code |
| QuranEnc download host | Offline translation packs / files | Translation key and file id |
| EveryAyah (everyayah.com) | Quran recitation audio (verified styles) | Reciter style id, surah/ayah numbers |
| AlAdhan API (aladhan.com) | Prayer times (fallback tier), Adhan recordings (cdn.aladhan.com) | Coordinates of the selected location, method, date |
| JAKIM e-Solat (Malaysia) | Official Malaysian times | JAKIM zone code, year |
| Nominatim / BigDataCloud | City search / reverse geocoding | The search text, or the coordinates you asked to reverse-geocode |

These providers have their own privacy policies. No account data exists to
share with them, because the app has no accounts. No API keys exist for any
of these services and none are embedded in the app.

## What the server logs and keeps (web version)

- A local SQLite database caches: the translation catalog (with a content
  hash), administrator-entered verification records, and prayer-time
  payloads (keyed by rounded coordinates + settings + date). These caches
  contain no personal identifiers.
- Server logs contain standard request lines and error messages (truncated).
  Query logging is enabled in development only.

## Cookies, analytics, advertising

None. The app sets no cookies, includes no analytics, no trackers, and no
advertising. Quran text is never displayed next to ads.

## Children and content

The app contains no age-restricted content and collects no personal data
from anyone, including children.

## Deleting your data

- Device data: clear this site's storage in your browser settings, or the
  app's storage in Android settings, or use the app's Settings -> Reset.
- Server-side caches: they are anonymous and expire; a server operator can
  clear the SQLite file at any time.

## Contact

This application is self-hosted. Direct privacy questions to the operator of
the instance you use.
