# Global Quran — iOS Build & Installation Guide

This document explains exactly how to build and run the native iOS app
(Global Quran 2.0.2, versionCode 9 — matching Android 2.0.2) from this
repository, and exactly what each step requires.

## What is in this repository

```
ios/
├── App/
│   ├── App/                       # the Xcode application target
│   │   ├── Info.plist             # permissions, background modes, orientation
│   │   ├── PrivacyInfo.xcprivacy # Apple privacy manifest (honest declarations)
│   │   ├── AppDelegate.swift / SceneDelegate.swift   # Capacitor template
│   │   ├── Assets.xcassets/       # App icon (1024, original 2.0.x brand) + splash
│   │   └── public/                # the static web bundle (generated — do not edit)
│   ├── AppTests/                  # XCTest unit-test target (CapAppTests)
│   ├── App.xcodeproj/             # Xcode project (App + CapAppTests targets)
│   └── CapApp-SPM/                # Swift Package hosting Capacitor + the 4 custom
│       └── Sources/CapApp-SPM/plugins/
│           ├── AdhanModels.swift              # shared Adhan data layer (pure logic)
│           ├── AdhanSchedulerPlugin.swift     # prayer reminders (UNUserNotificationCenter)
│           ├── DeviceBridgePlugin.swift       # location service/permission states
│           ├── TtsBridgePlugin.swift          # translation narration (AVSpeechSynthesizer)
│           └── AudioSessionBridgePlugin.swift # background audio session control
```

The app is the same Global Quran web core (Next.js 16 static export)
that ships inside Android 2.0.2, served from the WKWebView through
Capacitor 8, with four Swift plugins providing the iOS-native
integrations that a WebView cannot perform.

## Prerequisites (all of them mandatory)

| Requirement | Why |
|---|---|
| A Mac with macOS 14+ | Xcode runs only on macOS. **This cannot be replaced or simulated on Linux/Windows.** |
| Xcode 16+ (with iOS 17/18/26 SDK) | Builds the project, runs the iOS Simulator, signs archives. |
| An Apple ID (free) | Personal Team signing for running on your own device. |
| Apple Developer Program membership (paid, $99/yr) | Only for App Store distribution / TestFlight / unlimited provisioning. Not needed to run on your own device with a free team. |
| CocoaPods | NOT required — this project uses Swift Package Manager (Capacitor 8 default). |
| Node.js 20+/Bun, the repo's node_modules | `bun install` in the repository root first. |

> Signing reality: no Apple Development certificate, provisioning
> profile, or Developer account exists in this repository, and none was
> invented. The project uses **Automatic signing** (`CODE_SIGN_STYLE =
> Automatic`); you select your own Team in Xcode.

## Step-by-step build

All commands run from the **repository root** (`/path/to/my-project`),
unless noted.

1. **Install JS dependencies** (once):

   ```bash
   bun install
   ```

2. **Build the shared web bundle** (the same bundle Android ships):

   ```bash
   bun run scripts/build-native.mjs
   ```

   This runs the Next.js static export into `native/www` (staging the
   API routes aside and restoring them afterwards — the native adapter
   in `src/services/native/` replaces the server inside the app).

3. **Sync the iOS platform** (copies the bundle + wires the plugins):

   ```bash
   bun run sync:ios
   ```

   > Always use `bun run sync:ios` — never raw `npx cap sync ios`.
   > The wrapper re-appends the four custom plugin classes to
   > `ios/App/App/capacitor.config.json`'s `packageClassList`, which the
   > Capacitor CLI regenerates (and truncates) on every raw sync.

4. **Open the project in Xcode**:

   ```bash
   open ios/App/App.xcodeproj
   ```

5. **Select your signing team**:
   - Select the **App** target → **Signing & Capabilities**.
   - Check *Automatically manage signing*.
   - Select your Team (a free Personal Team works for your own device).
   - Do the same for the **CapAppTests** target if you will run tests.

6. **Run**:
   - **Simulator**: pick an iPhone simulator (iOS 15+ supported;
     iPhone 15/16 recommended) and press Cmd+R.
   - **Physical device**: connect the iPhone/iPad, enable Developer
     Mode (Settings → Privacy & Security), select it as the run
     destination, press Cmd+R, and trust the developer certificate in
     Settings → General → VPN & Device Management on first run.

7. **Run the unit tests**:

   ```bash
   cd ios/App
   xcodebuild test -project App.xcodeproj -scheme App \
     -destination 'platform=iOS Simulator,name=iPhone 15'
   ```

   or press Cmd+U in Xcode. The `CapAppTests` target verifies the
   Adhan data layer (event parsing, quiet hours, sanitizer, store
   codec, notification texts), TTS rate/pitch/alias mapping, chunker,
   and the location permission mapping.

8. **Archive for distribution** (App Store / TestFlight / Ad Hoc):

   ```bash
   cd ios/App
   xcodebuild archive -project App.xcodeproj -scheme App \
     -configuration Release -archivePath build/App.xcarchive \
     DEVELOPMENT_TEAM=<YOUR_TEAM_ID>
   ```

   then export the IPA from the archive in Xcode's Organizer (or with
   `xcodebuild -exportArchive`), choosing:
   - **App Store Connect** distribution for the App Store,
   - **Ad Hoc** for direct distribution to registered devices,
   - **Development** for testing.

   An Apple Distribution certificate and a provisioning profile with
   the `com.globalquran.app` bundle identifier are required at this
   step (created automatically by Xcode when your team is set).

## Version and identity

| Setting | Value |
|---|---|
| Bundle identifier | `com.globalquran.app` (same identity as Android) |
| Display name | Global Quran |
| Marketing version (CFBundleShortVersionString) | 2.0.2 |
| Build number (CFBundleVersion) | 9 |
| Minimum iOS | 15.0 |
| Devices | iPhone + iPad (all four orientations on iPad) |
| App icon | the original 2.0.x brand icon (generated from `native-assets/icon.png`, the same source as Android — never changed) |

## Updating the app after web changes

```bash
bun run scripts/build-native.mjs && bun run sync:ios
```

Xcode picks up the new `App/App/public` contents on the next build
(the folder is a synced resource).

## Troubleshooting

- **"Unimplemented" from a native plugin on simulator/device** — the
  packageClassList patch was skipped: re-run `bun run sync:ios` (never
  raw `npx cap sync ios`).
- **No reminders fire** — check Settings → Notifications → Global
  Quran (permission + sounds), and remember the honest iOS limits in
  `IOS-PLATFORM-DIFFERENCES.md` (force-quit stops delivery until the
  app is opened again).
- **Qibla compass asks for Motion & Fitness permission** — expected on
  iOS 13+; the app requests it from the compass start button (a user
  gesture, as iOS requires).
- **TTS narration says the language is unavailable** — the device has
  no installed voice for that translation's language (Settings →
  Accessibility → Spoken Content → Voices); the app reports this
  honestly and never falls back to reciting Arabic.
