# Global Quran — iOS Platform Differences (vs Android 2.0.2)

Every difference below is imposed by iOS. None was invented, and none
is hidden from the user: the in-app UI states the honest behavior
wherever it affects what the user experiences.

## 1. Adhan reminders while the app is closed

**Android 2.0.2:** `AlarmManager.setAlarmClock` (exact, Doze-proof)
fires; a foreground `MediaPlayer` service plays the full Adhan
recording (~2 minutes) at the user's volume on the ALARM stream —
audible even in silent mode, independent of notification muting.

**iOS 2.0.2:** local notifications (`UNUserNotificationCenter`) are the
closest reliable equivalent. Differences:

| Aspect | Android | iOS | Why |
|---|---|---|---|
| Background full Adhan | Yes (foreground service) | **No** — notification sound only | iOS does not allow an app to start audio playback from a local notification. Custom notification sounds are capped by the system at 30 seconds; longer files fall back to the default sound. The app attaches the mirrored recording only when its **measured** duration is ≤ 30 s (measured with AVAudioFile at mirror time — never guessed), otherwise the default sound. |
| Silent Mode / Focus | Adhan plays (alarm stream) | **Notification sound respects system settings** | Only Apple-approved Critical Alerts (a special entitlement, granted case-by-case) may interrupt Silent Mode/Focus. The app does not claim that capability. Applying for it is a documented future option. |
| Exactness | `setAlarmClock` = always exact | Notifications are generally on time but not alarm-grade (Low Power Mode can defer) | iOS has no exact-alarm API for local notifications. `status.exact` reports `false` and the UI's "exact" label is hidden on iOS. |
| After force-quit | Alarms still fire (system-managed) | **Delivery stops until the app is opened again** | iOS suspends notification delivery to force-quit apps by design. Re-opening the app re-arms the schedule. |
| Scheduling window | 3 rolling alarms, re-armed on every fire (no app needed) | 60 pending notifications (~12 days of 5 daily slots), re-armed on every sync, app activation, notification presentation, and tap | iOS caps pending local notifications at 64. A local notification cannot execute code on delivery, so re-arming requires app activity. |
| Foreground (app open) | `foregroundFire` event → full Adhan through the app | **Identical** `foregroundFire` flow → full Adhan through the **native** player (see §2) | Parity preserved |

**In-app honesty:** the reminder sheet shows a platform-specific note
in all 80 languages. Android keeps the alarm-output note; iOS shows:
"On iPhone and iPad the reminder arrives as a notification. While the
app is open, the full Adhan plays at your chosen volume. When the app
is closed, iOS plays a short notification sound (system limit) and
respects Silent Mode and Focus; after you force-quit the app,
reminders resume when it is opened again."

## 2. Adhan volume control

**Android:** the foreground Adhan plays through the WebView's audio
element; `audio.volume` works.

**iOS:** WKWebView exposes `audio.volume` as a read-only no-op. The
foreground Adhan therefore plays through the native plugin
(`AVAudioPlayer`) with real per-stream volume — the slider works
exactly as on Android while the app is open. For a scheduled
notification while the app is in the background, iOS exposes no
per-notification volume API; the system controls the notification
sound level using the device's notification settings. The web player
remains as an honest fallback (for example if the native mirror is
missing), accepting its volume limitation.

## 3. Location settings deep-link

**Android:** `DeviceBridge.openLocationSettings` opens the system
location-settings screen (needed when the system-wide location service
is off).

**iOS:** iOS offers exactly one public deep-link:
`UIApplication.openSettingsURLString` → **this app's** settings page
(where the app's location permission lives). There is no public URL
for Settings → Privacy → Location Services. The same UX flow (detect
service-off state → open settings → return to the app → re-check and
auto-locate) works with the app's settings page as the destination.

## 4. Text-to-speech

**Android:** system TTS engines (`android.speech.tts`), per-language
downloadable data, engine selection, TTS settings screen.

**iOS:** one built-in engine (`AVSpeechSynthesizer`). Differences:

- `getStatus().engine` reports the built-in engine (no engine list).
- The Android states "missing-data" (downloadable language data) do
  not exist on iOS: a language either has an installed voice or it
  does not (`not-supported`).
- `openTtsSettings()` returns `{ opened: false }` honestly — iOS has
  no TTS settings screen for third-party apps and no deep-link to
  voice management. (Users manage voices in Settings → Accessibility →
  Spoken Content.)
- `pauseSupported()` remains `{ supported: false }` — not because
  AVSpeechSynthesizer cannot pause (it can), but because the shared
  bridge contract exposes no pause/resume methods; claiming support
  would be dishonest.

Identical: voice listing with the shared alias table, explicit voice
selection, rate/pitch mapping (Web Speech scale → AVSpeech scale),
3500-char whitespace chunking, resolve-on-start semantics, `done` /
`error` utterance events, QUEUE_FLUSH behavior, and the absolute rule
that **TTS never recites Arabic Quranic text** (translation meanings
only).

## 5. Hardware Back button

**Android:** the hardware Back controller (dialog dismissal → in-app
history → deep-link return home → double-back exit).

**iOS:** no hardware Back. Equivalent behaviors: the iOS
edge-swipe-back gesture (works on the hash-history navigation), the
on-screen back controls in every screen, and the exact same in-app
navigation logic. Nothing was removed from Android.

## 6. Background audio (recitation/narration)

**Android:** WebView media continues in the background.

**iOS:** requires (a) the `audio` UIBackgroundModes entry — added to
Info.plist — and (b) an active `.playback` AVAudioSession — the
AudioSessionBridge plugin activates it whenever WebView playback
starts and deactivates it on full stop. This is the standard iOS
configuration; it still **requires on-device verification** (documented
as such everywhere a claim would otherwise appear). `.playback` also
means recitation is audible with the Ring/Silent switch in silent —
matching Android's media-stream behavior.

## 7. Notification channels

**Android:** per-recording notification channels with per-recording
sounds (`adhan-<id>`), a default `prayer-reminders` channel, and a
silent `adhan-playback` foreground-service channel.

**iOS:** no channel concept. The mapping: notification categories are
the same content (title + slot-specific body), sounds are attached per
notification (default sound, or the mirrored recording when its
measured duration fits the 30-second limit), and tap always opens the
app. There is no foreground-service notification on iOS — the
foreground Adhan is the in-app banner instead (identical to Android's
foreground path).

## 8. Boot persistence

**Android:** `BOOT_COMPLETED` / `TIME_SET` / `TIMEZONE_CHANGED`
receiver re-arms the alarm window without opening the app.

**iOS:** not possible — no equivalent lifecycle event exists for local
notification re-arming. The window is instead re-armed on every app
activation (and each sync/notification presentation/tap), which keeps
roughly 12 days of reminders armed at all times.

## 9. App installation and updates

**Android:** direct APK sideloading (delivered in
`public/downloads/`), forced uninstall between signature changes.

**iOS:** installation only through Xcode (development), TestFlight, or
the App Store. The project is Archive-ready with Automatic signing;
**no Apple Developer credentials exist in this repository and none
were invented** — the team must be selected on the build Mac.
