import type { CapacitorConfig } from '@capacitor/cli'

/**
 * Global Quran - Capacitor configuration.
 *
 * The native app ships the static export of the web app (native/www,
 * produced by scripts/build-native.mjs) inside a thin native shell:
 * - androidScheme 'https': the WebView is served from https://localhost so
 *   the app is a secure context (geolocation, WebCrypto, service worker)
 *   exactly like the deployed web app.
 * - No CapacitorHttp global fetch patching: the native adapter
 *   (src/services/native/http.ts) calls CapacitorHttp explicitly for the
 *   two cases that need it (the CORS-less QuranEnc download host and the
 *   Nominatim User-Agent policy); everything else uses the WebView's own
 *   fetch against CORS-open documented APIs.
 * - Geolocation and device-orientation sensors work through the WebView's
 *   standard APIs (permissions are declared in the Android manifest).
 */
const config: CapacitorConfig = {
  appId: 'com.globalquran.app',
  appName: 'Global Quran',
  webDir: 'native/www',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
  },
  ios: {
    contentInset: 'always',
  },
}

export default config
