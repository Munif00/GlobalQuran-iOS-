# Global Quran — iOS Source Project (2.0.2, build 9)

Complete, self-contained source archive of the native iOS application
**Global Quran 2.0.2** (versionCode/build 9) — feature-matched to the
Android 2.0.2 release. See `ios/IOS-FEATURE-PARITY.md` for the full
parity matrix.

## What this archive contains

```
GlobalQuran-iOS-2.0.2/
├── ios/                                # COMPLETE native iOS project
│   ├── App/
│   │   ├── App.xcodeproj/              # Xcode project (App + CapAppTests schemes)
│   │   ├── App/                        # application target
│   │   │   ├── AppDelegate.swift / SceneDelegate.swift
│   │   │   ├── Info.plist              # permissions, background modes, orientation
│   │   │   ├── PrivacyInfo.xcprivacy   # Apple privacy manifest
│   │   │   ├── Assets.xcassets/        # app icon (1024) + splash imageset
│   │   │   ├── Base.lproj/             # LaunchScreen + Main storyboards
│   │   │   ├── capacitor.config.json   # generated + PATCHED packageClassList
│   │   │   ├── config.xml              # generated Cordova compatibility config
│   │   │   └── public/                 # GENERATED web bundle (synced — do not edit)
│   │   ├── AppTests/                   # XCTest target (CapAppTests, 5 suites)
│   │   └── CapApp-SPM/                 # Swift Package: Capacitor + 4 custom plugins
│   │       └── Sources/CapApp-SPM/plugins/
│   │           ├── AdhanModels.swift              # shared Adhan data layer
│   │           ├── AdhanSchedulerPlugin.swift     # prayer reminders (UNUserNotificationCenter)
│   │           ├── DeviceBridgePlugin.swift       # location service/permission states
│   │           ├── TtsBridgePlugin.swift          # translation narration (AVSpeechSynthesizer)
│   │           └── AudioSessionBridgePlugin.swift # background audio session control
│   ├── capacitor-cordova-ios-plugins/  # generated Cordova compatibility scaffold
│   ├── debug.xcconfig
│   ├── .gitignore
│   ├── IOS-BUILD.md                    # ← START HERE (build & install guide)
│   ├── IOS-FEATURE-PARITY.md           # Android 2.0.2 parity matrix
│   ├── IOS-PLATFORM-DIFFERENCES.md     # honest iOS-vs-Android differences
│   └── IOS-TEST-PLAN.md                # XCTest + manual test plan
├── native/www/                         # GENERATED shared web bundle (sync source)
├── native-assets/                      # brand icon/splash source PNGs (source of truth)
├── scripts/
│   ├── build-native.mjs                # builds the static web bundle → native/www
│   ├── sync-ios.mjs                    # `cap sync ios` wrapper (preserves plugin list)
│   ├── verify-ios-project.ts           # 65-check structural verifier (all passing)
│   ├── generate-native-assets.ts       # regenerates native-assets/ brand images
│   └── import-meta.d.ts                # TS support for the scripts
├── src/                                # web app source (Next.js 16 — the shared core)
├── public/                             # web app static assets
│                                       #   (public/downloads/ APK delivery folder excluded)
├── prisma/schema.prisma                # dev-server database schema
├── db/custom.db                        # dev-server seed database (SQLite)
├── package.json / bun.lock             # dependency configuration (bun install)
├── capacitor.config.ts                 # Capacitor configuration (appId, webDir, …)
├── next.config.ts / tsconfig.json / tailwind.config.ts /
│   postcss.config.mjs / components.json / eslint.config.mjs / next-env.d.ts / .gitignore
└── README.md                           # this file
```

## Version and identity

| Setting | Value |
|---|---|
| Bundle identifier | `com.globalquran.app` (same identity as Android) |
| Display name | Global Quran |
| Marketing version (CFBundleShortVersionString) | 2.0.2 |
| Build number (CFBundleVersion) | 9 |
| Minimum iOS | 15.0 |
| Devices | iPhone + iPad |
| Capacitor | 8.6.2 (Swift Package Manager — no CocoaPods needed) |

## Three ways to use this archive

### A. Build & run immediately (web bundle is already synced)

The generated web bundle is already copied into `ios/App/App/public/`
and `capacitor.config.json` already carries the full `packageClassList`
(6 entries: AppPlugin, GeolocationPlugin + the 4 custom plugins).

1. Open `ios/App/App.xcodeproj` in Xcode 16+ on macOS 14+.
2. Select your signing team (Automatic signing; a free Personal Team
   works for your own device).
3. Cmd+R on an iPhone simulator (iOS 15+) or a connected device.

No `bun install`, no sync step needed.

### B. Rebuild everything from source

Requires Node.js 20+/Bun on any OS for the web part; macOS + Xcode for
the native part.

```bash
bun install                            # restores node_modules from bun.lock
bun run scripts/build-native.mjs       # static export → native/www
bun run sync:ios                       # cap sync ios + plugin-list patch
bun run verify:ios                     # 65 structural checks (all must pass)
open ios/App/App.xcodeproj             # then build in Xcode
```

### C. Run the unit tests

```bash
cd ios/App
xcodebuild test -project App.xcodeproj -scheme App \
  -destination 'platform=iOS Simulator,name=iPhone 15'
```

The `CapAppTests` target (5 suites) verifies the Adhan data layer
(event parsing, quiet hours, sanitizer, store codec, notification
texts), TTS rate/pitch/alias mapping and chunker, and the location
permission mapping.

## Honest scope notes

- **No IPA is included.** No Apple build has been performed: iOS apps
  can only be compiled with Xcode on macOS. This archive contains the
  complete, verified, ready-to-build source project.
- **No signing material is included.** There is no Apple certificate,
  provisioning profile, or private key in this archive. The project
  uses Automatic signing; you select your own team in Xcode.
- **The Android platform is not part of this archive** (the existing
  Android 2.0.2 APK/AAB artifacts are untouched and shipped separately).
- **Excluded by design:** `node_modules/` (restored by `bun install`),
  `.next*` build caches, `.git/`, the Android platform folder, the
  web-only APK delivery folder `public/downloads/`, local-only `.env`,
  and all signing/secrets directories.
- `db/custom.db` + `prisma/` + `src/app/api/` exist for the dev web
  server only; the native app ships the static export and replaces the
  API routes with the client-side adapter in `src/services/native/`.

## Documentation index

| Document | Contents |
|---|---|
| `ios/IOS-BUILD.md` | Prerequisites, step-by-step build, signing, archiving |
| `ios/IOS-FEATURE-PARITY.md` | Feature-by-feature parity with Android 2.0.2 |
| `ios/IOS-PLATFORM-DIFFERENCES.md` | Honest platform differences and their reasons |
| `ios/IOS-TEST-PLAN.md` | XCTest suites + manual on-device test plan |

## Verification performed on this archive's source tree

`bun run verify:ios` — **65/65 checks passed**:
Xcode project structure and targets, Info.plist permissions and
background modes, privacy manifest, all four Swift plugins implement
their shared TypeScript contracts (24 methods total), asset catalogs
(1024×1024 icon, splash imageset), web bundle present in both
`native/www` and `ios/App/App/public`, Capacitor config with the full
`packageClassList`, test scheme wiring, and Android-untouched gates.
